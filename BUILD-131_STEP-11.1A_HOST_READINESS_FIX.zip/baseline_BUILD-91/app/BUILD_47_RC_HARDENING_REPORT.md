# BUILD 47 — RC Hardening & Full System Gate

## Mục tiêu
Đóng băng kiến trúc sau BUILD-46 và chuyển từ phát triển tính năng sang kiểm định RC. BUILD-47 không mở thêm nghiệp vụ người dùng.

## Đã khóa
- Full-system contract gate cho BUILD-40 → BUILD-47.
- PHP syntax gate cho backend runtime/test/bin/public.
- Production artifact hygiene: không đóng gói `env.production` thật.
- Frontend production build contract.
- PHP production hardening và Nginx production hardening hiện có được đưa vào gate.
- Queue, auto-recovery, Discovery reconciliation và Operations/Exception Center phải hiện diện trước RC.
- RC checklist và runbook tách rõ artifact gate với runtime/staging gate.

## Nguyên tắc RC
BUILD-47 chỉ tuyên bố **artifact/static gate PASS** khi kiểm tra trong repository đạt. Không tuyên bố production-ready hoặc RC1-ready nếu chưa có staging evidence cho E2E, load/stress, backup/restore và recovery drills.

## Lệnh kiểm định
`ops/release/rc-full-system-gate.sh`

## RC1 runtime bắt buộc
- staging migrations
- worker/queue health
- event → queue → quality gate → projection E2E
- reconciliation/self-healing drill
- Exception Center escalation drill
- identity onboarding E2E
- password recovery delivery
- abuse/rate-limit verification
- backup/restore + disaster recovery
- load/stress evidence
- public job/SEO verification

## Kết luận
BUILD-47 là **RC Hardening Gate**, không phải tuyên bố Production Ready. Chỉ sau khi runtime checklist có bằng chứng staging thật mới được khóa RC1.
