# PR06 — Feed Scale Contract

Public Feed remains viewable without login. Public pagination uses a numeric `id` cursor. Authenticated Feed may use a personalized `{f,id}` cursor. Interaction still requires authentication.

## Acceptance
- Public requests remain anonymous.
- Public ordering uses `s.id DESC`.
- Cursor values are stable numeric IDs.
- Authenticated feed may include follow priority without changing the public contract.
