<?php
declare(strict_types=1);
$root=__DIR__;
$files=['backend/src/Services/ContentDiscoveryAdminOverrideService.php','backend/src/Controllers/ContentDiscoveryAdminOverrideController.php','database/86_BUILD_20_CONTENT_DISCOVERY_ADMIN_OVERRIDE.sql','BUILD_20_CONTENT_DISCOVERY_ADMIN_OVERRIDE.md'];
foreach($files as $f){ if(!is_file($root.'/'.$f)) throw new RuntimeException("Missing $f"); }
$auth=file_get_contents($root.'/backend/src/Core/AdminAuth.php');
foreach(['content.discovery.override.view','content.discovery.override.manage'] as $p){ if(strpos($auth,$p)===false) throw new RuntimeException("Missing permission $p"); }
$idx=file_get_contents($root.'/backend/public/index.php');
if(strpos($idx,'ContentDiscoveryAdminOverrideController')===false || strpos($idx,'/api/admin/content-discovery/jobs/')===false) throw new RuntimeException('Missing route/controller wiring');
echo "BUILD-20 CONTRACT: PASS\n";
