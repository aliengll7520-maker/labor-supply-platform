<?php
declare(strict_types=1);
$root=__DIR__;
$files=[
 $root.'/backend/src/Services/ContentDiscoveryOrchestratorService.php',
 $root.'/backend/src/Controllers/ContentDiscoveryOrchestratorController.php',
 $root.'/BUILD_21_SYSTEM_ORCHESTRATOR.md',
];
foreach($files as $f){ if(!is_file($f)) throw new RuntimeException('Missing: '.$f); }
$service=file_get_contents($files[0]);
foreach(['dispatchJob','status','content_discovery_events','content_type="job"'] as $needle){ if(strpos($service,$needle)===false) throw new RuntimeException('Missing contract: '.$needle); }
$index=file_get_contents($root.'/backend/public/index.php');
if(strpos($index,'ContentDiscoveryOrchestratorController.php')===false) throw new RuntimeException('Controller not wired');
if(strpos($index,'/api/admin/content-discovery/jobs/')===false) throw new RuntimeException('Routes not wired');
echo "BUILD-21 contract PASS\n";
