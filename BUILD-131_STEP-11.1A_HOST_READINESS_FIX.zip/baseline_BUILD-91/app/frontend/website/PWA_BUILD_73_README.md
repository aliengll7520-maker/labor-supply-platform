# BUILD 73 - PWA

Nâng cấp từ BUILD 72, bổ sung lớp PWA cho website Labor Platform.

## Thành phần
- `public/manifest.webmanifest`: khai báo ứng dụng, tên, icon, start URL và chế độ standalone.
- `public/sw.js`: service worker nền cho cache/app-shell và fallback khi mất mạng.
- `public/icons/labor-platform.svg`: icon ứng dụng.
- `src/pwa/PWAInstallPrompt.jsx`: lời mời cài ứng dụng, chỉ hiện khi trình duyệt hỗ trợ và người dùng chưa chọn "Để sau".
- `src/pwa/PWAInstallPrompt.css`: giao diện lời mời cài.
- `src/App.jsx`: đăng ký service worker và hiển thị lời mời cài trên các route.

## Nguyên tắc
- Không ép người dùng cài.
- Không thay đổi luồng nghiệp vụ tuyển dụng và đăng ký hồ sơ; PWA không mở rộng sang nghiệp vụ chấm công hoặc quản lý lao động hậu tuyển dụng.
- PWA là lớp trải nghiệm phía trên hệ thống hiện có.
- Push notification vẫn dùng hạ tầng thông báo hiện có; BUILD 73 chỉ chuẩn bị lớp cài đặt PWA và service worker.

## Lưu ý triển khai
Website phải được phục vụ qua HTTPS (localhost là ngoại lệ) để service worker/PWA hoạt động đầy đủ trên thiết bị thật.
