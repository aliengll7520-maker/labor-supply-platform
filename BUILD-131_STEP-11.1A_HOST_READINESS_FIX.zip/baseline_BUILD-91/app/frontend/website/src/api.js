const API_BASE =
  import.meta.env.VITE_API_BASE_URL || "/api";

let adminCsrfToken = null;

async function getAdminCsrfToken() {
  const response = await fetch(`${API_BASE}/admin/csrf`, { credentials: "include" });
  const data = await response.json().catch(() => null);
  if (!response.ok) throw new Error(data?.message || data?.error || "Không lấy được CSRF token");
  adminCsrfToken = data?.data?.token ?? data?.token ?? null;
  return adminCsrfToken;
}

async function request(path, options = {}) {
  const method = (options.method || "GET").toUpperCase();
  const isAdminMutation = path.startsWith("/admin/") && method !== "GET" && path !== "/admin/login" && path !== "/admin/csrf";
  if (isAdminMutation && !adminCsrfToken) await getAdminCsrfToken();
  const workerToken = localStorage.getItem("worker_access_token");
  const requestId = (globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const headers = {
    "Content-Type": "application/json",
    "X-Request-ID": requestId,
    ...(workerToken ? { Authorization: `Bearer ${workerToken}` } : {}),
    ...(options.headers || {}),
  };
  if (isAdminMutation && adminCsrfToken) headers["X-CSRF-Token"] = adminCsrfToken;
  if (["POST","PUT","PATCH"].includes(method)) headers["Idempotency-Key"] = requestId;
  const response = await fetch(
    `${API_BASE}${path}`,
    { ...options, credentials: "include", headers }
  );

  let data = null;

  try {
    data = await response.json();
  } catch (_) {
    data = null;
  }

  if (!response.ok) {
    throw new Error(
      data?.message ||
      data?.error ||
      `Yêu cầu thất bại (${response.status})`
    );
  }

  return data?.data ?? data;
}


export function bridgePostMessage({
  requestId,
  event,
  surfaceId,
  payload = {},
}) {
  if (typeof window === "undefined" || typeof window.postMessage !== "function") {
    return false;
  }

  window.postMessage(
    {
      protocolVersion: "1.0",
      requestId,
      event,
      surfaceId,
      payload,
    },
    window.location.origin
  );

  return true;
}

export const api = {
  get(path) {
    return request(path, {
      method: "GET",
    });
  },

  post(path, body = {}) {
    return request(path, {
      method: "POST",
      body: JSON.stringify(body),
    });
  },

  put(path, body = {}) {
    return request(path, {
      method: "PUT",
      body: JSON.stringify(body),
    });
  },

  patch(path, body = {}) {
    return request(path, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
  },

  delete(path) {
    return request(path, {
      method: "DELETE",
    });
  },
};

export function bridgeSubscribe(callback) {
  if (typeof window === "undefined") return () => {};

  const handler = (event) => {
    const data = event?.data;
    if (!data || data.event !== "platform.surface.callback") return;
    callback(data);
  };

  window.addEventListener("message", handler);
  return () => window.removeEventListener("message", handler);
}
