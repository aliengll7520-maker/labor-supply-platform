import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import {api} from "../../api";
import "./Profile.css";

function Profile(){
 const [profile,setProfile]=useState(null),[error,setError]=useState(""),[loading,setLoading]=useState(true);
 useEffect(()=>{(async()=>{try{setProfile(await api.get("/worker/profile"));}catch(e){setError(e.message||"Không thể tải hồ sơ.");}finally{setLoading(false);}})();},[]);
 return <MainLayout><div className="profile"><h1 className="profile-title">Thông tin của tôi</h1><Card>{loading&&<p>Đang tải hồ sơ...</p>}{error&&<p>{error}</p>}{profile&&<><p><strong>Họ và tên:</strong> {profile.ho_ten||"Chưa cập nhật"}</p><p><strong>Số điện thoại:</strong> {profile.so_dien_thoai||"Chưa cập nhật"}</p><p><strong>Quê quán:</strong> {profile.que_quan||"Chưa cập nhật"}</p></>}</Card></div></MainLayout>;
}
export default Profile;
