import React, { useState } from "react";
import Card from "../components/Card/Card";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";
import { api } from "../api";
import "./Login.css";

function Login() {
  const [soDienThoai, setSoDienThoai] = useState("");
  const [matKhau, setMatKhau] = useState("");

  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [googleBusy, setGoogleBusy] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    if (!soDienThoai.trim() || !matKhau.trim()) {
      setError("Vui lòng nhập số điện thoại và mật khẩu.");
      return;
    }
    try {
      setBusy(true);
      const result = await api.post("/auth/login", {
        identifier: soDienThoai.trim(),
        password: matKhau,
      });
      if (result?.token) localStorage.setItem("worker_access_token", result.token);
      if (result?.user) localStorage.setItem("worker_user", JSON.stringify(result.user));
      window.location.hash = "#/dashboard";
    } catch (e) {
      setError(e.message || "Đăng nhập không thành công.");
    } finally {
      setBusy(false);
    }
  };

  const handleGoogleLogin = () => {
    setGoogleBusy(true);
    window.location.href = "/api/auth/google/start";
  };

  const handleRegister = () => {
    window.location.hash = "#/worker-register";
  };

  return (
    <div className="login-page">

      <Card>
        {error && <div className="login-error">{error}</div>}

        <div className="login-header">
          <h1>Đăng nhập</h1>

          <p>
            Đăng nhập vào nền tảng
          </p>
        </div>

        <form onSubmit={handleSubmit}>

          <Input
            type="tel"
            placeholder="Số điện thoại"
            value={soDienThoai}
            onChange={(event) =>
              setSoDienThoai(event.target.value)
            }
          />

          <div className="space"></div>

          <Input
            type="password"
            placeholder="Mật khẩu"
            value={matKhau}
            onChange={(event) =>
              setMatKhau(event.target.value)
            }
          />

          <div className="space"></div>

          <Button
            text={busy ? "ĐANG ĐĂNG NHẬP..." : "ĐĂNG NHẬP"}
            type="submit"
          />

        </form>

        <div className="login-divider"><span>HOẶC</span></div>

        <button
          type="button"
          className="google-login-button"
          onClick={handleGoogleLogin}
          disabled={busy || googleBusy}
        >
          {googleBusy ? "ĐANG MỞ GOOGLE..." : "ĐĂNG NHẬP BẰNG GOOGLE"}
        </button>

        <p className="login-note">
          Bạn có thể dùng số điện thoại hoặc tài khoản Google. Hai phương thức có thể được liên kết vào cùng một tài khoản Người lao động.
        </p>

        <div className="login-register">

          <p>
            Chưa có tài khoản Người lao động?
          </p>

          <Button
            text="ĐĂNG KÝ"
            onClick={handleRegister}
          />

        </div>

        <div className="login-employer-option">
          <strong>Bạn cũng có doanh nghiệp?</strong>
          <p>Bạn có thể đăng ký không gian Đơn vị sử dụng lao động riêng để đăng việc và tạo nội dung.</p>
          <a href="#/supplier-register">ĐĂNG KÝ DOANH NGHIỆP →</a>
        </div>

      </Card>

    </div>
  );
}

export default Login;
