import React,{useState} from 'react';
import {api} from '../../api';
import '../Employer/EmployerPortal.css';

export function SupplierLogin(){
 const [login,setLogin]=useState(''),
 [matKhau,setMatKhau]=useState(''),
 [error,setError]=useState('');

 const submit=async e=>{
   e.preventDefault();
   setError('');
   if(!accepted){setError('Vui lòng đọc và xác nhận Điều khoản sử dụng, Chính sách bảo vệ dữ liệu và Chính sách về tiền và giao dịch riêng.');return;}

   try{
     await api.post('/supplier/login',{
       login,
       mat_khau:matKhau
     });

     window.location.hash='#/supplier';

   }catch(e){
     setError(e.message);
   }
 };

 return <div className="supplier-portal">
   <div
     className="sp-card"
     style={{maxWidth:480,margin:'50px auto'}}
   >
     <h1>Đăng nhập Đơn vị sử dụng lao động</h1>

     {error&&
       <div className="sp-alert">
         {error}
       </div>
     }

     <form onSubmit={submit}>

       <label className="sp-field">
         <span>Email / SĐT / Mã tài khoản</span>

         <input
           value={login}
           onChange={e=>setLogin(e.target.value)}
           required
         />
       </label>

       <label className="sp-field">
         <span>Mật khẩu</span>

         <input
           type="password"
           value={matKhau}
           onChange={e=>setMatKhau(e.target.value)}
           required
         />
       </label>

       <button className="sp-btn">
         Đăng nhập
       </button>

     </form>

     <p>
       <a href="#/supplier-register">
         Đăng ký Đơn vị sử dụng lao động
       </a>
     </p>

   </div>
 </div>
}

export function SupplierRegister(){

 const [form,setForm]=useState({
   loai_don_vi:'doanh_nghiep',
   ten_don_vi:'',
   ma_so_thue:'',
   nguoi_dai_dien:'',
   so_dien_thoai:'',
   email:'',
   dia_chi:'',
   mat_khau:''
 });

 const [error,setError]=useState('');
 const [result,setResult]=useState(null);
 const [accepted,setAccepted]=useState(false);

 const set=(n,v)=>
   setForm(x=>({...x,[n]:v}));

 const submit=async e=>{
   e.preventDefault();
   setError('');
   if(!accepted){setError('Vui lòng đọc và xác nhận Điều khoản sử dụng, Chính sách bảo vệ dữ liệu và Chính sách về tiền và giao dịch riêng.');return;}

   try{
     const data=await api.post(
       '/supplier/register',
       form
     );

     setResult(data);

   }catch(e){
     setError(e.message);
   }
 };

 if(result)
   return <div className="supplier-portal">
     <div
       className="sp-card"
       style={{maxWidth:620,margin:'50px auto'}}
     >

       <h1>Đăng ký thành công</h1>

       <p>
         Đơn vị sử dụng lao động{" "}
         <b>{result.ma_nha_cung_ung}</b>{" "}
         đã được tạo.
       </p>

       <p>
         Trạng thái hiện tại:{" "}
         <b>Chờ duyệt</b>.
       </p>

       <p>
         Hãy đăng nhập sau khi hồ sơ được
         Quản trị viên xác minh và kích hoạt.
       </p>

       <button
         className="sp-btn"
         onClick={()=>
           window.location.hash='#/supplier-login'
         }
       >
         Đến đăng nhập
       </button>

     </div>
   </div>;

 return <div className="supplier-portal">
   <div
     className="sp-card"
     style={{maxWidth:620,margin:'30px auto'}}
   >

     <h1>Đăng ký Đơn vị sử dụng lao động</h1>

     <p><b>Miễn phí sử dụng · Không thu phí đăng việc.</b></p>

     <p>
       Doanh nghiệp sẽ được xác thực Mã số thuế tự động trước khi tài khoản được kích hoạt.
     </p>

     {error&&
       <div className="sp-alert">
         {error}
       </div>
     }

     <form onSubmit={submit}>

       <label className="sp-field">
         <span>Loại đơn vị sử dụng lao động</span>
         <select value={form.loai_don_vi} onChange={e=>set('loai_don_vi',e.target.value)}>
           <option value="doanh_nghiep">Doanh nghiệp</option>
           <option value="ho_kinh_doanh">Hộ kinh doanh</option>
           <option value="hop_tac_xa">Hợp tác xã</option>
           <option value="to_chuc">Tổ chức</option>
           <option value="ca_nhan">Cá nhân sử dụng lao động</option>
         </select>
       </label>

       {[
         'ten_don_vi',
         'ma_so_thue',
         'nguoi_dai_dien',
         'so_dien_thoai',
         'email',
         'dia_chi',
         'mat_khau'
       ].map(f=>
         <label
           className="sp-field"
           key={f}
         >

           <span>
             {({'ten_don_vi':'Tên đơn vị sử dụng lao động','ma_so_thue':'Mã số thuế (được xác thực tự động)','nguoi_dai_dien':'Người đại diện','so_dien_thoai':'Số điện thoại','email':'Email','dia_chi':'Địa chỉ','mat_khau':'Mật khẩu'})[f]}
           </span>

           <input
             type={
               f==='mat_khau'
                 ?'password'
                 :'text'
             }
             value={form[f]}
             onChange={e=>
               set(f,e.target.value)
             }
             required={
               [
                 'ten_don_vi',
                 'nguoi_dai_dien',
                 'so_dien_thoai',
                 'mat_khau'
               ].includes(f)
             }
           />

         </label>
       )}

       <label className="sp-field" style={{display:"flex",gap:8,alignItems:"flex-start"}}>
         <input type="checkbox" checked={accepted} onChange={e=>setAccepted(e.target.checked)} style={{width:18,marginTop:3}} />
         <span style={{fontWeight:400}}>Tôi đã đọc <a href="#/terms">Điều khoản sử dụng</a>, <a href="#/privacy">Chính sách bảo vệ dữ liệu</a> và <a href="#/money-and-private-transactions">Chính sách về tiền và giao dịch riêng</a>.</span>
       </label>

       <button className="sp-btn">
         Tạo tài khoản
       </button>

     </form>

     <p>
       <a href="#/supplier-login">
         Đã có tài khoản? Đăng nhập
       </a>
     </p>

   </div>
 </div>
}
