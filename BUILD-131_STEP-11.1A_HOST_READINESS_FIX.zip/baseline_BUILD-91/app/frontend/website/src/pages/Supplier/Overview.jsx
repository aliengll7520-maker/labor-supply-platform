import React from 'react';

export default function Overview({me,jobs=[],registrations=[],setTab,unreadNotifications=0}){
 const activeJobs=jobs.filter(x=>!['da_dong','het_han'].includes(x.trang_thai));
 const pending=registrations.filter(x=>['da_mo_so','da_xem','khong_lien_he_duoc'].includes(x.trang_thai));
 const contacted=registrations.filter(x=>x.trang_thai==='da_lien_he');
 const cards=[
  ['Tin đang tuyển',activeJobs.filter(x=>x.trang_thai==='dang_tuyen').length,'jobs'],
  ['Hồ sơ cần xử lý',pending.length,'registrations'],
  ['Đã liên hệ',contacted.length,'registrations'],
  ['Thông báo mới',unreadNotifications,'notifications']
 ];
 const profileFields=['ten_nha_cung_ung','ma_so_thue','dia_chi','so_dien_thoai'];
 const profilePct=Math.round(profileFields.filter(k=>me?.[k]).length/profileFields.length*100);
 return <section>
  <div className="sp-welcome"><div><h2>Tổng quan</h2><p>Xin chào <b>{me?.ten_nha_cung_ung||'Đơn vị sử dụng lao động'}</b>. Tập trung vào đăng tin, nhận hồ sơ và liên hệ.</p></div><button className="sp-btn" type="button" onClick={()=>setTab('jobs')}>+ Đăng tin tuyển dụng</button></div>
  <div className="sp-grid sp-kpi-grid">{cards.map(([label,value,tab])=><button key={label} type="button" className="sp-card sp-kpi-card" onClick={()=>setTab(tab)}><small>{label}</small><strong>{value}</strong><span>Xem →</span></button>)}</div>
  <div className="sp-grid"><div className="sp-card sp-action-card"><h3>Việc cần làm</h3><button type="button" onClick={()=>setTab('registrations')}>👤 Xem hồ sơ cần xử lý <b>{pending.length}</b></button><button type="button" onClick={()=>setTab('notifications')}>🔔 Thông báo mới <b>{unreadNotifications}</b></button><button type="button" onClick={()=>setTab('profile')}>🏢 Hoàn thiện hồ sơ đơn vị <b>{profilePct}%</b></button></div><div className="sp-card"><h3>App Website miễn phí</h3><p>Doanh nghiệp/Nhà cung ứng tự quản lý hoạt động tuyển dụng. App Website tập trung kết nối hồ sơ và hỗ trợ liên hệ.</p><p><b>Không thu phí sử dụng.</b></p></div></div>
  <div className="sp-card"><h3>Hồ sơ đăng ký gần đây</h3>{!registrations.length&&<p>Chưa có hồ sơ.</p>}{registrations.slice(0,5).map(item=><div className="sp-list" key={item.id}><div><b>{item.ho_ten||'—'}</b><small>{item.ma_ho_so||'—'} · {item.tieu_de||'—'}</small></div><span className="sp-status">{item.trang_thai}</span></div>)}{!!registrations.length&&<button type="button" onClick={()=>setTab('registrations')}>Xem tất cả hồ sơ →</button>}</div>
 </section>;
}
