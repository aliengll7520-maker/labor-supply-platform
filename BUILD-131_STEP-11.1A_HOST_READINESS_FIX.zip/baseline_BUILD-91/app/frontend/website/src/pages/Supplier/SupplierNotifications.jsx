import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import {api} from "../../api";
import "./SupplierNotifications.css";

export default function SupplierNotifications({embedded=false}){

 const [items,setItems]=useState([]);
 const [loading,setLoading]=useState(true);
 const [error,setError]=useState("");
 const [busy,setBusy]=useState(false);

 const load=async()=>{
  try{
   setLoading(true);
   setError("");

   const data=await api.get(
    "/notifications/supplier"
   );

   setItems(
    Array.isArray(data)
     ? data
     : (
       data?.items||
       data?.notifications||
       []
      )
   );

  }catch(e){
   setError(e.message);
  }finally{
   setLoading(false);
  }
 };

 useEffect(()=>{
  load();
 },[]);

 const read=async(id)=>{
  try{

   setBusy(true);

   await api.post(
    `/notifications/supplier/${id}/read`
   );

   setItems(items=>
    items.map(item=>
     Number(item.id)===Number(id)
      ? {
         ...item,
         da_doc:1,
         da_doc_at:
          new Date().toISOString()
        }
      : item
    )
   );

  }catch(e){
   setError(e.message);
  }finally{
   setBusy(false);
  }
 };

 const readAll=async()=>{
  try{

   setBusy(true);

   await api.post(
    "/notifications/supplier/read-all"
   );

   setItems(items=>
    items.map(item=>({
     ...item,
     da_doc:1
    }))
   );

  }catch(e){
   setError(e.message);
  }finally{
   setBusy(false);
  }
 };

 const unread=
  items.filter(
   item=>!Number(
    item.da_doc||0
   )
  ).length;

 const content=(
   <section className="supplier-notifications">

    <div className="sn-header">

     <div>

      <h1>
       Thông báo
      </h1>

      <p>
       Theo dõi các thông báo liên quan đến
       tài khoản, Tin tuyển dụng và hồ sơ đăng ký.
      </p>

     </div>

     {unread>0&&
      <button
       type="button"
       disabled={busy}
       onClick={readAll}
      >
       Đánh dấu tất cả đã đọc
      </button>
     }

    </div>

    {error&&
     <div className="sn-alert">

      {error}

      <button
       type="button"
       onClick={()=>
        setError("")
       }
      >
       ×
      </button>

     </div>
    }

    {loading&&
     <div className="sn-empty">
      Đang tải thông báo...
     </div>
    }

    {!loading&&
     !error&&
     !items.length&&
     <div className="sn-empty">
      Chưa có thông báo.
     </div>
    }

    {!loading&&
     items.length>0&&
     <div className="sn-list">

      {items.map(item=>{

       const isUnread=
        !Number(
         item.da_doc||0
        );

       return (
        <article
         key={item.id}
         className={
          isUnread
           ? "sn-item unread"
           : "sn-item"
         }
        >

         <div className="sn-item-main">

          <div className="sn-item-top">

           <h2>
            {item.tieu_de||
             item.title||
             "Thông báo"}
           </h2>

           {isUnread&&
            <span className="sn-unread">
             Chưa đọc
            </span>
           }

          </div>

          <p>
           {item.noi_dung||
            item.message||
            ""}
          </p>

          <small>
           {item.thoi_gian||
            item.created_at||
            item.createdAt||
            ""}
          </small>

         </div>

         {isUnread&&
          <button
           type="button"
           disabled={busy}
           onClick={()=>
            read(item.id)
           }
          >
           Đã đọc
          </button>
         }

        </article>
       );

      })}

     </div>
    }

   </section>
  );

 return embedded ? content : <MainLayout>{content}</MainLayout>;
}
