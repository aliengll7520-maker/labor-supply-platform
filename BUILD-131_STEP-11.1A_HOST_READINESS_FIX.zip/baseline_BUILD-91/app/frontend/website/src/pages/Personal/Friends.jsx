import React,{useEffect,useState} from 'react';
import MainLayout from '../../layouts/MainLayout/MainLayout';
import {api} from '../../api';
import './PersonalProfile.css';
export default function Friends(){
 const [friends,setFriends]=useState([]),[requests,setRequests]=useState([]),[error,setError]=useState('');
 const load=async()=>{try{const [a,b]=await Promise.all([api.get('/ca-nhan/ban-be'),api.get('/ca-nhan/loi-moi-ket-ban')]);setFriends(a.friends||[]);setRequests(b.requests||[])}catch(e){setError(e.message)}};
 useEffect(()=>{load()},[]);
 const action=async(id,hanh_dong)=>{try{await api.post(`/ca-nhan/ban-be/${id}/xu-ly`,{hanh_dong});load()}catch(e){setError(e.message)}};
 return <MainLayout><main className="personal-page"><h1>Bạn bè</h1>{error&&<div className="personal-error">{error}</div>}<section className="personal-card"><h2>Lời mời kết bạn</h2>{requests.length===0?<p>Không có lời mời mới.</p>:requests.map(x=><div className="personal-row" key={x.id}><b>{x.ho_ten}</b><div><button onClick={()=>action(x.nguoi_gui_id,'chap_nhan')}>Chấp nhận</button><button onClick={()=>action(x.nguoi_gui_id,'tu_choi')}>Từ chối</button></div></div>)}</section><section className="personal-card"><h2>Bạn bè</h2>{friends.length===0?<p>Chưa có bạn bè.</p>:friends.map(x=><div className="personal-row" key={x.user_id}><span>{x.ho_ten}</span><button onClick={()=>window.location.hash=`#/ca-nhan?id=${x.user_id}`}>Xem trang cá nhân</button></div>)}</section></main></MainLayout>
}
