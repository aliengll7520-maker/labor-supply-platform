import React,{useEffect,useState} from 'react';
import MainLayout from '../../layouts/MainLayout/MainLayout';
import {api} from '../../api';
import './PersonalProfile.css';

export default function PersonalProfile(){
 const id=Number(new URLSearchParams(window.location.hash.split('?')[1]||'').get('id')||0);
 const [data,setData]=useState(null),[error,setError]=useState(''),[loading,setLoading]=useState(true),[note,setNote]=useState('');
 const load=async()=>{try{setError('');setData(await api.get(`/ca-nhan/nguoi-lao-dong/${id}`));}catch(e){setError(e.message)}finally{setLoading(false)}};
 useEffect(()=>{load()},[id]);
 const friend=async()=>{try{const f=data.friendship;if(data.la_ban_be) await api.post(`/ca-nhan/ban-be/${id}/xu-ly`,{hanh_dong:'huy_ket_ban'}); else if(f?.trang_thai==='cho_chap_nhan'&&f.nguoi_gui_id===Number(data.toi_id)) await api.post(`/ca-nhan/ban-be/${id}/xu-ly`,{hanh_dong:'huy_loi_moi'}); else if(f?.trang_thai==='cho_chap_nhan'&&f.nguoi_nhan_id===Number(data.toi_id)) await api.post(`/ca-nhan/ban-be/${id}/xu-ly`,{hanh_dong:'chap_nhan'}); else await api.post(`/ca-nhan/ban-be/${id}/gui`);load()}catch(e){setError(e.message)}};
 const follow=async()=>{try{await api.post(`/social/follow/nguoi_lao_dong/${id}`,{});load()}catch(e){setError(e.message)}};
 const send=()=>{window.location.hash=`#/trao-doi?id=${id}`};
 if(loading)return <MainLayout><main className="personal-page">Đang tải trang cá nhân...</main></MainLayout>;
 if(error&&!data)return <MainLayout><main className="personal-page"><div className="personal-error">{error}</div></main></MainLayout>;
 const p=data.profile||{}; const f=data.friendship;
 let friendLabel='Kết bạn'; if(data.la_ban_be) friendLabel='Hủy kết bạn'; else if(f?.trang_thai==='cho_chap_nhan') friendLabel=f.nguoi_nhan_id===Number(data.toi_id)?'Chấp nhận kết bạn':'Hủy lời mời';
 return <MainLayout><main className="personal-page">
  <section className="personal-hero">{p.avatar_url?<img src={p.avatar_url} alt="Ảnh đại diện"/>:<div className="personal-avatar">{(p.ho_ten||'N').slice(0,1)}</div>}<div><h1>{p.ho_ten||'Người dùng'}</h1><p>{p.occupation||'Chưa cập nhật nghề nghiệp'}{p.province?` · ${p.province}`:''}</p>{Number(data.toi_id)!==id&&<div className="personal-actions"><button onClick={friend}>{friendLabel}</button><button onClick={follow}>{data.dang_theo_doi?'Bỏ theo dõi':'Theo dõi'}</button><button onClick={send}>Trao đổi</button></div>}</div></section>
  <div className="personal-stats"><b>{data.counts?.ban_be??0}<span>Bạn bè</span></b><b>{data.counts?.nguoi_theo_doi??0}<span>Người theo dõi</span></b><b>{data.counts?.dang_theo_doi??0}<span>Đang theo dõi</span></b></div>
  <section className="personal-card"><h2>Giới thiệu</h2><p>{p.bio||'Chưa cập nhật.'}</p>{p.skills&&<p><b>Kỹ năng:</b> {p.skills}</p>}{p.experience&&<p><b>Kinh nghiệm:</b> {p.experience}</p>}</section>
  {data.can_xem_bai_viet&&<section><h2>Bài viết</h2>{(data.posts||[]).map(x=><article className="personal-post" key={x.id}><p>{x.noi_dung}</p>{x.anh_urls&&<div className="personal-images">{(()=>{try{return JSON.parse(x.anh_urls)}catch{return []}})().map((u,i)=><img key={i} src={u} alt="Ảnh bài viết" loading="lazy"/> )}</div>}{x.loai_nguon==='tin_tuyen_dung'&&<div className="job-share-card"><b>🔵 Tin tuyển dụng được chia sẻ</b><p>{x.noi_dung}</p><button onClick={()=>window.location.hash=`#/job-detail?id=${x.nguon_id}`}>Xem tin tuyển dụng</button></div>}<small>{x.ngay_tao}</small></article>)}</section>}
  <section className="personal-card"><h2>Thảo luận</h2><p>Muốn trao đổi riêng với người này?</p><button onClick={send}>Mở phần Trao đổi</button></section>
 </main></MainLayout>
}
