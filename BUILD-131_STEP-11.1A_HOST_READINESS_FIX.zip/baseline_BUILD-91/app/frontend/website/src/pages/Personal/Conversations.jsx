import React,{useEffect,useState} from 'react';
import MainLayout from '../../layouts/MainLayout/MainLayout';
import {api} from '../../api';
import './PersonalProfile.css';
export default function Conversations(){
 const id=Number(new URLSearchParams(window.location.hash.split('?')[1]||'').get('id')||0);
 const [list,setList]=useState([]),[messages,setMessages]=useState([]),[text,setText]=useState(''),[error,setError]=useState('');
 const loadList=async()=>{try{const r=await api.get('/ca-nhan/trao-doi');setList(r.conversations||[])}catch(e){setError(e.message)}};
 const loadChat=async()=>{if(!id)return;try{const r=await api.get(`/ca-nhan/trao-doi/${id}`);setMessages(r.messages||[]);await api.post(`/ca-nhan/trao-doi/${id}/da-doc`,{})}catch(e){setError(e.message)}};
 useEffect(()=>{loadList();loadChat()},[id]);
 const send=async()=>{if(!text.trim()||!id)return;try{await api.post(`/ca-nhan/trao-doi/${id}`,{noi_dung:text.trim()});setText('');loadChat();loadList()}catch(e){setError(e.message)}};
 return <MainLayout><main className="personal-page"><h1>Trao đổi</h1>{error&&<div className="personal-error">{error}</div>}<div className="personal-card"><h2>Cuộc trao đổi</h2>{list.length===0?<p>Chưa có cuộc trao đổi nào.</p>:list.map(x=><button className="personal-row" key={x.user_id} onClick={()=>window.location.hash=`#/trao-doi?id=${x.user_id}`}><span><b>{x.ho_ten}</b><small>{x.noi_dung}</small></span>{Number(x.chua_doc)>0&&<strong>{x.chua_doc}</strong>}</button>)}</div>{id>0&&<section className="personal-card"><h2>Trao đổi với {list.find(x=>x.user_id===id)?.ho_ten||'người dùng'}</h2><div className="discussion-box">{messages.map(m=><div key={m.id} className={Number(m.nguoi_gui_id)===id?'discussion-in':'discussion-out'}><span>{m.noi_dung}</span><small>{m.ngay_tao}</small></div>)}{messages.length===0&&<p>Chưa có nội dung trao đổi.</p>}</div><textarea value={text} onChange={e=>setText(e.target.value)} maxLength={2000} placeholder="Viết nội dung trao đổi..."/><button onClick={send}>Gửi</button></section>}</main></MainLayout>
}
