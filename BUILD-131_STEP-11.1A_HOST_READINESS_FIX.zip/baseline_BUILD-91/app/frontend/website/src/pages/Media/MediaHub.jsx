import React,{useEffect,useState} from 'react';
import {api} from '../../api';
import './MediaHub.css';
import AdNetworkSlot from '../../components/Ads/AdNetworkSlot';
export default function MediaHub(){
 const [videos,setVideos]=useState([]),[rooms,setRooms]=useState([]),[title,setTitle]=useState(''),[url,setUrl]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const load=async()=>{try{const v=await api.get('/media/videos');setVideos(v.videos||[]);const r=await api.get('/media/live');setRooms(r.rooms||[])}catch(e){setError(e.message)}};
 useEffect(()=>{load()},[]);
 const publish=async e=>{e.preventDefault();setError('');try{await api.post('/media/videos',{tieu_de:title,media_url:url,loai_media:'video'});setTitle('');setUrl('');setNotice('Đã gửi video chờ kiểm duyệt.');await load()}catch(e){setError(e.message)}};
 const start=async id=>{try{await api.post(`/media/live/${id}/start`,{});setNotice('Live đã bắt đầu.');await load()}catch(e){setError(e.message)}};
 const end=async id=>{try{await api.post(`/media/live/${id}/end`,{});setNotice('Live đã kết thúc.');await load()}catch(e){setError(e.message)}};
 return <div className="media-shell"><header><small>BUILD 98 · MEDIA + LIVE</small><h1>Video & Live nghề nghiệp</h1><p>Video và Live phục vụ việc làm, kỹ năng và cộng đồng. Không thu phí sử dụng.</p></header>
 {notice&&<div className="media-note">{notice}</div>}{error&&<div className="media-error">{error}</div>}
 <section className="media-grid"><div className="media-card"><h2>Đăng video</h2><form onSubmit={publish}><label>Tiêu đề<input value={title} onChange={e=>setTitle(e.target.value)} required/></label><label>URL video<input value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://..." required/></label><button>Gửi kiểm duyệt</button></form><p className="muted">BUILD 98 dùng URL media để kết nối với hạ tầng lưu trữ/stream. Hệ thống không bỏ qua kiểm duyệt.</p></div>
 <div className="media-card"><h2>Live đang hoạt động</h2>{rooms.length===0?<p className="muted">Chưa có Live đang hoạt động.</p>:rooms.map(r=><div className="media-row" key={r.id}><div><b>{r.tieu_de}</b><span>{r.ten_don_vi} · {r.trang_thai}</span></div><div>{r.trang_thai==='dang_live'?<button onClick={()=>end(r.id)}>Kết thúc</button>:<button onClick={()=>start(r.id)}>Bắt đầu</button>}</div></div>)}</div></section>
 <AdNetworkSlot placement="live"/> <AdNetworkSlot placement="video"/><section><h2>Video mới</h2><div className="video-grid">{videos.map(v=><article className="video-card" key={v.id}>{v.thumbnail_url&&<img src={v.thumbnail_url} alt=""/>}<h3>{v.tieu_de}</h3><p>{v.ten_tac_gia}</p><span>{v.luot_xem} lượt xem · {v.trang_thai}</span></article>)}</div></section></div>
}
