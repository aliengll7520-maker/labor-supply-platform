import React,{useState} from 'react';
import {api} from '../../api';
import './ApplicationRegistrationPanel.css';
import TrustReputation from '../../components/TrustReputation/TrustReputation';

export default function ApplicationRegistrationPanel({job,onSuccess}){
 const [form,setForm]=useState({ho_ten:'',so_dien_thoai:'',que_quan:''});
 const [busy,setBusy]=useState(false);
 const [error,setError]=useState('');
 const [result,setResult]=useState(null);

 const submit=async e=>{
  e.preventDefault();
  setBusy(true); setError('');
  try{
   const data=await api.post('/applications',{
    tin_tuyen_dung_id:Number(job.id),
    ho_ten:form.ho_ten.trim(),
    so_dien_thoai:form.so_dien_thoai.trim(),
    que_quan:form.que_quan.trim()
   });
   setResult(data);
   if(onSuccess) onSuccess(data);
  }catch(e){
   setError(e.message||'Không thể đăng ký hồ sơ đăng ký.');
  }finally{ setBusy(false); }
 };

 if(result) return <section className="wir-card wir-success">
  <h2>Đăng ký hồ sơ thành công</h2>
  <p>Hồ sơ của bạn đã được ghi nhận và gửi tới đơn vị sử dụng lao động.</p>
  <div className="wir-result">
   <div><span>Mã hồ sơ</span><strong>{result.ma_ho_so}</strong></div>
   <div><span>Trạng thái</span><strong>Đã mở hồ sơ</strong></div>
  </div>
  <p className="wir-note">Hãy lưu Mã hồ sơ và Số điện thoại để tra cứu trạng thái hồ sơ.</p>
  {result.id&&job?.nha_cung_ung_id&&localStorage.getItem("worker_access_token")&&<TrustReputation type="employer" id={job.nha_cung_ung_id} applicationId={result.id}/>}
 </section>;

 return <section className="wir-card">
  <h2>Đăng ký hồ sơ</h2>
  <p>Điền thông tin tối thiểu để đơn vị sử dụng lao động có thể tiếp nhận hồ sơ.</p>
  {error&&<p className="wir-error">{error}</p>}
  <form onSubmit={submit}>
   <label><span>Họ tên *</span><input required maxLength="255" autoComplete="name" value={form.ho_ten} onChange={e=>setForm({...form,ho_ten:e.target.value})}/></label>
   <label><span>Số điện thoại *</span><input required maxLength="20" inputMode="tel" autoComplete="tel" value={form.so_dien_thoai} onChange={e=>setForm({...form,so_dien_thoai:e.target.value})}/></label>
   <label><span>Quê quán *</span><input required maxLength="255" value={form.que_quan} onChange={e=>setForm({...form,que_quan:e.target.value})}/></label>
   <button type="submit" disabled={busy}>{busy?'ĐANG GỬI HỒ SƠ...':'ĐĂNG KÝ HỒ SƠ'}</button>
  </form>
 </section>;
}
