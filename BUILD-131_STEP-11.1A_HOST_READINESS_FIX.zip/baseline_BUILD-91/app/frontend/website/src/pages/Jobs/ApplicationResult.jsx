import React from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import Button from "../../components/Button/Button";
import "./ApplicationResult.css";

function ApplicationResult() {
  const params = new URLSearchParams((window.location.hash.split("?")[1] || ""));
  const maHoSo = params.get("ma_ho_so") || "";
  return <MainLayout><div className="application-result"><h1 className="application-result-title">Đăng ký hồ sơ</h1><Card>
    <div className="application-result-success"><h2>Đăng ký hồ sơ đã được ghi nhận</h2><p>Hệ thống đã tạo hồ sơ và thông báo cho Đơn vị sử dụng lao động.</p></div>
    <div className="application-result-info"><p><strong>Mã hồ sơ:</strong> {maHoSo || "Đã được cấp trong phản hồi đăng ký"}</p><p><strong>Trạng thái:</strong> Đã mở hồ sơ</p></div>
    <p>Hãy lưu Mã hồ sơ và Số điện thoại của bạn để tra cứu hồ sơ. Thông tin liên hệ riêng của Đơn vị sử dụng lao động không được công khai tại đây.</p>
    <div style={{marginTop:"20px"}}><Button text="XEM ĐĂNG KÝ HỒ SƠ" onClick={()=>window.location.hash="#/applications"}/><div className="space"></div><Button text="TIẾP TỤC XEM VIỆC" onClick={()=>window.location.hash="#/jobs"}/></div>
  </Card></div></MainLayout>;
}
export default ApplicationResult;
