import { api } from "../../api";
import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Input from "../../components/Input/Input";
import Button from "../../components/Button/Button";
import Card from "../../components/Card/Card";
import Badge from "../../components/Badge/Badge";
import "./SearchJobs.css";

function SearchJobs(){
 const [keyword,setKeyword]=useState(""),[location,setLocation]=useState(""),[jobs,setJobs]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState("");
 const load=async()=>{
  setLoading(true);setError("");
  try{
   const qs=new URLSearchParams();
   if(keyword.trim())qs.set("q",keyword.trim());
   if(location.trim())qs.set("dia_diem",location.trim());
   const query=qs.toString();
   const j=await api.get(`/jobs/public${query?`?${query}`:""}`);
   setJobs(j||[]);
  }catch(e){setError(e.message)}finally{setLoading(false)}
 };
 useEffect(()=>{load()},[]);
 const handleSearch=e=>{e.preventDefault();load()};
 return <MainLayout><div className="search-jobs"><h1>Tìm kiếm việc làm</h1><p>Tìm công việc đang tuyển công khai.</p>
  <form onSubmit={handleSearch}><Input placeholder="Tên công việc, ngành nghề..." value={keyword} onChange={e=>setKeyword(e.target.value)}/><Input placeholder="Địa điểm..." value={location} onChange={e=>setLocation(e.target.value)}/><div className="space"></div><Button text="TÌM KIẾM" type="submit"/></form><div className="space"></div>
  {loading&&<p>Đang tải Tin tuyển dụng...</p>}{error&&<p>{error}</p>}{!loading&&!jobs.length&&<p>Chưa có Tin tuyển dụng phù hợp.</p>}
  {jobs.map(job=><Card key={job.id}><h2>{job.tieu_de}</h2><Badge text="Đang tuyển" color="#2e7d32"/><p><strong>Đơn vị sử dụng lao động:</strong> {job.ten_nha_cung_ung}</p><p><strong>Ngành nghề:</strong> {job.nganh_nghe}</p><p><strong>Địa điểm:</strong> {job.dia_diem}</p><p><strong>Lương cơ bản:</strong> {Number(job.luong_co_ban||0).toLocaleString("vi-VN")} VNĐ</p><Button text="XEM CHI TIẾT" onClick={()=>{window.location.hash=`#/job-detail?id=${job.id}`}}/></Card>)}
 </div></MainLayout>
}
export default SearchJobs;
