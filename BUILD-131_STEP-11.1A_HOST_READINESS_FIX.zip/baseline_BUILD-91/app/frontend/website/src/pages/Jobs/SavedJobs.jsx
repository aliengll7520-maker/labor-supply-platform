import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import Button from "../../components/Button/Button";
import {api} from "../../api";
import "./SavedJobs.css";

function SavedJobs(){
 const [jobs,setJobs]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState("");
 const load=async()=>{try{setLoading(true);setJobs(await api.get("/worker/favorites")||[]);}catch(e){setError(e.message||"Không thể tải Tin đã lưu.");}finally{setLoading(false);}};
 useEffect(()=>{load();},[]);
 const remove=async(id)=>{try{await api.post("/worker/favorites/remove",{tin_tuyen_dung_id:Number(id)});await load();}catch(e){setError(e.message);}};
 return <MainLayout><div className="saved-jobs"><h1 className="saved-jobs-title">Tin tuyển dụng đã lưu</h1>{loading&&<Card><p>Đang tải...</p></Card>}{error&&<Card><p>{error}</p></Card>}{!loading&&!error&&!jobs.length&&<Card><h2>Chưa có Tin tuyển dụng được lưu</h2><p>Bạn có thể lưu Tin tuyển dụng để xem lại sau.</p></Card>}{jobs.map(job=><Card key={job.job_id}><h2>{job.title}</h2><p><strong>Đơn vị sử dụng lao động:</strong> {job.ten_nha_cung_ung||job.ten_don_vi||"Đơn vị sử dụng lao động"}</p><p><strong>Địa điểm:</strong> {job.location}</p><Button text="XEM CHI TIẾT" onClick={()=>window.location.hash=`#/job-detail?tin_tuyen_dung_id=${job.job_id}`}/><div className="space"/><Button text="BỎ LƯU" onClick={()=>remove(job.job_id)}/></Card>)}</div></MainLayout>;
}
export default SavedJobs;
