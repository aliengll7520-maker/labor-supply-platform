import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Button from "../../components/Button/Button";
import {api} from "../../api";
import ApplicationRegistrationPanel from "./ApplicationRegistrationPanel";
import "./JobDetail.css";
import AdNetworkSlot from "../../components/Ads/AdNetworkSlot";
import ShareMenu from "../../components/Share/ShareMenu";
import TrustReputation from "../../components/TrustReputation/TrustReputation";

function JobDetail(){

 const [
  job,
  setJob
 ]=useState(null);

 const [
  supplier,
  setSupplier
 ]=useState(null);

 const [
  loading,
  setLoading
 ]=useState(true);

 const [
  error,
  setError
 ]=useState("");

 const id=new URLSearchParams(
  window.location.hash.split("?")[1]||""
 ).get("tin_tuyen_dung_id")||
  new URLSearchParams(
   window.location.hash.split("?")[1]||""
  ).get("id");

 useEffect(()=>{
  (async()=>{
   try{
    const [jobResponse,me]=await Promise.all([
     api.get(`/jobs/public/${id}`),
     api.get("/supplier/me").catch(()=>null)
    ]);
    setJob(jobResponse);
    setSupplier(me);
   }catch(e){
    setError(e.message);
   }finally{
    setLoading(false);
   }
  })();
 },[id]);

 const deleteJob=async()=>{

  if(!job)
   return;

  const confirmed=window.confirm(
   `Xóa tin "${job.tieu_de}" khỏi trang công khai?\n\nTin sẽ không còn nhận hồ sơ mới nhưng toàn bộ lịch sử tuyển dụng vẫn được bảo toàn.`
  );

  if(!confirmed)
   return;

  try{

   await api.patch(
    `/supplier/jobs/${job.id}/status`,
    {trang_thai:'da_dong'}
   );

   window.alert("Đã xóa Tin tuyển dụng khỏi trang công khai. Dữ liệu lịch sử vẫn được bảo toàn.");

   window.setTimeout(()=>{
    window.location.hash="#/jobs";
   },500);

  }catch(e){
   setError(e.message);
  }
 };

 if(loading)
  return (
   <MainLayout>
    <div className="job-detail">
     <p>Đang tải...</p>
    </div>
   </MainLayout>
  );

 if(error&&!job)
  return (
   <MainLayout>
    <div className="job-detail">
     <p>{error}</p>
    </div>
   </MainLayout>
  );

 const isOwner=
  supplier&&
  Number(supplier.id)===
  Number(job.nha_cung_ung_id);

 return (
  <MainLayout>

   <div className="job-detail">

    <h1>{job.tieu_de}</h1>

    <p>
     <b>Đơn vị sử dụng lao động:</b>{" "}
     {job.ten_nha_cung_ung}
    </p>

    <p>
     <b>Ngành nghề:</b>{" "}
     {job.nganh_nghe}
     {" · "}
     <b>Địa điểm:</b>{" "}
     {job.dia_diem}
    </p>

        <div className="job-income">
      <p>
        <b>Lương cơ bản:</b>{" "}
        {Number(
          job.luong_co_ban||0
        ).toLocaleString("vi-VN")}{" "}
        VNĐ
      </p>

      <p>
        <b>Tổng thu nhập dự kiến:</b>{" "}
        {Number(
          job.tong_thu_nhap_du_kien||0
        ).toLocaleString("vi-VN")}{" "}
        VNĐ
      </p>

      <p>
        <b>Hỗ trợ tiền xe cho người lao động ở xa:</b>{" "}
        {Number(
          job.ho_tro_tien_xe_nguoi_lao_dong_o_xa||0
        ).toLocaleString("vi-VN")}{" "}
        VNĐ
      </p>
    </div>

    <AdNetworkSlot placement="job_detail" />

    <h2>Mô tả công việc</h2>

    <p>
     {job.mo_ta_cong_viec||
      "Chưa có mô tả."}
    </p>

    <h2>Điều kiện tuyển dụng</h2>

    <p>
     {job.dieu_kien_tuyen_dung||
      "Chưa cập nhật."}
    </p>

    <div className="job-detail-actions">
     <ShareMenu
      job={job}
      onPersonalShare={async()=>{
       try{
        const note=window.prompt('Bạn muốn giới thiệu gì về tin này?','Chia sẻ một cơ hội việc làm.');
        if(note===null)return;
        await api.post(`/social/jobs/${job.id}/share`,{ghi_chu:note});
        window.alert('Đã gửi chia sẻ lên trang cá nhân, chờ hệ thống kiểm tra tự động.');
       }catch(e){setError(e.message);}
      }}
     />
     <Button
      text="LƯU TIN TUYỂN DỤNG"
      onClick={async()=>{
       try{
        await api.post('/worker/favorites',{job_id:Number(job.id)});
        window.alert('Đã lưu Tin tuyển dụng.');
       }catch(e){
        setError(e.message);
       }
      }}
     />
    </div>

    <TrustReputation type="employer" id={job.nha_cung_ung_id} />

    <ApplicationRegistrationPanel job={job} />

    {isOwner&&
     <div className="job-owner-actions">

      <h2>
       Quản lý Tin tuyển dụng
      </h2>

      <p>
       Bạn là Nhà cung ứng sở hữu Tin tuyển dụng này.
      </p>

      <Button
       text="XÓA TIN"
       onClick={deleteJob}
      />

     </div>
    }

   </div>

  </MainLayout>
 );
}

export default JobDetail;
