import React,{useState} from "react";
import {api} from "../../api";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import Badge from "../../components/Badge/Badge";
import Button from "../../components/Button/Button";
import "./AppliedJobs.css";

const labels={da_mo_so:'Đã đăng ký',da_xem:'Nhà cung ứng đã xem',da_lien_he:'Đã liên hệ',khong_lien_he_duoc:'Chưa liên hệ được',khong_phu_hop:'Không phù hợp',da_huy:'Đã hủy'};

function AppliedJobs(){
 const [form,setForm]=useState({so_dien_thoai:"",ma_ho_so:""}),
 [data,setData]=useState(null),
 [error,setError]=useState(""),
 [message,setMessage]=useState("");

 const lookup=async e=>{
   e.preventDefault();
   setError("");
   setMessage("");

   try{
     const j=await api.post("/applications/lookup",form);
     setData(j);

   }catch(e){
     setError(e.message);
   }
 };

 const cancel=async()=>{
   const reason=window.prompt(
     "Lý do hủy Đăng ký hồ sơ:"
   );

   if(!reason)return;

   try{
     const j=await api.post(`/applications/${data.id}/cancel`,{...form,ly_do:reason});
     setMessage(j?.message||"Đã hủy hồ sơ.");
     setData({
       ...data,
       trang_thai:"da_huy"
     });

   }catch(e){
     setError(e.message);
   }
 };

 return <MainLayout>
   <div className="applied-jobs">

     <h1 className="applied-jobs-title">
       Tra cứu Đăng ký hồ sơ
     </h1>

     <Card>

       <p>
         Nhập đúng Số điện thoại đã đăng ký và
         Mã hồ sơ được cấp sau khi đăng ký.
       </p>

       <form onSubmit={lookup}>

         <label>
           Số điện thoại
           <input
             required
             value={form.so_dien_thoai}
             onChange={e=>
               setForm({
                 ...form,
                 so_dien_thoai:e.target.value
               })
             }
           />
         </label>

         <label>
           Mã hồ sơ
           <input
             required
             value={form.ma_ho_so}
             onChange={e=>
               setForm({
                 ...form,
                 ma_ho_so:e.target.value
               })
             }
           />
         </label>

         <Button
           text="TRA CỨU"
           type="submit"
         />

       </form>

       {error&&<p>{error}</p>}
       {message&&<p>{message}</p>}

     </Card>

     {data&&<Card>

       <h2>{data.tieu_de}</h2>

       <p>
         <b>Mã hồ sơ:</b> {data.ma_ho_so}
       </p>

       <p>
         <b>Đơn vị sử dụng lao động:</b> {data.ten_nha_cung_ung}
       </p>

       <p>
         <b>Địa điểm:</b> {data.dia_diem}
       </p>

       <Badge
         text={
           labels[data.trang_thai]||data.trang_thai
         }
         color="#2e7d32"
       />

       <h3>Quá trình</h3>

       <div>
         {(data.timeline||[]).map((x,i)=>
           <div
             key={i}
             style={{
               padding:"10px 0",
               borderBottom:"1px solid #eee"
             }}
           >

             <b>
               {labels[x.hanh_dong]||x.hanh_dong}
             </b>

             <div>
               {x.thoi_gian}
             </div>

             {x.ghi_chu&&
               <small>{x.ghi_chu}</small>
             }

           </div>
         )}
       </div>

       {[
         "da_mo_so",
         "da_xem",
         "da_lien_he",
         "khong_lien_he_duoc"
       ].includes(data.trang_thai)&&

       <div style={{marginTop:20}}>

         <Button
           text="HỦY ĐĂNG KÝ"
           onClick={cancel}
         />

       </div>}

     </Card>}

   </div>
 </MainLayout>
}

export default AppliedJobs;
