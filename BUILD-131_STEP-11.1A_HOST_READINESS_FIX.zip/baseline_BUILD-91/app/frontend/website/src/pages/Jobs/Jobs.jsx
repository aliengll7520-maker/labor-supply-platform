 import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import Button from "../../components/Button/Button";
import Badge from "../../components/Badge/Badge";
import {api} from "../../api";
import "./Jobs.css";

function Jobs(){

 const [jobs,setJobs]=useState([]);
 const [supplier,setSupplier]=useState(null);
 const [loading,setLoading]=useState(true);
 const [error,setError]=useState("");
 const [notice,setNotice]=useState("");

 const load=async()=>{
  try{
   setLoading(true);
   setError("");

   const [publicJobs,me]=await Promise.all([
    api.get("/jobs/public"),
    api.get("/supplier/me").catch(()=>null)
   ]);

   setJobs(publicJobs||[]);
   setSupplier(me);

  }catch(e){
   setError(e.message);
  }finally{
   setLoading(false);
  }
 };

 useEffect(()=>{
  load();
 },[]);

 const handleViewJob=(jobId)=>{
  window.location.hash=
   `#/job-detail?tin_tuyen_dung_id=${jobId}`;
 };

 const handleDelete=async(job)=>{
  const confirmed=window.confirm(
   `Xóa tin "${job.tieu_de}" khỏi trang công khai?\n\nTin sẽ không còn nhận hồ sơ mới nhưng toàn bộ lịch sử tuyển dụng vẫn được bảo toàn.`
  );

  if(!confirmed)
   return;

  try{
   await api.patch(
    `/supplier/jobs/${job.id}/status`,
    {trang_thai:'da_dong'}
   );

   setJobs(x=>
    x.filter(item=>item.id!==job.id)
   );

   setNotice(
    "Đã xóa Tin tuyển dụng khỏi trang công khai. Dữ liệu lịch sử vẫn được bảo toàn."
   );

  }catch(e){
   setError(e.message);
  }
 };

 return (
  <MainLayout>

   <div className="jobs">

    <h1 className="jobs-title">
     Việc làm
    </h1>

    <p>
     Xem các tin tuyển dụng công khai
     từ Đơn vị sử dụng lao động.
    </p>

    {notice&&<p>{notice}</p>}
    {error&&<p>{error}</p>}

    {loading&&
     <p>Đang tải Tin tuyển dụng...</p>
    }

    {!loading&&!error&&!jobs.length&&
     <p>
      Hiện chưa có Tin tuyển dụng đang công khai.
     </p>
    }

    {jobs.map(job=>{

     const isOwner=
      supplier&&
      Number(supplier.id)===
      Number(job.nha_cung_ung_id);

     return (
      <Card key={job.id}>

       <h2>
        {job.tieu_de}
       </h2>

       <Badge
        text="Đang tuyển"
        color="#2e7d32"
       />

       <p>
        <strong>Đơn vị sử dụng lao động:</strong>{" "}
        {job.ten_nha_cung_ung}
       </p>

              <p>
          <strong>Lương cơ bản:</strong>{" "}
          {Number(
            job.luong_co_ban||0
          ).toLocaleString("vi-VN")}{" "}
          VNĐ
        </p>

        <p>
          <strong>Tổng thu nhập dự kiến:</strong>{" "}
          {Number(
            job.tong_thu_nhap_du_kien||0
          ).toLocaleString("vi-VN")}{" "}
          VNĐ
        </p>

        <p>
          <strong>Hỗ trợ tiền xe cho người lao động ở xa:</strong>{" "}
          {Number(
            job.ho_tro_tien_xe_nguoi_lao_dong_o_xa||0
          ).toLocaleString("vi-VN")}{" "}
          VNĐ
        </p>

       <p>
        <strong>Địa điểm:</strong>{" "}
        {job.dia_diem}
       </p>

       <p>
        <strong>Số lượng:</strong>{" "}
        {job.so_luong} người
       </p>

       <div className="jobs-actions">

        <Button
         text="XEM CHI TIẾT"
         onClick={()=>
          handleViewJob(job.id)
         }
        />

        {isOwner&&
         <Button
          text="XÓA TIN"
          onClick={()=>
           handleDelete(job)
          }
         />
        }

       </div>

      </Card>
     );
    })}

   </div>

  </MainLayout>
 );
}

export default Jobs;
