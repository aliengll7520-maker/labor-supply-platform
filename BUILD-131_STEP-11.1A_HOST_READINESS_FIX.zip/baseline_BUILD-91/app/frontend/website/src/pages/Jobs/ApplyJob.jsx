import React,{useEffect,useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import {api} from "../../api";
import ApplicationRegistrationPanel from "./ApplicationRegistrationPanel";

function ApplyJob(){
 const [job,setJob]=useState(null);const [error,setError]=useState("");
 const params=new URLSearchParams(window.location.hash.split("?")[1]||"");
 const id=params.get("tin_tuyen_dung_id")||params.get("id");
 useEffect(()=>{(async()=>{try{if(!id)throw new Error("Thiếu mã Tin tuyển dụng.");setJob(await api.get(`/jobs/public/${id}`))}catch(e){setError(e.message||"Không thể tải Tin tuyển dụng.")}})()},[id]);
 return <MainLayout><div className="apply-job">{error&&<p>{error}</p>}{job&&<ApplicationRegistrationPanel job={job}/>}</div></MainLayout>
}
export default ApplyJob;
