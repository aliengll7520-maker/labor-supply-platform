import { api } from "../../api";
import React,{useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import Select from "../../components/Select/Select";
import Button from "../../components/Button/Button";
import Badge from "../../components/Badge/Badge";
import "./FilterJobs.css";

function FilterJobs(){
 const [province,setProvince]=useState("");
 const [jobs,setJobs]=useState([]);
 const [loading,setLoading]=useState(false);
 const [error,setError]=useState("");
 const provinceOptions=[
  {value:"",label:"Tất cả tỉnh thành"},
  {value:"Bắc Ninh",label:"Bắc Ninh"},
  {value:"Hải Phòng",label:"Hải Phòng"}
 ];
 const handleFilter=async e=>{
  e.preventDefault();setLoading(true);setError("");
  try{
   const qs=new URLSearchParams();
   if(province)qs.set("dia_diem",province);
   const query=qs.toString();
   const j=await api.get(`/jobs/public${query?`?${query}`:""}`);
   setJobs(j||[]);
  }catch(err){setError(err.message||"Không thể tải Tin tuyển dụng.");setJobs([])}
  finally{setLoading(false)}
 };
 const handleViewJob=id=>{window.location.hash=`#/job-detail?id=${id}`};
 return <MainLayout><div className="filter-jobs"><h1>Lọc việc làm</h1><p>Lọc các tin tuyển dụng công khai theo nhu cầu của bạn.</p>
  <Card><form onSubmit={handleFilter}><Select options={provinceOptions} value={province} onChange={e=>setProvince(e.target.value)}/><div className="space"></div><Button text="ÁP DỤNG BỘ LỌC" type="submit"/></form></Card>
  <div className="space"></div>
  {loading&&<p>Đang tải Tin tuyển dụng...</p>}{error&&<p>{error}</p>}{!loading&&!error&&!jobs.length&&<p>Chưa có Tin tuyển dụng phù hợp.</p>}
  {jobs.map(job=><Card key={job.id}><h2>{job.tieu_de}</h2><Badge text="Đang tuyển" color="#2e7d32"/><p><strong>Đơn vị sử dụng lao động:</strong> {job.ten_nha_cung_ung}</p><p><strong>Địa điểm:</strong> {job.dia_diem}</p><p><strong>Lương cơ bản:</strong> {Number(job.luong_co_ban||0).toLocaleString("vi-VN")} VNĐ</p><Button text="XEM CHI TIẾT" onClick={()=>handleViewJob(job.id)}/></Card>)}
 </div></MainLayout>
}
export default FilterJobs;
