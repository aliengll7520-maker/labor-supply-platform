import React,{useEffect,useState} from 'react';
import {api} from '../../api';
import '../Employer/EmployerPortal.css';
import ApplicationDetail from './ApplicationDetail';
import Overview from './Overview';
import SupplierNotifications from './SupplierNotifications';

const tabs=[
 ['overview','Tổng quan'],
 ['jobs','Tin tuyển dụng'],
 ['registrations','Đăng ký hồ sơ'],
 ['profile','Hồ sơ đơn vị'],
 ['accounts','Tài khoản đội ngũ'],
 ['worker-posts','Người đang tìm việc'],
 ['live','Live'],
 ['notifications','Thông báo']
];

const emptyJob={
 tieu_de:'',
 nganh_nghe:'',
 so_luong:1,
 dia_diem:'',
 google_maps:'',
 luong_co_ban:0,
tong_thu_nhap_du_kien:0,
ho_tro_tien_xe_nguoi_lao_dong_o_xa:0,
chuyen_can:0,
 nha_o:0,
 xang_xe:0,
 hieu_suat:0,
 phu_cap_khac:0,
 thuong:'',
 ho_tro:'',
 tang_ca:'',
 chinh_sach_tra_luong:'',
 hop_dong:'',
 bao_hiem:'',
 che_do_khac:'',
 dieu_kien_tuyen_dung:'',
 mo_ta_cong_viec:'',
 hinh_anh:'',
 video:'',
 ngay_het_han:''
};

function Field({
 label,
 name,
 value,
 onChange,
 type='text',
 placeholder=''
}){
 return <label className="sp-field">
  <span>{label}</span>
  <input
   type={type}
   name={name}
   value={value??''}
   placeholder={placeholder}
   onChange={e=>
    onChange(
     e.target.name,
     e.target.value
    )
   }
  />
 </label>
}

function Status({children}){
 return (
  <span className="sp-status">
   {children}
  </span>
 );
}

export default function EmployerPortal({initialTab="overview"}){

 const [tab,setTab]=useState(initialTab||'overview'),
 [selectedApplication,setSelectedApplication]=useState(null),
 [applicationContacts,setApplicationContacts]=useState([]),
 [passwordForm,setPasswordForm]=useState({
  mat_khau_hien_tai:'',
  mat_khau_moi:''
 }),
 [me,setMe]=useState(null),
 [jobs,setJobs]=useState([]),
 [applications,setApplications]=useState([]),
 [accounts,setAccounts]=useState([]),
 [workerPosts,setWorkerPosts]=useState([]),
 [liveRooms,setLiveRooms]=useState([]),
 [error,setError]=useState(''),
 [notice,setNotice]=useState(''),
 [busy,setBusy]=useState(false),
 [job,setJob]=useState(emptyJob),
 [editingJob,setEditingJob]=useState(null),
 [profile,setProfile]=useState({}),
 [unreadNotifications,setUnreadNotifications]=useState(0);

 const load=async()=>{
  try{
   setBusy(true);

   const m=await api.get(
    '/supplier/me'
   );

   setMe(m);
   setProfile(m);

   const active=
    m.tai_khoan_trang_thai==='hoat_dong'&&
    m.trang_thai==='hoat_dong'&&
    m.xac_minh==='da_xac_minh';

   if(active){

    const [
     j,c,n,ac,wp,lr
    ]=await Promise.all([
     api.get('/supplier/jobs'),
     api.get('/supplier/applications'),
     api.get('/notifications/supplier').catch(()=>[]),
     api.get('/employer/accounts').catch(()=>[]),
     api.get('/employer/worker-posts').catch(()=>[]),
     api.get('/employer/live').catch(()=>[])
    ]);

    setJobs(j);
    setApplications(c);
    setAccounts(Array.isArray(ac)?ac:[]);
    setWorkerPosts(Array.isArray(wp)?wp:[]);
    setLiveRooms(Array.isArray(lr)?lr:[]);
    const notificationItems=Array.isArray(n)?n:(n?.items||n?.notifications||[]);
    setUnreadNotifications(notificationItems.filter(item=>!Number(item.da_doc||0)).length);

   }else{

    setJobs([]);
    setApplications([]);
    setAccounts([]);
    setWorkerPosts([]);
    setLiveRooms([]);
    setUnreadNotifications(0);

   }

  }catch(e){
   setError(e.message);
  }finally{
   setBusy(false);
  }
 };

 useEffect(()=>{
  load();
 },[]);

 const flash=(msg)=>{
  setNotice(msg);
  setTimeout(
   ()=>setNotice(''),
   2500
  );
 };

 const createTeamAccount=async(e)=>{
  e.preventDefault();
  const fd=new FormData(e.currentTarget);
  try{
   setBusy(true);
   await api.post('/employer/accounts',{
    ten_dang_nhap:fd.get('ten_dang_nhap'),
    mat_khau:fd.get('mat_khau'),
    ten_hien_thi:fd.get('ten_hien_thi'),
    vai_tro:fd.get('vai_tro'),
    co_quyen_live:fd.get('co_quyen_live')==='1'
   });
   e.currentTarget.reset();
   await load();
   flash('Đã tạo tài khoản thành viên.');
  }catch(e){setError(e.message);}finally{setBusy(false);}
 };
 const updateTeamAccount=async(account)=>{
  try{
   await api.put(`/employer/accounts/${account.id}`,{
    vai_tro:account.vai_tro,
    co_quyen_live:Boolean(account.co_quyen_live),
    trang_thai:account.trang_thai
   });
   await load();
   flash('Đã cập nhật tài khoản thành viên.');
  }catch(e){setError(e.message);}
 };
 const connectWorkerPost=async(id)=>{
  try{
   const r=await api.post(`/employer/worker-posts/${id}/connect`);
   setNotice(r?.message||'Đã gửi yêu cầu kết nối.');
   setWorkerPosts(await api.get('/employer/worker-posts'));
  }catch(e){setError(e.message);}
 };
 const createLiveRoom=async(e)=>{
  e.preventDefault();
  const fd=new FormData(e.currentTarget);
  try{
   setBusy(true);
   await api.post('/employer/live',{
    tieu_de:fd.get('tieu_de'),
    mo_ta:fd.get('mo_ta'),
    bat_dau_du_kien:fd.get('bat_dau_du_kien')||null
   });
   e.currentTarget.reset();
   await load();
   flash('Đã tạo phòng Live.');
  }catch(e){setError(e.message);}finally{setBusy(false);}
 };
 const saveJob=async()=>{
  try{
   setBusy(true);

   if(editingJob)
    await api.put(
     `/supplier/jobs/${editingJob}`,
     job
    );
   else
    await api.post(
     '/supplier/jobs',
     job
    );

   setJob(emptyJob);
   setEditingJob(null);

   await load();

   flash(
    'Đã lưu tin tuyển dụng.'
   );

  }catch(e){
   setError(e.message);
  }finally{
   setBusy(false);
  }
 };

 const jobStatus=async(
  id,
  status
 )=>{
  try{

   await api.patch(
    `/supplier/jobs/${id}/status`,
    {
     trang_thai:status
    }
   );

   await load();

   flash(
    'Đã cập nhật trạng thái tin.'
   );

  }catch(e){
   setError(e.message);
  }
 };

 const deleteJob=async(id)=>{

  const confirmed=
   window.confirm(
    'Xóa Tin tuyển dụng khỏi trang công khai?\n\n'+
    'Tin sẽ không còn nhận hồ sơ mới nhưng '+
    'toàn bộ lịch sử tuyển dụng vẫn được bảo toàn.'
   );

  if(!confirmed)
   return;

  try{

   setBusy(true);

   await api.patch(
    `/supplier/jobs/${id}/status`,
    {trang_thai:'da_dong'}
   );

   if(editingJob===id){
    setEditingJob(null);
    setJob(emptyJob);
   }

   await load();

   flash(
    'Đã xóa Tin tuyển dụng khỏi trang công khai. '+
    'Dữ liệu lịch sử vẫn được bảo toàn.'
   );

  }catch(e){
   setError(e.message);
  }finally{
   setBusy(false);
  }
 };

 const submitJobReview=async(id)=>{
  try{

   await api.post(
    `/supplier/jobs/${id}/submit-review`
   );

   await load();

   flash(
    'Đã gửi Tin tuyển dụng để Quản trị viên kiểm tra.'
   );

  }catch(e){
   setError(e.message);
  }
 };

 const applicationStatus=
 async(
  id,
  status,
  note=''
 )=>{
  try{

   await api.patch(
    `/supplier/applications/${id}/status`,
    {
     trang_thai:status,
     ghi_chu:note
    }
   );

   await load();

   flash(
    'Đã cập nhật Đăng ký hồ sơ.'
   );

  }catch(e){
   setError(e.message);
  }
 };

 const openRegistration=async(id)=>{
  try{

   const [
    data,
    contacts
   ]=await Promise.all([
    api.get(
     `/supplier/applications/${id}`
    ),
    api.get(
     `/supplier/applications/${id}/contacts`
    )
   ]);

   setSelectedApplication(data);
   setApplicationContacts(
    contacts||[]
   );

  }catch(e){
   setError(e.message);
  }
 };
 const acceptRegistration=async(id)=>{
   try{

    await api.post(
     `/supplier/applications/${id}/acknowledge`
    );

    await load();
    await openRegistration(id);

    flash(
     'Đã tiếp nhận Đăng ký hồ sơ.'
    );

   }catch(e){
    setError(e.message);
   }
  };

  const callWorker=async(id)=>{
   try{
    const result=await api.post(
     `/supplier/applications/${id}/call`
    );
    flash(
     result?.thong_bao||'Đã tạo yêu cầu gọi qua hệ thống.'
    );
   }catch(e){
    setError(e.message);
   }
  };

  const recordContact=async(
   id,
   payload
  )=>{
   try{

    await api.post(
     `/supplier/applications/${id}/contacts`,
     payload
    );

    await load();
    await openRegistration(id);

    flash(
     'Đã ghi nhận liên hệ.'
    );

   }catch(e){
    setError(e.message);
   }
  };






  const saveProfile=async()=>{
   try{

    await api.put(
     '/supplier/profile',
     profile
    );

    await load();

    flash(
     'Đã cập nhật hồ sơ.'
    );

   }catch(e){
    setError(e.message);
   }
  };

  const submitVerification=
  async()=>{
   try{

    await api.post(
     '/supplier/verification/submit'
    );

    await load();

    flash(
     'Đã gửi hồ sơ xác minh.'
    );

   }catch(e){
    setError(e.message);
   }
  };

  const changePassword=
  async()=>{
   try{

    await api.put(
     '/supplier/password',
     passwordForm
    );

    setPasswordForm({
     mat_khau_hien_tai:'',
     mat_khau_moi:''
    });

    flash(
     'Đã đổi mật khẩu.'
    );

   }catch(e){
    setError(e.message);
   }
  };

  if(!me)
   return (
    <div className="supplier-portal">

     <div className="sp-alert">
      {error||'Đang tải...'}
     </div>

    </div>
   );

  return (
   <div className="supplier-portal">

    <header className="sp-header">

     <div>

      <h1>
       Bảng điều hành Đơn vị sử dụng lao động
      </h1>

      <p>
       {me.ten_nha_cung_ung}
       {' · '}
       {me.ma_nha_cung_ung}
      </p>

     </div>

     <div>

      <Status>
       {me.trang_thai}
      </Status>

      <button
       className="sp-btn secondary"
       onClick={async()=>{
        await api.post(
         '/supplier/logout'
        );

        window.location.reload();
       }}
      >
       Đăng xuất
      </button>

     </div>

    </header>

   {notice&&
    <div className="sp-notice">
     {notice}
    </div>
   }

   {error&&
    <div className="sp-alert">
     {error}

     <button
      onClick={()=>setError('')}
     >
      ×
     </button>
    </div>
   }

   {
    me.tai_khoan_trang_thai!=='hoat_dong'||
    me.trang_thai!=='hoat_dong'||
    me.xac_minh!=='da_xac_minh'
   ?
    <div className="sp-alert">
     <b>Tài khoản đang chờ xác minh.</b>{" "}
     Đơn vị sử dụng lao động chỉ có thể hoàn thiện hồ sơ
     và gửi yêu cầu xác minh. Các chức năng vận hành
     sẽ mở sau khi Quản trị viên kích hoạt.
    </div>
   :
    null
   }

   <nav className="sp-tabs">

    {tabs.map(([id,label])=>
     <button
      key={id}
      className={
       tab===id
        ?'active'
        :''
      }
      onClick={()=>setTab(id)}
     >
      {label}
     </button>
    )}

   </nav>

   {tab==='overview'&&
    <Overview
     me={me}
     jobs={jobs}
     applications={applications}
     setTab={setTab}
     unreadNotifications={unreadNotifications}
    />
   }

   {tab==='jobs'&&
    <section className="sp-grid">
     <div className="sp-card">
      <div className="sp-section-head">
       <div><h2>{editingJob?'Chỉnh sửa Tin tuyển dụng':'Tin tuyển dụng'}</h2><p>Đăng và tự quản lý cơ hội việc làm.</p></div>
       <button className="sp-btn" type="button" onClick={()=>{setJob(emptyJob);setEditingJob(null);}}>+ Tạo tin</button>
      </div>
      <Field label="Tiêu đề" name="tieu_de" value={job.tieu_de} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <Field label="Ngành nghề" name="nganh_nghe" value={job.nganh_nghe} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <Field label="Số lượng" name="so_luong" type="number" value={job.so_luong} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <Field label="Địa điểm" name="dia_diem" value={job.dia_diem} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <Field label="Google Maps" name="google_maps" value={job.google_maps} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <Field label="Lương cơ bản" name="luong_co_ban" type="number" value={job.luong_co_ban} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <Field label="Tổng thu nhập dự kiến" name="tong_thu_nhap_du_kien" type="number" value={job.tong_thu_nhap_du_kien} onChange={(n,v)=>setJob(x=>({...x,[n]:v}))} />
      <label className="sp-field"><span>Mô tả công việc</span><textarea value={job.mo_ta_cong_viec||''} onChange={e=>setJob(x=>({...x,mo_ta_cong_viec:e.target.value}))} /></label>
      <label className="sp-field"><span>Điều kiện tuyển dụng</span><textarea value={job.dieu_kien_tuyen_dung||''} onChange={e=>setJob(x=>({...x,dieu_kien_tuyen_dung:e.target.value}))} /></label>
      <button className="sp-btn" type="button" disabled={busy} onClick={saveJob}>{busy?'Đang lưu...':'Lưu Tin tuyển dụng'}</button>
     </div>
     <div className="sp-card">
      <h3>Tin đã đăng</h3>
      {jobs.map(j=><div className="sp-list" key={j.id}>
       <div><b>{j.tieu_de}</b><small>{j.ma_tin||'—'} · {j.trang_thai}</small></div>
       <div className="sp-actions"><Status>{j.trang_thai}</Status><button type="button" onClick={()=>{setJob({...emptyJob,...j});setEditingJob(j.id);}}>Sửa</button><button type="button" onClick={()=>deleteJob(j.id)}>Đóng tin</button></div>
      </div>)}
      {!jobs.length&&<p>Chưa có Tin tuyển dụng.</p>}
     </div>
    </section>
   }

   {tab==='registrations'&&
    <section className="sp-grid">
     <div className="sp-card">
      <h2>Đăng ký hồ sơ</h2>
      <p>Điểm kết thúc nghiệp vụ của App Website là khi Doanh nghiệp/Nhà cung ứng nhận hồ sơ và có thể liên hệ Người lao động.</p>
      {!applications.length&&<p>Chưa có hồ sơ đăng ký.</p>}
      {applications.map(r=><div className="sp-list" key={r.id}>
       <div><b>{r.ho_ten||'—'}</b><small>{r.ma_ho_so||'—'} · {r.tieu_de||'—'}</small></div>
       <div className="sp-actions"><Status>{r.trang_thai}</Status><button type="button" onClick={()=>openRegistration(r.id)}>Xem hồ sơ</button></div>
      </div>)}
     </div>
     {selectedApplication&&<ApplicationDetail registration={selectedApplication} contacts={applicationContacts} onClose={()=>setSelectedApplication(null)} onAccept={acceptRegistration} onContact={recordContact} onCall={callWorker} onStatus={applicationStatus} />}
    </section>
   }

    {tab==='accounts'&&
    <section className="sp-grid">
     <div className="sp-card">
      <h2>Tài khoản đội ngũ</h2>
      <p>Một Đơn vị sử dụng lao động có thể có nhiều tài khoản đăng nhập đồng thời. Mỗi tài khoản có quyền riêng và được ghi nhật ký thao tác.</p>
      {accounts.map(a=><div className="sp-list" key={a.id}>
       <div><b>{a.ten_hien_thi||a.ten_dang_nhap}</b><small>{a.ten_dang_nhap} · {a.vai_tro} · {a.trang_thai}</small></div>
       <div className="sp-actions">
        <Status>{a.co_quyen_live?'Được Live':'Không Live'}</Status>
        <button type="button" onClick={()=>updateTeamAccount({...a,co_quyen_live:!Number(a.co_quyen_live)})}>{Number(a.co_quyen_live)?'Tắt quyền Live':'Cấp quyền Live'}</button>
        <button type="button" onClick={()=>updateTeamAccount({...a,trang_thai:a.trang_thai==='hoat_dong'?'khoa':'hoat_dong'})}>{a.trang_thai==='hoat_dong'?'Khóa':'Mở khóa'}</button>
       </div>
      </div>)}
     </div>
     <div className="sp-card">
      <h3>Tạo tài khoản thành viên</h3>
      <form onSubmit={createTeamAccount}>
       <Field label="Tên đăng nhập" name="ten_dang_nhap" />
       <Field label="Mật khẩu" name="mat_khau" type="password" />
       <Field label="Tên hiển thị" name="ten_hien_thi" />
       <label className="sp-field"><span>Vai trò</span><select name="vai_tro" defaultValue="nhan_vien"><option value="nhan_vien">Nhân viên</option><option value="quan_ly">Quản lý</option></select></label>
       <label className="sp-field"><span><input type="checkbox" name="co_quyen_live" value="1" /> Cấp quyền Live</span></label>
       <button className="sp-btn" type="submit">Tạo tài khoản</button>
      </form>
     </div>
    </section>
   }

   {tab==='worker-posts'&&
    <section className="sp-card">
     <h2>Người lao động đang tìm việc</h2>
     <p>Số điện thoại không công khai. Kết nối chỉ được thực hiện khi Người lao động đồng ý.</p>
     {workerPosts.map(p=><div className="sp-list" key={p.id}>
      <div><b>{p.tieu_de}</b><small>{p.ten_nguoi_lao_dong} · {p.dia_diem_mong_muon} · {p.thu_nhap_mong_muon||'Thỏa thuận'}</small><small>{p.ky_nang||'Chưa cập nhật kỹ năng'}</small></div>
      <button type="button" disabled={p.trang_thai_ket_noi} onClick={()=>connectWorkerPost(p.id)}>{p.trang_thai_ket_noi==='da_chap_nhan'?'Đã kết nối':p.trang_thai_ket_noi==='cho_nguoi_lao_dong_xac_nhan'?'Đang chờ':'Kết nối'}</button>
     </div>)}
     {!workerPosts.length&&<p>Chưa có Tin tìm việc phù hợp.</p>}
    </section>
   }

   {tab==='live'&&
    <section className="sp-grid">
     <div className="sp-card">
      <h2>Live của Đơn vị sử dụng lao động</h2>
      <p>Quyền Live được cấp riêng cho từng tài khoản. Hạ tầng truyền video thực tế vẫn là lớp phát triển riêng.</p>
      {liveRooms.map(r=><div className="sp-list" key={r.id}><div><b>{r.tieu_de}</b><small>{r.trang_thai} · {r.room_key}</small></div><Status>{r.trang_thai}</Status></div>)}
      {!liveRooms.length&&<p>Chưa có phòng Live.</p>}
     </div>
     <div className="sp-card">
      <h3>Tạo phòng Live</h3>
      <form onSubmit={createLiveRoom}>
       <Field label="Tiêu đề" name="tieu_de" />
       <Field label="Mô tả" name="mo_ta" />
       <Field label="Thời gian dự kiến" name="bat_dau_du_kien" type="datetime-local" />
       <button className="sp-btn" type="submit">Tạo phòng Live</button>
      </form>
     </div>
    </section>
   }

   {tab==='notifications'&&<SupplierNotifications embedded />}

   {tab==='profile'&&
     <section>

      <div className="sp-section-head">

       <div>

        <h2>
         Hồ sơ Đơn vị sử dụng lao động
        </h2>

        <p>
         Hoàn thiện thông tin tài khoản và Đơn vị sử dụng lao động.
        </p>

       </div>

       <button
        type="button"
        className="sp-btn"
        onClick={saveProfile}
       >
        Lưu hồ sơ
       </button>

      </div>

      <div className="sp-grid">

       <div className="sp-card">

        <h3>
         Thông tin cơ bản
        </h3>

        {[
         [
          'ten_nha_cung_ung',
          'Tên Đơn vị sử dụng lao động'
         ],
         [
          'ma_nha_cung_ung',
          'Mã Đơn vị sử dụng lao động'
         ],
         [
          'so_dien_thoai',
          'Số điện thoại'
         ],
         [
          'email',
          'Email'
         ],
         [
          'dia_chi',
          'Địa chỉ'
         ]
        ].map(
         ([name,label])=>
          <Field
           key={name}
           label={label}
           name={name}
           value={profile[name]}
           onChange={(n,v)=>
            setProfile(
             x=>({
              ...x,
              [n]:v
             })
            )
           }
          />
        )}

       </div>

       <div className="sp-card">

        <h3>
         Tin nhắn SMS tự động
        </h3>

        <p>
         Mẫu này được hệ thống tự động dùng khi có hồ sơ đăng ký mới. Đơn vị sử dụng lao động chỉ cần điền một lần.
        </p>

        <label className="sp-field">
         <span>Mẫu SMS đầu tiên</span>
         <textarea
          name="sms_mau_tin_dau_tien"
          value={profile.sms_mau_tin_dau_tien??''}
          maxLength={500}
          placeholder="Xin chao [TEN_NGUOI_LAO_DONG]..."
          onChange={e=>setProfile(x=>({...x,sms_mau_tin_dau_tien:e.target.value}))}
         />
        </label>

        <small>
         Biến được hỗ trợ: [TEN_NGUOI_LAO_DONG], [MA_HO_SO], [TEN_NHA_CUNG_UNG] (tên đơn vị), [TEN_TIN], [MA_TIN].
        </small>

        <div className="sp-actions">
         <Status>Chi phí SMS do Đơn vị sử dụng lao động chịu</Status>
         <Status>{(profile.sms_mau_tin_dau_tien||'').length}/500 ký tự</Status>
        </div>

       </div>

       <div className="sp-card">

        <h3>
         Đổi mật khẩu
        </h3>

        <Field
         label="Mật khẩu hiện tại"
         name="mat_khau_hien_tai"
         type="password"
         value={
          passwordForm.mat_khau_hien_tai
         }
         onChange={(n,v)=>
          setPasswordForm(
           x=>({
            ...x,
            [n]:v
           })
          )
         }
        />

        <Field
         label="Mật khẩu mới"
         name="mat_khau_moi"
         type="password"
         value={
          passwordForm.mat_khau_moi
         }
         onChange={(n,v)=>
          setPasswordForm(
           x=>({
            ...x,
            [n]:v
           })
          )
         }
        />

        <button
         type="button"
         className="sp-btn"
         onClick={changePassword}
        >
         Đổi mật khẩu
        </button>

        <div className="sp-actions">

         <Status>
          Xác minh: {me.xac_minh}
         </Status>

         {me.xac_minh!=='da_xac_minh'&&
          <button
           type="button"
           onClick={submitVerification}
          >
           Gửi yêu cầu xác minh
          </button>
         }

        </div>

       </div>

      </div>

     </section>
    }

   </div>
  );
              }
    
