import React,{useState} from 'react';
import TrustReputation from '../../components/TrustReputation/TrustReputation';

const LABELS={da_mo_so:'Đã đăng ký',da_xem:'Đã xem',da_lien_he:'Đã liên hệ',khong_lien_he_duoc:'Không liên hệ được',da_huy:'Đã hủy'};

const NEXT={da_mo_so:['da_xem'],da_xem:['da_lien_he','khong_lien_he_duoc','da_huy'],da_lien_he:[],khong_lien_he_duoc:['da_lien_he','da_huy'],da_huy:[]};

const METHODS=[
 ['dien_thoai','Điện thoại'],
 ['zalo','Zalo'],
 ['truc_tiep','Trực tiếp'],
 ['khac','Khác']
];

const DIRECTIONS=[
 ['goi_di','Gọi đi'],
 ['nhan_cuoc_goi','Nhận cuộc gọi'],
 ['gap_truc_tiep','Gặp trực tiếp'],
 ['tin_nhan','Tin nhắn']
];

const RESULTS=[
 ['da_lien_he','Đã liên hệ'],
 ['khong_lien_he_duoc','Không liên hệ được'],
 ['khac','Khác']
];

export default function ApplicationDetail({
 registration,
 contacts=[],
 onClose,
 onAccept,
 onContact,
 onCall,
 onStatus
}){

 const [
  contact,
  setContact
 ]=useState({
  loai_lien_he:'dien_thoai',
  ket_qua:'da_lien_he',
  ghi_chu:''
 });

 if(!registration)
  return null;

 const next=
  NEXT[registration.trang_thai]||[];

 const submitContact=async(e)=>{
  e.preventDefault();

  await onContact(
   registration.id,
   contact
  );

  setContact({
   loai_lien_he:'dien_thoai',
   ket_qua:'da_lien_he',
   ghi_chu:''
  });
 };

 return (
  <div className="sp-card sp-registration-detail">

   <div className="sp-section-head">

    <div>

     <h3>
      Chi tiết Hồ sơ đăng ký
     </h3>

     <p>
      {registration.ma_ho_so||'—'}
      {' · '}
      {registration.tieu_de||'—'}
     </p>

    </div>

    <button
     type="button"
     className="sp-btn secondary"
     onClick={onClose}
    >
     Đóng
    </button>

   </div>

   <div className="sp-grid">

    <div className="sp-card">

     <h4>
      Thông tin Người lao động
     </h4>

     <p>
      <b>Họ tên:</b>{' '}
      {registration.ho_ten||'—'}
     </p>

     <p>
      <b>Số điện thoại:</b>{' '}
      {registration.so_dien_thoai_nguoi_lao_dong||'—'}
     </p>

     {registration.nguoi_lao_dong_da_phan_hoi===1&&registration.so_dien_thoai_nguoi_lao_dong&&onCall&&
      <button
       type="button"
       className="sp-btn"
       onClick={()=>onCall(registration.id)}
      >
       Gọi qua hệ thống
      </button>
     }

     <p>
      <b>Quê quán:</b>{' '}
      {registration.que_quan||'—'}
     </p>

     <p>
      <b>Tin tuyển dụng:</b>{' '}
      {registration.tieu_de||'—'}
     </p>

     <p>
      <b>Mã tin:</b>{' '}
      {registration.ma_tin||'—'}
     </p>

     <p>
      <b>Trạng thái:</b>{' '}

      <span className="sp-status">
       {
        LABELS[
         registration.trang_thai
        ]||
        registration.trang_thai
       }
      </span>

     </p>

     <div className="sp-actions">

      {registration.trang_thai==='da_mo_so'&&
       <button
        type="button"
        className="sp-btn"
        onClick={()=>
         onAccept(
          registration.id
         )
        }
       >
        Tiếp nhận hồ sơ
       </button>
      }

      {next.map(status=>

       <button
        key={status}
        type="button"
        onClick={()=>{

         const note=
          window.prompt(
           `Ghi chú khi chuyển sang ${
            LABELS[status]||status
           }:`,
           ''
          );

         if(note!==null)
          onStatus(
           registration.id,
           status,
           note
          );

        }}
       >
        {
         LABELS[status]||
         status
        }
       </button>

      )}

     </div>

    </div>

    <div className="sp-card sp-contact-box">

     <h4>
      Ghi nhận liên hệ
     </h4>

     <form
      onSubmit={submitContact}
     >

      <label className="sp-field">

       <span>
        Phương thức
       </span>

       <select
        value={
         contact.loai_lien_he
        }
        onChange={e=>
         setContact(x=>({
          ...x,
          loai_lien_he:
           e.target.value
         }))
        }
       >

        {METHODS.map(
         ([value,label])=>
          <option
           key={value}
           value={value}
          >
           {label}
          </option>
        )}

       </select>

      </label>

      <label className="sp-field">

       <span>
        Kết quả
       </span>

       <select
        value={
         contact.ket_qua
        }
        onChange={e=>
         setContact(x=>({
          ...x,
          ket_qua:
           e.target.value
         }))
        }
       >

        {RESULTS.map(
         ([value,label])=>
          <option
           key={value}
           value={value}
          >
           {label}
          </option>
        )}

       </select>

      </label>

      <label className="sp-field">

       <span>
        Ghi chú
       </span>

       <textarea
        value={
         contact.ghi_chu
        }
        onChange={e=>
         setContact(x=>({
          ...x,
          ghi_chu:
           e.target.value
         }))
        }
       />

      </label>

      <button
       type="submit"
       className="sp-btn"
      >
       Lưu lần liên hệ
      </button>

     </form>

    </div>

   </div>

   <div className="sp-card sp-contact-history">

    <h4>
     Lịch sử liên hệ
    </h4>

    {!contacts.length&&
     <p>
      Chưa có lần liên hệ nào.
     </p>
    }

    {contacts.map(item=>

     <div
      className="sp-list"
      key={item.id}
     >

      <div>

       <b>
        {item.ket_qua||'—'}
       </b>

       <small>
        {item.loai_lien_he||'—'}

       </small>

       <small>
        {
         item.ghi_chu||
         'Không có ghi chú'
        }
       </small>

      </div>

      <small>
       {item.thoi_gian||'—'}
      </small>

     </div>

    )}

   </div>

  </div>
 );
}
