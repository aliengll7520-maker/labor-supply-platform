import React,{useEffect,useState} from "react";
import MainLayout from "../layouts/MainLayout/MainLayout";
import Card from "../components/Card/Card";
import {api} from "../api";
import ApplicationRegistrationPanel from "./Jobs/ApplicationRegistrationPanel";
import "./Register.css";

function Register(){
 const [job,setJob]=useState(null),[error,setError]=useState(""),[loading,setLoading]=useState(true);
 useEffect(()=>{(async()=>{try{const hash=window.location.hash;const q=hash.split("?")[1]||"";const id=new URLSearchParams(q).get("tin_tuyen_dung_id")||new URLSearchParams(q).get("id");if(!id)throw new Error("Không xác định được Tin tuyển dụng.");setJob(await api.get(`/jobs/public/${id}`));}catch(e){setError(e.message||"Không thể tải Tin tuyển dụng.");}finally{setLoading(false);}})();},[]);
 return <MainLayout><div className="register-page"><Card>{loading&&<p>Đang tải Tin tuyển dụng...</p>}{error&&<p className="register-error">{error}</p>}{job&&<ApplicationRegistrationPanel job={job}/>}</Card></div></MainLayout>;
}
export default Register;
