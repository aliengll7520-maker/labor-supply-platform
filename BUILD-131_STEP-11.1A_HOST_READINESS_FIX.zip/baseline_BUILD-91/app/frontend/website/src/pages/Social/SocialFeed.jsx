import React,{useEffect,useState} from 'react';
import {api} from '../../api';
import './SocialFeed.css';
import AdNetworkSlot from '../../components/Ads/AdNetworkSlot';

const typeLabel={cap_nhat:'Cập nhật',viec_lam:'Việc làm',tim_viec:'Tìm việc',kien_thuc:'Kiến thức',hoi_dap:'Hỏi đáp'};
const reportReasons='spam / lua_dao / noi_dung_khong_phu_hop / quay_roi / thong_tin_sai / khac';
const responsiveImageSources=(url)=>{
 const value=String(url||'');
 const marker='/web.webp';
 const index=value.lastIndexOf(marker);
 if(index<0)return null;
 const thumb=value.slice(0,index)+'/thumb.webp';
 return `${thumb} 400w, ${value} 2000w`;
};

export default function SocialFeed(){
 const [posts,setPosts]=useState([]),[text,setText]=useState(''),[kind,setKind]=useState('cap_nhat'),[tags,setTags]=useState(''),[images,setImages]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(true),[loadingMore,setLoadingMore]=useState(false),[nextCursor,setNextCursor]=useState(null),[comments,setComments]=useState({}),[commentText,setCommentText]=useState({}),[replyTo,setReplyTo]=useState({});
 const load=async()=>{setLoading(true);try{const r=await api.get('/social/feed?limit=30');setPosts(r.posts||[]);setNextCursor(r.next_cursor||null);setError('')}catch(e){setError(e.message)}finally{setLoading(false)}};
 const loadMore=async()=>{if(!nextCursor||loadingMore)return;setLoadingMore(true);try{const r=await api.get(`/social/feed?limit=30&cursor=${encodeURIComponent(nextCursor)}`);setPosts(x=>[...x,...(r.posts||[])]);setNextCursor(r.next_cursor||null);setError('')}catch(e){setError(e.message)}finally{setLoadingMore(false)}};
 useEffect(()=>{load()},[]);
 const publish=async()=>{if(!text.trim()){setError('Hãy viết nội dung trước khi đăng.');return}const imageList=images.split(/\n|,/).map(x=>x.trim()).filter(Boolean);if(imageList.length>6){setError('Mỗi bài viết tối đa 6 ảnh. Vui lòng xóa ảnh thứ 7 trở đi.');return}try{await api.post('/social/posts',{noi_dung:text,loai_bai_dang:kind,hashtag:tags,anh_urls:imageList});setText('');setTags('');setImages('');setError('');load()}catch(e){setError(e.message)}};
 const like=async(id)=>{try{await api.post(`/social/posts/${id}/like`);load()}catch(e){setError(e.message)}};
 const share=async(id)=>{try{await api.post(`/social/posts/${id}/share`,{});load()}catch(e){setError(e.message)}};
 const follow=async(p)=>{try{await api.post(`/social/follow/${p.loai_tac_gia}/${p.tac_gia_id}`,{});setError('')}catch(e){setError(e.message)}};
 const loadComments=async(id)=>{try{const r=await api.get(`/social/posts/${id}/comments`);setComments(x=>({...x,[id]:r.comments||[]}))}catch(e){setError(e.message)}};
 const addComment=async(id,parentId=0)=>{const key=parentId?`reply-${parentId}`:`post-${id}`;const value=(commentText[key]||'').trim();if(!value)return;try{await api.post(`/social/posts/${id}/comments`,{noi_dung:value,tra_loi_cho_id:parentId||null});setCommentText(x=>({...x,[key]:''}));setReplyTo(x=>({...x,[id]:0}));loadComments(id);load()}catch(e){setError(e.message)}};
 const reportComment=async(id)=>{const reason=window.prompt(`Lý do báo cáo bình luận: ${reportReasons}`,'noi_dung_khong_phu_hop');if(!reason)return;try{await api.post(`/social/comments/${id}/report`,{ly_do:reason});setError('Đã gửi báo cáo bình luận.')}catch(e){setError(e.message)}};
 const report=async(id)=>{const reason=window.prompt(`Lý do báo cáo: ${reportReasons}`,'noi_dung_khong_phu_hop');if(!reason)return;try{await api.post(`/social/posts/${id}/report`,{ly_do:reason});setError('Đã gửi báo cáo.')}catch(e){setError(e.message)}};
 const renderComments=(postId)=>{
   const list=comments[postId]||[], roots=list.filter(c=>!c.tra_loi_cho_id), replies=list.filter(c=>c.tra_loi_cho_id);
   const renderOne=(c,depth=0)=><div className="social-comment" key={c.id} style={{marginLeft:Math.min(depth,3)*18}}>
     <b>{c.ten_tac_gia||'Thành viên'}</b><div>{c.noi_dung}</div>
     <div className="social-row social-comment-actions"><button className="social-button secondary" onClick={()=>setReplyTo(x=>({...x,[postId]:c.id}))}>Trả lời</button><button className="social-button secondary" onClick={()=>reportComment(c.id)}>Báo cáo</button></div>
     {replyTo[postId]===c.id&&<div className="social-comment-form"><input placeholder="Viết câu trả lời..." value={commentText[`reply-${c.id}`]||''} onChange={e=>setCommentText(x=>({...x,[`reply-${c.id}`]:e.target.value}))}/><button className="social-button" onClick={()=>addComment(postId,c.id)}>Gửi</button></div>}
     {replies.filter(r=>Number(r.tra_loi_cho_id)===Number(c.id)).map(r=>renderOne(r,depth+1))}
   </div>;
   return <div className="social-comments">{roots.map(c=>renderOne(c))}{!list.length&&<div className="social-meta">Chưa có bình luận.</div>}<div className="social-comment-form"><input placeholder="Viết bình luận..." value={commentText[`post-${postId}`]||''} onChange={e=>setCommentText(x=>({...x,[`post-${postId}`]:e.target.value}))}/><button className="social-button" onClick={()=>addComment(postId)}>Gửi</button></div></div>;
 };
 return <main className="social-page">
  <header className="social-head"><div><h1>Mạng xã hội việc làm</h1><p>Chia sẻ nghề nghiệp, việc làm, kiến thức và cơ hội kết nối.</p></div><button className="social-button secondary" onClick={load}>Làm mới</button></header>
  {error&&<div className="social-error">{error}</div>}
  <section className="social-card social-compose"><textarea placeholder="Bạn đang muốn chia sẻ điều gì về công việc hoặc nghề nghiệp?" value={text} onChange={e=>setText(e.target.value)}/><div className="social-row" style={{marginTop:10}}><select value={kind} onChange={e=>setKind(e.target.value)}>{Object.entries(typeLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select><input placeholder="#hashtag (tùy chọn)" value={tags} onChange={e=>setTags(e.target.value)}/><input placeholder="Đường dẫn ảnh (tối đa 6 ảnh, mỗi ảnh một dòng)" value={images} onChange={e=>setImages(e.target.value)}/><button className="social-button" onClick={publish}>Đăng bài</button></div></section>
  <AdNetworkSlot placement="feed"/>{loading?<div className="social-empty">Đang tải Feed...</div>:posts.length===0?<div className="social-card social-empty">Chưa có bài đăng công khai.</div>:posts.map(p=><article className="social-card" key={p.id}><div><span className="social-author">{p.ten_tac_gia||'Thành viên'}</span><span className="social-type">{typeLabel[p.loai_bai_dang]||p.loai_bai_dang} · {p.ngay_tao}</span></div><div className="social-content">{p.noi_dung}</div>{Array.isArray(p.anh_urls)&&p.anh_urls.length>0&&<div className={`social-images social-images-${Math.min(p.anh_urls.length,6)}`}>{p.anh_urls.slice(0,6).map((url,i)=><img key={`${p.id}-image-${i}`} src={url} srcSet={responsiveImageSources(url)||undefined} alt="" loading="lazy" decoding="async" sizes="(max-width: 768px) 100vw, 640px" referrerPolicy="no-referrer" onError={e=>{e.currentTarget.style.display="none"}} />)}</div>}{p.hashtag&&<div className="social-tags">{p.hashtag}</div>}<div className="social-actions"><button className="social-button secondary" onClick={()=>like(p.id)}>{p.da_thich?'Bỏ thích':'Thích'} · {p.luot_thich}</button><button className="social-button secondary" onClick={()=>loadComments(p.id)}>Bình luận · {p.luot_binh_luan}</button><button className="social-button secondary" onClick={()=>share(p.id)}>Chia sẻ · {p.luot_chia_se}</button><button className="social-button secondary" onClick={()=>follow(p)}>Theo dõi</button><button className="social-button secondary" onClick={()=>report(p.id)}>Báo cáo</button></div>{comments[p.id]&&renderComments(p.id)}</article>)}{nextCursor&&<div className="social-row" style={{justifyContent:'center',margin:'16px 0'}}><button className="social-button secondary" onClick={loadMore} disabled={loadingMore}>{loadingMore?'Đang tải...':'Xem thêm'}</button></div>}
 </main>
}
