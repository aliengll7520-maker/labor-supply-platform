import React,{useEffect,useState} from 'react';
import {api} from '../../api';
import './OperationsCenter.css';

const labels={healthy:'Bình thường',warning:'Cảnh báo',critical:'Nghiêm trọng'};
export default function OperationsCenter(){
 const [data,setData]=useState(null),[alerts,setAlerts]=useState([]),[exceptions,setExceptions]=useState(null),[error,setError]=useState('');
 const load=async()=>{try{const [d,a,e]=await Promise.all([api.get('/admin/operations/overview'),api.get('/admin/operations/alerts'),api.get('/admin/operations/exceptions')]);setData(d);setAlerts(a.alerts||[]);setExceptions(e);setError('')}catch(e){setError(e.message)}};
 useEffect(()=>{load();const t=setInterval(load,30000);return()=>clearInterval(t)},[]);
 if(error)return <div className="ops-page"><h1>Trung tâm vận hành</h1><p className="ops-error">{error}</p></div>;
 if(!data)return <div className="ops-page"><h1>Trung tâm vận hành</h1><p>Đang tải trạng thái hệ thống...</p></div>;
 const q=data.queues||{};
 return <div className="ops-page">
  <header><div><h1>Trung tâm vận hành</h1><p>Hệ thống tự theo dõi tải, hàng đợi và các ngoại lệ. Quản trị chỉ xử lý những việc cần can thiệp.</p></div><button onClick={load}>Làm mới</button></header>
  <div className="ops-status"><strong>{labels[data.status]||data.status}</strong><span>Cập nhật {data.collected_at}</span></div>
  <div className="ops-cards">
   <div><span>Queue đang chờ</span><b>{data.summary.queued}</b></div><div><span>Đang xử lý</span><b>{data.summary.processing}</b></div><div><span>Dead Letter</span><b>{data.summary.dead}</b></div><div><span>Cảnh báo mở</span><b>{data.summary.open_alerts}</b></div>
  </div>
  <section><h2>Queue</h2><div className="ops-table"><div className="ops-tr ops-head"><b>Queue</b><b>Chờ</b><b>Đang xử lý</b><b>Dead</b><b>Chờ lâu nhất</b></div>{Object.entries(q).map(([name,s])=><div className="ops-tr" key={name}><span>{name}</span><span>{s.queued}</span><span>{s.processing}</span><span>{s.dead}</span><span>{s.oldest_queued_seconds}s</span></div>)}</div></section>
  <section><h2>Ngoại lệ cần Quản trị xem</h2>{alerts.length?alerts.map(a=><div className={`ops-alert ${a.severity}`} key={a.id||a.fingerprint}><b>{a.severity.toUpperCase()}</b><span>{a.message}</span><small>{a.source}/{a.code}</small></div>):<p>Không có ngoại lệ đang mở.</p>}</section>
  {exceptions&&<section><h2>Self-healing & Discovery</h2><div className="ops-runtime"><span>Reconciliation 24h: {exceptions.discovery?.reconciliation_runs_24h??0}</span><span>Đã requeue: {exceptions.discovery?.requeued_24h??0}</span><span>Failed requeue: {exceptions.discovery?.failed_requeued_24h??0}</span><span>Orphaned: {exceptions.discovery?.orphaned_24h??0}</span><span>Failed events: {exceptions.discovery?.failed_events_24h??0}</span></div></section>}
  <section><h2>Sức khỏe máy chủ</h2><div className="ops-runtime"><span>PHP: {data.runtime.php}</span><span>DB: {data.database.status} · {data.database.latency_ms}ms</span><span>RAM: {data.runtime.memory.usage_percent??'—'}%</span><span>Disk trống: {data.storage.free_percent??'—'}%</span></div></section>
 </div>;
}
