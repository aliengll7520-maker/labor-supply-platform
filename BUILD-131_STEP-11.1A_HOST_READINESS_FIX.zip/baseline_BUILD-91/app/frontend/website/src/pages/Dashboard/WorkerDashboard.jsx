import React,{useState} from "react";
import {api} from "../../api";
import "./Dashboard.css";

export default function WorkerDashboard(){
 const [f,setF]=useState({so_dien_thoai:"",ma_ho_so:""}),[d,setD]=useState(null),[error,setError]=useState("");

 const load=async e=>{
   e.preventDefault();
   try{
     setD(await api.post("/dashboard/worker",f));
     setError("");
   }catch(e){
     setError(e.message);
   }
 };

 return <div className="dashboard-page">
   <h1>Dashboard Người lao động</h1>

   <div className="dashboard-actions"><button type="button" onClick={()=>{window.location.hash="#/worker-job-seeking"}}>ĐĂNG TIN TÌM VIỆC</button></div>

   <form className="dashboard-form" onSubmit={load}>
     <input
       placeholder="Số điện thoại"
       required
       value={f.so_dien_thoai}
       onChange={e=>setF({...f,so_dien_thoai:e.target.value})}
     />

     <input
       placeholder="Mã hồ sơ"
       required
       value={f.ma_ho_so}
       onChange={e=>setF({...f,ma_ho_so:e.target.value})}
     />

     <button>TRA CỨU</button>
   </form>

   {error&&<p>{error}</p>}

   {d&&<>
     <h2>{d.ho_so.tieu_de}</h2>

     <p>Đơn vị sử dụng lao động: {d.ho_so.ten_nha_cung_ung}</p>

     <div className="dashboard-cards">

       <div className="dashboard-card">
         <span>Trạng thái hồ sơ</span>
         <strong>{d.ho_so.trang_thai}</strong>
       </div>

       <div className="dashboard-card">
         <span>Thông báo chưa đọc</span>
         <strong>{d.thong_bao_chua_doc}</strong>
       </div>

     </div>
   </>}
 </div>
}
