import React,{useEffect,useState} from "react";
import {api} from "../../api";
import "./Dashboard.css";

export default function AdminDashboard(){
 const [d,setD]=useState(null),[error,setError]=useState("");

 useEffect(()=>{
   api.get("/dashboard/admin")
     .then(setD)
     .catch(e=>setError(e.message))
 },[]);

 if(error)return <div className="dashboard-page"><p>{error}</p></div>;
 if(!d)return <div className="dashboard-page"><p>Đang tải Dashboard...</p></div>;

 const cards=[
   ["Nhà cung ứng",d.nha_cung_ung],
   ["Cần xử lý NCC",d.ncc_cho_duyet],
   ["Tin đang tuyển",d.tin_dang_tuyen],
   ["Hồ sơ mới",d.ho_so_moi],
   ["Thông báo chưa đọc",d.thong_bao_chua_doc]
 ];

 return <div className="dashboard-page">
   <h1>Dashboard Quản trị</h1>
   <p>Tổng quan vận hành và các việc cần xử lý.</p>
   <p><a href="#/operations">Mở Trung tâm vận hành →</a></p>

   <div className="dashboard-cards">
     {cards.map(x=>
       <div className="dashboard-card" key={x[0]}>
         <span>{x[0]}</span>
         <strong>{x[1]}</strong>
       </div>
     )}
   </div>

   <section className="dashboard-section">
     <h2>Nhà cung ứng cần xử lý</h2>

     {d.ncc_can_xu_ly.map(x=>
       <div className="dashboard-row" key={x.id}>
         <b>{x.ma_nha_cung_ung}</b>
         <span>{x.ten_nha_cung_ung}</span>
         <span>{x.xac_minh}</span>
         <span>{x.trang_thai}</span>
       </div>
     )}

     {!d.ncc_can_xu_ly.length&&
       <p>Không có Đơn vị sử dụng lao động đang chờ xử lý.</p>
     }
   </section>
 </div>
}
