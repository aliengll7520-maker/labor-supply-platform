import React from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import "./Policies.css";

export default function PolicyDocument({title, intro, sections=[], version="3.0"}){
 return <MainLayout><article className="policy-document">
   <div className="policy-doc-head"><span>Phiên bản {version}</span><h1>{title}</h1><p>{intro}</p></div>
   {sections.map(([h,body])=><section key={h}><h2>{h}</h2><div>{body}</div></section>)}
   <p className="policy-updated">Trạng thái: nội dung sản phẩm để công khai và tiếp tục rà soát trước khi app và website phát hành chính thức.</p>
 </article></MainLayout>;
}
