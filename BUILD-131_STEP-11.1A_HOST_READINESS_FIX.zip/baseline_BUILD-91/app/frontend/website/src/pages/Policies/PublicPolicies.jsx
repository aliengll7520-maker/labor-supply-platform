import React from "react";
import PolicyDocument from "./PolicyDocument";

const FreeModelNote = () => (
  <p>
    <b>Sử dụng miễn phí:</b> App và website không thu phí Người lao động hoặc Đơn vị sử dụng lao động đối với các chức năng cộng đồng miễn phí được công bố như tạo tài khoản, xem việc, đăng việc và đăng Tin tìm việc.
  </p>
);

const docs = {
  about: [
    ["App và website là gì?", <><FreeModelNote/><p>App và website là nơi kết nối việc làm miễn phí dành cho cộng đồng. Người lao động có thể tìm việc, đăng Tin tìm việc, xây dựng hồ sơ nghề nghiệp và chia sẻ nội dung. Doanh nghiệp có thể giới thiệu nhu cầu tuyển dụng, đăng tin tuyển dụng, xây dựng hồ sơ và chủ động kết nối với Người lao động.</p></>],
    ["Hai vai trò có thể cùng tồn tại", <p>Một người có thể tham gia với tư cách Người lao động và sau này đăng ký thêm không gian Đơn vị sử dụng lao động nếu có doanh nghiệp, hộ kinh doanh, tổ chức hoặc nhu cầu sử dụng lao động. Hai vai trò không loại trừ nhau.</p>],
    ["Môi trường cộng đồng", <p>App và website cung cấp khung để cộng đồng tự tạo nội dung, tự tìm hiểu và tự quyết định việc kết nối. App và website không thay thế sự kiểm tra, thỏa thuận và quyết định của các bên.</p>],
    ["Quảng cáo bên thứ ba", <p>App và website có thể hiển thị quảng cáo do mạng quảng cáo bên thứ ba tự động phân phối. App và website không tự bán vị trí quảng cáo cho từng doanh nghiệp trong mô hình này. Nếu chương trình quảng cáo có cơ chế chia sẻ doanh thu, app và website có thể nhận doanh thu theo chính sách của nhà cung cấp quảng cáo.</p>],
  ],
  terms: [
    ["Tài khoản", <p>Người dùng cung cấp thông tin trung thực, bảo vệ tài khoản và chỉ sử dụng tài khoản, quyền truy cập của mình.</p>],
    ["Sử dụng miễn phí", <FreeModelNote/>],
    ["Nội dung do người dùng tạo", <p>Người đăng tin, bài viết, video hoặc thông tin hồ sơ chịu trách nhiệm về tính chính xác và tính hợp pháp của nội dung do mình cung cấp.</p>],
    ["Quan hệ giữa Người lao động và doanh nghiệp", <p>App và website cung cấp môi trường để hai bên tự tìm hiểu và kết nối. App và website không phải là bên của hợp đồng lao động hoặc thỏa thuận riêng giữa các bên.</p>],
    ["Tiền, lương, tiền cọc và chi phí", <p>App và website không phải là bên nhận, giữ hoặc chuyển tiền thay cho người dùng trong các giao dịch riêng giữa Người lao động và doanh nghiệp, trừ khi một chức năng cụ thể được công bố rõ ràng. Người dùng phải tự kiểm tra, tự thỏa thuận và tự quyết định trước khi chuyển tiền hoặc cam kết tài chính.</p>],
    ["Không bảo đảm giao dịch riêng", <p>App và website không bảo đảm khả năng thanh toán, mức lương, tiền cọc hoặc lời hứa tài chính của người dùng khác. Quy định này không loại trừ bất kỳ trách nhiệm pháp lý bắt buộc nào áp dụng cho app và website.</p>],
    ["Nội dung bị cấm", <p>Không lừa đảo, mạo danh, spam, chiếm đoạt dữ liệu, đăng thông tin sai lệch có chủ ý hoặc sử dụng app và website cho hoạt động trái pháp luật.</p>],
    ["Cập nhật", <p>Điều khoản có thể được cập nhật khi chức năng hoặc quy định pháp luật thay đổi. Phiên bản hiện hành được công bố tại Trung tâm chính sách.</p>],
  ],
  privacy: [
    ["Nguyên tắc tự quản lý và giới hạn quyền can thiệp của Quản trị viên", <div>
      <p><b>App Website</b> được xây dựng theo nguyên tắc: <b>Người dùng tự quản lý hoạt động của mình — Hệ thống tự vận hành — Quản trị viên chỉ xử lý các trường hợp ngoại lệ.</b></p>
      <p><b>Doanh nghiệp / Nhà cung ứng</b> và <b>Người lao động</b> chịu trách nhiệm trực tiếp đối với các thông tin, hồ sơ và hoạt động do mình tạo lập hoặc quản lý trên App Website.</p>
      <p>App Website cung cấp các công cụ cần thiết để Doanh nghiệp / Nhà cung ứng và Người lao động tự quản lý hoạt động của mình theo phạm vi chức năng được cung cấp.</p>
      <h4>Giới hạn quyền can thiệp của Quản trị viên</h4>
      <p>Quản trị viên <b>không quản lý thay</b> hoạt động thông thường của Doanh nghiệp / Nhà cung ứng hoặc Người lao động.</p>
      <p>Quản trị viên không can thiệp thường xuyên vào:</p>
      <ul>
        <li>Chấm công;</li>
        <li>Ca làm;</li>
        <li>Xác nhận giờ làm;</li>
        <li>Quá trình làm việc;</li>
        <li>Tiền lương;</li>
        <li>Thu nhập;</li>
        <li>Thanh toán;</li>
        <li>Quan hệ lao động thực tế giữa các bên;</li>
        <li>Các hoạt động nội bộ khác do Doanh nghiệp / Nhà cung ứng và Người lao động tự quản lý.App Website không cung cấp chức năng chấm công, quản lý ca làm, hồ sơ làm việc, nghỉ việc hoặc quản lý nhân sự nội bộ. Các hoạt động này do Doanh nghiệp/Nhà cung ứng và Người lao động tự quản lý.  App Website không bắt buộc Doanh nghiệp / Nhà cung ứng phải sử dụng và Quản trị viên không quản lý thay các bên.</p>
      <h4>Khi nào Quản trị viên được can thiệp?</h4>
      <p>Quyền truy cập và can thiệp của Quản trị viên được giới hạn ở mức cần thiết để:</p>
      <ul>
        <li>bảo vệ an toàn hệ thống;</li>
        <li>bảo vệ quyền riêng tư;</li>
        <li>xử lý báo cáo;</li>
        <li>xử lý spam;</li>
        <li>xử lý gian lận;</li>
        <li>xử lý nội dung vi phạm;</li>
        <li>xử lý tài khoản có nguy cơ;</li>
        <li>bảo vệ thông tin liên hệ, bao gồm cơ chế <b>ẩn số điện thoại</b> khi cần thiết;</li>
        <li>xử lý sự cố kỹ thuật;</li>
        <li>xử lý các trường hợp ngoại lệ cần thiết khác.</li>
      </ul>
      <p>Trong trường hợp cần can thiệp, Quản trị viên chỉ thực hiện trong <b>phạm vi tối thiểu cần thiết</b>, phù hợp với mục đích xử lý và nguyên tắc bảo vệ dữ liệu của người dùng.</p>
      <p>Các hoạt động quản trị quan trọng có thể được ghi nhận trong nhật ký hệ thống nhằm bảo đảm khả năng kiểm tra và truy vết.</p>
      <h4>Phạm vi trách nhiệm của App Website</h4>
      <blockquote><p><b>App Website không tự nhận mình là người quản lý lao động, người sử dụng lao động, đơn vị chấm công, đơn vị trả lương hoặc bên trực tiếp điều hành quan hệ lao động giữa Doanh nghiệp / Nhà cung ứng và Người lao động.</b></p></blockquote>
      <p>App Website chủ yếu cung cấp <b>môi trường kết nối, công cụ tự quản lý và hệ thống tự động hỗ trợ cộng đồng</b>.</p>
      <p><b>Doanh nghiệp / Nhà cung ứng tự quản lý hoạt động của mình.</b><br/><b>Người lao động tự quản lý hoạt động của mình.</b><br/><b>App Website tự động vận hành trong phạm vi được thiết kế.</b><br/><b>Quản trị viên chỉ can thiệp khi thật sự cần thiết.</b></p>
    </div>],
    ["Ranh giới nghiệp vụ tuyển dụng", <p><b>App Website tập trung vào kết nối việc làm.</b> Quy trình nghiệp vụ kết thúc ở phạm vi Người lao động đăng ký hồ sơ, Doanh nghiệp / Nhà cung ứng tiếp nhận hồ sơ và có thể liên hệ. App Website không quản lý việc Người lao động có đi làm hay không, không quản lý chấm công, ca làm, hồ sơ làm việc, nghỉ việc, tiền lương hoặc các hoạt động nhân sự nội bộ sau khi hai bên đã kết nối. Các hoạt động đó do các bên tự quản lý và tự chịu trách nhiệm theo thỏa thuận và pháp luật áp dụng.</p>],
    ["Nguyên tắc", <p>App và website xử lý dữ liệu cá nhân theo mục đích rõ ràng, trong phạm vi cần thiết cho chức năng đã cung cấp, với quyền truy cập phù hợp và các biện pháp bảo vệ dữ liệu.</p>],
    ["Dữ liệu có thể được xử lý", <p>Tùy chức năng, có thể gồm họ tên, số điện thoại, email, thông tin đăng nhập, hồ sơ nghề nghiệp, hồ sơ ứng tuyển, nội dung đăng tải, tương tác xã hội, thông tin thiết bị, nhật ký bảo mật và dữ liệu cần thiết để vận hành app và website.</p>],
    ["Dùng dữ liệu để làm gì?", <p>Dữ liệu có thể được dùng để tạo và bảo vệ tài khoản, cung cấp chức năng tìm việc và kết nối, gửi thông báo, chống spam và lạm dụng, xử lý sự cố, cải thiện hoạt động của app và website và thực hiện các nghĩa vụ theo pháp luật.</p>],
    ["Không quản lý tiền riêng của người dùng", <p>App và website không xây dựng hệ thống đối soát, phiếu thanh toán hoặc sổ thu nhập để quản lý giao dịch tiền riêng giữa Người lao động và doanh nghiệp. App và website không yêu cầu người dùng cung cấp thông tin tài khoản thanh toán hoặc mã giao dịch riêng chỉ để sử dụng chức năng kết nối việc làm miễn phí.</p>],
    ["Không bán dữ liệu cá nhân", <p>App và website không xây dựng mô hình bán dữ liệu cá nhân của Người lao động hoặc Đơn vị sử dụng lao động cho bên thứ ba để đổi lấy tiền.</p>],
    ["Nhà cung cấp dịch vụ", <p>App và website có thể sử dụng nhà cung cấp cần thiết để vận hành như lưu trữ, bảo mật, thông báo, phân tích kỹ thuật hoặc các dịch vụ khác. Việc xử lý dữ liệu trong từng trường hợp phải tuân theo mục đích và yêu cầu pháp luật áp dụng.</p>],
    ["Quảng cáo bên thứ ba", <p>Nếu app và website sử dụng mạng quảng cáo bên thứ ba, nhà cung cấp quảng cáo có thể xử lý một số dữ liệu kỹ thuật, thông tin ngữ cảnh hoặc mã nhận diện quảng cáo theo cơ chế của họ và các lựa chọn quyền riêng tư được cung cấp.</p>],
    ["Bảo vệ số điện thoại và thông tin liên hệ", <div>
      <p><b>Số điện thoại đầy đủ không được hiển thị công khai trên App Website dưới bất kỳ hình thức nào.</b></p>
      <p>Số điện thoại là dữ liệu liên hệ được bảo vệ. Khi cần hiển thị cho một mục đích được phép, hệ thống phải sử dụng dạng che, ví dụ <b>091***5678</b>, thay vì hiển thị số đầy đủ.</p>
      <p>Nguyên tắc này áp dụng cho hồ sơ công khai, Tin tuyển dụng, Tin tìm việc, bài đăng, bình luận, trả lời bình luận, hồ sơ nghề nghiệp, kết quả tìm kiếm, nội dung liên quan, đề xuất, thông báo công khai và các khu vực công khai khác.</p>
      <p>Người dùng không được đưa số điện thoại đầy đủ vào nội dung công khai hoặc cố tình sử dụng các biến thể nhằm né cơ chế bảo vệ. Hệ thống có thể tự động phát hiện và từ chối nội dung chứa thông tin liên hệ không được phép.</p>
      <p>Việc kết nối giữa Doanh nghiệp / Nhà cung ứng và Người lao động được ưu tiên thực hiện thông qua các cơ chế kết nối của App Website nhằm hạn chế spam, thu thập số hàng loạt và các cuộc gọi không mong muốn.</p>
    </div>],
    ["Bảo vệ liên kết bên ngoài trong nội dung người dùng", <div>
      <p>Người dùng có tài khoản hợp lệ được tham gia bình luận, trả lời bình luận và tạo nội dung cộng đồng theo chính sách của App Website. Tuy nhiên, <b>nội dung do người dùng tạo không được chứa liên kết dẫn tới website hoặc dịch vụ bên ngoài App Website</b>.</p>
      <p>Quy định này áp dụng cho bài đăng, bình luận, trả lời bình luận và các trường nội dung công khai tương tự. Hệ thống có thể tự động phát hiện URL, tên miền, liên kết rút gọn hoặc các biến thể được sử dụng để né bộ lọc và từ chối nội dung vi phạm.</p>
      <p>Khi nội dung bị từ chối vì chứa liên kết bên ngoài, người dùng được thông báo lý do và có thể chỉnh sửa nội dung để tiếp tục đăng.</p>
      <p>Các liên kết nội bộ do hệ thống tạo ra để phục vụ chức năng của App Website không thuộc phạm vi cấm này.</p>
      <p>Nguyên tắc này nhằm hạn chế spam, quảng cáo trá hình, phishing, link farm, chuyển hướng người dùng và việc lợi dụng nội dung cộng đồng để phát tán liên kết không mong muốn.</p>
    </div>],
    ["Đăng nhập Google", <p>Khi Người lao động đăng nhập bằng Google, app và website xử lý thông tin Google cung cấp trong phạm vi cần thiết cho xác thực và liên kết tài khoản. App và website không nhận hoặc lưu mật khẩu Google.</p>],
    ["Quyền của người dùng", <p>Người dùng có các quyền đối với dữ liệu cá nhân theo pháp luật áp dụng và các cơ chế mà app và website cung cấp. Yêu cầu liên quan đến dữ liệu có thể được tiếp nhận và xử lý theo quy trình của app và website.</p>],
    ["Sự cố dữ liệu", <p>App và website duy trì cơ chế phát hiện, ghi nhận và xử lý sự cố dữ liệu. Việc thông báo, phối hợp hoặc báo cáo được thực hiện khi pháp luật yêu cầu.</p>],
  ],
  security: [
    ["Bảo vệ tài khoản", <p>App và website áp dụng xác thực, quản lý phiên và token, phân quyền và các biện pháp phù hợp để hạn chế truy cập trái phép.</p>],
    ["Bảo vệ dữ liệu", <p>Dữ liệu được giới hạn theo vai trò và mục đích. Số điện thoại và thông tin riêng tư không được đưa vào nội dung công khai nếu không cần thiết.</p>],
    ["Bảo vệ API và hệ thống", <p>App và website sử dụng các lớp kiểm soát truy cập, xác thực API, kiểm tra quyền và ghi nhận hoạt động quan trọng để giảm nguy cơ truy cập hoặc sử dụng trái phép.</p>],
    ["Audit và xử lý sự cố", <p>Các thao tác quan trọng được lưu vết để phục vụ kiểm tra, xử lý sự cố và bảo vệ cộng đồng. Khi phát hiện sự cố, app và website có quy trình hạn chế phạm vi ảnh hưởng và khôi phục hoạt động phù hợp.</p>],
    ["Không có cam kết an toàn tuyệt đối", <p>Không có hệ thống Internet nào có thể loại bỏ mọi rủi ro. Mục tiêu của app và website là giảm nguy cơ, phát hiện sớm, hạn chế phạm vi ảnh hưởng và cải thiện biện pháp bảo vệ.</p>],
  ],
  worker: [
    ["Quyền", <ul><li>Tìm việc và xem nội dung công khai miễn phí.</li><li>Đăng Tin tìm việc và nội dung nghề nghiệp.</li><li>Chủ động chấp nhận hoặc từ chối yêu cầu kết nối.</li><li>Quản lý hồ sơ nghề nghiệp và dữ liệu theo chức năng.</li></ul>],
    ["Có thể đồng thời là chủ doanh nghiệp", <p>Nếu Người lao động có doanh nghiệp hoặc sử dụng lao động, có thể đăng ký thêm không gian Đơn vị sử dụng lao động. Việc này không làm mất tài khoản Người lao động.</p>],
    ["Trách nhiệm", <ul><li>Cung cấp thông tin trung thực.</li><li>Không mạo danh, lừa đảo hoặc xâm phạm dữ liệu người khác.</li><li>Tự kiểm tra các thỏa thuận về công việc, lương và giao dịch với đối tác.</li></ul>],
  ],
  employer: [
    ["Quyền", <ul><li>Tạo không gian Đơn vị sử dụng lao động miễn phí.</li><li>Đăng tin tuyển dụng và tạo nội dung nghề nghiệp.</li><li>Tiếp nhận và chủ động kết nối Người lao động.</li><li>Quản lý nhiều thành viên trong cùng không gian theo quyền.</li></ul>],
    ["Trách nhiệm", <ul><li>Thông tin tuyển dụng phải trung thực và phù hợp pháp luật.</li><li>Tự chịu trách nhiệm về hợp đồng lao động, tiền lương, điều kiện làm việc và các nghĩa vụ với Người lao động.</li><li>Không yêu cầu hoặc thu các khoản trái pháp luật thông qua app và website.</li></ul>],
  ],
  posting: [
    ["Tự động kiểm tra", <p>Tin có thể được kiểm tra tự động trước hoặc sau khi xuất bản.</p>],
    ["Kiểm duyệt", <p>Nội dung có dấu hiệu rủi ro có thể được đưa vào hàng chờ Quản trị hoặc bị hạn chế theo nội quy.</p>],
    ["Trách nhiệm người đăng", <p>Người đăng chịu trách nhiệm về nội dung và các nghĩa vụ pháp lý liên quan đến tin của mình.</p>],
  ],
  finance: [
    ["Không thu tiền cho chức năng cộng đồng miễn phí", <FreeModelNote/>],
    ["Không phải bên thanh toán", <p>App và website không phải là bên nhận, giữ hoặc chuyển tiền thay cho người dùng trong các giao dịch riêng giữa Người lao động và doanh nghiệp.</p>],
    ["Không đối soát hoặc lưu sổ thanh toán riêng", <p>App và website không quản lý đối soát tiền, phiếu thanh toán, mã giao dịch hoặc sổ thu nhập riêng của người dùng. Các giao dịch tài chính riêng được thực hiện trực tiếp giữa các bên liên quan theo thỏa thuận của họ.</p>],
    ["Lương, tiền cọc và chi phí", <p>Mọi thỏa thuận về lương, thưởng, tiền cọc, chi phí đi lại, ăn ở hoặc các khoản tiền khác là thỏa thuận giữa các bên. Người dùng phải tự xác minh trước khi chuyển tiền hoặc cam kết tài chính.</p>],
    ["Quảng cáo là nguồn doanh thu riêng", <p>App và website có thể nhận doanh thu chia sẻ từ mạng quảng cáo bên thứ ba theo chương trình và chính sách của nhà cung cấp. Khoản doanh thu này không phải là phí mà Người lao động hoặc doanh nghiệp trả để sử dụng chức năng kết nối việc làm miễn phí.</p>],
    ["Không bảo đảm giao dịch", <p>App và website không bảo đảm khả năng thanh toán, mức lương, tiền cọc hoặc lời hứa tài chính của bất kỳ người dùng nào. App và website có thể tiếp nhận và xử lý báo cáo trong phạm vi chức năng, nội quy và pháp luật áp dụng.</p>],
    ["Giới hạn pháp lý", <p>Nội dung này không nhằm loại trừ bất kỳ nghĩa vụ hoặc trách nhiệm pháp lý bắt buộc nào áp dụng cho app và website.</p>],
  ],
};

export function About(){return <PolicyDocument title="Giới thiệu App Website" intro="App Website là nơi kết nối việc làm miễn phí dành cho cộng đồng, nơi doanh nghiệp và người lao động cùng tạo ra nội dung gốc, có giá trị và có trách nhiệm.">{[
  ...docs.about,
  ["Hiến pháp nội dung", <div>
    <p><b>Không tạo nội dung rác để lấy lượt xem. Chỉ phát triển và phân phối những nội dung gốc, có giá trị, có nguồn và có trách nhiệm.</b></p>
    <p>Đây là nguyên tắc cốt lõi của App Website và là cam kết với doanh nghiệp, người lao động, cộng đồng và các hệ thống phân phối bên ngoài.</p>
  </div>],
  ["1. Nội dung gốc", <p>Nội dung trên App Website phải bắt nguồn từ hoạt động thật của doanh nghiệp, người lao động và cộng đồng. App Website không biến dữ liệu thành những thông tin không có căn cứ.</p>],
  ["2. Hệ thống tự động nhưng không tự bịa", <p>App Website có thể tự chuẩn hóa, phân loại, tạo chủ đề, tạo tag, liên kết nội dung, đề xuất, xây Feed, tạo trang Website, tạo dữ liệu SEO, Structured Data, Sitemap và phân phối nội dung. Tuy nhiên, hệ thống không được tự tạo ra sự thật không tồn tại trong dữ liệu nguồn.</p>],
  ["3. Giá trị trước lượt xem", <p>Lượt xem là kết quả của nội dung hữu ích. App Website không sử dụng nội dung gây hiểu lầm, nội dung lặp vô nghĩa hoặc thủ thuật làm tăng lượt xem để đánh đổi chất lượng.</p>],
  ["4. Uy tín của cộng đồng", <p>Mỗi tin tuyển dụng, hồ sơ và tương tác đều góp phần xây dựng uy tín chung. App Website khuyến khích <b>Trung thực → Minh bạch → Trách nhiệm → Tôn trọng cộng đồng.</b></p>],
  ["5. Tự động hóa có kiểm soát", <p>App Website được thiết kế để giảm tối đa công việc thủ công của quản trị viên. Khi phát hiện ngoại lệ, sai lệch hoặc nội dung cần xem xét, hệ thống phải cho phép kiểm tra, hạn chế, điều chỉnh hoặc gỡ bỏ quyền phân phối.</p>],
  ["6. Phân phối có trách nhiệm", <p>Nội dung được App Website đề xuất trong App và Website phải dựa trên dữ liệu và các nguyên tắc chất lượng. Việc nội dung có thể được tìm thấy bên ngoài App Website không làm thay đổi tiêu chuẩn này.</p>],
  ["7. Cam kết lâu dài", <p>Chúng tôi không xây dựng App Website chỉ để có thật nhiều nội dung. Chúng tôi xây dựng một cộng đồng việc làm đáng tin cậy, nơi doanh nghiệp có thể tìm người và người lao động có thể tìm cơ hội.</p>],
  ["Cam kết của App Website", <blockquote><p><b>Một nội dung tốt có thể tạo ra một lượt xem.</b><br/>Một hệ thống nội dung tốt có thể tạo ra hàng triệu lượt xem.<br/><b>Nhưng một cộng đồng đáng tin cậy mới có thể tồn tại lâu dài.</b></p><p><b>App Website — Nội dung thật. Cơ hội thật. Giá trị thật.</b></p></blockquote>]
]}</PolicyDocument>}
export function Terms(){return <PolicyDocument title="Điều khoản sử dụng" intro="Nguyên tắc sử dụng app và website để tìm việc, đăng việc, tạo nội dung và chủ động kết nối.">{docs.terms}</PolicyDocument>}
export function Privacy(){return <PolicyDocument title="Chính sách quyền riêng tư và bảo vệ dữ liệu cá nhân" intro="App và website giải thích rõ dữ liệu nào có thể được xử lý, dùng vào đâu và được bảo vệ như thế nào.">{docs.privacy}</PolicyDocument>}
export function Security(){return <PolicyDocument title="Chính sách bảo mật" intro="Các biện pháp bảo vệ tài khoản, dữ liệu, API và hoạt động cộng đồng trên app và website.">{docs.security}</PolicyDocument>}
export function WorkerRights(){return <PolicyDocument title="Quyền và trách nhiệm Người lao động" intro="Quyền tìm việc, đăng Tin tìm việc, tạo nội dung và bảo vệ thông tin cá nhân.">{docs.worker}</PolicyDocument>}
export function EmployerRights(){return <PolicyDocument title="Quyền và trách nhiệm Đơn vị sử dụng lao động" intro="Quyền sử dụng không gian doanh nghiệp miễn phí và trách nhiệm khi đăng tuyển, tạo nội dung và kết nối.">{docs.employer}</PolicyDocument>}
export function PostingRules(){return <PolicyDocument title="Quy tắc đăng tin tuyển dụng" intro="Nguyên tắc kiểm tra, kiểm duyệt và trách nhiệm đối với tin tuyển dụng.">{docs.posting}</PolicyDocument>}</PolicyDocument>}
export function FinancialIndependence(){return <PolicyDocument title="Chính sách về tiền và giao dịch riêng" intro="App và website không thu tiền cho các chức năng cộng đồng miễn phí và không đứng giữa các giao dịch tiền riêng giữa người dùng.">{docs.finance}</PolicyDocument>}
