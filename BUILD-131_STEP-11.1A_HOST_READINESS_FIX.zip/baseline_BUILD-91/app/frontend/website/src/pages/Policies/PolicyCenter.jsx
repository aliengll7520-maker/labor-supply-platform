import React from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import "./Policies.css";

const links = [
  ["#/about", "Giới thiệu app và website", "App và website là nơi cộng đồng tìm việc, đăng việc và chủ động kết nối."],
  ["#/terms", "Điều khoản sử dụng", "Nguyên tắc sử dụng tài khoản, nội dung và kết nối."],
  ["#/privacy", "Quyền riêng tư và dữ liệu cá nhân", "Dữ liệu nào có thể được xử lý, mục đích và quyền của người dùng."],
  ["#/security", "Chính sách bảo mật", "Cách app và website bảo vệ tài khoản, dữ liệu và hệ thống."],
  ["#/worker-rights", "Quyền và trách nhiệm Người lao động", "Thông tin dành riêng cho Người lao động."],
  ["#/employer-rights", "Quyền và trách nhiệm Đơn vị sử dụng lao động", "Thông tin dành riêng cho doanh nghiệp và người sử dụng lao động."],
  ["#/posting-rules", "Quy tắc đăng tin", "Nguyên tắc kiểm tra và trách nhiệm của người đăng tin."],
  ["#/money-and-private-transactions", "Chính sách về tiền và giao dịch riêng", "App và website không thu tiền cho chức năng cộng đồng miễn phí và không đứng giữa giao dịch tiền riêng."],
];

export default function PolicyCenter(){
  return <MainLayout>
    <div className="policy-page">
      <div className="policy-hero">
        <span className="policy-version">Chính sách công khai · Phiên bản 4.0</span>
        <h1>Chính sách của app và website</h1>
        <p>Thông tin dễ hiểu về cách app và website hoạt động miễn phí, quyền riêng tư, bảo mật, nội dung cộng đồng và trách nhiệm của người dùng.</p>
      </div>
      <div className="policy-grid">
        {links.map(([href,title,desc])=><a className="policy-card" href={href} key={href}>
          <h2>{title}</h2><p>{desc}</p><span>Xem nội dung →</span>
        </a>)}
      </div>
      <div className="policy-note"><b>Quan trọng:</b> App và website cung cấp môi trường kết nối việc làm miễn phí. Các chính sách này được viết để người dùng dễ hiểu và không nhằm loại trừ bất kỳ nghĩa vụ pháp lý bắt buộc nào.</div>
    </div>
  </MainLayout>;
}
