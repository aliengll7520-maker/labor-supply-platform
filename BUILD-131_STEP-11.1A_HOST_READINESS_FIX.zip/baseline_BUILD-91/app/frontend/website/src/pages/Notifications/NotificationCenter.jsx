import { api } from "../../api";
import React,{useState} from "react";
import MainLayout from "../../layouts/MainLayout/MainLayout";
import Card from "../../components/Card/Card";
import Button from "../../components/Button/Button";

function NotificationCenter(){
 const [role,setRole]=useState("worker"),[worker,setWorker]=useState({so_dien_thoai:"",ma_ho_so:""}),[items,setItems]=useState([]),[unread,setUnread]=useState(0),[error,setError]=useState("");
 const [loading,setLoading]=useState(false);
 const loadWorker=async()=>{setLoading(true);setError("");try{const j=await api.post("/notifications/worker", worker);setItems(j?.items||[]);setUnread(j?.unread||0)}catch(e){setError(e.message)}finally{setLoading(false)}};
 const loadRole=async()=>{setLoading(true);setError("");try{const url=role==="supplier"?"/notifications/supplier":"/notifications/admin";const j=await api.get(url);setItems(j?.items||[]);setUnread(j?.unread||0)}catch(e){setError(e.message)}finally{setLoading(false)}};
 const load=()=>role==="worker"?loadWorker():loadRole();
 const read=async id=>{try{if(role==="worker")await api.post(`/notifications/worker/${id}/read`,worker);else await api.post(`/notifications/${role}/${id}/read`);setItems(items.map(x=>x.id===id?{...x,da_doc:1}:x));setUnread(Math.max(0,unread-1))}catch(e){setError(e.message)}};
 return <MainLayout><div className="notification-center"><h1>Trung tâm Thông báo</h1><Card><label>Đối tượng <select value={role} onChange={e=>{setRole(e.target.value);setItems([]);setError("")}}><option value="worker">Người lao động</option><option value="supplier">Đơn vị sử dụng lao động</option><option value="admin">Quản trị</option></select></label>{role==="worker"&&<><label>Số điện thoại<input value={worker.so_dien_thoai} onChange={e=>setWorker({...worker,so_dien_thoai:e.target.value})}/></label><label>Mã hồ sơ<input value={worker.ma_ho_so} onChange={e=>setWorker({...worker,ma_ho_so:e.target.value})}/></label></>}<Button text={loading?"ĐANG TẢI...":"XEM THÔNG BÁO"} onClick={load}/>{error&&<p>{error}</p>}</Card><Card><h2>Chưa đọc: {unread}</h2>{!items.length&&!loading&&<p>Không có thông báo.</p>}{items.map(x=><div key={x.id} style={{padding:"14px 0",borderBottom:"1px solid #eee",opacity:x.da_doc?0.65:1}}><b>{x.tieu_de}</b><p>{x.noi_dung}</p><small>{x.ngay_tao}</small>{!x.da_doc&&<div><Button text="ĐÁNH DẤU ĐÃ ĐỌC" onClick={()=>read(x.id)}/></div>}</div>)}</Card></div></MainLayout>
}
export default NotificationCenter;
