import {SupplierLogin,SupplierRegister} from './pages/Supplier/SupplierAuth';
import EmployerPortal from './pages/Employer/EmployerPortal';
import React, { useEffect, useState } from "react";

import Login from "./pages/Login";
import Register from "./pages/Register";
import WorkerRegistration from "./pages/WorkerRegistration";

import Jobs from "./pages/Jobs/Jobs";
import JobDetail from "./pages/Jobs/JobDetail";
import SearchJobs from "./pages/Jobs/SearchJobs";
import FilterJobs from "./pages/Jobs/FilterJobs";
import SavedJobs from "./pages/Jobs/SavedJobs";

import AppliedJobs from "./pages/Jobs/AppliedJobs";
import ApplicationResult from "./pages/Jobs/ApplicationResult";

import Profile from "./pages/Profile/Profile";
import Dashboard from "./pages/Dashboard/Dashboard";
import AdminDashboard from "./pages/Dashboard/AdminDashboard";
import WorkerDashboard from "./pages/Dashboard/WorkerDashboard";
import WorkerJobSeeking from './pages/Worker/WorkerJobSeeking';
import WorkerMatches from './pages/Worker/WorkerMatches';
import SocialFeed from './pages/Social/SocialFeed';
import ProfessionalIdentity from './pages/Professional/ProfessionalIdentity';
import PersonalProfile from './pages/Personal/PersonalProfile';
import Friends from './pages/Personal/Friends';
import Conversations from './pages/Personal/Conversations';
import AdminPortal from "./pages/Admin/AdminPortal";
import OperationsCenter from "./pages/Admin/OperationsCenter";
import NotificationCenter from "./pages/Notifications/NotificationCenter";
import PWAInstallPrompt from './pwa/PWAInstallPrompt';
import PolicyCenter from './pages/Policies/PolicyCenter';
import {About,Terms,Privacy,Security,WorkerRights,EmployerRights,PostingRules,FinancialIndependence} from './pages/Policies/PublicPolicies';

function App() {
  const getRoute = () => {
    const hash = window.location.hash || "#/jobs";

    const routePart = hash.split("?")[0];

    return routePart.replace(/^#\/?/, "") || "jobs";
  };

  const [currentRoute, setCurrentRoute] = useState(getRoute());

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').catch(() => {});
      }, { once: true });
    }

    const handleHashChange = () => {
      setCurrentRoute(getRoute());
    };

    window.addEventListener("hashchange", handleHashChange);

    return () => {
      window.removeEventListener(
        "hashchange",
        handleHashChange
      );
    };
  }, []);

  /*
   * =====================================================
   * CỬA VÀO CÔNG KHAI
   * =====================================================
   *
   * Người lao động không cần đăng nhập để:
   *
   * - Xem tin tuyển dụng.
   * - Tìm kiếm việc làm.
   * - Lọc việc làm.
   * - Xem chi tiết tin.
   *
   * Đăng nhập chỉ là chức năng tùy chọn.
   *
   * =====================================================
   */

  const renderRoute = () => {
    switch (currentRoute) {

    /*
     * -----------------------------------------------
     * TIN TUYỂN DỤNG CÔNG KHAI
     * -----------------------------------------------
     */

    case "":
    case "jobs":
      return <Jobs />;

    case "social":
      return <SocialFeed />;

    case "professional-identity":
      return <ProfessionalIdentity />;

    case "ca-nhan":
      return <PersonalProfile />;

    case "ban-be":
      return <Friends />;

    case "trao-doi":
      return <Conversations />;

    case "search":
      return <SearchJobs />;

    case "filter":
      return <FilterJobs />;

    case "job-detail":
      return <JobDetail />;

    /*
     * -----------------------------------------------
     * ĐĂNG NHẬP / ĐĂNG KÝ
     *
     * Không phải cửa vào bắt buộc.
     * -----------------------------------------------
     */

    case "login":
      return <Login />;

    case "register":
      return <Register />;

    case "worker-register":
      return <WorkerRegistration />;

    /*
     * -----------------------------------------------
     * NGƯỜI LAO ĐỘNG
     * -----------------------------------------------
     */

    case "saved-jobs":
      return <SavedJobs />;

    case "applications":
      return <AppliedJobs />;

    case "application-result":
      return <ApplicationResult />;

    case "profile":
      return <Profile />;

    case "worker-job-seeking":
      return <WorkerJobSeeking />;

    case "worker-matches":
      return <WorkerMatches />;

    /*
     * -----------------------------------------------
     * DASHBOARD
     *
     * Dashboard đã kết nối dữ liệu thật theo từng vai trò.
     * -----------------------------------------------
     */

    case "supplier":
    case "employer":
      return <EmployerPortal />;

    case "employer-login":
      return <SupplierLogin />;

    case "supplier-profile":
      return <EmployerPortal initialTab="profile" />;

    case "supplier-login":
      return <SupplierLogin />;

    case "supplier-register":
      return <SupplierRegister />;

    case "dashboard":
      return <WorkerDashboard />;

    case "supplier-dashboard":
      return <EmployerPortal initialTab="overview" />;

    case "admin-dashboard":
      return <AdminDashboard />;

    case "admin":
      return <AdminPortal />;

    case "operations":
      return <OperationsCenter />;

    case "notifications":
      return <NotificationCenter />;

    case "policies":
      return <PolicyCenter />;

    case "about":
      return <About />;

    case "terms":
      return <Terms />;

    case "privacy":
      return <Privacy />;

    case "security":
      return <Security />;

    case "worker-rights":
      return <WorkerRights />;

    case "employer-rights":
      return <EmployerRights />;

    case "posting-rules":
      return <PostingRules />;

    case "money-and-private-transactions":
      return <FinancialIndependence />;

    // Giữ route cũ để liên kết/bookmark cũ không bị hỏng.
    case "financial-independence":
      return <FinancialIndependence />;

    /*
     * -----------------------------------------------
     * ROUTE KHÔNG HỢP LỆ
     *
     * Luôn đưa khách về tin tuyển dụng công khai.
     * Không bắt đăng nhập.
     * -----------------------------------------------
     */

      default:
        window.location.hash = "#/jobs";
        return <Jobs />;
    }
  };

  return (
    <>
      {renderRoute()}
      <PWAInstallPrompt />
    </>
  );
}

export default App;
