# BUILD 103 — APP & WEBSITE PUBLIC POLICY RESET

## Mục tiêu

Thay toàn bộ cách diễn đạt chính sách công khai cũ bằng ngôn ngữ trực tiếp, thân thiện:

- Dùng "app và website" thay cho "chúng tôi" và hạn chế dùng "nền tảng" trong nội dung người dùng nhìn thấy.
- Giới thiệu rõ app và website là nơi kết nối việc làm miễn phí dành cho cộng đồng.
- Người lao động và Đơn vị sử dụng lao động không trả phí cho các chức năng cộng đồng miễn phí được công bố.
- Người dùng tự tạo nội dung, tự tìm hiểu và chủ động kết nối.
- App và website không phải bên nhận, giữ hoặc chuyển tiền trong các giao dịch riêng giữa người dùng, trừ chức năng cụ thể được công bố rõ ràng.
- Quảng cáo, nếu triển khai, là quảng cáo tự động từ mạng quảng cáo bên thứ ba; khoản doanh thu chia sẻ từ quảng cáo không phải phí người dùng trả cho chức năng kết nối miễn phí.
- Không bán dữ liệu cá nhân.
- Giải thích quyền riêng tư, dữ liệu cá nhân, bảo mật, nội dung người dùng và trách nhiệm tài chính bằng ngôn ngữ dễ hiểu.

## Thay thế

- Thay nội dung `PublicPolicies.jsx`.
- Thay `PolicyCenter.jsx`.
- Thay `PolicyDocument.jsx`.
- File `BUILD_85_PUBLIC_POLICY_CENTER.md` được giữ lại như tài liệu lịch sử; nội dung chính thức hiện tại nằm ở BUILD 103.

## Kiểm thử

BUILD 103 chưa được kiểm thử chức năng theo yêu cầu. Chỉ thực hiện thay nội dung và đóng gói.
