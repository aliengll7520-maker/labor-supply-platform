import { api } from './api';

/** BUILD 18 — public Website/App Content Delivery adapter. */
export const contentDiscoveryApi = {
  getJob(id, options = {}) {
    const limit = Math.min(20, Math.max(1, Number(options.limit || 10)));
    return api.get(`/content-discovery/public/jobs/${Number(id)}/delivery?limit=${limit}`);
  },
};
