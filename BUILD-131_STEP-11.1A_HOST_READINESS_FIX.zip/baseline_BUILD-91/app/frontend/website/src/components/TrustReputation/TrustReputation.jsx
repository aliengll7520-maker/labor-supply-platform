import React,{useEffect,useState} from "react";
import {api} from "../../api";
import "./TrustReputation.css";

function Stars({value=0}){const n=Math.round(Number(value)||0);return <span className="trust-stars" aria-label={`${value} trên 5 sao`}>{[1,2,3,4,5].map(i=><span key={i}>{i<=n?"★":"☆"}</span>)}</span>}

export default function TrustReputation({type,id,applicationId=null}){
 const [data,setData]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState(""),[message,setMessage]=useState(""),[rating,setRating]=useState(5),[text,setText]=useState("");
 const load=async()=>{try{setData(await api.get(`/trust/${type==="employer"?"employers":"workers"}/${id}`));}catch(e){setError(e.message||"Không thể tải đánh giá.")}};
 useEffect(()=>{if(id)load()},[id]);
 const submit=async()=>{setBusy(true);setError("");setMessage("");try{await api.post(`/trust/${type==="employer"?"employers":"workers"}/${id}/reviews`,{application_id:Number(applicationId),rating:Number(rating),review_text:text.trim()});setText("");setMessage("Đã gửi đánh giá.");await load()}catch(e){setError(e.message||"Không thể gửi đánh giá.")}finally{setBusy(false)}};
 if(!id)return null; const summary=data?.danh_tieng||{};
 return <section className="trust-card"><h3>Uy tín cộng đồng</h3><div className="trust-score"><Stars value={summary.diem_trung_binh}/><strong>{summary.luot_danh_gia?Number(summary.diem_trung_binh).toFixed(1):"Chưa có đánh giá"}</strong><span>({summary.luot_danh_gia||0} đánh giá)</span></div>
 {applicationId&&<div className="trust-form"><h4>Đánh giá</h4><div className="trust-rating-input">{[1,2,3,4,5].map(i=><button type="button" key={i} className={i<=rating?"selected":""} onClick={()=>setRating(i)} aria-label={`${i} sao`}>★</button>)}</div><textarea maxLength={1000} placeholder="Nhận xét về trải nghiệm kết nối trên App Website..." value={text} onChange={e=>setText(e.target.value)}/><p className="trust-note">Không đăng số điện thoại, liên kết hoặc quảng cáo.</p><button type="button" disabled={busy} onClick={submit}>{busy?"ĐANG GỬI...":"GỬI ĐÁNH GIÁ"}</button></div>}
 {error&&<p className="trust-error">{error}</p>}{message&&<p className="trust-success">{message}</p>}
 <div className="trust-list">{(data?.danh_gia||[]).length?data.danh_gia.map(r=><article key={r.id} className="trust-review"><div><strong>{r.nguoi_danh_gia}</strong> <Stars value={r.rating}/></div><p>{r.review_text||"Không có nhận xét."}</p><small>{new Date(r.created_at).toLocaleDateString("vi-VN")}</small></article>):<p>Chưa có đánh giá công khai.</p>}</div></section>
}
