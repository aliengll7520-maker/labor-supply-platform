import React from "react";
import "./Footer.css";

function Footer({text="© Labor Supply Platform"}) {
  return <footer className="footer">
    <div>{text}</div>
    <nav className="footer-policy-links">
      <a href="#/about">Giới thiệu</a>
      <a href="#/policies">Chính sách</a>
      <a href="#/privacy">Bảo vệ dữ liệu</a>
      <a href="#/security">Bảo mật</a>
      <a href="#/money-and-private-transactions">Tiền và giao dịch riêng</a>
      <a href="#/posting-rules">Quy tắc đăng tin</a>
    </nav>
  </footer>;
}
export default Footer;
