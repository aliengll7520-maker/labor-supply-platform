import React,{useEffect,useRef,useState} from 'react';
import {api} from '../../api';
import './AdNetworkSlot.css';

/**
 * BUILD 101 - Ad Network Integration Slot.
 * The platform does not select, sell, price, bill or track advertiser orders.
 * A configured third-party ad network owns delivery and measurement.
 */
export default function AdNetworkSlot({placement='feed'}){
 const ref=useRef(null);
 const [config,setConfig]=useState(null);
 const [error,setError]=useState('');
 useEffect(()=>{let alive=true;api.get('/ad-network/config').then(r=>{if(alive)setConfig(r)}).catch(()=>{if(alive)setError('')});return()=>{alive=false}},[]);
 useEffect(()=>{
  if(!config?.enabled || !config.script_url || !ref.current)return;
  const existing=document.querySelector(`script[data-labor-ad-network="${config.provider}"]`);
  const mount=()=>{
   if(window.LaborAdNetwork?.render){
    window.LaborAdNetwork.render(ref.current,{placement,publisherId:config.publisher_id,slot:config.slots?.[placement]||placement});
   }
  };
  if(existing){mount();return}
  const script=document.createElement('script');
  script.src=config.script_url;
  script.async=true;
  script.dataset.laborAdNetwork=config.provider||'external';
  script.onload=mount;
  script.onerror=()=>setError('');
  document.head.appendChild(script);
  return()=>{};
 },[config,placement]);
 if(!config?.enabled || !config.script_url || error)return null;
 return <aside className="ad-network-slot" aria-label="Quảng cáo">
   <div className="ad-network-label">QUẢNG CÁO</div>
   <div ref={ref} className="ad-network-container" data-ad-network-provider={config.provider} data-ad-network-placement={placement}/>
 </aside>;
}
