import React,{useEffect,useState} from 'react';
import {api,bridgePostMessage,bridgeSubscribe} from '../../api';
import './ShareMenu.css';

function getJobUrl(jobId){
  return `${window.location.origin}${window.location.pathname}#/job-detail?id=${encodeURIComponent(jobId)}`;
}

export default function ShareMenu({job,onPersonalShare}){
  const [open,setOpen]=useState(false);
  const [friends,setFriends]=useState([]);
  const [showFriends,setShowFriends]=useState(false);
  const [message,setMessage]=useState('');
  useEffect(()=>{
    return bridgeSubscribe((data)=>{
      if(data?.requestId?.startsWith('share-')){
        setMessage(data?.status==='CLOSED' ? 'Đã đóng bảng chia sẻ.' :
          data?.status==='CANCELLED' ? 'Đã hủy chia sẻ.' :
          data?.status==='FAILED' ? 'Không thể mở bảng chia sẻ.' : '');
      }
    });
  },[]);


  const url=getJobUrl(job?.id);
  const title=job?.tieu_de||'Tin tuyển dụng';
  const text=`${title} – Xem thông tin tuyển dụng miễn phí.`;

  useEffect(()=>{
    if(!open||!showFriends||friends.length)return;
    api.get('/ca-nhan/ban-be').then(r=>setFriends(r.friends||[])).catch(()=>setFriends([]));
  },[open,showFriends,friends.length]);

  const copyLink=async()=>{
    try{
      if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(url);}
      else{const el=document.createElement('textarea');el.value=url;document.body.appendChild(el);el.select();document.execCommand('copy');el.remove();}
      setMessage('Đã sao chép liên kết tin tuyển dụng.');
    }catch(e){setMessage('Không thể sao chép liên kết trên thiết bị này.');}
  };

  const nativeShare=async()=>{
    const requestId=`share-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const bridged=bridgePostMessage({
      requestId,
      event:'platform.surface.open',
      surfaceId:'share',
      payload:{
        resourceType:'job',
        resourceId:job?.id,
        action:'share',
        context:'job-detail',
      },
    });
    if(bridged)return;
    if(!navigator.share){setMessage('Thiết bị/trình duyệt chưa hỗ trợ chia sẻ nhanh. Bạn có thể dùng Facebook, Zalo hoặc Sao chép liên kết.');return;}
    try{await navigator.share({title,text,url});setMessage('Đã mở bảng chia sẻ của thiết bị.');}catch(e){if(e?.name!=='AbortError')setMessage('Không thể mở bảng chia sẻ.');}
  };

  const external=(name,shareUrl)=>{
    window.open(shareUrl,'_blank','noopener,noreferrer,width=720,height=640');
    setMessage(`Đã mở cửa sổ chia sẻ ${name}.`);
  };

  const shareFacebook=()=>external('Facebook',`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`);
  const shareZalo=()=>external('Zalo',`https://zalo.me/share?u=${encodeURIComponent(url)}`);

  const sendToFriend=async(friend)=>{
    try{
      const content=`${title}\n${url}`;
      await api.post(`/ca-nhan/trao-doi/${friend.user_id}`,{noi_dung:content});
      setMessage(`Đã gửi tin tuyển dụng cho ${friend.ho_ten}.`);
      setShowFriends(false);
    }catch(e){setMessage(e.message||'Không thể gửi tin tuyển dụng cho bạn bè.');}
  };

  return <div className="share-menu-wrap">
    <button className="share-main-button" type="button" onClick={()=>{setOpen(v=>!v);setMessage('');}} aria-expanded={open}>↗ Chia sẻ</button>
    {open&&<>
      <div className="share-menu-backdrop" onClick={()=>setOpen(false)} />
      <div className="share-menu" role="menu">
        <div className="share-menu-title">Chia sẻ tin tuyển dụng</div>
        <button type="button" onClick={onPersonalShare}>👤 Chia sẻ lên trang cá nhân</button>
        <button type="button" onClick={()=>setShowFriends(v=>!v)}>👥 Gửi cho bạn bè</button>
        {showFriends&&<div className="share-friends">
          {friends.length===0?<div className="share-empty">Chưa có bạn bè hoặc cần đăng nhập.</div>:friends.map(f=><button className="share-friend" type="button" key={f.user_id} onClick={()=>sendToFriend(f)}><span>{f.ho_ten}</span><small>Gửi tin tuyển dụng</small></button>)}
        </div>}
        <button type="button" onClick={nativeShare}>📱 Chia sẻ bằng điện thoại</button>
        <button type="button" onClick={shareFacebook}>ⓕ Chia sẻ lên Facebook</button>
        <button type="button" onClick={shareZalo}>💬 Chia sẻ lên Zalo</button>
        <button type="button" onClick={copyLink}>🔗 Sao chép liên kết</button>
        {message&&<div className="share-message" role="status">{message}</div>}
      </div>
    </>}
  </div>;
}
