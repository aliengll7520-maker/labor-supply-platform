# PR10 — Monitoring and Alert Contract

Request metrics are captured at runtime and queue/operations monitoring must remain independent of release build markers.

## Required signals
- request count and error count
- latency percentiles
- queue depth and retry/dead-letter state
- notification delivery failures

Alerts should be actionable and tied to documented operational thresholds. Runtime code must not contain PR10 release markers.
