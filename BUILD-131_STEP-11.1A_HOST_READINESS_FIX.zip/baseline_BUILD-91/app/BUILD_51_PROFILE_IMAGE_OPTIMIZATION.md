# BUILD 51 — Profile Image Optimization

## Mục tiêu
- Ảnh đại diện người lao động và logo doanh nghiệp có variant `profile`.
- Kích thước tối đa: 200x200 px.
- Dung lượng mục tiêu cứng: <= 50 KiB (51,200 bytes).
- Định dạng phân phối: WebP.
- Không thay đổi ảnh gốc ngay trong build này để giữ khả năng rollback/audit.

## Luồng
Upload ảnh -> `media_asset` -> queue `media.process_image` -> tạo `web`, `thumb`, `profile` -> lưu `media_asset_variant`.

API phân phối variant:
`/api/media/{id}/url?variant=profile`

## An toàn
- Giữ nguyên MIME validation và giới hạn pixel hiện có.
- Variant profile giảm quality trước; nếu vẫn vượt 50 KiB thì giảm kích thước tiếp.
- Chỉ công khai variant khi media asset đã ở trạng thái `ready` và `public_access=1`.
