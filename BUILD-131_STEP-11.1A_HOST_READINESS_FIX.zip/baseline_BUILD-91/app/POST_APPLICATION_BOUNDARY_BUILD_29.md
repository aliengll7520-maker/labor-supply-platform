# BUILD-29 — POST-APPLICATION BOUNDARY

## Phạm vi mới

App Website tập trung vào kết nối việc làm và kết thúc quy trình nghiệp vụ tại:

Tin tuyển dụng → Người lao động đăng ký hồ sơ → Doanh nghiệp/Nhà cung ứng tiếp nhận → xem hồ sơ → liên hệ.

Sau điểm liên hệ, App Website không quản lý kết quả quan hệ lao động thực tế.

## Đã loại khỏi runtime

- Hồ sơ làm việc
- Lịch sử hồ sơ làm việc
- Chấm công
- Kỳ công
- Ca làm
- Lịch hẹn/phỏng vấn
- Nhắc lịch phỏng vấn
- Đánh giá dựa trên hồ sơ làm việc
- Góp ý hậu tuyển dụng dựa trên hồ sơ làm việc
- Các trạng thái ứng tuyển hậu tuyển dụng: đã hẹn, đã phỏng vấn, đã nhận việc
- Các trạng thái hậu tuyển dụng: đang làm, tạm nghỉ, đã nghỉ
- Quyền Admin xem/điều hành các dữ liệu trên

## Giữ lại

- Tin tuyển dụng
- Hồ sơ nghề nghiệp
- Đăng ký hồ sơ
- Tiếp nhận hồ sơ
- Lịch sử liên hệ
- Kết nối Người lao động ↔ Doanh nghiệp/Nhà cung ứng
- Mạng xã hội
- Content Discovery
- Search/Feed/Related/Recommendation
- Public Web/SEO/Schema/Sitemap
- Anti-spam/Content Safety/Phone Privacy
- Operations/Security/Audit

## Database

Migration `88_BUILD_29_POST_APPLICATION_CLEANUP.sql` dọn các bảng hậu tuyển dụng sau khi triển khai code mới.

Các migration lịch sử được giữ nguyên để bảo toàn lịch sử dựng database; cleanup được thực hiện bằng migration mới.
