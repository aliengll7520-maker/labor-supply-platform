<?php
declare(strict_types=1);

$root = __DIR__;
$required = [
    'backend/src/Services/ContentDiscoveryApiService.php',
    'backend/src/Controllers/ContentDiscoveryApiController.php',
    'database/86_BUILD_17_CONTENT_DISCOVERY_API.sql',
    'BUILD_17_CONTENT_DISCOVERY_API.md',
];
foreach ($required as $file) {
    if (!is_file($root.'/'.$file)) {
        fwrite(STDERR, "MISSING: {$file}\n");
        exit(1);
    }
}
$index = file_get_contents($root.'/backend/public/index.php');
foreach ([
    '/api/content-discovery/capabilities',
    '/api/content-discovery/jobs/{id}/pipeline',
    'ContentDiscoveryApiService',
    'ContentDiscoveryApiController',
] as $needle) {
    if ($needle === '/api/content-discovery/jobs/{id}/pipeline') {
        $needle = 'content-discovery/jobs/(\\d+)/pipeline';
    }
    if (strpos($index, $needle) === false) {
        fwrite(STDERR, "MISSING CONTRACT: {$needle}\n");
        exit(1);
    }
}
$service = file_get_contents($root.'/backend/src/Services/ContentDiscoveryApiService.php');
foreach (['tin_tuyen_dung', 'read_only', 'rebuildable', '17.0.0'] as $needle) {
    if (strpos($service, $needle) === false) {
        fwrite(STDERR, "MISSING SERVICE CONTRACT: {$needle}\n");
        exit(1);
    }
}
echo "BUILD-17 CONTRACT: PASS\n";
