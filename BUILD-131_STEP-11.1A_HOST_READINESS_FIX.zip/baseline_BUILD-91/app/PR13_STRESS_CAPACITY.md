# PR13 — Stress Capacity Contract

Stress testing is performed on **staging first**, with controlled concurrency levels up to 200. The harness records p95 latency and error rate, stops at the first breached level when configured, and reports the highest contiguous passing level and first breached level.

The stress test is a capacity exercise, not a runtime build marker and does not authorize uncontrolled production traffic.
