# Versioning & Build Identity

GitHub là **SOURCE OF TRUTH**. Số BUILD của từng ZIP kiểm thử không được trở thành dependency của runtime, API, Recovery hoặc Database.

## Ba lớp định danh

- `SOURCE_VERSION` — phiên bản logic của sản phẩm, cấu hình bằng `LABOR_SOURCE_VERSION`, không tự tăng theo ZIP.
- `RELEASE_ID` — mã phát hành/deployment, cấu hình bằng `LABOR_RELEASE_ID`.
- `BUILD_ID` — mã gói build/CI nội bộ, cấu hình bằng `LABOR_BUILD_ID`, mặc định `dev`; không dùng cho business logic hay schema compatibility.

## Recovery

Recovery không dùng `RESTORE_BUILDxxx`. Confirmation phrase ổn định là `RESTORE_CONFIRM`. Tương thích backup dựa trên manifest/schema/backup-format, không dựa trên số ZIP.

## Migration

Tên migration có số BUILD lịch sử là **bất biến**. Không đổi tên hoặc đánh lại số migration đã chạy. Ví dụ `70_BUILD_152_PR04_Live_Production_Hardening.sql` giữ nguyên.

## Lịch sử BUILD

Các file `BUILD_*.md` và comment ghi BUILD cũ được giữ như lịch sử phát triển; chúng không phải runtime version.

## Quy tắc khóa

- Không đưa `BUILD_ID` vào business logic.
- Không dùng `BUILD_ID` làm Recovery token.
- Không đổi tên migration lịch sử.
- Không tạo build mới chỉ để đổi số build.
- GitHub source cuối cùng phải chạy được với metadata release độc lập với số ZIP.

## BUILD 51
Profile image optimization: dedicated `profile` WebP variant, max 200x200 px and 50 KiB.
