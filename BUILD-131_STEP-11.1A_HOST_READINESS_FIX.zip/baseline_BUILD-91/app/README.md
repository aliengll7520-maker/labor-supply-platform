# App Website — Labor Supply

App Website mạng xã hội việc làm miễn phí, tập trung vào kết nối Doanh nghiệp/Nhà cung ứng với Người lao động.

## Nguyên tắc cốt lõi

Người dùng tự quản lý → Hệ thống tự vận hành → Admin chỉ xử lý ngoại lệ.

## Ranh giới nghiệp vụ

Tin tuyển dụng → đăng ký hồ sơ → tiếp nhận → liên hệ → kết thúc.

App Website không quản lý chấm công, ca làm, hồ sơ làm việc, nghỉ việc, lương hoặc các nghiệp vụ nhân sự nội bộ sau khi hai bên đã kết nối.

## Các lớp tự động hóa

Content Discovery, Classification, Tags, Topic, Search, Feed, Related, Recommendation, Public Web, SEO, Schema, Sitemap, Queue, Worker, Notification và Auto Moderation.

## Bảo vệ cộng đồng

- Không cho nội dung người dùng phát tán link bên ngoài.
- Không công khai số điện thoại đầy đủ.
- Chặn các biến thể né bộ lọc.
- Admin xử lý ngoại lệ, không duyệt thủ công toàn bộ nội dung hợp lệ.

## Database

Các migration SQL lịch sử được giữ để bảo toàn khả năng dựng lại database. Migration mới nhất của đợt tinh gọn là:

`database/88_BUILD_29_POST_APPLICATION_CLEANUP.sql`

## cPanel RC1 deployment

For the current cPanel/LiteSpeed staging environment, use `ops/cpanel/RC1_RUNBOOK.md` and `ops/cpanel/README.md`. The web document root is `backend/public`; secrets belong in `backend/config/cpanel.env.php`; queue workers run as bounded cPanel Cron processes rather than systemd daemons.

## cPanel RC1 deployment

Use `ops/cpanel/RC1_RUNBOOK.md` and `ops/cpanel/README.md` for the current cPanel/LiteSpeed staging environment. The web document root is `backend/public`; secrets belong in `backend/config/cpanel.env.php`; queue workers run as bounded cPanel Cron processes rather than systemd daemons.
