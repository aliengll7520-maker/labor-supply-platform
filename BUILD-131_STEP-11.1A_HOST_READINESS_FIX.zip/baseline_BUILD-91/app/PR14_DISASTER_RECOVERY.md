# PR14 — Disaster Recovery Contract

Required recovery assets: backup-create.php, backup-verify.php, backup-restore.php and dr-drill.php.

Recovery documentation defines RPO, RTO, off-site retention and restore drill procedures. Restore operations are performed in an isolated recovery environment before production recovery.
