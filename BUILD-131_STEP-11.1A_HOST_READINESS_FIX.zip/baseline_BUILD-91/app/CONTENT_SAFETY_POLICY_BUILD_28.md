# BUILD-28 — Content Safety & Contact Privacy

## Locked rules
- User-generated posts/comments/replies/share notes cannot contain external links.
- Dedicated media/map URL fields remain structured system fields and are not treated as user prose links.
- User-generated public text cannot contain full phone numbers or obfuscated phone-number variants.
- The backend blocks unsafe content before insertion; asynchronous moderation remains a second safety layer.
- Phone numbers are masked in user-visible API responses.
- Internal/system-generated links are allowed because they are not user-authored external links.

## Design principle
User freedom to create useful content is preserved; the platform does not become a link-spam, phone-harvesting, phishing or unsolicited-call distribution channel.
