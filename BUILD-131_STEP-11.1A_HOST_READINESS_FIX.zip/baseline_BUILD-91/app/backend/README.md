# Backend — App Website

Backend PHP 8.1+ / MySQL 8 cho App Website kết nối Doanh nghiệp / Nhà cung ứng với Người lao động.

## Phạm vi chính
- Tài khoản, xác thực và hồ sơ người dùng.
- Tin tuyển dụng, Tin tìm việc và matching.
- Đăng ký hồ sơ, tiếp nhận và liên hệ.
- Mạng xã hội, bài đăng, bình luận và tương tác.
- Content Discovery, Feed, Search, Related, SEO/Public.
- Queue, worker, notification và automation.
- Media, Live và third-party ad integration.
- Moderation, anti-abuse, privacy, security, audit và operations.

## Chạy local
```bash
php -S 127.0.0.1:8080 -t backend/public
```
