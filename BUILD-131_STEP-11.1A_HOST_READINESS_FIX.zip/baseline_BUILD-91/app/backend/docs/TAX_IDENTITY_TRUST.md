# Tax Identity / Trust Gate — BUILD 101

## Purpose
Doanh nghiệp phải có Mã số thuế được dịch vụ xác thực xác nhận **đang hoạt động** trước khi tài khoản được tự động kích hoạt.

## Important provider boundary
BUILD does not hard-code or scrape a Tổng cục Thuế web session. The integration uses a configurable JSON provider endpoint so production can use an authorized/contracted tax-data API or a controlled adapter. Public GDT/eTax lookup pages are not treated as a stable API contract.

## Environment
- `LABOR_TAX_VERIFICATION_ENABLED=true`
- `LABOR_TAX_VERIFICATION_ENDPOINT=<authorized endpoint>`
- `LABOR_TAX_VERIFICATION_TOKEN=<secret if required>`
- `LABOR_TAX_VERIFICATION_TIMEOUT=8`

## Provider request
POST JSON: `{ "tax_code": "0101234567", "ma_so_thue": "0101234567" }`

## Provider response contract
Minimum: `{ "found": true, "status": "active", "name": "..." }`
`status=active` is the only state that passes the gate. Unknown/inactive/suspended/ceased/not-found/provider-error all fail closed.

## Activation
For `doanh_nghiep` + verified active tax status:
- `nha_cung_ung.trang_thai = hoat_dong`
- `nha_cung_ung.xac_minh = da_xac_minh`
- supplier account = `hoat_dong`
- supplier account role = `chu_so_huu`
- `co_quyen_live = 1`

Other unit types keep the existing manual verification workflow.

## Verification evidence
Each successful provider verification stores only minimal evidence: provider request/transaction ID (when supplied), UTC verification timestamp, provider source, and SHA-256 hash of the provider response. The raw provider response is not stored.

## Re-verification lifecycle
`bin/tax-reverify.php [limit]` re-checks doanh_nghiep records whose last successful verification is older than `LABOR_TAX_REVERIFY_DAYS` (default 30 days). Active results restore/retain live access. Explicit not-found/inactive results suspend the supplier and disable owner live access. Provider outages or invalid provider responses do not change the existing trust state and are reported as errors for retry.
