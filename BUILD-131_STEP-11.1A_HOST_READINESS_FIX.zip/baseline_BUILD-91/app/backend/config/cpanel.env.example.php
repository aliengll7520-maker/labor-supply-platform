<?php
declare(strict_types=1);

/**
 * cPanel staging runtime configuration.
 * Copy to backend/config/cpanel.env.php and fill in real values.
 * Never commit/package real credentials.
 */
return [
    'DB_HOST' => 'localhost',
    'DB_PORT' => '3306',
    'DB_NAME' => 'cpanel_database_name',
    'DB_USER' => 'cpanel_database_user',
    'DB_PASS' => 'CHANGE_ME',
    'LABOR_TAX_VERIFICATION_ENABLED' => 'false',
    'LABOR_TAX_VERIFICATION_ENDPOINT' => '',
    'LABOR_TAX_VERIFICATION_TOKEN' => '',
    'LABOR_TAX_VERIFICATION_TIMEOUT' => '8',
    'LABOR_SOURCE_VERSION' => 'BUILD-59',
    'LABOR_RELEASE_ID' => 'RC1-cPanel',
    'LABOR_BUILD_ID' => 'BUILD-59',
    'LABOR_FRONTEND_URL' => '/',
    'LABOR_CPANEL_WORKER_MAX_ITERATIONS' => '10',
    'LABOR_CPANEL_WORKER_MAX_RUNTIME_SECONDS' => '50',
    'LABOR_MEDIA_STORAGE_DRIVER' => 'local',
    'LABOR_MEDIA_CDN_ENABLED' => 'false',
    'LABOR_QUEUE_ENABLED' => 'true',
    'LABOR_AUTO_RECOVERY_ENABLED' => 'true',
    'FCM_PROJECT_ID' => '',
    'FCM_CLIENT_EMAIL' => '',
    'FCM_PRIVATE_KEY' => '',
];
