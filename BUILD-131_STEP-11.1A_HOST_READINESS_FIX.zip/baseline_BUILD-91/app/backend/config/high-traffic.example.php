<?php
// BUILD 106: High-Traffic Foundation. Copy values into config.php/environment as needed.
return [
    'enabled' => true,
    'max_body_bytes' => 1048576,
    'request_timeout_seconds' => 15,
    'retry_after_seconds' => 2,
    'rate_limits' => [
        ['path_prefix'=>'/api/auth/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'ip'],
        ['path_prefix'=>'/api/worker/auth/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'ip'],
        ['path_prefix'=>'/api/social/posts','method'=>'POST','limit'=>30,'window_seconds'=>60,'key'=>'actor'],
        ['path'=>'/api/media/profile-upload','method'=>'POST','limit'=>6,'window_seconds'=>60,'key'=>'actor'],
                ['path_prefix'=>'/api/media/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'actor'],
        ['path_prefix'=>'/api/worker/job-seeking-posts','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'actor'],
        ['path_prefix'=>'/api/jobs/public','method'=>'GET','limit'=>300,'window_seconds'=>60,'key'=>'ip'],
    ],
];
