<?php
declare(strict_types=1);

/**
 * cPanel runtime adapter. Secrets stay outside public/ and are never required
 * to be exported as shell environment variables by Apache/LiteSpeed.
 */
$cpanelEnvFile = __DIR__ . '/cpanel.env.php';
if (is_file($cpanelEnvFile)) {
    $cpanelEnv = require $cpanelEnvFile;
    if (is_array($cpanelEnv)) {
        foreach ($cpanelEnv as $key => $value) {
            $key = trim((string)$key);
            if ($key === '') continue;
            if (getenv($key) === false || getenv($key) === '') {
                $value = is_scalar($value) ? (string)$value : '';
                putenv($key . '=' . $value);
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

return [
    'mobile_bootstrap'=>[
        'versions'=>[
            'config'=>'1',
            'category'=>'1',
            'location'=>'1',
            'feature'=>'1',
        ],
    ],
    'security' => ['max_json_bytes' => 2097152],
    'app'=>[
        'source_version'=>(string)(getenv('LABOR_SOURCE_VERSION') ?: 'dev'),
        'release_id'=>(string)(getenv('LABOR_RELEASE_ID') ?: 'unreleased'),
        'build_id'=>(string)(getenv('LABOR_BUILD_ID') ?: 'dev'),
        'session_name'=>getenv('LABOR_SESSION_NAME') ?: 'labor_platform_session',
        'session_driver'=>getenv('LABOR_SESSION_DRIVER') ?: 'database',
        'session_table'=>getenv('LABOR_SESSION_TABLE') ?: 'labor_php_sessions',
        'session_lock_timeout'=>(int)(getenv('LABOR_SESSION_LOCK_TIMEOUT') ?: 5),
        'frontend_url'=>getenv('LABOR_FRONTEND_URL') ?: '/',
    ],
    'tax_verification'=>[
        'enabled'=>filter_var(getenv('LABOR_TAX_VERIFICATION_ENABLED') ?: 'false', FILTER_VALIDATE_BOOLEAN),
        'endpoint'=>getenv('LABOR_TAX_VERIFICATION_ENDPOINT') ?: '',
        'token'=>getenv('LABOR_TAX_VERIFICATION_TOKEN') ?: '',
        'timeout_seconds'=>(int)(getenv('LABOR_TAX_VERIFICATION_TIMEOUT') ?: 8),
        'reverify_days'=>(int)(getenv('LABOR_TAX_REVERIFY_DAYS') ?: 30),
    ],
    'fcm'=>[
        'project_id'=>getenv('FCM_PROJECT_ID') ?: '',
        'client_email'=>getenv('FCM_CLIENT_EMAIL') ?: '',
        'private_key'=>str_replace('\\n', "\n", getenv('FCM_PRIVATE_KEY') ?: ''),
    ],
    'google'=>[
        'client_id'=>getenv('GOOGLE_CLIENT_ID') ?: '',
        'client_secret'=>getenv('GOOGLE_CLIENT_SECRET') ?: '',
        'redirect_uri'=>getenv('GOOGLE_REDIRECT_URI') ?: '',
    ],
    'email'=>[
        'provider'=>getenv('LABOR_EMAIL_PROVIDER') ?: 'http',
        'endpoint'=>getenv('LABOR_EMAIL_ENDPOINT') ?: '',
        'token'=>getenv('LABOR_EMAIL_TOKEN') ?: '',
        'sender'=>getenv('LABOR_EMAIL_SENDER') ?: '',
    ],
    'sms'=>[
        'provider'=>getenv('LABOR_SMS_PROVIDER') ?: 'queue',
        'endpoint'=>getenv('LABOR_SMS_ENDPOINT') ?: '',
        'token'=>getenv('LABOR_SMS_TOKEN') ?: '',
        'sender'=>getenv('LABOR_SMS_SENDER') ?: 'LABOR',
        'callback_token'=>getenv('LABOR_SMS_CALLBACK_TOKEN') ?: '',
    ],
    'high_traffic'=>[
        'enabled'=>filter_var(getenv('LABOR_HIGH_TRAFFIC_ENABLED') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'max_body_bytes'=>(int)(getenv('LABOR_MAX_BODY_BYTES') ?: 524288),
        'media_upload_max_body_bytes'=>(int)(getenv('LABOR_MEDIA_UPLOAD_MAX_BYTES') ?: 5242880),
            'profile_media_upload_max_body_bytes'=>(int)(getenv('LABOR_PROFILE_MEDIA_UPLOAD_MAX_BYTES') ?: 524288),
        'request_timeout_seconds'=>(int)(getenv('LABOR_REQUEST_TIMEOUT') ?: 15),
        'retry_after_seconds'=>(int)(getenv('LABOR_RETRY_AFTER') ?: 2),
        'rate_limits'=>[
            ['path_prefix'=>'/api/auth/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'ip'],
            ['path_prefix'=>'/api/supplier/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'ip'],
            ['path_prefix'=>'/api/identity/security/password-reset','method'=>'POST','limit'=>5,'window_seconds'=>900,'key'=>'ip'],
            ['path_prefix'=>'/api/identity/verification/','method'=>'POST','limit'=>10,'window_seconds'=>600,'key'=>'ip'],
            ['path_prefix'=>'/api/worker/auth/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'ip'],
            ['path'=>'/api/social/posts','method'=>'POST','limit'=>5,'window_seconds'=>300,'key'=>'actor'],
            ['path_prefix'=>'/api/social/posts/','method'=>'POST','limit'=>60,'window_seconds'=>60,'key'=>'actor'],
            ['path_prefix'=>'/api/social/follow/','method'=>'POST','limit'=>30,'window_seconds'=>60,'key'=>'actor'],
            ['path_prefix'=>'/api/social/block/','method'=>'POST','limit'=>20,'window_seconds'=>300,'key'=>'actor'],
            ['path_suffix'=>'/report','method'=>'POST','limit'=>10,'window_seconds'=>3600,'key'=>'actor'],
            ['path_prefix'=>'/api/social/comments/','method'=>'POST','limit'=>10,'window_seconds'=>3600,'key'=>'actor'],
            ['path_prefix'=>'/api/social/jobs/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'actor'],
            ['path'=>'/api/media/profile-upload','method'=>'POST','limit'=>6,'window_seconds'=>60,'key'=>'actor'],
                ['path_prefix'=>'/api/media/','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'actor'],
            ['path_prefix'=>'/api/worker/job-seeking-posts','method'=>'POST','limit'=>20,'window_seconds'=>60,'key'=>'actor'],
            ['path_prefix'=>'/api/jobs/public','method'=>'GET','limit'=>300,'window_seconds'=>60,'key'=>'ip'],
        ],
    ],
    'queue'=>[
        'enabled'=>filter_var(getenv('LABOR_QUEUE_ENABLED') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'default_max_attempts'=>(int)(getenv('LABOR_QUEUE_MAX_ATTEMPTS') ?: 5),
        'retry_base_seconds'=>(int)(getenv('LABOR_QUEUE_RETRY_BASE') ?: 5),
        'retry_max_seconds'=>(int)(getenv('LABOR_QUEUE_RETRY_MAX') ?: 900),
        'default_max_depth'=>(int)(getenv('LABOR_QUEUE_MAX_DEPTH') ?: 100000),
        'max_depth_by_queue'=>[
            'notifications'=>(int)(getenv('LABOR_QUEUE_MAX_NOTIFICATIONS') ?: 200000),
            'moderation'=>(int)(getenv('LABOR_QUEUE_MAX_MODERATION') ?: 200000),
            'search'=>(int)(getenv('LABOR_QUEUE_MAX_SEARCH') ?: 200000),
            'feed'=>(int)(getenv('LABOR_QUEUE_MAX_FEED') ?: 200000),
            'media'=>(int)(getenv('LABOR_QUEUE_MAX_MEDIA') ?: 50000),
            'audit'=>(int)(getenv('LABOR_QUEUE_MAX_AUDIT') ?: 200000),
        ],
        'batch_size'=>(int)(getenv('LABOR_QUEUE_BATCH_SIZE') ?: 20),
        'lease_seconds'=>(int)(getenv('LABOR_QUEUE_LEASE_SECONDS') ?: 120),
        'idle_sleep_seconds'=>(int)(getenv('LABOR_QUEUE_IDLE_SLEEP') ?: 2),
        'max_iterations'=>(int)(getenv('LABOR_QUEUE_MAX_ITERATIONS') ?: 0),
        'max_runtime_seconds'=>(int)(getenv('LABOR_QUEUE_MAX_RUNTIME_SECONDS') ?: 0),
    ],
    'auto_recovery'=>[
        'enabled'=>filter_var(getenv('LABOR_AUTO_RECOVERY_ENABLED') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'lock_name'=>getenv('LABOR_AUTO_RECOVERY_LOCK_NAME') ?: 'labor_queue_auto_recovery',
        'lock_timeout_seconds'=>(int)(getenv('LABOR_AUTO_RECOVERY_LOCK_TIMEOUT') ?: 5),
        'max_recover_per_queue'=>(int)(getenv('LABOR_AUTO_RECOVERY_MAX_PER_QUEUE') ?: 1000),
        'queues'=>['notifications','moderation','search','feed','media','media_cleanup','audit','matching'],
    ],
    'content_discovery_warm'=>[
        'token'=>getenv('LABOR_DISCOVERY_WARM_TOKEN') ?: '',
    ],
    'content_discovery_reconciliation'=>[
        'enabled'=>filter_var(getenv('LABOR_DISCOVERY_RECONCILIATION_ENABLED') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'interval_seconds'=>(int)(getenv('LABOR_DISCOVERY_RECONCILIATION_INTERVAL') ?: 3600),
        'batch_limit'=>(int)(getenv('LABOR_DISCOVERY_RECONCILIATION_BATCH') ?: 500),
        'lock_name'=>getenv('LABOR_DISCOVERY_RECONCILIATION_LOCK_NAME') ?: 'labor_content_discovery_reconcile',
        'lock_timeout_seconds'=>(int)(getenv('LABOR_DISCOVERY_RECONCILIATION_LOCK_TIMEOUT') ?: 5),
    ],
    'operations'=>[
        'queue_warn_depth'=>(int)(getenv('LABOR_OPS_QUEUE_WARN_DEPTH') ?: 5000),
        'queue_critical_depth'=>(int)(getenv('LABOR_OPS_QUEUE_CRITICAL_DEPTH') ?: 20000),
        'stale_processing_seconds'=>(int)(getenv('LABOR_OPS_STALE_PROCESSING_SECONDS') ?: 600),
        'disk_warn_percent'=>(float)(getenv('LABOR_OPS_DISK_WARN_PERCENT') ?: 15),
        'disk_critical_percent'=>(float)(getenv('LABOR_OPS_DISK_CRITICAL_PERCENT') ?: 8),
        'memory_warn_percent'=>(float)(getenv('LABOR_OPS_MEMORY_WARN_PERCENT') ?: 80),
        'memory_critical_percent'=>(float)(getenv('LABOR_OPS_MEMORY_CRITICAL_PERCENT') ?: 90),
        'snapshot_retention_days'=>(int)(getenv('LABOR_OPS_SNAPSHOT_RETENTION_DAYS') ?: 30),
    ],
    'performance'=>[
        'enabled'=>filter_var(getenv('LABOR_PERF_TEST_ENABLED') ?: 'false', FILTER_VALIDATE_BOOLEAN),
        'default_duration_seconds'=>(int)(getenv('LABOR_PERF_DURATION') ?: 30),
        'default_concurrency'=>(int)(getenv('LABOR_PERF_CONCURRENCY') ?: 20),
        'max_concurrency'=>(int)(getenv('LABOR_PERF_MAX_CONCURRENCY') ?: 200),
        'max_error_rate'=>(float)(getenv('LABOR_PERF_MAX_ERROR_RATE') ?: 0.05),
        'max_p95_ms'=>(float)(getenv('LABOR_PERF_MAX_P95_MS') ?: 1000),
    ],
    'ad_network'=>[
        'enabled'=>filter_var(getenv('LABOR_AD_NETWORK_ENABLED') ?: 'false', FILTER_VALIDATE_BOOLEAN),
        'provider'=>getenv('LABOR_AD_NETWORK_PROVIDER') ?: '',
        'publisher_id'=>getenv('LABOR_AD_NETWORK_PUBLISHER_ID') ?: '',
        'script_url'=>getenv('LABOR_AD_NETWORK_SCRIPT_URL') ?: '',
        'feed_slot'=>getenv('LABOR_AD_NETWORK_FEED_SLOT') ?: 'feed',
        'job_detail_slot'=>getenv('LABOR_AD_NETWORK_JOB_DETAIL_SLOT') ?: 'job_detail',
        'video_slot'=>getenv('LABOR_AD_NETWORK_VIDEO_SLOT') ?: 'video',
        'live_slot'=>getenv('LABOR_AD_NETWORK_LIVE_SLOT') ?: 'live',
    ],
    'live_production'=>[
        'enabled'=>filter_var(getenv('LABOR_LIVE_PRODUCTION_ENABLED') ?: 'true', FILTER_VALIDATE_BOOLEAN),
    ],
    'media_storage'=>[
        'driver'=>getenv('LABOR_MEDIA_STORAGE_DRIVER') ?: 'local',
        'root'=>getenv('LABOR_MEDIA_ROOT') ?: dirname(__DIR__, 2) . '/storage/media',
        'public_base_url'=>getenv('LABOR_MEDIA_PUBLIC_BASE_URL') ?: '',
        'endpoint'=>getenv('LABOR_MEDIA_OBJECT_ENDPOINT') ?: '',
        'bucket'=>getenv('LABOR_MEDIA_OBJECT_BUCKET') ?: '',
        'region'=>getenv('LABOR_MEDIA_OBJECT_REGION') ?: 'us-east-1',
        'access_key'=>getenv('LABOR_MEDIA_OBJECT_ACCESS_KEY') ?: '',
        'secret_key'=>getenv('LABOR_MEDIA_OBJECT_SECRET_KEY') ?: '',
        'prefix'=>getenv('LABOR_MEDIA_OBJECT_PREFIX') ?: 'labor-media',
        'path_style'=>filter_var(getenv('LABOR_MEDIA_OBJECT_PATH_STYLE') ?: 'true', FILTER_VALIDATE_BOOLEAN),
        'timeout'=>(int)(getenv('LABOR_MEDIA_OBJECT_TIMEOUT') ?: 30),
    ],
    'media_cdn'=>[
        'enabled'=>filter_var(getenv('LABOR_MEDIA_CDN_ENABLED') ?: 'false', FILTER_VALIDATE_BOOLEAN),
        'base_url'=>getenv('LABOR_MEDIA_CDN_BASE_URL') ?: '',
        'cache_seconds'=>(int)(getenv('LABOR_MEDIA_CDN_CACHE_SECONDS') ?: 3600),
    ],
    'identity_security'=>[
        'reset_ttl_minutes'=>(int)(getenv('LABOR_IDENTITY_RESET_TTL_MINUTES') ?: 30),
        'max_reset_requests'=>(int)(getenv('LABOR_IDENTITY_RESET_MAX_REQUESTS') ?: 5),
        'expose_reset_token'=>filter_var(getenv('LABOR_IDENTITY_SECURITY_EXPOSE_RESET_TOKEN') ?: 'false', FILTER_VALIDATE_BOOLEAN),
    ],
    'identity_verification'=>[
        'ttl_minutes'=>(int)(getenv('LABOR_IDENTITY_VERIFICATION_TTL_MINUTES') ?: 10),
        'max_attempts'=>(int)(getenv('LABOR_IDENTITY_VERIFICATION_MAX_ATTEMPTS') ?: 5),
        'expose_code'=>filter_var(getenv('LABOR_IDENTITY_VERIFICATION_EXPOSE_CODE') ?: 'false', FILTER_VALIDATE_BOOLEAN),
    ],
    'media_cleanup'=>[
        'max_attempts'=>(int)(getenv('LABOR_MEDIA_CLEANUP_MAX_ATTEMPTS') ?: 8),
        'temp_max_age_seconds'=>(int)(getenv('LABOR_MEDIA_CLEANUP_TEMP_MAX_AGE_SECONDS') ?: 86400),
        'temp_batch_limit'=>(int)(getenv('LABOR_MEDIA_CLEANUP_TEMP_BATCH_LIMIT') ?: 200),
    ],
    'media_image'=>[
        'web_max_width'=>(int)(getenv('LABOR_MEDIA_IMAGE_WEB_MAX_WIDTH') ?: 2000),
        'thumb_max_width'=>(int)(getenv('LABOR_MEDIA_IMAGE_THUMB_MAX_WIDTH') ?: 400),
        'profile_max_width'=>(int)(getenv('LABOR_MEDIA_IMAGE_PROFILE_MAX_WIDTH') ?: 200),
        'profile_max_height'=>(int)(getenv('LABOR_MEDIA_IMAGE_PROFILE_MAX_HEIGHT') ?: 200),
        'profile_max_bytes'=>(int)(getenv('LABOR_MEDIA_IMAGE_PROFILE_MAX_BYTES') ?: 51200),
        'max_pixels'=>(int)(getenv('LABOR_MEDIA_IMAGE_MAX_PIXELS') ?: 25000000),
    ],
    'backup'=>[
        'root'=>getenv('LABOR_BACKUP_ROOT') ?: dirname(__DIR__, 2) . '/backups',
        'media_root'=>getenv('LABOR_MEDIA_ROOT') ?: dirname(__DIR__, 2) . '/storage/media',
        'format_version'=>1,
    ],
    'db'=>[
        'host'=>getenv('DB_HOST') ?: '127.0.0.1',
        'port'=>getenv('DB_PORT') ?: '3306',
        'name'=>getenv('DB_NAME') ?: 'labor_supply_platform',
        'user'=>getenv('DB_USER') ?: '',
        'pass'=>getenv('DB_PASS') ?: '',
        'charset'=>'utf8mb4',
    ],
];

// Performance validation controls; used by load-test tooling, not runtime request identity/versioning.
