<?php
// Load-test profile. Keep disabled in application runtime; use environment overrides in a staging environment.
return [
    'enabled' => false,
    'duration_seconds' => 30,
    'warmup_seconds' => 5,
    'concurrency' => 20,
    'max_concurrency' => 200,
    'max_error_rate' => 0.05,
    'max_p95_ms' => 1000,
];
