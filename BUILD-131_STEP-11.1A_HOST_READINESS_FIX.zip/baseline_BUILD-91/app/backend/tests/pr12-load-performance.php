<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$tool=file_get_contents($root.'/tools/load-test/http-load.php');
$config=file_get_contents($root.'/config/config.php');
$runbook=file_get_contents(dirname($root).'/ops/load-test/README.md');
$checks=[];
$checks['curl_harness']=str_contains($tool,'curl_init') && str_contains($tool,'curl_setopt_array');
$checks['concurrency_cap']=str_contains($tool,'min(200');
$checks['warmup']=str_contains($tool,"warmup::");
$checks['p95']=str_contains($tool,"p95_latency_ms");
$checks['error_rate']=str_contains($tool,"error_rate");
$checks['threshold_exit']=str_contains($tool,"exit(\$report['pass'] ? 0 : 1)");
$checks['config_perf_section']=str_contains($config,"'performance'");
$checks['runbook']=str_contains($runbook,'Load Test') && str_contains($runbook,'production');
$checks['no_runtime_pr12']=!preg_match('/[\'\"](?:build|version|release)[\'\"]\s*=>\s*[\'\"]PR-?12/i',$config.$tool);
$ok=true; foreach($checks as $k=>$v){echo ($v?'PASS':'FAIL')." $k\n"; $ok=$ok&&$v;} exit($ok?0:1);
