<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentClassificationService.php',
    $root.'/src/Controllers/ContentClassificationController.php',
    dirname($root).'/database/77_BUILD_02_CONTENT_CLASSIFICATION.sql',
];

foreach ($required as $file) {
    if (!is_file($file)) {
        fwrite(STDERR, "MISSING: {$file}\n");
        exit(1);
    }
}

echo "BUILD 02 Content Classification contract: PASS\n";
