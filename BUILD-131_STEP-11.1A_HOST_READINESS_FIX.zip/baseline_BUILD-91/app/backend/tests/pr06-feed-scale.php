<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$controller = file_get_contents($root.'/backend/src/Controllers/SocialController.php');
$doc = file_get_contents($root.'/PR06_FEED_SCALE.md');

$checks = [
    'public feed remains anonymous' => str_contains($controller, '$actor=$this->actor(false);'),
    'public feed uses id cursor' => str_contains($controller, 's.id < ?'),
    'personal cursor only for authenticated actor' => str_contains($controller, "if(\$actor) \$cursorFollow=(int)\$decoded['f'];"),
    'personal cursor predicate guarded by actor' => str_contains($controller, 'if($actor && $cursorFollow!==null && $cursorId>0){'),
    'public order path uses s.id only' => str_contains($controller, "'s.id DESC'"),
    'public next cursor is numeric' => str_contains($controller, "\$nextCursor=(string)(int)\$last['id'];"),
    'authenticated next cursor keeps follow priority' => str_contains($controller, "'dang_theo_doi'"),
    'interaction still requires authentication' => str_contains($controller, '$a=$this->actor();'),
    'public feed contract documented' => str_contains($doc, 'Public Feed remains viewable without login.') && str_contains($doc, 'numeric `id` cursor'),
    'authenticated feed contract documented' => str_contains($doc, 'Authenticated Feed may use') && str_contains($doc, 'personalized `{f,id}` cursor'),
];
$failed = array_keys(array_filter($checks, static fn(bool $ok): bool => !$ok));
foreach ($checks as $name=>$ok) echo ($ok?'PASS':'FAIL').' '.$name.PHP_EOL;
if ($failed) exit(1);
