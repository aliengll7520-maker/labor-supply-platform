<?php
declare(strict_types=1);
$root = dirname(__DIR__, 2);
$required = [
    'backend/bin/backup-create.php',
    'backend/bin/backup-verify.php',
    'backend/bin/backup-restore.php',
    'backend/bin/dr-drill.php',
    'ops/backup/README.md',
    'ops/disaster-recovery/README.md',
    'ops/disaster-recovery/retention-policy.md',
];
$fail=[];
foreach ($required as $file) if (!is_file($root.'/'.$file)) $fail[]='missing: '.$file;
$readme = (string)@file_get_contents($root.'/ops/disaster-recovery/README.md');
foreach (['RPO','RTO','backup-verify.php','backup-restore.php','off-site','restore drill'] as $needle) if (stripos($readme,$needle)===false) $fail[]='README missing: '.$needle;
$dr = (string)@file_get_contents($root.'/backend/bin/dr-drill.php');
foreach (['destructive_restore','rpo_target_seconds','rto_target_seconds','NOT_RUN'] as $needle) if (strpos($dr,$needle)===false) $fail[]='dr-drill missing: '.$needle;
if ($fail) { echo "PR14 FAIL\n".implode("\n",$fail)."\n"; exit(1); }
echo "PR14 PASS\n";
