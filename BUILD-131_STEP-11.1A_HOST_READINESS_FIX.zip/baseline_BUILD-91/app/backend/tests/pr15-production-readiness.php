<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$checks = [];
$checks['release_gate'] = is_file($root . '/ops/release/production-readiness-gate.sh');
$checks['release_doc'] = is_file($root . '/PR15_PRODUCTION_READINESS.md');
$checks['preflight'] = is_file($root . '/ops/production/preflight.sh');
$checks['runbook'] = is_file($root . '/ops/production/runbook.md');
$checks['dr_contract'] = is_file($root . '/PR14_DISASTER_RECOVERY.md');
$checks['pr14_test'] = is_file($root . '/backend/tests/pr14_disaster_recovery.php');
$checks['pr13_test'] = is_file($root . '/backend/tests/pr13-stress-capacity.php');
$checks['pr12_test'] = is_file($root . '/backend/tests/pr12-load-performance.php');
$checks['no_real_env'] = !is_file($root . '/ops/production/env.production');
$checks['env_example'] = is_file($root . '/ops/production/env.production.example');

$fail = false;
foreach ($checks as $name => $ok) {
    echo ($ok ? 'PASS ' : 'FAIL ') . $name . PHP_EOL;
    $fail = $fail || !$ok;
}

echo $fail ? "PR15 FAIL\n" : "PR15 PASS\n";
exit($fail ? 1 : 0);
