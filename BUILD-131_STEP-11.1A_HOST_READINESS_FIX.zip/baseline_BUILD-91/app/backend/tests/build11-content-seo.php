<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
    $root.'/src/Services/ContentSeoService.php',
    $root.'/src/Controllers/ContentSeoController.php',
    $root.'/public/index.php',
    dirname($root).'/database/82_BUILD_11_CONTENT_SEO.sql',
];
foreach ($checks as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: $file\n"); exit(1); }
}
$index = file_get_contents($root.'/public/index.php');
foreach (['ContentSeoController','ContentSeoService','/api/content-discovery/public/jobs/(\\d+)/seo'] as $needle) {
    if (strpos($index, $needle) === false) { fwrite(STDERR, "MISSING ROUTE TOKEN: $needle\n"); exit(1); }
}
$service = file_get_contents($root.'/src/Services/ContentSeoService.php');
foreach (['meta','canonical_path','index,follow','source_of_truth','content_discovery_seo'] as $needle) {
    if (strpos($service, $needle) === false) { fwrite(STDERR, "MISSING SEO TOKEN: $needle\n"); exit(1); }
}
echo "BUILD-11 CONTENT SEO CONTRACT: PASS\n";
