<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
 $root.'/src/Services/ContentSitemapService.php',
 $root.'/src/Controllers/ContentSitemapController.php',
 $root.'/public/index.php',
 dirname($root).'/database/84_BUILD_13_CONTENT_SITEMAP.sql',
];
foreach($checks as $file){if(!is_file($file)){fwrite(STDERR,"MISSING: $file\n");exit(1);}}
$index=file_get_contents($root.'/public/index.php');
foreach(['ContentSitemapService','ContentSitemapController','/sitemap/jobs.xml'] as $needle){if(strpos($index,$needle)===false){fwrite(STDERR,"MISSING TOKEN: $needle\n");exit(1);}}
$service=file_get_contents($root.'/src/Services/ContentSitemapService.php');
foreach(['sitemaps.org/schemas/sitemap/0.9','tin_tuyen_dung','content_discovery_sitemaps','fingerprint','dang_tuyen'] as $needle){if(strpos($service,$needle)===false){fwrite(STDERR,"MISSING SITEMAP TOKEN: $needle\n");exit(1);}}
echo "BUILD-13 CONTENT SITEMAP CONTRACT: PASS\n";
