<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
 $root.'/src/Services/ContentStructuredDataService.php',
 $root.'/src/Controllers/ContentStructuredDataController.php',
 $root.'/public/index.php',
 dirname($root).'/database/83_BUILD_12_CONTENT_STRUCTURED_DATA.sql',
];
foreach($checks as $file){if(!is_file($file)){fwrite(STDERR,"MISSING: $file\n");exit(1);}}
$index=file_get_contents($root.'/public/index.php');
foreach(['ContentStructuredDataService','ContentStructuredDataController','/api/content-discovery/public/jobs/(\\d+)/structured-data'] as $needle){if(strpos($index,$needle)===false){fwrite(STDERR,"MISSING TOKEN: $needle\n");exit(1);}}
$service=file_get_contents($root.'/src/Services/ContentStructuredDataService.php');
foreach(['@context','https://schema.org','JobPosting','identifier','jobLocation','baseSalary','content_discovery_structured_data','source_of_truth'] as $needle){if(strpos($service,$needle)===false){fwrite(STDERR,"MISSING SCHEMA TOKEN: $needle\n");exit(1);}}
echo "BUILD-12 CONTENT STRUCTURED DATA CONTRACT: PASS\n";
