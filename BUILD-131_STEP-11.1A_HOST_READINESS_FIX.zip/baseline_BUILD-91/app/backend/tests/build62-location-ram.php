<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$s=file_get_contents($root.'/src/Services/ContentSearchService.php');
$checks=[
 'bounded chunk'=>str_contains($s,'LOCATION_CHUNK_SIZE = 100')&&str_contains($s,'locationChunkKey'),
 'job item cache'=>str_contains($s,'jobItemCacheKey'),
 'RAM pagination'=>str_contains($s,'searchFromLocationRam')&&str_contains($s,'array_slice'),
 'no request DB fallback for location'=>str_contains($s,"if (\$q === '' && \$topic === '' && \$location !== '')")&&str_contains($s,"location_ram_warming"),
 'worker sync'=>str_contains($s,'syncWarmedJobById'),
 'warm CLI'=>is_file($root.'/bin/content-search-warm.php'),
 'post deploy FPM warm'=>is_file($root.'/bin/post-deploy.php')&&str_contains(file_get_contents($root.'/bin/post-deploy.php'),'LABOR_DISCOVERY_WARM_URL')&&str_contains(file_get_contents($root.'/bin/post-deploy.php'),'X-Labor-Warm-Token'),
 'protected warm endpoint'=>is_file($root.'/src/Controllers/ContentSearchController.php')&&str_contains(file_get_contents($root.'/src/Controllers/ContentSearchController.php'),'hash_equals')&&str_contains(file_get_contents($root.'/public/index.php'),'/internal/content-discovery/warm'),
 'no old location cache'=>!str_contains($s,'location:v1'),
];
$failed=[];foreach($checks as $k=>$v){echo ($v?'PASS':'FAIL').' '.$k.PHP_EOL;if(!$v)$failed[]=$k;}exit($failed?1:0);
