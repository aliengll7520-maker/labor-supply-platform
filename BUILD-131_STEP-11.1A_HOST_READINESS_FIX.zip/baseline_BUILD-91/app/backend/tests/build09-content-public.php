<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
    $root.'/src/Services/ContentPublicService.php',
    $root.'/src/Controllers/ContentPublicController.php',
    $root.'/public/index.php',
];
foreach ($checks as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: $file\n"); exit(1); }
}
$index = file_get_contents($root.'/public/index.php');
foreach (['ContentPublicController','ContentPublicService','/api/content-discovery/public/jobs/(\\d+)'] as $needle) {
    if (strpos($index, $needle) === false) { fwrite(STDERR, "MISSING ROUTE TOKEN: $needle\n"); exit(1); }
}
$service = file_get_contents($root.'/src/Services/ContentPublicService.php');
foreach (['source_of_truth','public_url','visibility','capabilities'] as $needle) {
    if (strpos($service, $needle) === false) { fwrite(STDERR, "MISSING SERVICE TOKEN: $needle\n"); exit(1); }
}
echo "BUILD-09 CONTENT PUBLIC CONTRACT: PASS\n";
