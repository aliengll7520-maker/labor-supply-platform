<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
    $root.'/src/Services/ContentUrlService.php',
    $root.'/src/Controllers/ContentUrlController.php',
    $root.'/public/index.php',
];
foreach ($checks as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: $file\n"); exit(1); }
}
$index = file_get_contents($root.'/public/index.php');
foreach (['ContentUrlController','ContentUrlService','/api/content-discovery/public/jobs/(\\d+)/url'] as $needle) {
    if (strpos($index, $needle) === false) { fwrite(STDERR, "MISSING ROUTE TOKEN: $needle\n"); exit(1); }
}
$service = file_get_contents($root.'/src/Services/ContentUrlService.php');
foreach (['canonical_path','/viec-lam/','{id}-{slug}','source_of_truth','visibility'] as $needle) {
    if (strpos($service, $needle) === false) { fwrite(STDERR, "MISSING URL TOKEN: $needle\n"); exit(1); }
}
echo "BUILD-10 CONTENT URL CONTRACT: PASS\n";
