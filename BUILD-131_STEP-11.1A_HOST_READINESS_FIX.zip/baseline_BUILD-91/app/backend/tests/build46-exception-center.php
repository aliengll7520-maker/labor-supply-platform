<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$checks=[
 'migration'=>file_exists($root.'/../database/97_BUILD_46_EXCEPTION_CENTER_OBSERVABILITY.sql'),
 'operations_service'=>file_exists($root.'/src/Services/OperationsService.php') && str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'exceptionCenter'),
 'controller'=>file_exists($root.'/src/Controllers/OperationsController.php') && str_contains(file_get_contents($root.'/src/Controllers/OperationsController.php'),'exceptions()'),
 'route'=>str_contains(file_get_contents($root.'/public/index.php'),"/api/admin/operations/exceptions"),
 'discovery_observability'=>str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'discoveryObservability'),
 'auto_recovery_hint'=>str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'autoRecoveryHint'),
 'permission'=>str_contains(file_get_contents($root.'/src/Controllers/OperationsController.php'),"operations.view"),
 'frontend'=>file_exists($root.'/../frontend/website/src/pages/Admin/OperationsCenter.jsx') && str_contains(file_get_contents($root.'/../frontend/website/src/pages/Admin/OperationsCenter.jsx'),"/admin/operations/exceptions"),
 'no_source_mutation'=>!str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'UPDATE tin_tuyen_dung') && !str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'DELETE FROM tin_tuyen_dung'),
 'recent_snapshots'=>str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'recentSnapshots(10)'),
];
$failed=[];foreach($checks as $k=>$v)if(!$v)$failed[]=$k;echo 'BUILD-46 CONTRACT: '.(count($failed)?'FAIL':'PASS').PHP_EOL;foreach($checks as $k=>$v)echo ($v?'PASS ':'FAIL ').$k.PHP_EOL;exit(count($failed)?1:0);
