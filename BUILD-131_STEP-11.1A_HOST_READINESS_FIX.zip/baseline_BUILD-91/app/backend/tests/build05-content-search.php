<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentSearchService.php',
    $root.'/src/Controllers/ContentSearchController.php',
    dirname($root).'/database/80_BUILD_05_CONTENT_SEARCH.sql',
];
foreach ($required as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: {$file}\n"); exit(1); }
}
$index = $root.'/public/index.php';
$source = file_get_contents($index);
foreach (['ContentSearchController','ContentSearchService','/api/content-discovery/search'] as $needle) {
    if (strpos($source, $needle) === false) { fwrite(STDERR, "MISSING CONTRACT: {$needle}\n"); exit(1); }
}
echo "BUILD 05 Content Search contract: PASS\n";
