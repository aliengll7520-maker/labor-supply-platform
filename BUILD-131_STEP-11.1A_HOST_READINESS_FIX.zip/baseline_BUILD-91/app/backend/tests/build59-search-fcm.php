<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$search=file_get_contents($root.'/src/Services/ContentSearchService.php');
$push=file_get_contents($root.'/src/Services/PushNotificationService.php');
$index=file_get_contents($root.'/public/index.php');
$worker=file_get_contents($root.'/bin/queue-worker.php');
$checks=[
 'search FULLTEXT'=>str_contains($search,'MATCH(j.tieu_de,j.nganh_nghe,j.dia_diem,j.mo_ta_cong_viec,j.dieu_kien_tuyen_dung)'),
 'search APCu'=>str_contains($search,'apcu_fetch')&&str_contains($search,'apcu_store'),
 'cache invalidation'=>str_contains($search,'invalidateCache')&&str_contains(file_get_contents($root.'/src/Controllers/JobController.php'),'ContentSearchService::invalidateCache'),
 'FCM endpoint'=>str_contains($push,'fcm.googleapis.com/v1/projects/'),
 'no Expo service'=>!str_contains($push,'exp.host'),
 'FCM config'=>str_contains($index,"config['fcm']"),
 'worker FCM'=>str_contains($worker,"'provider'=>'fcm'"),
 'location RAM snapshot'=>str_contains($search,'warmLocationSnapshots')&&str_contains($search,'locationMetaKey')&&str_contains($search,'locationChunkKey'),
 'location RAM fast path'=>str_contains($search,"'source'=>'location_ram'"),
 'location sync from worker'=>str_contains(file_get_contents($root.'/src/Services/ContentDiscoveryProjectionWorker.php'),'syncWarmedJobById'),
 'location warm CLI'=>is_file($root.'/bin/content-search-warm.php') && str_contains(file_get_contents($root.'/bin/content-search-warm.php'),'warmLocationSnapshots'),
];
$failed=[]; foreach($checks as $k=>$v){echo ($v?'PASS':'FAIL').' '.$k.PHP_EOL;if(!$v)$failed[]=$k;}
exit($failed?1:0);
