<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$tool = file_get_contents($root.'/tools/stress-test/stress-test.php');
$doc = file_get_contents(dirname($root).'/PR13_STRESS_CAPACITY.md');
$runbook = file_get_contents(dirname($root).'/ops/stress-test/README.md');
$checks = [];
$checks['curl_multi'] = str_contains($tool, 'curl_multi_init') && str_contains($tool, 'curl_multi_exec') && str_contains($tool, 'curl_multi_info_read');
$checks['levels'] = str_contains($tool, "explode(',',") && str_contains($tool, '$levels');
$checks['cap_200'] = str_contains($tool, '$n <= 200');
$checks['p95'] = str_contains($tool, 'percentile($latencies, 0.95)');
$checks['error_rate'] = str_contains($tool, '$errorRate');
$checks['capacity_gate'] = str_contains($tool, 'highest_contiguous_passing_level') && str_contains($tool, 'first_breached_level') && str_contains($tool, 'capacity_gate_pass') && str_contains($tool, '$contiguousPassing');
$checks['stop_breach'] = str_contains($tool, '$stopOnBreach');
$checks['staging_first'] = str_contains($runbook, 'staging') && str_contains($runbook, 'production');
$checks['no_runtime_pr13'] = !preg_match('/[\'"](?:build|version|release)[\'"]\s*=>\s*[\'"]PR-?13/i', $tool . $doc . $runbook);
$ok = true;
foreach ($checks as $k => $v) { echo ($v ? 'PASS' : 'FAIL')." $k\n"; $ok = $ok && $v; }
exit($ok ? 0 : 1);
