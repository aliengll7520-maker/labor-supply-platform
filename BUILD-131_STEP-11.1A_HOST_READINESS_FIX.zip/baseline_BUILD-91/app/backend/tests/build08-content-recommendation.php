<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
    $root.'/src/Services/ContentRecommendationService.php',
    $root.'/src/Controllers/ContentRecommendationController.php',
    $root.'/public/index.php',
];
foreach ($checks as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: $file\n"); exit(1); }
}
$index = file_get_contents($root.'/public/index.php');
foreach (['ContentRecommendationController','ContentRecommendationService','/api/content-discovery/jobs/(\\d+)/recommendations'] as $needle) {
    if (strpos($index, $needle) === false) { fwrite(STDERR, "MISSING ROUTE TOKEN: $needle\n"); exit(1); }
}
$service = file_get_contents($root.'/src/Services/ContentRecommendationService.php');
foreach (['industry_location_salary_recency','recommendation_score','personalization'] as $needle) {
    if (strpos($service, $needle) === false) { fwrite(STDERR, "MISSING SERVICE TOKEN: $needle\n"); exit(1); }
}
echo "BUILD-08 CONTENT RECOMMENDATION CONTRACT: PASS\n";
