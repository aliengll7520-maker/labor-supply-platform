<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$checks = [
 $root.'/src/Services/ContentSeoLifecycleService.php',
 $root.'/src/Controllers/ContentSeoLifecycleController.php',
 $root.'/public/index.php',
 dirname($root).'/database/85_BUILD_14_CONTENT_SEO_LIFECYCLE.sql',
];
foreach ($checks as $file) { if (!is_file($file)) { fwrite(STDERR,"MISSING: $file\n"); exit(1); } }
$service=file_get_contents($root.'/src/Services/ContentSeoLifecycleService.php');
foreach(['tin_tuyen_dung','indexable','retired','structured_data_allowed','sitemap_allowed','fingerprint','content_discovery_seo_lifecycle'] as $needle){if(strpos($service,$needle)===false){fwrite(STDERR,"MISSING TOKEN: $needle\n");exit(1);}}
$index=file_get_contents($root.'/public/index.php');
foreach(['ContentSeoLifecycleService','ContentSeoLifecycleController','seo-lifecycle'] as $needle){if(strpos($index,$needle)===false){fwrite(STDERR,"MISSING ROUTE TOKEN: $needle\n");exit(1);}}
echo "BUILD-14 CONTENT SEO LIFECYCLE CONTRACT: PASS\n";
