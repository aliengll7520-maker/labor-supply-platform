<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentDiscoveryService.php',
    $root.'/src/Controllers/ContentDiscoveryController.php',
    dirname($root).'/database/76_BUILD_01_CONTENT_DISCOVERY_FOUNDATION.sql',
];

foreach ($required as $file) {
    if (!is_file($file)) {
        fwrite(STDERR, "MISSING: {$file}\n");
        exit(1);
    }
}

echo "BUILD 01 Content Discovery Foundation contract: PASS\n";
