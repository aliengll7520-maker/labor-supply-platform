<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$checks=[
 'migration'=>file_exists(dirname($root).'/database/95_BUILD_43_IDENTITY_SECURITY_HARDENING.sql'),
 'service'=>file_exists($root.'/src/Services/IdentitySecurityService.php'),
 'controller'=>file_exists($root.'/src/Controllers/IdentitySecurityController.php'),
 'request_route'=>str_contains(file_get_contents($root.'/public/index.php'),"/api/identity/security/password-reset/request"),
 'confirm_route'=>str_contains(file_get_contents($root.'/public/index.php'),"/api/identity/security/password-reset/confirm"),
 'events_route'=>str_contains(file_get_contents($root.'/public/index.php'),"/api/identity/security/events"),
 'token_hash'=>str_contains(file_get_contents($root.'/src/Services/IdentitySecurityService.php'),"hash('sha256',trim(\$token))"),
 'single_use'=>str_contains(file_get_contents($root.'/src/Services/IdentitySecurityService.php'),'status="used"'),
 'generic_response'=>str_contains(file_get_contents($root.'/src/Controllers/IdentitySecurityController.php'),'Nếu tài khoản tồn tại'),
 'rate_limits'=>str_contains(file_get_contents($root.'/config/config.php'),'/api/identity/security/password-reset'),
 'no_merge'=>str_contains(file_get_contents(dirname($root).'/database/95_BUILD_43_IDENTITY_SECURITY_HARDENING.sql'),'identity_auto_merge_disabled'),
];
$ok=0;foreach($checks as $k=>$v){echo $k.': '.($v?'PASS':'FAIL').PHP_EOL;if($v)$ok++;}
echo 'BUILD-43 CONTRACT: '.$ok.'/'.count($checks).' PASS'.PHP_EOL; exit($ok===count($checks)?0:1);
