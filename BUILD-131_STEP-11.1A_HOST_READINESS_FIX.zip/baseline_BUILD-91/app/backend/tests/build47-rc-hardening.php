<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$app=dirname($root);
$checks=[];
$checks['build46_contract']=is_file($root.'/tests/build46-exception-center.php');
$checks['reconciliation_contract']=is_file($root.'/tests/build45-content-discovery-reconciliation.php');
$checks['identity_security_contract']=is_file($root.'/tests/build43-identity-security.php');
$checks['self_flow_contract']=is_file($root.'/tests/build44-self-flow-closure.php');
$checks['production_preflight']=is_file($app.'/ops/production/preflight.sh');
$checks['production_runbook']=is_file($app.'/ops/production/runbook.md');
$checks['production_gate']=is_file($app.'/ops/release/production-readiness-gate.sh');
$checks['env_example']=is_file($app.'/ops/production/env.production.example');
$checks['no_real_env']=!is_file($app.'/ops/production/env.production');
$checks['php_hardening']=is_file($app.'/ops/production/php/php-production.ini') && str_contains(file_get_contents($app.'/ops/production/php/php-production.ini'),'display_errors=Off') && str_contains(file_get_contents($app.'/ops/production/php/php-production.ini'),'session.use_strict_mode=1');
$checks['nginx_hardening']=is_file($app.'/ops/production/nginx/default.conf') && str_contains(file_get_contents($app.'/ops/production/nginx/default.conf'),'client_body_timeout') && str_contains(file_get_contents($app.'/ops/production/nginx/default.conf'),'deny all');
$checks['frontend_build_contract']=is_file($app.'/frontend/website/package.json') && str_contains(file_get_contents($app.'/frontend/website/package.json'),'"build": "vite build"');
$checks['queue_enabled_by_default']=str_contains(file_get_contents($root.'/config/config.php'),'LABOR_QUEUE_ENABLED') && str_contains(file_get_contents($root.'/config/config.php'),'?: \'true\'');
$checks['auto_recovery_enabled']=str_contains(file_get_contents($root.'/config/config.php'),'LABOR_AUTO_RECOVERY_ENABLED');
$checks['discovery_reconciliation_enabled']=str_contains(file_get_contents($root.'/config/config.php'),'LABOR_DISCOVERY_RECONCILIATION_ENABLED');
$checks['operations_exception_center']=is_file($root.'/src/Services/OperationsService.php') && str_contains(file_get_contents($root.'/src/Services/OperationsService.php'),'exceptionCenter');
$checks['health_route']=str_contains(file_get_contents($root.'/public/index.php'),'/api/health/operations');
$checks['exception_route']=str_contains(file_get_contents($root.'/public/index.php'),'/api/admin/operations/exceptions');
$checks['rc_docs']=is_file($app.'/ops/rc/RC_RUNBOOK.md') && is_file($app.'/ops/rc/RC_CHECKLIST.md');
$checks['no_runtime_build_marker']=true;
$runtimeDirs=[$root.'/src',$root.'/public',$root.'/bin',$app.'/ops'];
foreach($runtimeDirs as $dir){ if(!is_dir($dir)) continue; $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)); foreach($it as $f){ if(!$f->isFile()) continue; $ext=strtolower($f->getExtension()); if(!in_array($ext,['php','sh'],true)) continue; $s=@file_get_contents($f->getPathname()); if($s!==false && preg_match('/[\'\"]LABOR_BUILD_ID\s*=\s*[\'\"]?[0-9]+|[\'\"]PR-1[0-5][\'\"]/', $s)){ $checks['no_runtime_build_marker']=false; break 2; } } }
$fail=[]; foreach($checks as $k=>$v){ echo ($v?'PASS ':'FAIL ').$k.PHP_EOL; if(!$v)$fail[]=$k; }
echo $fail ? 'BUILD-47 RC HARDENING: FAIL'.PHP_EOL : 'BUILD-47 RC HARDENING: PASS'.PHP_EOL;
exit($fail?1:0);
