<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentFeedService.php',
    $root.'/src/Controllers/ContentFeedController.php',
    dirname($root).'/database/81_BUILD_06_CONTENT_FEED.sql',
];
foreach ($required as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: {$file}\n"); exit(1); }
}
$index = $root.'/public/index.php';
$source = file_get_contents($index);
foreach (['ContentFeedController','ContentFeedService','/api/content-discovery/feed'] as $needle) {
    if (strpos($source, $needle) === false) { fwrite(STDERR, "MISSING CONTRACT: {$needle}\n"); exit(1); }
}
echo "BUILD 06 Content Feed contract: PASS\n";
