<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$index = file_get_contents(__DIR__.'/../public/index.php');
$ops = file_get_contents(__DIR__.'/../src/Services/OperationsService.php');
$queue = file_get_contents(__DIR__.'/../src/Controllers/QueueController.php');
$monitor = file_get_contents(__DIR__.'/../bin/operations-monitor.php');
$metrics = file_get_contents(__DIR__.'/../src/Services/OperationsRequestMetricsService.php');

$checks = [
    'request metrics service exists' => str_contains($metrics, 'function register('),
    'request metrics registered after DB bind' => strpos($index, 'RequestContext::bindDatabase($db);') < strpos($index, '$requestMetrics->register('),
    'metrics registered before traffic guard' => strpos($index, '$requestMetrics->register(') < strpos($index, '$trafficGuard->apply();'),
    'shutdown metric capture exists' => str_contains($metrics, 'register_shutdown_function'),
    'operations runtime has no PR10 build marker' => !str_contains($ops, "'build'=>'PR10'"),
    'queue runtime has no PR10 marker' => !str_contains($queue, "'monitoring'=>'PR10'"),
    'monitor runtime has no PR10 marker' => !str_contains($monitor, "'monitoring'=>'PR10'"),
    'PR10 documentation remains' => file_exists($root.'/PR10_MONITORING_ALERT.md'),
];

$failed = [];
foreach ($checks as $name => $ok) {
    echo ($ok ? 'PASS' : 'FAIL')." — {$name}\n";
    if (!$ok) $failed[] = $name;
}
exit($failed ? 1 : 0);
