<?php
declare(strict_types=1);
$root=dirname(__DIR__,2);
$checks=[];
$checks['migration']=is_file($root.'/database/94_BUILD_41_IDENTITY_VERIFICATION.sql');
$checks['service']=is_file(__DIR__.'/../src/Services/IdentityVerificationService.php');
$checks['controller']=is_file(__DIR__.'/../src/Controllers/IdentityVerificationController.php');
$index=file_get_contents(__DIR__.'/../public/index.php');
$checks['route_status']=str_contains($index,"/api/identity/verification");
$checks['route_request']=str_contains($index,"/api/identity/verification/request");
$checks['route_confirm']=str_contains($index,"/api/identity/verification/confirm");
$service=file_get_contents(__DIR__.'/../src/Services/IdentityVerificationService.php');
$checks['hash_only']=str_contains($service,"hash('sha256'") && !str_contains($service,'challenge_code');
$checks['attempt_limit']=str_contains($service,'max_attempts');
$checks['expiry']=str_contains($service,'expires_at');
$checks['no_merge']=str_contains($service,'identity_principals SET trang_thai');
$failed=array_keys(array_filter($checks,fn($v)=>!$v));
foreach($checks as $k=>$v) echo ($v?'PASS ':'FAIL ').$k.PHP_EOL;
if($failed){fwrite(STDERR,'BUILD-41 FAILED: '.implode(', ',$failed).PHP_EOL);exit(1);}
echo 'BUILD-41 CONTRACT: PASS '.count($checks).'/'.count($checks).PHP_EOL;
