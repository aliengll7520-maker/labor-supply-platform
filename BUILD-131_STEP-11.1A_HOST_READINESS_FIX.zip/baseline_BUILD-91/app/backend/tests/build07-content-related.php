<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentRelatedService.php',
    $root.'/src/Controllers/ContentRelatedController.php',
];
foreach ($required as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: {$file}\n"); exit(1); }
}
$index = $root.'/public/index.php';
$source = file_get_contents($index);
foreach (['ContentRelatedController','ContentRelatedService','/api/content-discovery/jobs/','/related$'] as $needle) {
    if (strpos($source, $needle) === false) { fwrite(STDERR, "MISSING CONTRACT: {$needle}\n"); exit(1); }
}
echo "BUILD 07 Content Related contract: PASS\n";
