<?php
declare(strict_types=1);

$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentTagService.php',
    $root.'/src/Controllers/ContentTagController.php',
    dirname($root).'/database/78_BUILD_03_CONTENT_TAGS.sql',
];
foreach ($required as $file) {
    if (!is_file($file)) { fwrite(STDERR, "MISSING: {$file}\n"); exit(1); }
}
$index = $root.'/public/index.php';
$source = file_get_contents($index);
foreach (['ContentTagController','ContentTagService','/api/content-discovery/jobs/(\\d+)/tags'] as $needle) {
    if (strpos($source, $needle) === false) { fwrite(STDERR, "MISSING CONTRACT: {$needle}\n"); exit(1); }
}
echo "BUILD 03 Content Tags / Hashtags contract: PASS\n";
