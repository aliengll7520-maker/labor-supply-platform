<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$checks=[];
$index=file_get_contents($root.'/public/index.php');
$admin=file_get_contents($root.'/src/Core/AdminAuth.php');
$policy=file_get_contents($root.'/src/Core/SecurityPolicy.php');
$checks['security_policy_loaded']=str_contains($index,"src/Core/SecurityPolicy.php");
$checks['security_headers']=str_contains($index,'SecurityPolicy::applyHeaders()');
$checks['request_envelope']=str_contains($index,'SecurityPolicy::validateRequestEnvelope');
$checks['admin_db_binding']=str_contains($index,'AdminAuth::bindDatabase($db)');
$checks['admin_role_validation']=str_contains($admin,'Vai trò Quản trị không hợp lệ.');
$checks['admin_live_status_check']=str_contains($admin,"SELECT trang_thai FROM tai_khoan_quan_tri");
$checks['hsts_https_only']=str_contains($policy,"Strict-Transport-Security");
$checks['json_limit']=str_contains($policy,'Payload quá lớn.');
$checks['multipart_preserved']=str_contains($policy,'multipart/form-data');
$checks['no_runtime_pr11']=!preg_match('/[\'\"](?:build|version|release)[\'\"]\s*=>\s*[\'\"]PR-?11/i',$index.$admin.$policy);
$ok=true; foreach($checks as $k=>$v){echo ($v?'PASS':'FAIL')." $k\n"; $ok=$ok&&$v;} exit($ok?0:1);
