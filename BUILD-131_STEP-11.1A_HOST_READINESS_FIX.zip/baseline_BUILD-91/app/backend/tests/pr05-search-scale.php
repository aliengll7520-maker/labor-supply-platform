<?php
declare(strict_types=1);

$root = dirname(__DIR__, 2);
$controller = file_get_contents($root.'/backend/src/Controllers/JobController.php');
$migration = file_get_contents($root.'/database/71_PR05_SEARCH_SCALE.sql');

$checks = [
    'q uses FULLTEXT' => str_contains($controller, 'MATCH(t.tieu_de,t.nganh_nghe,t.dia_diem) AGAINST(:search_q IN BOOLEAN MODE)'),
    'province filter' => str_contains($controller, '$_GET[\'province\']'),
    'legacy location compatibility' => str_contains($controller, '$_GET[\'dia_diem\']'),
    'district filter' => str_contains($controller, '$_GET[\'district\']'),
    'salary min/max' => str_contains($controller, 'salary_min') && str_contains($controller, 'salary_max'),
    'page/per_page contract' => str_contains($controller, 'per_page') && str_contains($controller, 'X-Search-Page'),
    'stable ordering' => str_contains($controller, 'ORDER BY t.ngay_dang DESC,t.id DESC'),
    'composite status/date index' => str_contains($migration, 'idx_job_public_status_date'),
    'income index' => str_contains($migration, 'idx_job_public_status_income'),
    'fulltext index' => str_contains($migration, 'ft_job_public_search'),
];
$failed = array_keys(array_filter($checks, static fn(bool $ok): bool => !$ok));
foreach ($checks as $name=>$ok) echo ($ok?'PASS':'FAIL').' '.$name.PHP_EOL;
if ($failed) exit(1);
