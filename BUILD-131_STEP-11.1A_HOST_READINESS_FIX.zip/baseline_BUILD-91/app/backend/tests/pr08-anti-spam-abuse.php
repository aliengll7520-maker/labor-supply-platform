<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$ok=0;$fail=0;
function checkx(string $name,bool $v): void {global $ok,$fail;if($v){$ok++;echo "PASS: $name\n";}else{$fail++;echo "FAIL: $name\n";}}
$guard=file_get_contents($root.'/src/Core/TrafficGuard.php');
$config=file_get_contents($root.'/config/config.php');
$social=file_get_contents($root.'/src/Controllers/SocialController.php');
$routes=file_get_contents($root.'/public/index.php');
checkx('TrafficGuard supports exact path rules',str_contains($guard,"'path'"));
checkx('TrafficGuard supports suffix rules',str_contains($guard,"'path_suffix'"));
checkx('More specific rate rule wins',str_contains($guard,'usort($matches'));
checkx('Post creation is rate limited',str_contains($config,"['path'=>'/api/social/posts','method'=>'POST','limit'=>5"));
checkx('Follow is rate limited',str_contains($config,"/api/social/follow/"));
checkx('Block is rate limited',str_contains($config,"/api/social/block/"));
checkx('Comment is rate limited',str_contains($config,"/api/social/comments/"));
checkx('Report suffix is rate limited',str_contains($config,"'path_suffix'=>'/report'"));
checkx('Duplicate post report is rejected while open',str_contains($social,'Bạn đã báo cáo bài đăng này và đang chờ xử lý.'));
checkx('Duplicate comment report is rejected while open',str_contains($social,'Bạn đã báo cáo bình luận này và đang chờ xử lý.'));
checkx('Social report route remains authenticated by actor()',str_contains($social,'public function reportPost') && preg_match('/public function reportPost.*?\$a=\$this->actor\(\)/s',$social));
checkx('Public feed route remains GET',str_contains($routes,"/api/social/feed") && str_contains($routes,'$social->feed();'));
echo "RESULT: {$ok} PASS, {$fail} FAIL\n"; exit($fail?1:0);
