<?php
declare(strict_types=1);
$root=dirname(__DIR__);
$guard=file_get_contents($root.'/src/Core/TrafficGuard.php');
$ctx=file_get_contents($root.'/src/Core/RequestContext.php');
$index=file_get_contents($root.'/public/index.php');
$social=file_get_contents($root.'/src/Controllers/SocialController.php');
$ok=0;$fail=0;
function checkx(string $name,bool $condition): void { global $ok,$fail; if($condition){$ok++;echo "PASS $name\n";}else{$fail++;echo "FAIL $name\n";} }
checkx('RequestContext binds database',str_contains($ctx,'bindDatabase'));
checkx('Worker actor key resolves stable worker id',str_contains($ctx, "return 'nguoi_lao_dong:'.\$workerId"));
checkx('Supplier actor key uses supplier/account ids',str_contains($ctx, "return 'nha_cung_ung:'.\$supplierId"));
checkx('TrafficGuard uses actorKey',str_contains($guard,'RequestContext::actorKey()'));
checkx('Database is bound before TrafficGuard',strpos($index,'RequestContext::bindDatabase($db)')<strpos($index,'$trafficGuard->apply()'));
checkx('Report comment locks target row',str_contains($social,'SELECT id,bai_dang_id,trang_thai FROM social_binh_luan WHERE id=? FOR UPDATE'));
checkx('Report post locks target row',str_contains($social,'SELECT id FROM social_bai_dang WHERE id=? AND trang_thai="cong_khai" FOR UPDATE'));
checkx('Report comment check is inside transaction',str_contains($social,'$this->db->beginTransaction();'));
checkx('Report paths rollback before 409',str_contains($social,'rollBack(); Response::error(\'Bạn đã báo cáo'));
checkx('No token-only actor bucket',!str_contains($ctx, "return 'auth:'.hash('sha256', \$auth)"));
echo "TOTAL $ok PASS, $fail FAIL\n";
exit($fail?1:0);
