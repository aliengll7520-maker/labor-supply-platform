<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$required = [
    $root.'/src/Services/ContentTopicLocationService.php',
    $root.'/src/Controllers/ContentTopicLocationController.php',
    dirname($root).'/database/79_BUILD_04_TOPIC_LOCATION.sql',
];
foreach ($required as $file) if (!is_file($file)) { fwrite(STDERR,"MISSING: {$file}\n"); exit(1); }
$index = $root.'/public/index.php'; $source=file_get_contents($index);
foreach (['ContentTopicLocationController','ContentTopicLocationService','/api/content-discovery/jobs/(\\d+)/taxonomy'] as $needle)
    if (strpos($source,$needle)===false) { fwrite(STDERR,"MISSING CONTRACT: {$needle}\n"); exit(1); }
echo "BUILD 04 Topic / Location contract: PASS\n";
