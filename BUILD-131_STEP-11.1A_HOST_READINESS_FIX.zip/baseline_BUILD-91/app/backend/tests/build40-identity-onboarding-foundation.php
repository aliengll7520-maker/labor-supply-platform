<?php
declare(strict_types=1);

$root=dirname(__DIR__);
$service=$root.'/src/Services/IdentityService.php';
$controller=$root.'/src/Controllers/IdentityController.php';
$worker=$root.'/src/Controllers/WorkerAuthController.php';
$supplier=$root.'/src/Controllers/SupplierController.php';
$index=$root.'/public/index.php';
$migration=dirname($root).'/database/93_BUILD_40_IDENTITY_ONBOARDING_FOUNDATION.sql';

$checks=[
    'IdentityService exists'=>is_file($service),
    'IdentityController exists'=>is_file($controller),
    'Identity migration exists'=>is_file($migration),
    'Worker auth syncs identity'=>str_contains((string)file_get_contents($worker),'syncWorker'),
    'Supplier auth syncs identity'=>str_contains((string)file_get_contents($supplier),'syncEmployerAccount'),
    'Identity endpoint exists'=>str_contains((string)file_get_contents($index),"/api/identity/me"),
    'Identity migration has principals'=>str_contains((string)file_get_contents($migration),'CREATE TABLE IF NOT EXISTS identity_principals'),
    'Identity migration has roles'=>str_contains((string)file_get_contents($migration),'CREATE TABLE IF NOT EXISTS identity_role_memberships'),
    'Identity migration blocks implicit merge'=>str_contains((string)file_get_contents($migration),'identity_auto_merge_disabled'),
];

$failed=[];
foreach($checks as $name=>$ok){echo ($ok?'PASS':'FAIL')." - $name\n";if(!$ok)$failed[]=$name;}
if($failed){echo "FAILED: ".count($failed)."\n";exit(1);}echo "BUILD-40 IDENTITY FOUNDATION: PASS\n";
