<?php
$src=file_get_contents(__DIR__.'/../src/Queue/QueueService.php');
$checks=[
 'attempts < max' => strpos($src, 'attempts')!==false && strpos($src, 'max_attempts')!==false,
 'dead on max attempts' => strpos($src, 'status="dead"')!==false && strpos($src, 'max attempts reached')!==false,
 'dead letter recovery' => strpos($src, 'queue_dead_letters')!==false,
 'transaction' => strpos($src, '$this->db->beginTransaction()')!==false,
 'row lock' => strpos($src, 'FOR UPDATE')!==false,
 'stale retry' => strpos($src, 'status="queued"')!==false && strpos($src, 'lease expired')!==false,
];
$ok=true; foreach($checks as $k=>$v){echo ($v?'PASS':'FAIL')." $k\n"; $ok=$ok&&$v;} exit($ok?0:1);
