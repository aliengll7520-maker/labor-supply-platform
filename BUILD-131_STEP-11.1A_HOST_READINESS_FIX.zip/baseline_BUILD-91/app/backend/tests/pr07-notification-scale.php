<?php
declare(strict_types=1);

$root=dirname(__DIR__,2);
$checks=[];
$checks['migration_exists']=is_file($root.'/database/73_PR07_NOTIFICATION_SCALE.sql');
$checks['delivery_key_schema']=str_contains(file_get_contents($root.'/database/73_PR07_NOTIFICATION_SCALE.sql'),'delivery_key VARCHAR(191)');
$checks['delivery_unique']=str_contains(file_get_contents($root.'/database/73_PR07_NOTIFICATION_SCALE.sql'),'uq_notification_delivery_key');
$checks['delivery_processing_state']=str_contains(file_get_contents($root.'/database/73_PR07_NOTIFICATION_SCALE.sql'),"ENUM('queued','processing','sent','failed')");
$checks['delivery_claim_lease']=str_contains(file_get_contents($root.'/backend/bin/queue-worker.php'),'delivery_claimed_at') && str_contains(file_get_contents($root.'/backend/bin/queue-worker.php'),'claimSeconds = 90');
$checks['queued_not_already_sent']=str_contains(file_get_contents($root.'/backend/bin/queue-worker.php'),'Only a fresh processing lease means another worker is actively sending.');
$checks['notification_indexes']=str_contains(file_get_contents($root.'/database/73_PR07_NOTIFICATION_SCALE.sql'),'idx_thong_bao_recipient_read_id');
$checks['queue_delivery_key']=str_contains(file_get_contents($root.'/backend/src/Services/WorkerNotificationEventService.php'),"'delivery_key' =>");
$checks['worker_idempotency']=str_contains(file_get_contents($root.'/backend/bin/queue-worker.php'),'INSERT IGNORE INTO notification_delivery_log') && str_contains(file_get_contents($root.'/backend/bin/queue-worker.php'),'WHERE delivery_key=? LIMIT 1 FOR UPDATE');
$checks['retry_remains']=str_contains(file_get_contents($root.'/backend/src/Queue/QueueService.php'),'retry_base_seconds');
$checks['deep_link_payload']=str_contains(file_get_contents($root.'/backend/src/Services/WorkerNotificationEventService.php'),"'target' =>");
$checks['supplier_column_consistency']=str_contains(file_get_contents($root.'/backend/src/Controllers/NotificationController.php'),'doi_tuong="nha_cung_ung"');
$checks['admin_column_consistency']=str_contains(file_get_contents($root.'/backend/src/Controllers/NotificationController.php'),'doi_tuong="quan_tri"');
foreach($checks as $k=>$v) echo ($v?'PASS':'FAIL')." $k
";
$failed=array_filter($checks,fn($v)=>!$v);
exit($failed?1:0);
