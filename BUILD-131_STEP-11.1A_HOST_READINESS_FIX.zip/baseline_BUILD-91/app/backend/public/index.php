<?php
declare(strict_types=1);
// BUILD-36 compatibility layer: legacy interview-registration API retained temporarily; frontend uses /applications.

use LaborPlatform\Core\{
    Database,
    Response,
    Request,
    Auth,
    WorkerAuth,
    MobileAuth,
    AdminAuth,
    TrafficGuard,
    RequestContext,
    SecurityPolicy
};

use LaborPlatform\Services\{
    AuditService,
    NotificationService,
    PushNotificationService,
    SupplierCommunicationService,
    AutoJobModerationService,
    GoogleOAuthService,
    JobMatchingService,
    ContentDiscoveryService,
    ContentClassificationService
};

use LaborPlatform\Controllers\{
    TrustReputationController,
    WorkerPushTokenController,
    ApplicationRegistrationController,
    WorkerAuthController,
    MobileAuthController,
    WorkerProfileController,
    WorkerPostController,
    WorkerFavoriteController,
    SupplierController,
    JobController,
    AdminSupplierController,
    NotificationController,
    DashboardController,
    AdminJobController,
    PlatformExtensionController,
    AdminControlCenterController,
    IdentityController,
    IdentityVerificationController,
    IdentityOnboardingController,
    IdentitySecurityController,
    EmployerController,
    SocialController,
    SocialAdminController,
    MediaController,
    AdNetworkController,
    QueueController,
    OperationsController,
    PersonalSocialController,
    ContentDiscoveryController,
    ContentClassificationController,
    ContentTagController,
    ContentTopicLocationController,
    ContentRelatedController
};

$config=require dirname(__DIR__).'/config/config.php';

require_once dirname(__DIR__).'/src/Core/Database.php';
require_once dirname(__DIR__).'/src/Core/Response.php';
require_once dirname(__DIR__).'/src/Core/Request.php';
require_once dirname(__DIR__).'/src/Core/Auth.php';
require_once dirname(__DIR__).'/src/Core/DatabaseSessionHandler.php';
require_once dirname(__DIR__).'/src/Core/AdminAuth.php';
require_once dirname(__DIR__).'/src/Core/WorkerAuth.php';
require_once dirname(__DIR__).'/src/Core/MobileAuth.php';
require_once dirname(__DIR__).'/src/Core/RequestContext.php';
require_once dirname(__DIR__).'/src/Core/SecurityPolicy.php';
require_once dirname(__DIR__).'/src/Core/TrafficGuard.php';
require_once dirname(__DIR__).'/src/Core/IdempotencyKey.php';
require_once dirname(__DIR__).'/src/Core/ApiIdempotency.php';
require_once dirname(__DIR__).'/src/Core/Pagination.php';
require_once dirname(__DIR__).'/src/Queue/QueueService.php';
require_once dirname(__DIR__).'/src/Queue/JobRegistry.php';
require_once dirname(__DIR__).'/src/Queue/WorkerRunner.php';

require_once dirname(__DIR__).'/src/Services/AuditService.php';
require_once dirname(__DIR__).'/src/Services/NotificationService.php';
require_once dirname(__DIR__).'/src/Services/PushNotificationService.php';
require_once dirname(__DIR__).'/src/Services/EmailNotificationService.php';
require_once dirname(__DIR__).'/src/Services/PhoneMaskService.php';
require_once dirname(__DIR__).'/src/Services/SupplierCommunicationService.php';
require_once dirname(__DIR__).'/src/Services/AutoJobModerationService.php';
require_once dirname(__DIR__).'/src/Services/AutoContentModerationService.php';
require_once dirname(__DIR__).'/src/Services/ContentSafetyService.php';
require_once dirname(__DIR__).'/src/Services/ContentDiscoveryService.php';
require_once dirname(__DIR__).'/src/Services/ContentClassificationService.php';
require_once dirname(__DIR__).'/src/Services/ContentTopicLocationService.php';
require_once dirname(__DIR__).'/src/Services/GoogleOAuthService.php';
require_once dirname(__DIR__).'/src/Services/DataProtectionService.php';

require_once dirname(__DIR__).'/src/Controllers/WorkerAuthController.php';
require_once dirname(__DIR__).'/src/Controllers/MobileAuthController.php';
require_once dirname(__DIR__).'/src/Services/MobileBootstrapService.php';
require_once dirname(__DIR__).'/src/Controllers/MobileBootstrapController.php';
require_once dirname(__DIR__).'/src/Controllers/IdentityController.php';
require_once dirname(__DIR__).'/src/Services/IdentityService.php';
require_once dirname(__DIR__).'/src/Services/TaxAuthorityVerificationService.php';
require_once dirname(__DIR__).'/src/Services/IdentityVerificationService.php';
require_once dirname(__DIR__).'/src/Controllers/IdentityVerificationController.php';
require_once dirname(__DIR__).'/src/Services/IdentityOnboardingService.php';
require_once dirname(__DIR__).'/src/Controllers/IdentityOnboardingController.php';
require_once dirname(__DIR__).'/src/Services/IdentitySecurityService.php';
require_once dirname(__DIR__).'/src/Controllers/IdentitySecurityController.php';
require_once dirname(__DIR__).'/src/Controllers/WorkerProfileController.php';
require_once dirname(__DIR__).'/src/Controllers/WorkerFavoriteController.php';
require_once dirname(__DIR__).'/src/Controllers/WorkerPushTokenController.php';
require_once dirname(__DIR__).'/src/Services/JobMatchingService.php';
require_once dirname(__DIR__).'/src/Controllers/WorkerApplicationController.php';
require_once dirname(__DIR__).'/src/Controllers/ApplicationRegistrationController.php';
require_once dirname(__DIR__).'/src/Services/WorkerNotificationEventService.php';
require_once dirname(__DIR__).'/src/Services/ApplicationStatusWorkflowService.php';
require_once dirname(__DIR__).'/src/Controllers/SupplierController.php';
require_once dirname(__DIR__).'/src/Controllers/JobController.php';
require_once dirname(__DIR__).'/src/Controllers/AdminSupplierController.php';
require_once dirname(__DIR__).'/src/Controllers/NotificationController.php';
require_once dirname(__DIR__).'/src/Controllers/DashboardController.php';
require_once dirname(__DIR__).'/src/Controllers/AdminJobController.php';
require_once dirname(__DIR__).'/src/Core/ModuleRegistry.php';
require_once dirname(__DIR__).'/src/Services/PlatformExtensionService.php';
require_once dirname(__DIR__).'/src/Controllers/PlatformExtensionController.php';
require_once dirname(__DIR__).'/src/Controllers/AdminControlCenterController.php';
require_once dirname(__DIR__).'/src/Controllers/AdminDataProtectionController.php';
require_once dirname(__DIR__).'/src/Controllers/EmployerController.php';
require_once dirname(__DIR__).'/src/Controllers/SocialController.php';
require_once dirname(__DIR__).'/src/Controllers/ProfessionalIdentityController.php';
require_once dirname(__DIR__).'/src/Controllers/SocialAdminController.php';
require_once dirname(__DIR__).'/src/Controllers/MediaController.php';
require_once dirname(__DIR__).'/src/Controllers/AdNetworkController.php';
require_once dirname(__DIR__).'/src/Controllers/QueueController.php';
require_once dirname(__DIR__).'/src/Contracts/MediaStorageInterface.php';
require_once dirname(__DIR__).'/src/Services/Media/LocalMediaStorage.php';
require_once dirname(__DIR__).'/src/Services/Media/S3CompatibleMediaStorage.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaStorageFactory.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaStorageService.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaCdnService.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaCleanupService.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaPolicyService.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaBackupService.php';
require_once dirname(__DIR__).'/src/Services/Media/ImageProcessingService.php';
require_once dirname(__DIR__).'/src/Services/Media/MediaSecurityService.php';
require_once dirname(__DIR__).'/src/Services/OperationsService.php';
require_once dirname(__DIR__).'/src/Services/OperationsRequestMetricsService.php';
require_once dirname(__DIR__).'/src/Controllers/OperationsController.php';
require_once dirname(__DIR__).'/src/Controllers/ContentClassificationController.php';
require_once dirname(__DIR__).'/src/Services/ContentTagService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentTagController.php';
require_once dirname(__DIR__).'/src/Controllers/ContentTopicLocationController.php';
require_once dirname(__DIR__).'/src/Services/ContentSearchService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentSearchController.php';
require_once dirname(__DIR__).'/src/Services/ContentFeedService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentFeedController.php';
require_once dirname(__DIR__).'/src/Services/ContentRelatedService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentRelatedController.php';
require_once dirname(__DIR__).'/src/Services/ContentRecommendationService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentRecommendationController.php';
require_once dirname(__DIR__).'/src/Services/ContentPublicService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentPublicController.php';
require_once dirname(__DIR__).'/src/Services/ContentUrlService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentUrlController.php';
require_once dirname(__DIR__).'/src/Services/ContentSeoService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentSeoController.php';
require_once dirname(__DIR__).'/src/Services/ContentStructuredDataService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentStructuredDataController.php';
require_once dirname(__DIR__).'/src/Services/ContentSitemapService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentSitemapController.php';
require_once dirname(__DIR__).'/src/Services/ContentSeoLifecycleService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentSeoLifecycleController.php';
require_once dirname(__DIR__).'/src/Services/ContentDiscoveryApiService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentDiscoveryApiController.php';
require_once dirname(__DIR__).'/src/Controllers/ContentDiscoveryDeliveryController.php';
require_once dirname(__DIR__).'/src/Services/ContentDiscoveryEventService.php';
require_once dirname(__DIR__).'/src/Services/ContentDiscoveryAdminOverrideService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentDiscoveryAdminOverrideController.php';
require_once dirname(__DIR__).'/src/Services/ContentDiscoveryProjectionWorker.php';
require_once dirname(__DIR__).'/src/Services/ContentDiscoveryOrchestratorService.php';
require_once dirname(__DIR__).'/src/Controllers/ContentDiscoveryOrchestratorController.php';
require_once dirname(__DIR__).'/src/Controllers/ContentDiscoveryControlController.php';
require_once dirname(__DIR__).'/src/Controllers/ModerationAdminController.php';

/*
 * LIVENESS HEALTH
 * Must work even when Database is unavailable.
 */
RequestContext::start();
SecurityPolicy::applyHeaders();
SecurityPolicy::validateRequestEnvelope((int)(($config['security']['max_json_bytes'] ?? 2097152)));

if(
    Request::method()==='GET' &&
    rtrim(Request::path(), '/')==='/api/health'
)
    Response::ok([
        'service'=>'supplier-core',
        'status'=>'alive',
        'time'=>date('c'),
        'request_id'=>RequestContext::id(),
        'source_version'=>$config['app']['source_version'],'release_id'=>$config['app']['release_id'],'build_id'=>$config['app']['build_id']
    ]);

try {

    $db=Database::connection(
        $config['db']
    );

    // PR-08: bind DB before TrafficGuard so actor-based limits use stable account/worker identity, not bearer-token strings.
    RequestContext::bindDatabase($db);

    // PR-10: register request metrics immediately after DB binding and before TrafficGuard/routing.
    // This captures normal requests and early 4xx/429 responses; liveness remains DB-independent.
    $requestMetrics = new \LaborPlatform\Services\OperationsRequestMetricsService($db, $config['operations'] ?? []);
    $requestMetrics->register(Request::method(), Request::path(), $_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true));

    $trafficGuard=new TrafficGuard($config['high_traffic'] ?? []);
    if (($config['high_traffic']['enabled'] ?? true) === true) {
        $trafficGuard->apply();
    }

    // PR-02: READINESS HEALTH — database must be reachable.
    if(
        Request::method()==='GET' &&
        rtrim(Request::path(), '/')==='/api/ready'
    ) {
        try {
            $stmt=$db->query('SELECT 1');
            $stmt->fetchColumn();
            Response::ok([
                'service'=>'supplier-core',
                'status'=>'ready',
                'database'=>'ok',
                'time'=>date('c'),
                'request_id'=>RequestContext::id(),
                'source_version'=>$config['app']['source_version'],'release_id'=>$config['app']['release_id'],'build_id'=>$config['app']['build_id']
            ]);
        } catch (\Throwable $e) {
            Response::error('Service not ready.',503);
        }
    }

    $audit=new AuditService(
        $db
    );

    Auth::bindDatabase($db);
    AdminAuth::bindDatabase($db);
    // BUILD-81: shared DB-backed PHP sessions make Web/API instances horizontally scalable.
    Auth::start($config['app']);

    // BUILD 82: CSRF bắt buộc cho mutation của khu vực Quản trị.
    if(str_starts_with(Request::path(),'/api/admin/') && Request::method()!=='GET' && !in_array(Request::path(),['/api/admin/login','/api/admin/csrf'],true)) {
        AdminAuth::requireCsrf();
    }

    $autoJobModeration=new AutoJobModerationService($db);

    $googleOAuth=new GoogleOAuthService($config['google'] ?? []);
    $_ENV['LABOR_FRONTEND_URL']=$config['app']['frontend_url'] ?? '/';

    $queue = new QueueService($db, $config['queue'] ?? []);
    $mediaCleanup = new \LaborPlatform\Services\Media\MediaCleanupService($queue, $config['media_cleanup'] ?? []);
    $queueController = new QueueController($queue);
    $operationsService = new \LaborPlatform\Services\OperationsService($db, $queue, $config['operations'] ?? []);
    $operationsController = new OperationsController($operationsService);
    $supplierCommunication=new SupplierCommunicationService($db, $queue);

    $notify=new NotificationService(
        $db
    );

    $identityService = new \LaborPlatform\Services\IdentityService($db);
    $taxVerificationService = new \LaborPlatform\Services\TaxAuthorityVerificationService($config['tax_verification'] ?? []);
    $verificationConfig = $config['identity_verification'] ?? [];
    $identityOnboardingService = new \LaborPlatform\Services\IdentityOnboardingService($db);
    $identityVerificationService = new \LaborPlatform\Services\IdentityVerificationService(
        $db,
        (int)($verificationConfig['ttl_minutes'] ?? 10),
        (int)($verificationConfig['max_attempts'] ?? 5),
        (bool)($verificationConfig['expose_code'] ?? false)
    );
    $identity = new IdentityController($db, $identityService);
    $identityVerification = new IdentityVerificationController($db, $identityService, $identityVerificationService, $identityOnboardingService);
    $identityOnboarding = new IdentityOnboardingController($db, $identityService, $identityOnboardingService);
    $securityConfig = $config['identity_security'] ?? [];
    $identitySecurityService = new \LaborPlatform\Services\IdentitySecurityService($db, (int)($securityConfig['reset_ttl_minutes'] ?? 30), (int)($securityConfig['max_reset_requests'] ?? 5), (bool)($securityConfig['expose_reset_token'] ?? false));
    $identitySecurity = new IdentitySecurityController($identitySecurityService, $identityService);

    $contentDiscoveryEvents = new \LaborPlatform\Services\ContentDiscoveryEventService($db, $queue);

    $adminSupplier=
        new AdminSupplierController(
            $db,
            $audit,
            $notify
        );

    $adminJobs=
        new AdminJobController(
            $db,
            $audit,
            $notify,
            $contentDiscoveryEvents
        );


    $adminControlCenter=new AdminControlCenterController($db);
    $employer=new EmployerController($db,$audit,(bool)($config['live_production']['enabled'] ?? true));
    $dataProtection=new DataProtectionService($db);
    $adminDataProtection=new AdminDataProtectionController($dataProtection);

    $supplier=
        new SupplierController(
            $db,
            $audit,
            $identityService,
            $taxVerificationService
        );

    $jobMatching = new JobMatchingService($db, $queue);

    $jobs=
        new JobController(
            $db,
            $audit,
            $notify,
            $autoJobModeration,
            $jobMatching,
            $contentDiscoveryEvents
        );

    $push = new PushNotificationService(
        $db,
        $config['fcm'] ?? [],
        new \Labor\Backend\Services\FcmDeliveryMetricsService($db)
    );
    $workerEvents=
        new WorkerNotificationEventService(
            $notify,
            $queue
        );

    $applicationWorkflow = new ApplicationStatusWorkflowService(
        $db,
        $workerEvents
    );

    $registrations = new ApplicationRegistrationController(
        $db,
        $audit,
        $notify,
        $workerEvents,
        $queue,
        $applicationWorkflow
    );


    $notifications=
        new NotificationController(
            $db
        );

    $workerPush=
        new WorkerPushTokenController(
            $db,
            $push
        );

    $workerAuth = new WorkerAuthController($db, $googleOAuth, $identityService);
    $mobileAuth = new MobileAuthController($db, $identityService);
    $mobileBootstrap = new \LaborPlatform\Controllers\MobileBootstrapController($db, $identityService, new \LaborPlatform\Services\MobileBootstrapService($config['mobile_bootstrap'] ?? []));
    $workerProfile = new WorkerProfileController($db);
    $workerPosts = new WorkerPostController($db, $audit, $queue);
    $workerFavorites = new WorkerFavoriteController($db);
    $platformExtensions = new PlatformExtensionController(new \LaborPlatform\Services\PlatformExtensionService($db));
    $social = new SocialController($db, $audit, $notify, $queue);
    $personalSocial = new PersonalSocialController($db, $audit, $notify);
    $socialAdmin = new SocialAdminController($db, $audit);
    $moderationAdmin = new ModerationAdminController($db);
    $professionalIdentity = new ProfessionalIdentityController($db, $audit);
    $trustReputation = new TrustReputationController($db, $audit);
    $mediaStorageConfig=$config['media_storage'] ?? [];
    $mediaStorage=\LaborPlatform\Services\Media\MediaStorageFactory::create($mediaStorageConfig);
    $mediaSecurity = new \LaborPlatform\Services\Media\MediaSecurityService((int)($config['media_image']['max_pixels'] ?? 25000000));
    $media = new MediaController($db, $audit, $queue, $mediaStorage, $config['media_image'] ?? [], $mediaSecurity, (string)($mediaStorageConfig['driver'] ?? 'local'), $mediaCleanup, new \LaborPlatform\Services\Media\MediaPolicyService(), (bool)($config['live_production']['enabled'] ?? true));
    $mediaCdn = new \LaborPlatform\Services\Media\MediaCdnService($config['media_cdn'] ?? []);
    $adNetwork = new AdNetworkController($db, $config);
    $contentDiscovery = new ContentDiscoveryController(new ContentDiscoveryService($db));
    $contentClassification = new ContentClassificationController(new ContentClassificationService($db));
    $contentTags = new ContentTagController(new ContentTagService($db));
    $contentTopicLocation = new ContentTopicLocationController(new ContentTopicLocationService($db));
    $contentSearch = new ContentSearchController(new ContentSearchService($db));
    $contentFeed = new ContentFeedController(new ContentFeedService($db));
    $contentRelated = new ContentRelatedController(new ContentRelatedService($db));
    $contentRecommendation = new ContentRecommendationController(new ContentRecommendationService($db));
    $contentPublic = new ContentPublicController(new ContentPublicService($db));
    $contentUrl = new ContentUrlController(new ContentUrlService($db));
    $contentSeo = new ContentSeoController(new ContentSeoService($db));
    $contentStructuredData = new ContentStructuredDataController(new \LaborPlatform\Services\ContentStructuredDataService($db));
    $contentSitemap = new ContentSitemapController(new \LaborPlatform\Services\ContentSitemapService($db, (string)($config['app']['frontend_url'] ?? '')));
    $contentSeoLifecycle = new ContentSeoLifecycleController(new \LaborPlatform\Services\ContentSeoLifecycleService($db));
    $contentDiscoveryApi = new ContentDiscoveryApiController(new \LaborPlatform\Services\ContentDiscoveryApiService($db));
    $contentDiscoveryAdminOverride = new ContentDiscoveryAdminOverrideController(new \LaborPlatform\Services\ContentDiscoveryAdminOverrideService($db));
    $contentDiscoveryControl = new ContentDiscoveryControlController(
        new \LaborPlatform\Services\ContentDiscoveryControlService(
            $db,
            new \LaborPlatform\Services\ContentDiscoveryEventService($db, $queue)
        )
    );

    $contentDiscoveryOrchestrator = new ContentDiscoveryOrchestratorController(
        new \LaborPlatform\Services\ContentDiscoveryOrchestratorService(
            $db,
            new \LaborPlatform\Services\ContentDiscoveryEventService($db, $queue)
        )
    );

    $contentDiscoveryDelivery = new ContentDiscoveryDeliveryController(
        new \LaborPlatform\Services\ContentDiscoveryDeliveryService(
            new \LaborPlatform\Services\ContentPublicService($db),
            new \LaborPlatform\Services\ContentUrlService($db),
            new \LaborPlatform\Services\ContentSeoService($db),
            new \LaborPlatform\Services\ContentStructuredDataService($db),
            new \LaborPlatform\Services\ContentTopicLocationService($db),
            new \LaborPlatform\Services\ContentTagService($db),
            new \LaborPlatform\Services\ContentClassificationService($db),
            new \LaborPlatform\Services\ContentRelatedService($db),
            new \LaborPlatform\Services\ContentRecommendationService($db)
        )
    );

    $workerApplications =
        new WorkerApplicationController(
            $db,
            $jobMatching
        );

    $dashboard=
        new DashboardController(
            $db
        );

    $method=
        Request::method();

    $path=
        rtrim(
            Request::path(),
            '/'
        ) ?: '/';



    if($path==='/api/admin/content-discovery/jobs' && $method==='GET') {
        $contentDiscoveryAdminOverride->list((int)($_GET['job_id']??0));
    }
    if(preg_match('#^/api/admin/content-discovery/jobs/(\d+)/overrides$#',$path,$m)) {
        $jobId=(int)$m[1];
        if($method==='GET') $contentDiscoveryAdminOverride->list($jobId);
        if($method==='POST') $contentDiscoveryAdminOverride->set($jobId);
        if($method==='DELETE') $contentDiscoveryAdminOverride->remove($jobId);
    }

    /*
     * SMS CALLBACK - provider to platform
     */
    if($path==='/api/communication/sms/callback' && $method==='POST') {
        $expected=getenv('LABOR_SMS_CALLBACK_TOKEN') ?: '';
        $provided=(string)($_SERVER['HTTP_X_LABOR_SMS_TOKEN']??'');
        if($expected==='' || !hash_equals($expected,$provided))
            Response::error('SMS callback không hợp lệ.',401);
        $body=Request::body();
        $phone=trim((string)($body['from']??$body['so_dien_thoai']??''));
        $reply=trim((string)($body['message']??$body['noi_dung']??''));
        if($phone==='' || $reply==='') Response::error('Thiếu số điện thoại hoặc nội dung phản hồi.');
        Response::ok($supplierCommunication->markSmsReply($phone,$reply,trim((string)($body['message_id']??''))),'Đã ghi nhận phản hồi SMS.');
    }

    /*
     * DATABASE READINESS
     */

    if(
        $path==='/api/health/db' &&
        $method==='GET'
    ) {
        $db->query('SELECT 1');
        Response::ok([
            'service'=>'supplier-core',
            'database'=>'ready',
            'time'=>date('c'),
            'request_id'=>RequestContext::id(),
            'source_version'=>$config['app']['source_version'],'release_id'=>$config['app']['release_id'],'build_id'=>$config['app']['build_id']
        ]);
    }

    if(
        $path==='/api/health/traffic' &&
        $method==='GET'
    ) {
        Response::ok([
            'source_version'=>$config['app']['source_version'],'release_id'=>$config['app']['release_id'],'build_id'=>$config['app']['build_id'],
            'enabled'=>(bool)($config['high_traffic']['enabled'] ?? true),
            'request_id'=>RequestContext::id(),
            'max_body_bytes'=>(int)($config['high_traffic']['max_body_bytes'] ?? 1048576),
            'request_timeout_seconds'=>(int)($config['high_traffic']['request_timeout_seconds'] ?? 15),
            'rate_limit_rules'=>count((array)($config['high_traffic']['rate_limits'] ?? [])),
            'queue_worker_layer'=>'database-backed queue + CLI worker'
        ]);
    }


    if($path==='/api/health/queue' && $method==='GET')
        $queueController->health();

    if($path==='/api/health/operations' && $method==='GET') {
        $snapshot=$operationsService->snapshot();
        Response::ok([
            'source_version'=>$config['app']['source_version'],'release_id'=>$config['app']['release_id'],'build_id'=>$config['app']['build_id'],
            'status'=>$snapshot['status'],
            'summary'=>$snapshot['summary'],
            'request_id'=>RequestContext::id(),
            'collected_at'=>$snapshot['collected_at'],
        ]);
    }

    if($path==='/api/admin/operations/overview' && $method==='GET') $operationsController->overview();
    if($path==='/api/admin/operations/alerts' && $method==='GET') $operationsController->alerts();
    if($path==='/api/admin/operations/exceptions' && $method==='GET') $operationsController->exceptions();
    if($path==='/api/admin/operations/snapshots' && $method==='GET') $operationsController->snapshots();

    /*
     * DASHBOARD
     */

    if(
        $path==='/api/dashboard/supplier' &&
        $method==='GET'
    )
        $dashboard->supplier();

    if(
        $path==='/api/dashboard/worker' &&
        $method==='POST'
    )
        $dashboard->worker();

    if(
        $path==='/api/dashboard/admin' &&
        $method==='GET'
    )
        $dashboard->admin();


    /*
     * NOTIFICATIONS
     */
    if($path==='/api/worker/sync/state' && $method==='GET')
        (new \LaborPlatform\Controllers\WorkerSyncController($db))->state();



    if(
        $path==='/api/notifications/supplier' &&
        $method==='GET'
    )
        $notifications->supplierList();

    if(
        preg_match(
            '#^/api/notifications/supplier/(\d+)/read$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $notifications->supplierRead(
            (int)$m[1]
        );

    if(
        $path==='/api/notifications/supplier/read-all' &&
        $method==='POST'
    )
        $notifications->supplierReadAll();

    if(
        $path==='/api/notifications/worker' &&
        ($method==='GET' || $method==='POST')
    )
        $notifications->workerList();

    if(
        preg_match(
            '#^/api/notifications/worker/(\d+)/read$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $notifications->workerRead(
            (int)$m[1]
        );
      if(
        $path==='/api/notifications/admin' &&
        $method==='GET'
    )
        $notifications->adminList();

    if(
        preg_match(
            '#^/api/notifications/admin/(\d+)/read$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $notifications->adminRead(
            (int)$m[1]
        );
        $notifications->adminReadAll();


    /*
     * BUILD 96 - SOCIAL CORE
     */
    /* BUILD 114 - PERSONAL SOCIAL COMPLETION */
    if(preg_match('#^/api/ca-nhan/nguoi-lao-dong/(\d+)$#',$path,$m) && $method==='GET') $personalSocial->profile((int)$m[1]);
    if($path==='/api/ca-nhan/loi-moi-ket-ban' && $method==='GET') $personalSocial->requests();
    if($path==='/api/ca-nhan/ban-be' && $method==='GET') $personalSocial->friends();
    if(preg_match('#^/api/ca-nhan/ban-be/(\d+)/gui$#',$path,$m) && $method==='POST') $personalSocial->friendRequest((int)$m[1]);
    if(preg_match('#^/api/ca-nhan/ban-be/(\d+)/xu-ly$#',$path,$m) && $method==='POST') $personalSocial->friendAction((int)$m[1]);
    if($path==='/api/ca-nhan/quyen-rieng-tu' && $method==='GET') $personalSocial->privacy();
    if($path==='/api/ca-nhan/quyen-rieng-tu' && $method==='PUT') $personalSocial->updatePrivacy();
    if($path==='/api/ca-nhan/trao-doi' && $method==='GET') $personalSocial->conversations();
    if(preg_match('#^/api/ca-nhan/trao-doi/(\d+)/da-doc$#',$path,$m) && $method==='POST') $personalSocial->markDiscussionRead((int)$m[1]);
    if(preg_match('#^/api/ca-nhan/trao-doi/(\d+)$#',$path,$m) && $method==='GET') $personalSocial->discussion((int)$m[1]);
    if(preg_match('#^/api/ca-nhan/trao-doi/(\d+)$#',$path,$m) && $method==='POST') $personalSocial->sendDiscussion((int)$m[1]);
    if(preg_match('#^/api/social/jobs/(\d+)/share$#',$path,$m) && $method==='POST') $social->shareJob((int)$m[1]);

    if($path==='/api/social/feed' && $method==='GET') $social->feed();
    if($path==='/api/social/posts' && $method==='GET') $social->mine();
    if($path==='/api/social/posts' && $method==='POST') $social->create();
    if(preg_match('#^/api/social/posts/(\d+)/like$#',$path,$m) && $method==='POST') $social->like((int)$m[1]);
    if(preg_match('#^/api/social/posts/(\d+)/comments$#',$path,$m) && $method==='GET') $social->comments((int)$m[1]);
    if(preg_match('#^/api/social/posts/(\d+)/comments$#',$path,$m) && $method==='POST') $social->comment((int)$m[1]);
    if(preg_match('#^/api/social/comments/(\d+)/report$#',$path,$m) && $method==='POST') $social->reportComment((int)$m[1]);
    if(preg_match('#^/api/social/posts/(\d+)/share$#',$path,$m) && $method==='POST') $social->share((int)$m[1]);
    if(preg_match('#^/api/social/follow/(nguoi_lao_dong|nha_cung_ung)/(\d+)$#',$path,$m) && $method==='POST') $social->follow($m[1],(int)$m[2]);
    if(preg_match('#^/api/social/posts/(\d+)/report$#',$path,$m) && $method==='POST') $social->reportPost((int)$m[1]);
    if(preg_match('#^/api/social/block/(nguoi_lao_dong|nha_cung_ung)/(\d+)$#',$path,$m) && $method==='POST') $social->block($m[1],(int)$m[2]);
    if($path==='/api/admin/moderation/abuse' && $method==='GET') $moderationAdmin->queue();
    if(preg_match('#^/api/admin/moderation/abuse/(\d+)$#',$path,$m) && $method==='POST') $moderationAdmin->resolve((int)$m[1]);
    if($path==='/api/admin/social/reports' && $method==='GET') $socialAdmin->reports();
    if(preg_match('#^/api/admin/social/posts/(\d+)/moderate$#',$path,$m) && $method==='POST') $socialAdmin->moderate((int)$m[1]);
    if(preg_match('#^/api/admin/social/comments/(\d+)/moderate$#',$path,$m) && $method==='POST') $socialAdmin->moderateComment((int)$m[1]);
    if(preg_match('#^/api/admin/social/reports/(\d+)$#',$path,$m) && $method==='POST') $socialAdmin->moderateReport((int)$m[1]);
    if($path==='/api/admin/trust/reviews' && $method==='GET') $trustReputation->adminReviews();
    if(preg_match('#^/api/admin/trust/reviews/(\d+)$#',$path,$m) && $method==='POST') $trustReputation->adminModerate((int)$m[1]);
    if(preg_match('#^/api/admin/trust/review-reports/(\d+)$#',$path,$m) && $method==='POST') $trustReputation->adminReport((int)$m[1]);

    /*
     * BUILD 98 - MEDIA + LIVE
     */
    if($path==='/api/media/upload' && $method==='POST') $media->upload();
    if($path==='/api/media/profile-upload' && $method==='POST') $media->uploadProfile();
    if(preg_match('#^/api/media/assets/(\d+)/url$#',$path,$m) && $method==='GET') $media->assetUrl((int)$m[1], $mediaCdn);
    if($path==='/api/media/videos' && $method==='GET') $media->videoFeed();
    if($path==='/api/media/videos' && $method==='POST') $media->createVideo();
    if(preg_match('#^/api/media/assets/(\d+)/publish-video$#',$path,$m) && $method==='POST') $media->publishVideoAsset((int)$m[1]);
    if(preg_match('#^/api/media/assets/(\d+)/video/view$#',$path,$m) && $method==='POST') $media->videoView((int)$m[1]);
    if(preg_match('#^/api/media/videos/(\d+)/view$#',$path,$m) && $method==='POST') $media->videoView((int)$m[1]);
    if($path==='/api/media/live' && $method==='GET') $media->liveRooms();
    if(preg_match('#^/api/media/live/(\d+)/start$#',$path,$m) && $method==='POST') $media->startLive((int)$m[1]);
    if(preg_match('#^/api/media/live/(\d+)/end$#',$path,$m) && $method==='POST') $media->endLive((int)$m[1]);
    if(preg_match('#^/api/media/live/(\d+)/heartbeat$#',$path,$m) && $method==='POST') $media->heartbeatLive((int)$m[1]);
    if(preg_match('#^/api/media/live/(\d+)/chat$#',$path,$m) && $method==='GET') $media->chat((int)$m[1]);
    if(preg_match('#^/api/media/live/(\d+)/chat$#',$path,$m) && $method==='POST') $media->sendChat((int)$m[1]);

    /* BUILD 101 - THIRD-PARTY AD NETWORK INTEGRATION */
    if($path==='/api/ad-network/config' && $method==='GET') $adNetwork->config();

    /*
     * WORKER AUTH / PROFILE / FAVORITES
     */

    if($path==='/api/identity/me' && $method==='GET') $identity->me();
    if($path==='/api/identity/verification' && $method==='GET') $identityVerification->status();
    if($path==='/api/identity/verification/request' && $method==='POST') $identityVerification->request();
    if($path==='/api/identity/verification/confirm' && $method==='POST') $identityVerification->confirm();
    if($path==='/api/identity/onboarding' && $method==='GET') $identityOnboarding->me();
    if($path==='/api/identity/security/password-reset/request' && $method==='POST') $identitySecurity->requestReset();
    if($path==='/api/identity/security/password-reset/confirm' && $method==='POST') $identitySecurity->confirmReset();
    if($path==='/api/identity/security/events' && $method==='GET') $identitySecurity->status();

    if($path==='/api/mobile/auth/login' && $method==='POST') $mobileAuth->login();
    if($path==='/api/mobile/auth/refresh' && $method==='POST') $mobileAuth->refresh();
    if($path==='/api/mobile/auth/logout' && $method==='POST') $mobileAuth->logout();
    if($path==='/api/mobile/auth/logout-device' && $method==='POST') $mobileAuth->logoutDevice();
    if($path==='/api/mobile/auth/logout-all' && $method==='POST') $mobileAuth->logoutAll();
    if($path==='/api/mobile/auth/me' && $method==='GET') $mobileAuth->me();
    if($path==='/api/mobile/bootstrap' && $method==='GET') $mobileBootstrap->show();

    if($path==='/api/auth/google/start' && $method==='GET') $workerAuth->googleStart();
    if($path==='/api/auth/google/callback' && $method==='GET') $workerAuth->googleCallback();
    if($path==='/api/worker/auth/google/link' && $method==='POST') $workerAuth->linkGoogleUrl();
    if($path==='/api/worker/auth/google/link/callback' && $method==='GET') $workerAuth->googleLinkCallback();

    if(
        $path==='/api/auth/register' &&
        $method==='POST'
    )
        $workerAuth->register();

    if(
        $path==='/api/auth/login' &&
        $method==='POST'
    )
        $workerAuth->login();

    if(
        $path==='/api/worker/profile' &&
        $method==='GET'
    )
        $workerProfile->show();

    if($path==='/api/worker/job-seeking-posts' && $method==='GET')
        $workerPosts->mine();

    if($path==='/api/worker/job-seeking-posts' && $method==='POST')
        $workerPosts->create();

    if(preg_match('#^/api/worker/job-seeking-posts/(\d+)$#',$path,$m) && $method==='PUT')
        $workerPosts->update((int)$m[1]);

    if($path==='/api/worker/connections' && $method==='GET')
        $workerPosts->connections();

    if(preg_match('#^/api/worker/connections/(\d+)$#',$path,$m) && $method==='PATCH')
        $workerPosts->respondConnection((int)$m[1]);

    if(
        $path==='/api/worker/profile' &&
        ($method==='POST' || $method==='PUT')
    )
        $workerProfile->update();

    if(
        $path==='/api/worker/favorites' &&
        $method==='GET'
    )
        $workerFavorites->index();

    if(
        $path==='/api/worker/favorites' &&
        $method==='POST'
    )
        $workerFavorites->add();

    if(
        $path==='/api/worker/favorites/remove' &&
        $method==='POST'
    )
        $workerFavorites->remove();


    /*
     * BUILD 76 - EXTENSIBILITY FOUNDATION
     */
    if($path==='/api/platform/modules' && $method==='GET')
        $platformExtensions->modules();
    if($path==='/api/platform/dictionaries' && $method==='GET')
        $platformExtensions->dictionary();
    if($path==='/api/platform/profile-schema' && $method==='GET')
        $platformExtensions->profileSchema();
    if($path==='/api/platform/api-version' && $method==='GET')
        $platformExtensions->apiVersion();

    /*
     * WORKER APPLICATIONS
     */

    if(
        $path==='/api/worker/applications' &&
        $method==='GET'
    )
        $workerApplications->index();

    if(
        $path==='/api/worker/matches' &&
        $method==='GET'
    )
        $workerApplications->matches();

    if(
        $path==='/api/worker/applications' &&
        $method==='POST'
    )
        $registrations->createPublic();

    if(
        preg_match(
            '#^/api/worker/applications/(\d+)$#',
            $path,
            $m
        ) &&
        $method==='GET'
    )
        $workerApplications->show(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/worker/applications/(\d+)/cancel$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $workerApplications->cancel(
            (int)$m[1]
        );


    /*
     * WORKER PUSH TOKENS
     */

    if(
        $path==='/api/worker/push-tokens' &&
        $method==='POST'
    )
        $workerPush->register();


    /*
     * ADMIN
     */

    if($path==='/api/admin/csrf' && $method==='GET')
        $adminControlCenter->csrf();

    if($path==='/api/admin/permissions' && $method==='GET')
        $adminControlCenter->permissions();

    if($path==='/api/admin/overview' && $method==='GET')
        $dashboard->admin();

    if($path==='/api/admin/users' && $method==='GET')
        $adminControlCenter->users();


    if($path==='/api/admin/unions' && $method==='GET')
        $adminControlCenter->unions();

    if($path==='/api/admin/security' && $method==='GET')
        $adminControlCenter->security();

    if($path==='/api/admin/system' && $method==='GET')
        $adminControlCenter->system();

    if($path==='/api/admin/data-protection/data-map' && $method==='GET')
        $adminDataProtection->dataMap();

    if($path==='/api/admin/data-protection/access-matrix' && $method==='GET')
        $adminDataProtection->accessMatrix();

    if($path==='/api/admin/data-protection/access-log' && $method==='GET')
        $adminDataProtection->accessLog();

    if(
        $path==='/api/admin/login' &&
        $method==='POST'
    )
        $adminSupplier->login();

    if(
        $path==='/api/admin/logout' &&
        $method==='POST'
    )
        $adminSupplier->logout();

    if(
        $path==='/api/admin/me' &&
        $method==='GET'
    )
        $adminSupplier->me();

    if(
        $path==='/api/admin/suppliers' &&
        $method==='GET'
    )
        $adminSupplier->list();

    if(
        preg_match('#^/api/admin/suppliers/(\d+)$#',$path,$m) &&
        $method==='GET'
    )
        $adminSupplier->detail((int)$m[1]);

    if(
        preg_match('#^/api/admin/suppliers/(\d+)/action$#',$path,$m) &&
        $method==='POST'
    )
        $adminSupplier->action((int)$m[1]);

    if(
        $path==='/api/admin/jobs' &&
        $method==='GET'
    )
        $adminJobs->list();

    if(
        preg_match(
            '#^/api/admin/jobs/(\d+)/action$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $adminJobs->action(
            (int)$m[1]
        );
          /*
     * PUBLIC JOBS
     */

    if(
        $path==='/api/jobs/public' &&
        $method==='GET'
    )
        $jobs->publicList();

    /*
     * BUILD 04 — TOPIC / LOCATION
     */
    if($path==='/internal/content-discovery/warm' && $method==='POST') { $contentSearch->warm($config); }
    if($path==='/api/content-discovery/search' && $method==='GET') { $contentSearch->publicJobs(); }
    if($path==='/api/content-discovery/feed' && $method==='GET') { $contentFeed->publicJobs(); }
    if(preg_match('#^/api/content-discovery/jobs/(\d+)/related$#',$path,$m) && $method==='GET')
        $contentRelated->publicJob((int)$m[1]);

    /* BUILD 08 — CONTENT RECOMMENDATION */
    if(preg_match('#^/api/content-discovery/jobs/(\d+)/recommendations$#',$path,$m) && $method==='GET')
        $contentRecommendation->publicJob((int)$m[1]);

    if(preg_match('#^/api/content-discovery/public/jobs/(\d+)$#',$path,$m) && $method==='GET')
        $contentPublic->publicJob((int)$m[1]);

    if(preg_match('#^/api/content-discovery/public/jobs/(\d+)/url$#',$path,$m) && $method==='GET')
        $contentUrl->publicJobUrl((int)$m[1]);

    /* BUILD 22 — CONTENT DISCOVERY CONTROL CENTER */
    if($path==='/api/admin/content-discovery/control' && $method==='GET')
        $contentDiscoveryControl->dashboard();
    if($path==='/api/admin/content-discovery/control/rebuild' && $method==='POST')
        $contentDiscoveryControl->rebuild();

    /* BUILD 21 — CONTENT DISCOVERY SYSTEM ORCHESTRATOR */
    if(preg_match('#^/api/admin/content-discovery/jobs/(\d+)/orchestrate$#',$path,$m) && $method==='POST')
        $contentDiscoveryOrchestrator->dispatch((int)$m[1]);
    if(preg_match('#^/api/admin/content-discovery/jobs/(\d+)/orchestrate$#',$path,$m) && $method==='GET')
        $contentDiscoveryOrchestrator->status((int)$m[1]);

    /* BUILD 17 — CONTENT DISCOVERY BACKEND/API ARCHITECTURE */
    if(preg_match('#^/api/content-discovery/public/jobs/(\d+)/delivery$#',$path,$m) && $method==='GET')
        $contentDiscoveryDelivery->job((int)$m[1]);

    if($path==='/api/content-discovery/capabilities' && $method==='GET')
        $contentDiscoveryApi->capabilities();

    if(preg_match('#^/api/content-discovery/jobs/(\d+)/pipeline$#',$path,$m) && $method==='GET')
        $contentDiscoveryApi->jobPipeline((int)$m[1]);

    /* BUILD 13 — CONTENT SITEMAP */
    if($path==='/sitemap/jobs.xml' && $method==='GET')
        $contentSitemap->jobs();

    /* BUILD 14 — CONTENT SEO LIFECYCLE */
    if(preg_match('#^/api/content-discovery/jobs/(\d+)/seo-lifecycle$#',$path,$m) && $method==='GET')
        $contentSeoLifecycle->show((int)$m[1]);

    /* BUILD 12 — CONTENT STRUCTURED DATA */
    if(preg_match('#^/api/content-discovery/public/jobs/(\d+)/structured-data$#',$path,$m) && $method==='GET')
        $contentStructuredData->publicJob((int)$m[1]);

    /* BUILD 11 — CONTENT SEO */
    if(preg_match('#^/api/content-discovery/public/jobs/(\d+)/seo$#',$path,$m) && $method==='GET')
        $contentSeo->publicJob((int)$m[1]);

    if(preg_match('#^/api/content-discovery/jobs/(\d+)/taxonomy$#',$path,$m) && $method==='GET')
        $contentTopicLocation->publicJob((int)$m[1]);

    /*
     * BUILD 03 — CONTENT TAGS / HASHTAGS
     */
    if(preg_match('#^/api/content-discovery/jobs/(\d+)/tags$#',$path,$m) && $method==='GET')
        $contentTags->publicJob((int)$m[1]);

    /*
     * BUILD 02 — CONTENT CLASSIFICATION
     */
    if(preg_match('#^/api/content-discovery/jobs/(\d+)/classification$#',$path,$m) && $method==='GET')
        $contentClassification->publicJob((int)$m[1]);

    if(preg_match('#^/api/content-discovery/jobs/(\d+)$#',$path,$m) && $method==='GET')
        $contentDiscovery->publicJob((int)$m[1]);

    if($path==='/api/worker/job-seeking-posts/public' && $method==='GET')
        $workerPosts->publicList();

    if(
        preg_match(
            '#^/api/jobs/public/(\d+)$#',
            $path,
            $m
        ) &&
        $method==='GET'
    )
        $jobs->publicDetail(
            (int)$m[1]
        );


    /*
     * SUPPLIER
     */

    /*
     * EMPLOYER / ĐƠN VỊ SỬ DỤNG LAO ĐỘNG
     * BUILD 90: dùng chung tài khoản Nhà cung ứng hiện hữu để giữ tương thích ngược.
     */

    if($path==='/api/professional/employer/me' && $method==='GET') $professionalIdentity->employer();
    if($path==='/api/professional/employer/me' && ($method==='POST' || $method==='PUT')) $professionalIdentity->updateEmployer();
    if(preg_match('#^/api/professional/employer/(\d+)$#',$path,$m) && $method==='GET') $professionalIdentity->employerPublic((int)$m[1]);
    if($path==='/api/professional/worker/me' && $method==='GET') $professionalIdentity->worker();
    if($path==='/api/professional/worker/me' && ($method==='POST' || $method==='PUT')) $professionalIdentity->updateWorker();
    if($path==='/api/professional/worker/certificates' && $method==='POST') $professionalIdentity->addCertificate();
    if($path==='/api/professional/worker/experiences' && $method==='POST') $professionalIdentity->addExperience();

    if(preg_match('#^/api/trust/employers/(\d+)$#',$path,$m) && $method==='GET') $trustReputation->publicEmployer((int)$m[1]);
    if(preg_match('#^/api/trust/workers/(\d+)$#',$path,$m) && $method==='GET') $trustReputation->publicWorker((int)$m[1]);
    if(preg_match('#^/api/trust/employers/(\d+)/reviews$#',$path,$m) && $method==='POST') $trustReputation->reviewEmployer((int)$m[1]);
    if(preg_match('#^/api/trust/workers/(\d+)/reviews$#',$path,$m) && $method==='POST') $trustReputation->reviewWorker((int)$m[1]);
    if(preg_match('#^/api/trust/reviews/(\d+)/report$#',$path,$m) && $method==='POST') $trustReputation->report((int)$m[1]);

    if($path==='/api/employer/worker-posts' && $method==='GET')
        $workerPosts->employerList();

    if(preg_match('#^/api/employer/worker-posts/(\d+)/connect$#',$path,$m) && $method==='POST')
        $workerPosts->connect((int)$m[1]);

    if(preg_match('#^/api/employer/candidates/(\d+)$#',$path,$m) && $method==='GET')
        $employer->candidateDetail((int)$m[1]);

    if(preg_match('#^/api/employer/workers/(\d+)$#',$path,$m) && $method==='GET')
        $employer->workerDetail((int)$m[1]);

    if($path==='/api/employer/accounts' && $method==='GET') $employer->accounts();
    if($path==='/api/employer/accounts' && $method==='POST') $employer->createAccount();
    if(preg_match('#^/api/employer/accounts/(\d+)$#',$path,$m) && $method==='PUT') $employer->updateAccount((int)$m[1]);
    if($path==='/api/employer/live' && $method==='GET') $employer->liveRooms();
    if($path==='/api/employer/live' && $method==='POST') $employer->createLiveRoom();

    if(
        $path==='/api/supplier/register' &&
        $method==='POST'
    )
        $supplier->register();

    if(
        $path==='/api/supplier/login' &&
        $method==='POST'
    )
        $supplier->login();

    if(
        $path==='/api/supplier/logout' &&
        $method==='POST'
    )
        $supplier->logout();

    if(
        $path==='/api/supplier/me' &&
        $method==='GET'
    )
        $supplier->me();

    if(
        $path==='/api/supplier/profile' &&
        $method==='GET'
    )
        $supplier->me();

    if(
        $path==='/api/supplier/profile' &&
        $method==='PUT'
    )
        $supplier->update();


    if(
        $path==='/api/supplier/password' &&
        $method==='PUT'
    )
        $supplier->changePassword();

    if(
        $path==='/api/supplier/verification/submit' &&
        $method==='POST'
    )
        $supplier->submitVerification();

    /*
     * SUPPLIER JOBS
     */

    if(
        $path==='/api/supplier/jobs' &&
        $method==='GET'
    )
        $jobs->list();

    if(
        $path==='/api/supplier/jobs' &&
        $method==='POST'
    )
        $jobs->create();
      if(
        preg_match(
            '#^/api/supplier/jobs/(\d+)$#',
            $path,
            $m
        ) &&
        $method==='GET'
    )
        $jobs->publicDetail(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/jobs/(\d+)$#',
            $path,
            $m
        ) &&
        $method==='PUT'
    )
        $jobs->update(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/jobs/(\d+)/submit-review$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $jobs->submitReview(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/jobs/(\d+)/status$#',
            $path,
            $m
        ) &&
        $method==='PATCH'
    )
        $jobs->status(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/jobs/(\d+)$#',
            $path,
            $m
        ) &&
        $method==='DELETE'
    )
        $jobs->delete(
            (int)$m[1]
        );
        if(
        preg_match('#^/api/supplier/interview-registrations/(\d+)/call$#',$path,$m) &&
        $method==='POST'
    )
        Response::ok($supplierCommunication->requestMaskedCall((int)$m[1],Auth::supplierId()));

    /*
     * APPLICATIONS API — canonical naming.
     * Legacy /interview-registrations routes remain below as a compatibility layer.
     */
    if($path==='/api/applications/lookup' && $method==='POST')
        $registrations->workerLookup();

    if(preg_match('#^/api/applications/(\d+)/cancel$#',$path,$m) && $method==='POST')
        $registrations->workerCancel((int)$m[1]);

    if($path==='/api/applications' && $method==='POST')
        $registrations->createPublic();

    if($path==='/api/supplier/applications' && $method==='GET')
        $registrations->list();

    if(preg_match('#^/api/supplier/applications/(\d+)$#',$path,$m) && $method==='GET')
        $registrations->detail((int)$m[1]);

    if(preg_match('#^/api/supplier/applications/(\d+)/status$#',$path,$m) && $method==='PATCH')
        $registrations->status((int)$m[1]);

    if(preg_match('#^/api/supplier/applications/(\d+)/acknowledge$#',$path,$m) && $method==='POST')
        $registrations->acknowledge((int)$m[1]);

    if(preg_match('#^/api/supplier/applications/(\d+)/contacts$#',$path,$m) && $method==='GET')
        $registrations->contacts((int)$m[1]);

    if(preg_match('#^/api/supplier/applications/(\d+)/contacts$#',$path,$m) && $method==='POST')
        $registrations->contact((int)$m[1]);

    if(preg_match('#^/api/supplier/applications/(\d+)/call$#',$path,$m) && $method==='POST')
        Response::ok($supplierCommunication->requestMaskedCall((int)$m[1],Auth::supplierId()));

    if(
        $path==='/api/interview-registrations/lookup' &&
        $method==='POST'
    )
        $registrations->workerLookup();

    if(
        preg_match(
            '#^/api/interview-registrations/(\d+)/cancel$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $registrations->workerCancel(
            (int)$m[1]
        );

    if(
        $path==='/api/interview-registrations' &&
        $method==='POST'
    )
        $registrations->createPublic();

    if(
        $path==='/api/supplier/interview-registrations' &&
        $method==='GET'
    )
        $registrations->list();

    if(
        preg_match('#^/api/supplier/interview-registrations/(\d+)$#',$path,$m) &&
        $method==='GET'
    )
        $registrations->detail((int)$m[1]);

    if(
        preg_match(
            '#^/api/supplier/interview-registrations/(\\d+)/status$#',
            $path,
            $m
        ) &&
        $method==='PATCH'
    )
        $registrations->status(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/interview-registrations/(\d+)/accept$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $registrations->acknowledge(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/interview-registrations/(\d+)/contacts$#',
            $path,
            $m
        ) &&
        $method==='GET'
    )
        $registrations->contacts(
            (int)$m[1]
        );

    if(
        preg_match(
            '#^/api/supplier/interview-registrations/(\d+)/contacts$#',
            $path,
            $m
        ) &&
        $method==='POST'
    )
        $registrations->contact(
            (int)$m[1]
        );


    Response::error(
        'Endpoint không tồn tại.',
        404
    );

} catch (
      Throwable $e
) {

    Response::error(
        'Lỗi máy chủ.',
        500
    );
}
