#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
failed=0
while IFS= read -r -d '' file; do
  if ! php -l "$file" >/dev/null; then
    echo "FAIL: $file"
    failed=1
  fi
done < <(find "$ROOT/src" "$ROOT/public" -type f -name '*.php' -print0)
if [ "$failed" -ne 0 ]; then
  echo "PHP syntax audit: FAILED"
  exit 1
fi
echo "PHP syntax audit: PASSED"
