<?php
declare(strict_types=1);

$root = dirname(__DIR__).'/src/Controllers';
$failed = false;

foreach (glob($root.'/*.php') as $file) {
    $text = file_get_contents($file);
    preg_match_all('/public\s+function\s+([A-Za-z0-9_]+)\s*\(/', $text, $m);
    $counts = array_count_values($m[1] ?? []);
    foreach ($counts as $method => $count) {
        if ($count > 1) {
            echo "DUPLICATE {$method} in {$file}\n";
            $failed = true;
        }
    }
}

if ($failed) {
    exit(1);
}

echo "Duplicate method audit: PASSED\n";
