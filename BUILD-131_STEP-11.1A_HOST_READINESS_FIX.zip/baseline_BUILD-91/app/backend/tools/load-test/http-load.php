<?php
declare(strict_types=1);

/**
 * Reproducible HTTP load-test harness.
 * Usage: php backend/tools/load-test/http-load.php --url=http://127.0.0.1/api/health --duration=10 --concurrency=10
 * This tool is intentionally external to runtime request handling.
 */
$options = getopt('', ['url:', 'duration::', 'concurrency::', 'timeout::', 'warmup::', 'method::', 'body::', 'header::', 'output::', 'max-error-rate::', 'max-p95-ms::']);
$url = (string)($options['url'] ?? '');
if ($url === '') { fwrite(STDERR, "Missing --url\n"); exit(2); }
$duration = max(1, (int)($options['duration'] ?? 10));
$concurrency = max(1, min(200, (int)($options['concurrency'] ?? 10)));
$timeout = max(1, (int)($options['timeout'] ?? 15));
$warmup = max(0, (int)($options['warmup'] ?? 2));
$method = strtoupper((string)($options['method'] ?? 'GET'));
$body = (string)($options['body'] ?? '');
$output = (string)($options['output'] ?? '');
$maxErrorRate = (float)($options['max-error-rate'] ?? 0.05);
$maxP95 = (float)($options['max-p95-ms'] ?? 1000);
$headers = [];
foreach ((array)($options['header'] ?? []) as $header) { $headers[] = (string)$header; }

if (!function_exists('curl_multi_init')) {
    fwrite(STDERR, "cURL multi extension is required for real concurrent load testing.
");
    exit(2);
}

function createRequestHandle(string $url, string $method, string $body, array $headers, int $timeout): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_HEADER => false,
    ]);
    if ($body !== '') curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    return ['handle' => $ch, 'started_at' => microtime(true)];
}

/**
 * Execute one batch with real HTTP concurrency using curl_multi_*.
 * The returned result count equals the number of completed handles in the batch.
 */
function requestBatch(string $url, string $method, string $body, array $headers, int $timeout, int $concurrency): array {
    $multi = curl_multi_init();
    $active = [];
    $results = [];

    for ($i = 0; $i < $concurrency; $i++) {
        $request = createRequestHandle($url, $method, $body, $headers, $timeout);
        $ch = $request['handle'];
        $active[(int)$ch] = $request['started_at'];
        curl_multi_add_handle($multi, $ch);
    }

    do {
        do {
            $multiStatus = curl_multi_exec($multi, $running);
        } while ($multiStatus === CURLM_CALL_MULTI_PERFORM);

        while ($info = curl_multi_info_read($multi)) {
            $ch = $info['handle'];
            $elapsed = (microtime(true) - ($active[(int)$ch] ?? microtime(true))) * 1000;
            $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $errno = (int)curl_errno($ch);
            $results[] = [
                'ms' => $elapsed,
                'status' => $status,
                'error' => $errno !== 0 || $info['result'] !== CURLE_OK,
            ];
            unset($active[(int)$ch]);
            curl_multi_remove_handle($multi, $ch);
            curl_close($ch);
        }

        if ($running) {
            $selected = curl_multi_select($multi, 1.0);
            if ($selected === -1) usleep(1000);
        }
    } while ($running || $active);

    curl_multi_close($multi);
    return $results;
}

function request(string $url, string $method, string $body, array $headers, int $timeout): array {
    $results = requestBatch($url, $method, $body, $headers, $timeout, 1);
    return $results[0] ?? ['ms' => 0.0, 'status' => 0, 'error' => true];
}

$endWarmup = microtime(true) + $warmup;
while (microtime(true) < $endWarmup) request($url, $method, $body, $headers, $timeout);

$end = microtime(true) + $duration;
$results = [];
while (microtime(true) < $end) {
    foreach (requestBatch($url, $method, $body, $headers, $timeout, $concurrency) as $r) $results[] = $r;
}

$count = count($results);
$errors = 0; $durations = [];
foreach ($results as $r) { $durations[] = (float)$r['ms']; if ($r['error'] || $r['status'] >= 500 || $r['status'] === 0) $errors++; }
sort($durations);
$p95 = $count ? $durations[max(0, (int)ceil($count * 0.95) - 1)] : 0.0;
$avg = $count ? array_sum($durations) / $count : 0.0;
$report = [
    'target'=>$url, 'method'=>$method, 'duration_seconds'=>$duration, 'warmup_seconds'=>$warmup,
    'concurrency'=>$concurrency, 'requests'=>$count, 'errors'=>$errors,
    'error_rate'=>$count ? $errors/$count : 1.0, 'avg_latency_ms'=>round($avg,2), 'p95_latency_ms'=>round($p95,2),
    'thresholds'=>['max_error_rate'=>$maxErrorRate, 'max_p95_ms'=>$maxP95],
    'pass'=>($count > 0 && ($errors/$count) <= $maxErrorRate && $p95 <= $maxP95),
    'generated_at'=>gmdate('c'),
];
$json = json_encode($report, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES).PHP_EOL;
echo $json;
if ($output !== '') file_put_contents($output, $json);
exit($report['pass'] ? 0 : 1);
