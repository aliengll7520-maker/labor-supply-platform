<?php
declare(strict_types=1);

/**
 * PR-13 Stress Test & Capacity Validation harness.
 * External tool only; never loaded by runtime request handling.
 * Usage: php backend/tools/stress-test/stress-test.php --url=... --levels=10,25,50 --duration=15
 */
$options = getopt('', [
    'url:', 'levels::', 'duration::', 'warmup::', 'timeout::', 'method::',
    'body::', 'header::', 'max-error-rate::', 'max-p95-ms::', 'output::',
    'stop-on-breach::'
]);
$url = (string)($options['url'] ?? '');
if ($url === '') { fwrite(STDERR, "Missing --url\n"); exit(2); }
if (!function_exists('curl_multi_init')) { fwrite(STDERR, "cURL multi extension is required.\n"); exit(2); }

$duration = max(1, (int)($options['duration'] ?? 15));
$warmup = max(0, (int)($options['warmup'] ?? 3));
$timeout = max(1, (int)($options['timeout'] ?? 15));
$method = strtoupper((string)($options['method'] ?? 'GET'));
$body = (string)($options['body'] ?? '');
$maxErrorRate = (float)($options['max-error-rate'] ?? 0.05);
$maxP95 = (float)($options['max-p95-ms'] ?? 1000);
$stopOnBreach = filter_var($options['stop-on-breach'] ?? true, FILTER_VALIDATE_BOOLEAN);
$headers = [];
foreach ((array)($options['header'] ?? []) as $header) $headers[] = (string)$header;

$levels = [];
foreach (explode(',', (string)($options['levels'] ?? '10,25,50,100')) as $level) {
    $n = (int)trim($level);
    if ($n >= 1 && $n <= 200) $levels[] = $n;
}
$levels = array_values(array_unique($levels));
if (!$levels) { fwrite(STDERR, "No valid concurrency levels (1..200).\n"); exit(2); }

function stressHandle(string $url, string $method, string $body, array $headers, int $timeout): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => min(5, $timeout),
        CURLOPT_HEADER => false,
    ]);
    if ($body !== '') curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    return ['handle' => $ch, 'started_at' => microtime(true)];
}

function stressBatch(string $url, string $method, string $body, array $headers, int $timeout, int $concurrency): array {
    $multi = curl_multi_init();
    $active = [];
    $results = [];
    for ($i = 0; $i < $concurrency; $i++) {
        $req = stressHandle($url, $method, $body, $headers, $timeout);
        $ch = $req['handle'];
        $active[(int)$ch] = $req['started_at'];
        curl_multi_add_handle($multi, $ch);
    }
    do {
        do { $multiStatus = curl_multi_exec($multi, $running); }
        while ($multiStatus === CURLM_CALL_MULTI_PERFORM);
        while ($info = curl_multi_info_read($multi)) {
            $ch = $info['handle'];
            $results[] = [
                'ms' => (microtime(true) - ($active[(int)$ch] ?? microtime(true))) * 1000,
                'status' => (int)curl_getinfo($ch, CURLINFO_HTTP_CODE),
                'error' => ((int)curl_errno($ch) !== 0 || $info['result'] !== CURLE_OK),
            ];
            unset($active[(int)$ch]);
            curl_multi_remove_handle($multi, $ch);
            curl_close($ch);
        }
        if ($running) {
            $selected = curl_multi_select($multi, 1.0);
            if ($selected === -1) usleep(1000);
        }
    } while ($running || $active);
    curl_multi_close($multi);
    return $results;
}

function percentile(array $values, float $p): float {
    if (!$values) return 0.0;
    sort($values, SORT_NUMERIC);
    $index = max(0, (int)ceil(count($values) * $p) - 1);
    return (float)$values[$index];
}

$warmEnd = microtime(true) + $warmup;
while (microtime(true) < $warmEnd) stressBatch($url, $method, $body, $headers, $timeout, min($levels[0], 10));

$results = [];
$capacity = null;
$firstBreachedLevel = null;
$contiguousPassing = true;
foreach ($levels as $level) {
    $end = microtime(true) + $duration;
    $samples = [];
    while (microtime(true) < $end) $samples = array_merge($samples, stressBatch($url, $method, $body, $headers, $timeout, $level));
    $count = count($samples); $errors = 0; $latencies = [];
    foreach ($samples as $sample) {
        $latencies[] = (float)$sample['ms'];
        if ($sample['error'] || $sample['status'] >= 500 || $sample['status'] === 0) $errors++;
    }
    $errorRate = $count ? $errors / $count : 1.0;
    $p95 = percentile($latencies, 0.95);
    $pass = $count > 0 && $errorRate <= $maxErrorRate && $p95 <= $maxP95;
    $row = [
        'concurrency' => $level, 'requests' => $count, 'errors' => $errors,
        'error_rate' => round($errorRate, 6), 'avg_latency_ms' => round($count ? array_sum($latencies) / $count : 0, 2),
        'p95_latency_ms' => round($p95, 2), 'pass' => $pass,
    ];
    $results[] = $row;
    if ($contiguousPassing && $pass) {
        $capacity = $row;
    } elseif ($contiguousPassing && !$pass) {
        $contiguousPassing = false;
        $firstBreachedLevel = $level;
        if ($stopOnBreach) break;
    }
}

$report = [
    'target' => $url, 'duration_seconds_per_level' => $duration, 'warmup_seconds' => $warmup,
    'levels' => $results, 'thresholds' => ['max_error_rate' => $maxErrorRate, 'max_p95_ms' => $maxP95],
    'last_passing_level' => $capacity['concurrency'] ?? null,
    'highest_contiguous_passing_level' => $capacity['concurrency'] ?? null,
    'first_breached_level' => $firstBreachedLevel,
    'capacity_gate_pass' => $capacity !== null && $firstBreachedLevel === null,
    'generated_at' => gmdate('c'),
];
$json = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;
echo $json;
if (($output = (string)($options['output'] ?? '')) !== '') file_put_contents($output, $json);
exit($report['capacity_gate_pass'] ? 0 : 1);
