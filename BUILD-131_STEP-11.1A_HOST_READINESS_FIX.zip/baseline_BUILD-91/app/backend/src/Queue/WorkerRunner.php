<?php
declare(strict_types=1);
namespace LaborPlatform\Queue;

final class WorkerRunner
{
    public function __construct(private QueueService $queue, private JobRegistry $registry, private array $config = []) {}

    public function run(string $queueName, int $once = 0, ?callable $onCycle = null): int
    {
        $batch = max(1, min(100, (int)($this->config['batch_size'] ?? 20)));
        $lease = max(15, (int)($this->config['lease_seconds'] ?? 120));
        $sleep = max(1, (int)($this->config['idle_sleep_seconds'] ?? 2));
        $processed = 0;
        $iterations = 0;
        $maxIterations = $once > 0 ? 1 : max(0, (int)($this->config['max_iterations'] ?? 0));
        $maxRuntimeSeconds = $once > 0 ? 0 : max(0, (int)($this->config['max_runtime_seconds'] ?? 0));
        $startedAt = microtime(true);

        do {
            if ($maxRuntimeSeconds > 0 && (microtime(true) - $startedAt) >= $maxRuntimeSeconds) break;
            if ($onCycle !== null) {
                $onCycle();
            }
            $jobs = $this->queue->claimBatch($queueName, $batch, $lease);
            if (!$jobs) {
                $iterations++;
                if ($once > 0 || ($maxIterations > 0 && $iterations >= $maxIterations)) break;
                if ($maxRuntimeSeconds > 0 && (microtime(true) - $startedAt) >= $maxRuntimeSeconds) break;
                sleep($sleep);
                continue;
            }

            foreach ($jobs as $job) {
                $jobId = (int)$job['id'];
                try {
                    // Extend the lease immediately before potentially long-running work.
                    $this->queue->renewLease($jobId, $lease);
                    $payload = json_decode((string)$job['payload_json'], true, 512, JSON_THROW_ON_ERROR);
                    $this->registry->handle((string)$job['job_type'], is_array($payload) ? $payload : []);
                    $this->queue->complete($jobId);
                    $processed++;
                } catch (\Throwable $e) {
                    $this->queue->fail($job, $e->getMessage());
                }
                if ($once > 0) break;
            }
            $iterations++;
        } while (
            $once === 0
            && ($maxIterations === 0 || $iterations < $maxIterations)
            && ($maxRuntimeSeconds === 0 || (microtime(true) - $startedAt) < $maxRuntimeSeconds)
        );

        return $processed;
    }
}
