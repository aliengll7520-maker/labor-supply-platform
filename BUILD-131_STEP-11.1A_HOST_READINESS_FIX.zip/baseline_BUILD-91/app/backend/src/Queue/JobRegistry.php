<?php
declare(strict_types=1);
namespace LaborPlatform\Queue;

final class JobRegistry
{
    /** @var array<string, callable> */
    private array $handlers = [];

    public function register(string $jobType, callable $handler): void
    {
        if ($jobType === '' || !preg_match('/^[A-Za-z0-9._:-]+$/', $jobType)) {
            throw new \InvalidArgumentException('Job type không hợp lệ.');
        }
        $this->handlers[$jobType] = $handler;
    }

    public function has(string $jobType): bool { return isset($this->handlers[$jobType]); }

    public function handle(string $jobType, array $payload): void
    {
        if (!$this->has($jobType)) throw new \RuntimeException('Không có worker handler cho job: '.$jobType);
        ($this->handlers[$jobType])($payload);
    }
}
