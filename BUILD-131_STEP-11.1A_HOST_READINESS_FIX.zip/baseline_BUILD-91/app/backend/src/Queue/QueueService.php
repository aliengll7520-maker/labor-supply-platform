<?php
declare(strict_types=1);
namespace LaborPlatform\Queue;

final class QueueService
{
    public function __construct(private \PDO $db, private array $config = []) {}

    public function enqueue(string $queue, string $jobType, array $payload = [], int $priority = 100, ?string $dedupeKey = null, ?int $maxAttempts = null, ?string $availableAt = null): int
    {
        $queue = $this->normalize($queue, 1, 80);
        $jobType = $this->normalize($jobType, 1, 120);
        $priority = max(0, min(1000, $priority));
        $operationId = \LaborPlatform\Core\RequestContext::idempotency()?->operationId();
        if ($operationId !== null && !array_key_exists('_operation_id', $payload)) {
            $payload['_operation_id'] = $operationId;
        }
        $payloadJson=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $maxAttempts = max(1, min(20, $maxAttempts ?? (int)($this->config['default_max_attempts'] ?? 5)));
        $availableAt = $availableAt ?: date('Y-m-d H:i:s');
        $dedupeKey = $dedupeKey !== null ? $this->normalize($dedupeKey, 1, 191) : null;

        $this->assertBackpressure($queue);

        $stmt = $this->db->prepare(
            'INSERT INTO queue_jobs
             (queue_name, job_type, payload_json, priority, status, attempts, max_attempts, available_at, dedupe_key, created_at, updated_at)
             VALUES (?, ?, ?, ?, "queued", 0, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
        );
        try {
            $stmt->execute([$queue, $jobType, $payloadJson, $priority, $maxAttempts, $availableAt, $dedupeKey]);
            return (int)$this->db->lastInsertId();
        } catch (\PDOException $e) {
            if ($dedupeKey === null || (int)$e->errorInfo[1] !== 1062) throw $e;
            $q = $this->db->prepare('SELECT id FROM queue_jobs WHERE queue_name=? AND dedupe_key=? AND status IN ("queued","processing") LIMIT 1');
            $q->execute([$queue, $dedupeKey]);
            $existing = $q->fetchColumn();
            if ($existing !== false) return (int)$existing;
            throw $e;
        }
    }

    public function claimBatch(string $queue, int $limit = 10, int $leaseSeconds = 120): array
    {
        $queue = $this->normalize($queue, 1, 80);
        $limit = max(1, min(100, $limit));
        $leaseSeconds = max(15, min(900, $leaseSeconds));

        $this->recoverStale($queue);
        $this->db->beginTransaction();
        try {
            $sql = 'SELECT id FROM queue_jobs
                    WHERE queue_name=? AND status="queued" AND available_at<=CURRENT_TIMESTAMP
                    ORDER BY priority DESC, id ASC
                    LIMIT '.$limit.' FOR UPDATE SKIP LOCKED';
            $q = $this->db->prepare($sql);
            $q->execute([$queue]);
            $ids = array_map('intval', $q->fetchAll(\PDO::FETCH_COLUMN));
            if (!$ids) {
                $this->db->commit();
                return [];
            }

            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $u = $this->db->prepare(
                'UPDATE queue_jobs
                 SET status="processing", reserved_at=CURRENT_TIMESTAMP,
                     lease_until=DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? SECOND),
                     attempts=attempts+1, updated_at=CURRENT_TIMESTAMP
                 WHERE id IN ('.$placeholders.')'
            );
            $u->execute(array_merge([$leaseSeconds], $ids));
            $this->db->commit();

            $s = $this->db->prepare('SELECT * FROM queue_jobs WHERE id IN ('.$placeholders.') ORDER BY priority DESC, id ASC');
            $s->execute($ids);
            return $s->fetchAll();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function renewLease(int $id, int $leaseSeconds = 120): void
    {
        $leaseSeconds = max(15, min(900, $leaseSeconds));
        $q = $this->db->prepare(
            'UPDATE queue_jobs
             SET lease_until=DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? SECOND),
                 updated_at=CURRENT_TIMESTAMP
             WHERE id=? AND status="processing"'
        );
        $q->execute([$leaseSeconds, $id]);
    }

    public function complete(int $id): void
    {
        $q = $this->db->prepare('UPDATE queue_jobs SET status="completed", completed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP, lease_until=NULL WHERE id=? AND status="processing"');
        $q->execute([$id]);
    }

    public function fail(array $job, string $error): void
    {
        $id = (int)$job['id'];
        $attempts = (int)$job['attempts'];
        $maxAttempts = (int)$job['max_attempts'];
        $error = mb_substr(trim($error), 0, 4000);

        if ($attempts < $maxAttempts) {
            $base = max(1, (int)($this->config['retry_base_seconds'] ?? 5));
            $cap = max($base, (int)($this->config['retry_max_seconds'] ?? 900));
            $delay = min($cap, $base * (2 ** max(0, $attempts - 1)));
            $delay += random_int(0, max(1, (int)floor($delay * 0.2)));
            $q = $this->db->prepare('UPDATE queue_jobs SET status="queued", last_error=?, available_at=DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? SECOND), lease_until=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=? AND status="processing"');
            $q->execute([$error, $delay, $id]);
            return;
        }

        $this->db->beginTransaction();
        try {
            $q = $this->db->prepare('UPDATE queue_jobs SET status="dead", last_error=?, lease_until=NULL, updated_at=CURRENT_TIMESTAMP WHERE id=? AND status="processing"');
            $q->execute([$error, $id]);
            $d = $this->db->prepare('INSERT INTO queue_dead_letters (queue_job_id, queue_name, job_type, payload_json, attempts, error_message, failed_at) SELECT id, queue_name, job_type, payload_json, attempts, last_error, CURRENT_TIMESTAMP FROM queue_jobs WHERE id=?');
            $d->execute([$id]);
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function recoverStale(?string $queue = null, int $limit = 1000): int
    {
        $limit = max(1, min(10000, $limit));
        $where = 'status="processing" AND lease_until IS NOT NULL AND lease_until<CURRENT_TIMESTAMP';
        $params = [];
        if ($queue !== null) {
            $where .= ' AND queue_name=?';
            $params[] = $this->normalize($queue, 1, 80);
        }

        $this->db->beginTransaction();
        try {
            $q = $this->db->prepare('SELECT id, queue_name, job_type, payload_json, attempts, max_attempts, last_error FROM queue_jobs WHERE '.$where.' ORDER BY lease_until ASC LIMIT '.$limit.' FOR UPDATE');
            $q->execute($params);
            $jobs = $q->fetchAll();
            if (!$jobs) {
                $this->db->commit();
                return 0;
            }

            $retryIds = [];
            $deadIds = [];
            foreach ($jobs as $job) {
                if ((int)$job['attempts'] >= (int)$job['max_attempts']) {
                    $deadIds[] = (int)$job['id'];
                } else {
                    $retryIds[] = (int)$job['id'];
                }
            }

            if ($retryIds) {
                $ph = implode(',', array_fill(0, count($retryIds), '?'));
                $u = $this->db->prepare('UPDATE queue_jobs SET status="queued", lease_until=NULL, available_at=CURRENT_TIMESTAMP, last_error=CONCAT(COALESCE(last_error,""), " [lease expired]"), updated_at=CURRENT_TIMESTAMP WHERE id IN ('.$ph.') AND status="processing"');
                $u->execute($retryIds);
            }

            if ($deadIds) {
                $ph = implode(',', array_fill(0, count($deadIds), '?'));
                $d = $this->db->prepare('INSERT INTO queue_dead_letters (queue_job_id, queue_name, job_type, payload_json, attempts, error_message, failed_at) SELECT id, queue_name, job_type, payload_json, attempts, CONCAT(COALESCE(last_error,""), " [lease expired: max attempts reached]"), CURRENT_TIMESTAMP FROM queue_jobs WHERE id IN ('.$ph.') AND status="processing"');
                $d->execute($deadIds);
                $u = $this->db->prepare('UPDATE queue_jobs SET status="dead", lease_until=NULL, updated_at=CURRENT_TIMESTAMP WHERE id IN ('.$ph.') AND status="processing"');
                $u->execute($deadIds);
            }

            $this->db->commit();
            return count($jobs);
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function stats(?string $queue = null): array
    {
        $where = '';
        $params = [];
        if ($queue !== null) { $where=' WHERE queue_name=?'; $params[]=$this->normalize($queue,1,80); }
        $q = $this->db->prepare('SELECT status, COUNT(*) AS total FROM queue_jobs'.$where.' GROUP BY status');
        $q->execute($params);
        $out = ['queued'=>0,'processing'=>0,'completed'=>0,'dead'=>0];
        foreach ($q->fetchAll() as $row) $out[(string)$row['status']]=(int)$row['total'];
        $out['depth']=$out['queued']+$out['processing'];
        return $out;
    }

    public function purgeCompleted(int $olderThanHours = 72, int $limit = 5000): int
    {
        $hours = max(1, min(8760, $olderThanHours));
        $limit = max(1, min(20000, $limit));
        $q = $this->db->prepare('DELETE FROM queue_jobs WHERE status="completed" AND completed_at < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? HOUR) LIMIT '.$limit);
        $q->execute([$hours]);
        return $q->rowCount();
    }

    private function assertBackpressure(string $queue): void
    {
        $limits = (array)($this->config['max_depth_by_queue'] ?? []);
        $max = isset($limits[$queue]) ? (int)$limits[$queue] : (int)($this->config['default_max_depth'] ?? 100000);
        if ($max <= 0) return;
        $q = $this->db->prepare('SELECT COUNT(*) FROM queue_jobs WHERE queue_name=? AND status IN ("queued","processing")');
        $q->execute([$queue]);
        if ((int)$q->fetchColumn() >= $max) {
            throw new \RuntimeException('Queue đang quá tải: '.$queue);
        }
    }

    private function normalize(string $value, int $min, int $max): string
    {
        $value = trim($value);
        if ($value === '' || mb_strlen($value) < $min || mb_strlen($value) > $max || !preg_match('/^[A-Za-z0-9._:-]+$/', $value)) {
            throw new \InvalidArgumentException('Queue key không hợp lệ.');
        }
        return $value;
    }
}
