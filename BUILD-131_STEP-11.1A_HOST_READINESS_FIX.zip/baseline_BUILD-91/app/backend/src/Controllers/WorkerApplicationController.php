<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Request, Response, WorkerAuth};
use LaborPlatform\Services\JobMatchingService;

final class WorkerApplicationController
{
    public function __construct(private \PDO $db, private ?JobMatchingService $matching = null)
    {
    }

    public function index(): never
    {
        $workerId = $this->resolveWorkerId();

        $q = $this->db->prepare(
            'SELECT id, ma_ho_so, trang_thai, ngay_tao, ngay_cap_nhat,
                    ma_tin, tieu_de, dia_diem, ten_nha_cung_ung
             FROM dang_ky_ho_so_phong_van
             WHERE nguoi_lao_dong_id=?
             ORDER BY ngay_cap_nhat DESC, id DESC'
        );
        $q->execute([$workerId]);

        Response::ok($q->fetchAll());
    }

    public function show(int $id): never
    {
        $workerId = $this->resolveWorkerId();

        $q = $this->db->prepare(
            'SELECT id, ma_ho_so, trang_thai, ngay_tao, ngay_cap_nhat,
                    ma_tin, tieu_de, dia_diem, ten_nha_cung_ung
             FROM dang_ky_ho_so_phong_van
             WHERE id=? AND nguoi_lao_dong_id=?
             LIMIT 1'
        );
        $q->execute([$id, $workerId]);
        $row = $q->fetch();

        if (!$row) {
            Response::error('Không tìm thấy hồ sơ ứng tuyển.', 404);
        }

        $timeline = $this->db->prepare(
            'SELECT hanh_dong, ghi_chu, thoi_gian
             FROM qua_trinh_dang_ky_ho_so_phong_van
             WHERE dang_ky_ho_so_phong_van_id=?
             ORDER BY thoi_gian ASC, id ASC'
        );
        $timeline->execute([$id]);
        $row['timeline'] = $timeline->fetchAll();

        Response::ok($row);
    }

    public function matches(): never
    {
        $workerId=$this->resolveWorkerId();
        if(!$this->matching) Response::error('Chức năng gợi ý việc làm chưa được cấu hình.',503);
        Response::ok($this->matching->workerMatches($workerId));
    }

    public function cancel(int $id): never
    {
        $workerId=$this->resolveWorkerId();
        $body=Request::body();
        $reason=trim((string)($body['ly_do']??''));

        if($reason==='')
            Response::error('Vui lòng nhập lý do hủy.');

        $this->db->beginTransaction();
        try{
            $q=$this->db->prepare(
                'SELECT * FROM dang_ky_ho_so_phong_van
                 WHERE id=? AND nguoi_lao_dong_id=?
                 LIMIT 1 FOR UPDATE'
            );
            $q->execute([$id,$workerId]);
            $old=$q->fetch();

            if(!$old)
                Response::error('Không tìm thấy hồ sơ ứng tuyển.',404);

            $cancelable=['da_mo_so','da_xem','da_lien_he','khong_lien_he_duoc'];
            if(!in_array($old['trang_thai'],$cancelable,true))
                Response::error('Hồ sơ đã đi qua giai đoạn không thể tự hủy.',409);

            $this->db->prepare(
                'UPDATE dang_ky_ho_so_phong_van
                 SET trang_thai="da_huy", nguoi_lao_dong_xac_nhan=1,
                     ghi_chu=?, ngay_cap_nhat=NOW()
                 WHERE id=? AND nguoi_lao_dong_id=?'
            )->execute([$reason,$id,$workerId]);


            $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                 (dang_ky_ho_so_phong_van_id,nguoi_thuc_hien,nguoi_thuc_hien_id,hanh_dong,ghi_chu)
                 VALUES (?,"nguoi_lao_dong",?,"da_huy",?)'
            )->execute([$id,$workerId,$reason]);

            $this->db->commit();
            Response::ok(['trang_thai'=>'da_huy'],'Đã hủy hồ sơ ứng tuyển.');
        }catch(\Throwable $e){
            if($this->db->inTransaction()) $this->db->rollBack();
            if($e instanceof \RuntimeException) throw $e;
            Response::error('Không thể hủy hồ sơ ứng tuyển.',500);
        }
    }

    private function resolveWorkerId(): int
    {
        return WorkerAuth::workerId($this->db);
    }

    /*
     * Legacy phone/code resolution intentionally removed from App API.
     * The Worker App must always use Bearer identity.
     */

}
