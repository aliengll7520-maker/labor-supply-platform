<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Response,WorkerAuth};

final class WorkerSyncController {
    public function __construct(private \PDO $db) {}
    public function state(): never {
        $workerId=WorkerAuth::workerId($this->db);

        $profile=$this->db->prepare('SELECT COALESCE(MAX(updated_at),MAX(created_at)) FROM nguoi_lao_dong WHERE id=?');
        $profile->execute([$workerId]);

        $apps=$this->db->prepare('SELECT COALESCE(MAX(ngay_cap_nhat),MAX(created_at)) FROM dang_ky_ho_so_phong_van WHERE nguoi_lao_dong_id=?');
        $apps->execute([$workerId]);


        $notifications=$this->db->prepare('SELECT COALESCE(MAX(created_at),"") FROM thong_bao WHERE nguoi_lao_dong_id=?');
        $notifications->execute([$workerId]);

        Response::ok([
            'worker_id'=>$workerId,
            'versions'=>[
                'profile'=>(string)($profile->fetchColumn()??''),
                'applications'=>(string)($apps->fetchColumn()??''),
                'notifications'=>(string)($notifications->fetchColumn()??''),
            ],
            'server_time'=>date(DATE_ATOM),
        ]);
    }
}
