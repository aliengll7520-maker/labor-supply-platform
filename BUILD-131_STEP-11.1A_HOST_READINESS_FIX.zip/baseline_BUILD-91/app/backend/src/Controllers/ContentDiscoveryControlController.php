<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Services\ContentDiscoveryControlService;

final class ContentDiscoveryControlController
{
    public function __construct(private ContentDiscoveryControlService $service) {}
    public function dashboard(): void { \Response::ok($this->service->dashboard()); }
    public function rebuild(): void {
        $body = class_exists('Request') ? \Request::body() : [];
        $limit = (int)($body['limit'] ?? 100);
        \Response::ok($this->service->rebuildActive($limit));
    }
}
