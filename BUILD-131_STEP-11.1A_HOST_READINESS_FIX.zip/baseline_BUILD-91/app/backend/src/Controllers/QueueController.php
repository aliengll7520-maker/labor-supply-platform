<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Request, Response};
use LaborPlatform\Queue\QueueService;

final class QueueController
{
    public function __construct(private QueueService $queue) {}

    public function health(): never
    {
        $queue = trim((string)($_GET['queue'] ?? ''));
        $stats = $this->queue->stats($queue !== '' ? $queue : null);
        Response::ok([
            'queue' => $queue !== '' ? $queue : null,
            'stats' => $stats,
            'worker_layer' => 'database-backed queue + CLI worker',
        ]);
    }
}
