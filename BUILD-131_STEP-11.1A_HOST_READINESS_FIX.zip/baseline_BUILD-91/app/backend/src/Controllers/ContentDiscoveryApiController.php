<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentDiscoveryApiService;

final class ContentDiscoveryApiController
{
    public function __construct(private ContentDiscoveryApiService $api) {}

    public function capabilities(): never
    {
        Response::ok($this->api->capabilities());
    }

    public function jobPipeline(int $jobId): never
    {
        try {
            Response::ok($this->api->jobPipeline($jobId));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), $e->getCode() === 404 ? 404 : 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tải trạng thái Content Discovery.', 500);
        }
    }
}
