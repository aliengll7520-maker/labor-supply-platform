<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Request,Response,WorkerAuth};
use LaborPlatform\Services\{AuditService,NotificationService};

final class PersonalSocialController {
    public function __construct(private \PDO $db, private AuditService $audit, private NotificationService $notify) {}

    private function me(): int { return WorkerAuth::workerId($this->db); }

    private function ensurePrivacy(int $id): void {
        $q=$this->db->prepare('INSERT IGNORE INTO social_quyen_rieng_tu (nguoi_lao_dong_id) VALUES (?)');
        $q->execute([$id]);
    }

    private function friendship(int $a,int $b): ?array {
        $q=$this->db->prepare('SELECT * FROM social_ket_ban WHERE (nguoi_gui_id=? AND nguoi_nhan_id=?) OR (nguoi_gui_id=? AND nguoi_nhan_id=?) ORDER BY id DESC LIMIT 1');
        $q->execute([$a,$b,$b,$a]); return $q->fetch() ?: null;
    }

    public function profile(int $id): never {
        if($id<=0) Response::error('Hồ sơ không hợp lệ.',400);
        $me=WorkerAuth::workerId($this->db,false);
        $q=$this->db->prepare('SELECT n.id,n.ho_ten,n.trang_thai,p.occupation,p.skills,p.experience,p.education,p.avatar_url,p.bio,p.desired_position,p.desired_location,p.province,p.district FROM nguoi_lao_dong n LEFT JOIN ho_so_nghe_nghiep_nguoi_lao_dong p ON p.nguoi_lao_dong_id=n.id WHERE n.id=? LIMIT 1');
        $q->execute([$id]); $p=$q->fetch(); if(!$p) Response::error('Không tìm thấy người dùng.',404);
        $q=$this->db->prepare('SELECT hien_ban_be,hien_bai_viet,cho_phep_ket_ban,cho_phep_theo_doi,cho_phep_trao_doi FROM social_quyen_rieng_tu WHERE nguoi_lao_dong_id=? LIMIT 1');$q->execute([$id]);$privacy=$q->fetch() ?: ['hien_ban_be'=>'cong_khai','hien_bai_viet'=>'cong_khai','cho_phep_ket_ban'=>'tat_ca','cho_phep_theo_doi'=>'tat_ca','cho_phep_trao_doi'=>'ban_be'];
        $friend=$me&&$me!==$id?$this->friendship($me,$id):null;
        $isFriend=$friend&&$friend['trang_thai']==='da_chap_nhan';
        $canSeeFriends=$privacy['hien_ban_be']==='cong_khai'||($privacy['hien_ban_be']==='ban_be'&&$isFriend)||($me===$id);
        $canSeePosts=$privacy['hien_bai_viet']==='cong_khai'||($privacy['hien_bai_viet']==='ban_be'&&$isFriend)||($me===$id);
        $counts=$this->counts($id);
        $following=false;
        if($me && $me!==$id){
            $q=$this->db->prepare('SELECT trang_thai FROM social_theo_doi WHERE nguoi_theo_doi_type=\'nguoi_lao_dong\' AND nguoi_theo_doi_id=? AND doi_tuong_type=\'nguoi_lao_dong\' AND doi_tuong_id=? LIMIT 1');
            $q->execute([$me,$id]);
            $following=((string)$q->fetchColumn()==='dang_theo_doi');
        }
        $posts=[];
        if($canSeePosts){$q=$this->db->prepare('SELECT s.id,s.loai_bai_dang,s.loai_nguon,s.nguon_id,s.noi_dung,s.anh_urls,s.hashtag,s.luot_thich,s.luot_binh_luan,s.luot_chia_se,s.ngay_tao FROM social_bai_dang s WHERE s.loai_tac_gia="nguoi_lao_dong" AND s.tac_gia_id=? AND s.trang_thai="cong_khai" ORDER BY s.id DESC LIMIT 50');$q->execute([$id]);$posts=$q->fetchAll();}
        if(!$canSeeFriends){$counts['ban_be']=null;}
        $p['so_dien_thoai']=null; $p['email']=null;
        Response::ok(['toi_id'=>$me,'profile'=>$p,'privacy'=>$privacy,'friendship'=>$friend,'la_ban_be'=>$isFriend,'can_xem_ban_be'=>$canSeeFriends,'can_xem_bai_viet'=>$canSeePosts,'counts'=>$counts,'dang_theo_doi'=>$following,'posts'=>$posts]);
    }

    public function requests(): never {
        $me=$this->me();$q=$this->db->prepare('SELECT k.id,k.nguoi_gui_id,n.ho_ten,p.avatar_url,k.ngay_tao FROM social_ket_ban k JOIN nguoi_lao_dong n ON n.id=k.nguoi_gui_id LEFT JOIN ho_so_nghe_nghiep_nguoi_lao_dong p ON p.nguoi_lao_dong_id=n.id WHERE k.nguoi_nhan_id=? AND k.trang_thai="cho_chap_nhan" ORDER BY k.id DESC');$q->execute([$me]);Response::ok(['requests'=>$q->fetchAll()]);
    }

    public function friends(): never {
        $me=$this->me();$q=$this->db->prepare('SELECT CASE WHEN k.nguoi_gui_id=? THEN k.nguoi_nhan_id ELSE k.nguoi_gui_id END user_id,n.ho_ten,p.avatar_url FROM social_ket_ban k JOIN nguoi_lao_dong n ON n.id=CASE WHEN k.nguoi_gui_id=? THEN k.nguoi_nhan_id ELSE k.nguoi_gui_id END LEFT JOIN ho_so_nghe_nghiep_nguoi_lao_dong p ON p.nguoi_lao_dong_id=n.id WHERE (k.nguoi_gui_id=? OR k.nguoi_nhan_id=?) AND k.trang_thai="da_chap_nhan" ORDER BY n.ho_ten');$q->execute([$me,$me,$me,$me]);Response::ok(['friends'=>$q->fetchAll()]);
    }

    public function friendRequest(int $id): never {
        $me=$this->me(); if($id<=0||$id===$me)Response::error('Không thể gửi lời mời cho chính mình.');
        $q=$this->db->prepare('SELECT id FROM nguoi_lao_dong WHERE id=? LIMIT 1');$q->execute([$id]);if(!$q->fetch())Response::error('Không tìm thấy người dùng.',404);
        $this->ensurePrivacy($id);$q=$this->db->prepare('SELECT cho_phep_ket_ban FROM social_quyen_rieng_tu WHERE nguoi_lao_dong_id=?');$q->execute([$id]);$allow=(string)$q->fetchColumn();if($allow==='khong_ai')Response::error('Người dùng không nhận lời mời kết bạn.',403);
        $old=$this->friendship($me,$id);if($old){if($old['trang_thai']==='da_chap_nhan')Response::error('Hai người đã là bạn bè.');if($old['trang_thai']==='cho_chap_nhan'&&$old['nguoi_nhan_id']===$me){$this->db->prepare('UPDATE social_ket_ban SET trang_thai="da_chap_nhan",ngay_cap_nhat=NOW() WHERE id=?')->execute([(int)$old['id']]);$status='da_chap_nhan';}else Response::error('Lời mời kết bạn đã tồn tại.');}
        else {$this->db->prepare('INSERT INTO social_ket_ban (nguoi_gui_id,nguoi_nhan_id) VALUES (?,?)')->execute([$me,$id]);$status='cho_chap_nhan';}
        $this->audit->log('nguoi_lao_dong',$me,null,'social_ket_ban','gui_loi_moi_ket_ban',null,['doi_tuong_id'=>$id]);Response::ok(['trang_thai'=>$status],$status==='da_chap_nhan'?'Đã trở thành bạn bè.':'Đã gửi lời mời kết bạn.');
    }

    public function friendAction(int $id): never {
        $me=$this->me();$b=Request::body();$action=(string)($b['hanh_dong']??'');$f=$this->friendship($me,$id);if(!$f)Response::error('Không tìm thấy lời mời kết bạn.',404);
        $new=null;
        if($action==='chap_nhan'&&$f['nguoi_nhan_id']===$me&&$f['trang_thai']==='cho_chap_nhan')$new='da_chap_nhan';
        elseif($action==='tu_choi'&&$f['nguoi_nhan_id']===$me&&$f['trang_thai']==='cho_chap_nhan')$new='da_tu_choi';
        elseif($action==='huy_loi_moi'&&$f['nguoi_gui_id']===$me&&$f['trang_thai']==='cho_chap_nhan')$new='da_huy';
        elseif($action==='huy_ket_ban'&&$f['trang_thai']==='da_chap_nhan')$new='da_huy_ket_ban';
        else Response::error('Thao tác kết bạn không hợp lệ.',409);
        $this->db->prepare('UPDATE social_ket_ban SET trang_thai=?,ngay_cap_nhat=NOW() WHERE id=?')->execute([$new,(int)$f['id']]);$this->audit->log('nguoi_lao_dong',$me,null,'social_ket_ban',$action,null,['doi_tuong_id'=>$id]);Response::ok(['trang_thai'=>$new],'Đã cập nhật quan hệ kết bạn.');
    }

    public function conversations(): never {
        $me=$this->me();
        $sql='SELECT x.doi_tuong_id AS user_id,n.ho_ten,p.avatar_url,x.ngay_tao,x.noi_dung,x.chua_doc FROM (SELECT CASE WHEN t.nguoi_gui_id=? THEN t.nguoi_nhan_id ELSE t.nguoi_gui_id END AS doi_tuong_id, MAX(t.id) AS last_id, MAX(t.ngay_tao) AS ngay_tao, SUBSTRING_INDEX(GROUP_CONCAT(t.noi_dung ORDER BY t.id DESC SEPARATOR "\n"),"\n",1) AS noi_dung, SUM(CASE WHEN t.nguoi_nhan_id=? AND t.trang_thai="da_gui" THEN 1 ELSE 0 END) AS chua_doc FROM social_trao_doi t WHERE t.nguoi_gui_id=? OR t.nguoi_nhan_id=? GROUP BY CASE WHEN t.nguoi_gui_id=? THEN t.nguoi_nhan_id ELSE t.nguoi_gui_id END) x JOIN nguoi_lao_dong n ON n.id=x.doi_tuong_id LEFT JOIN ho_so_nghe_nghiep_nguoi_lao_dong p ON p.nguoi_lao_dong_id=n.id ORDER BY x.last_id DESC LIMIT 100';
        $q=$this->db->prepare($sql);$q->execute([$me,$me,$me,$me,$me]);Response::ok(['conversations'=>$q->fetchAll()]);
    }

    public function markDiscussionRead(int $id): never {
        $me=$this->me();
        if($id<=0||$id===$me)Response::error('Đối tượng không hợp lệ.',400);
        $q=$this->db->prepare('UPDATE social_trao_doi SET trang_thai="da_doc" WHERE nguoi_gui_id=? AND nguoi_nhan_id=? AND trang_thai="da_gui"');
        $q->execute([$id,$me]);
        Response::ok(['da_doc'=>$q->rowCount()]);
    }

    public function privacy(): never { $me=$this->me();$this->ensurePrivacy($me);$q=$this->db->prepare('SELECT hien_ban_be,hien_bai_viet,cho_phep_ket_ban,cho_phep_theo_doi,cho_phep_trao_doi FROM social_quyen_rieng_tu WHERE nguoi_lao_dong_id=?');$q->execute([$me]);Response::ok($q->fetch()); }

    public function updatePrivacy(): never { $me=$this->me();$b=Request::body();$allowed=['cong_khai','ban_be','chi_minh_toi'];$friendAllow=['tat_ca','ban_be_cua_ban_be','khong_ai'];$followAllow=['tat_ca','khong_ai'];$chatAllow=['tat_ca','ban_be','khong_ai'];foreach(['hien_ban_be','hien_bai_viet'] as $k)if(isset($b[$k])&&!in_array($b[$k],$allowed,true))Response::error('Quyền riêng tư không hợp lệ.');if(isset($b['cho_phep_ket_ban'])&&!in_array($b['cho_phep_ket_ban'],$friendAllow,true))Response::error('Thiết lập kết bạn không hợp lệ.');if(isset($b['cho_phep_theo_doi'])&&!in_array($b['cho_phep_theo_doi'],$followAllow,true))Response::error('Thiết lập theo dõi không hợp lệ.');if(isset($b['cho_phep_trao_doi'])&&!in_array($b['cho_phep_trao_doi'],$chatAllow,true))Response::error('Thiết lập trao đổi không hợp lệ.');$this->ensurePrivacy($me);$this->db->prepare('UPDATE social_quyen_rieng_tu SET hien_ban_be=COALESCE(?,hien_ban_be),hien_bai_viet=COALESCE(?,hien_bai_viet),cho_phep_ket_ban=COALESCE(?,cho_phep_ket_ban),cho_phep_theo_doi=COALESCE(?,cho_phep_theo_doi),cho_phep_trao_doi=COALESCE(?,cho_phep_trao_doi) WHERE nguoi_lao_dong_id=?')->execute([$b['hien_ban_be']??null,$b['hien_bai_viet']??null,$b['cho_phep_ket_ban']??null,$b['cho_phep_theo_doi']??null,$b['cho_phep_trao_doi']??null,$me]);$this->privacy();}

    public function discussion(int $id): never { $me=$this->me();if($id===$me)Response::error('Đối tượng không hợp lệ.');$f=$this->friendship($me,$id);$this->ensurePrivacy($id);$q=$this->db->prepare('SELECT cho_phep_trao_doi FROM social_quyen_rieng_tu WHERE nguoi_lao_dong_id=?');$q->execute([$id]);$allow=(string)$q->fetchColumn();if($allow==='khong_ai'||($allow==='ban_be'&&(!$f||$f['trang_thai']!=='da_chap_nhan')))Response::error('Người dùng không nhận trao đổi từ bạn.',403);$q=$this->db->prepare('SELECT t.id,t.nguoi_gui_id,t.nguoi_nhan_id,t.noi_dung,t.trang_thai,t.ngay_tao,n.ho_ten FROM social_trao_doi t JOIN nguoi_lao_dong n ON n.id=t.nguoi_gui_id WHERE (t.nguoi_gui_id=? AND t.nguoi_nhan_id=?) OR (t.nguoi_gui_id=? AND t.nguoi_nhan_id=?) ORDER BY t.id ASC LIMIT 200');$q->execute([$me,$id,$id,$me]);Response::ok(['messages'=>$q->fetchAll()]);}

    public function sendDiscussion(int $id): never { $me=$this->me();$b=Request::body();$text=trim((string)($b['noi_dung']??''));if($text===''||mb_strlen($text)>2000)Response::error('Nội dung trao đổi phải từ 1 đến 2000 ký tự.');$f=$this->friendship($me,$id);$this->ensurePrivacy($id);$q=$this->db->prepare('SELECT cho_phep_trao_doi FROM social_quyen_rieng_tu WHERE nguoi_lao_dong_id=?');$q->execute([$id]);$allow=(string)$q->fetchColumn();if($allow==='khong_ai'||($allow==='ban_be'&&(!$f||$f['trang_thai']!=='da_chap_nhan')))Response::error('Người dùng không nhận trao đổi từ bạn.',403);$this->db->prepare('INSERT INTO social_trao_doi (nguoi_gui_id,nguoi_nhan_id,noi_dung) VALUES (?,?,?)')->execute([$me,$id,$text]);
        try{$q=$this->db->prepare('SELECT ho_ten FROM nguoi_lao_dong WHERE id=?');$q->execute([$me]);$sender=(string)($q->fetchColumn()?:'Một thành viên');$this->notify->worker($id,'Bạn có trao đổi mới',$sender.' đã gửi một trao đổi cho bạn.','social_message');}catch(\Throwable $e){}
        $this->audit->log('nguoi_lao_dong',$me,null,'social_trao_doi','gui_trao_doi',null,['doi_tuong_id'=>$id]);Response::ok(null,'Đã gửi trao đổi.');}

    private function counts(int $id): array { $q=$this->db->prepare('SELECT COUNT(*) FROM social_ket_ban WHERE (nguoi_gui_id=? OR nguoi_nhan_id=?) AND trang_thai="da_chap_nhan"');$q->execute([$id,$id]);$friends=(int)$q->fetchColumn();$q=$this->db->prepare('SELECT COUNT(*) FROM social_theo_doi WHERE doi_tuong_type="nguoi_lao_dong" AND doi_tuong_id=? AND trang_thai="dang_theo_doi"');$q->execute([$id]);$followers=(int)$q->fetchColumn();$q=$this->db->prepare('SELECT COUNT(*) FROM social_theo_doi WHERE nguoi_theo_doi_type="nguoi_lao_dong" AND nguoi_theo_doi_id=? AND trang_thai="dang_theo_doi"');$q->execute([$id]);$following=(int)$q->fetchColumn();return ['ban_be'=>$friends,'nguoi_theo_doi'=>$followers,'dang_theo_doi'=>$following]; }
}
