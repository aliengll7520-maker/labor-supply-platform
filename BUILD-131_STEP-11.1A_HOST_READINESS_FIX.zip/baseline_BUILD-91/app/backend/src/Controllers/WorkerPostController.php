<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Request,Response,WorkerAuth,Auth,Pagination};
use LaborPlatform\Services\AuditService;
use LaborPlatform\Queue\QueueService;

final class WorkerPostController {
    public function __construct(private \PDO $db, private AuditService $audit, private QueueService $queue) {}

    private function validate(array $b): array {
        $title=trim((string)($b['tieu_de']??''));
        $location=trim((string)($b['dia_diem_mong_muon']??''));
        if(mb_strlen($title)>255) Response::error('Công việc mong muốn không quá 255 ký tự.');
        if(mb_strlen($location)>255) Response::error('Khu vực mong muốn không quá 255 ký tự.');
        $salary=trim((string)($b['thu_nhap_mong_muon']??''));
        if(mb_strlen($salary)>120) Response::error('Thu nhập mong muốn không quá 120 ký tự.');
        $skills=trim((string)($b['ky_nang']??''));
        $experience=trim((string)($b['kinh_nghiem']??''));
        $intro=trim((string)($b['gioi_thieu']??''));
        if(mb_strlen($skills)>2000||mb_strlen($experience)>2000||mb_strlen($intro)>2000) Response::error('Nội dung mô tả không quá 2000 ký tự cho mỗi trường.');
        $availability=trim((string)($b['thoi_gian_co_the_di_lam']??''));
        if(mb_strlen($availability)>255) Response::error('Thời gian có thể đi làm không quá 255 ký tự.');
        $position=trim((string)($b['vi_tri_mong_muon']??''));
        $workType=trim((string)($b['hinh_thuc_lam_viec']??''));
        $shift=trim((string)($b['ca_lam_mong_muon']??''));
        $certificates=trim((string)($b['chung_chi']??''));
        $video=trim((string)($b['video_gioi_thieu_url']??''));
        foreach(['tieu_de'=>$title,'dia_diem_mong_muon'=>$location,'thu_nhap_mong_muon'=>$salary,'ky_nang'=>$skills,'kinh_nghiem'=>$experience,'gioi_thieu'=>$intro,'thoi_gian_co_the_di_lam'=>$availability,'vi_tri_mong_muon'=>$position,'hinh_thuc_lam_viec'=>$workType,'ca_lam_mong_muon'=>$shift,'chung_chi'=>$certificates] as $field=>$value) { \LaborPlatform\Services\ContentSafetyService::assertSafe($value, $field); }
        if(mb_strlen($position)>255||mb_strlen($workType)>120||mb_strlen($shift)>120||mb_strlen($certificates)>2000||mb_strlen($video)>500) Response::error('Một trường thông tin vượt quá giới hạn cho phép.');
        return [$title,$location,$salary,$skills,$experience,$intro,$availability,$position,$workType,$shift,$certificates,$video];
    }

    public function mine(): never {
        $id=WorkerAuth::workerId($this->db);
        $q=$this->db->prepare('SELECT id,tieu_de,dia_diem_mong_muon,thu_nhap_mong_muon,ky_nang,kinh_nghiem,gioi_thieu,thoi_gian_co_the_di_lam,vi_tri_mong_muon,hinh_thuc_lam_viec,ca_lam_mong_muon,chung_chi,video_gioi_thieu_url,trang_thai,ngay_tao,ngay_cap_nhat FROM tin_tim_viec_nguoi_lao_dong WHERE nguoi_lao_dong_id=? ORDER BY id DESC');
        $q->execute([$id]); Response::ok($q->fetchAll());
    }

    public function create(): never {
        $id=WorkerAuth::workerId($this->db);
        [$title,$location,$salary,$skills,$experience,$intro,$availability,$position,$workType,$shift,$certificates,$video]=$this->validate(Request::body());
        $q=$this->db->prepare('INSERT INTO tin_tim_viec_nguoi_lao_dong (nguoi_lao_dong_id,tieu_de,dia_diem_mong_muon,thu_nhap_mong_muon,ky_nang,kinh_nghiem,gioi_thieu,thoi_gian_co_the_di_lam,vi_tri_mong_muon,hinh_thuc_lam_viec,ca_lam_mong_muon,chung_chi,video_gioi_thieu_url,trang_thai) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,"cho_duyet")');
        $q->execute([$id,$title?:null,$location?:null,$salary?:null,$skills?:null,$experience?:null,$intro?:null,$availability?:null,$position?:null,$workType?:null,$shift?:null,$certificates?:null,$video?:null]);
        $postId=(int)$this->db->lastInsertId();
        $this->audit->log('nguoi_lao_dong',$id,null,'tin_tim_viec_nguoi_lao_dong','tao_tin_tim_viec',null,['id'=>$postId]);
        $this->queue->enqueue('moderation','moderation.worker_post',['post_id'=>$postId,'actor_type'=>'nguoi_lao_dong','actor_id'=>$id],200,'worker_post:'.$postId);
        Response::ok(['id'=>$postId,'trang_thai'=>'cho_duyet'],'Đã gửi Tin tìm việc. Tin sẽ được kiểm duyệt trước khi hiển thị.',201);
    }

    public function update(int $postId): never {
        $id=WorkerAuth::workerId($this->db);
        $q=$this->db->prepare('SELECT id,trang_thai FROM tin_tim_viec_nguoi_lao_dong WHERE id=? AND nguoi_lao_dong_id=? LIMIT 1');$q->execute([$postId,$id]);$old=$q->fetch();
        if(!$old) Response::error('Không tìm thấy Tin tìm việc.',404);
        [$title,$location,$salary,$skills,$experience,$intro,$availability,$position,$workType,$shift,$certificates,$video]=$this->validate(Request::body());
        $q=$this->db->prepare('UPDATE tin_tim_viec_nguoi_lao_dong SET tieu_de=?,dia_diem_mong_muon=?,thu_nhap_mong_muon=?,ky_nang=?,kinh_nghiem=?,gioi_thieu=?,thoi_gian_co_the_di_lam=?,vi_tri_mong_muon=?,hinh_thuc_lam_viec=?,ca_lam_mong_muon=?,chung_chi=?,video_gioi_thieu_url=?,trang_thai="cho_duyet" WHERE id=? AND nguoi_lao_dong_id=?');
        $q->execute([$title?:null,$location?:null,$salary?:null,$skills?:null,$experience?:null,$intro?:null,$availability?:null,$position?:null,$workType?:null,$shift?:null,$certificates?:null,$video?:null,$postId,$id]);
        $this->audit->log('nguoi_lao_dong',$id,null,'tin_tim_viec_nguoi_lao_dong','cap_nhat_tin_tim_viec',null,['id'=>$postId,'trang_thai_cu'=>$old['trang_thai'],'trang_thai_moi'=>'cho_duyet']);
        $this->queue->enqueue('moderation','moderation.worker_post',['post_id'=>$postId,'actor_type'=>'nguoi_lao_dong','actor_id'=>$id],200,'worker_post:'.$postId.':'.date('YmdHis'));
        Response::ok(null,'Đã cập nhật và gửi lại Tin tìm việc để kiểm duyệt.');
    }

    public function publicList(): never {
        $limit=Pagination::limit(50,100);
        $offset=Pagination::offset();
        $q=$this->db->prepare('SELECT p.id,p.tieu_de,p.dia_diem_mong_muon,p.thu_nhap_mong_muon,p.ky_nang,p.kinh_nghiem,p.gioi_thieu,p.thoi_gian_co_the_di_lam,p.vi_tri_mong_muon,p.hinh_thuc_lam_viec,p.ca_lam_mong_muon,p.chung_chi,p.video_gioi_thieu_url,p.ngay_tao,n.ho_ten AS ten_nguoi_lao_dong,n.id AS nguoi_lao_dong_id FROM tin_tim_viec_nguoi_lao_dong p JOIN nguoi_lao_dong n ON n.id=p.nguoi_lao_dong_id WHERE p.trang_thai="dang_hien" AND n.trang_thai="hoat_dong" ORDER BY p.ngay_tao DESC,p.id DESC LIMIT :limit OFFSET :offset');
        $q->bindValue(':limit',$limit,\PDO::PARAM_INT);
        $q->bindValue(':offset',$offset,\PDO::PARAM_INT);
        $q->execute();
        $rows=$q->fetchAll(); foreach($rows as &$r){ unset($r['nguoi_lao_dong_id']); } Response::ok($rows);
    }

    public function employerList(): never {
        $sid=Auth::supplierId();
        $q=$this->db->query('SELECT p.id,p.tieu_de,p.dia_diem_mong_muon,p.thu_nhap_mong_muon,p.ky_nang,p.kinh_nghiem,p.gioi_thieu,p.thoi_gian_co_the_di_lam,p.vi_tri_mong_muon,p.hinh_thuc_lam_viec,p.ca_lam_mong_muon,p.chung_chi,p.video_gioi_thieu_url,p.ngay_tao,n.ho_ten AS ten_nguoi_lao_dong FROM tin_tim_viec_nguoi_lao_dong p JOIN nguoi_lao_dong n ON n.id=p.nguoi_lao_dong_id WHERE p.trang_thai="dang_hien" AND n.trang_thai="hoat_dong" ORDER BY p.ngay_tao DESC,p.id DESC LIMIT 200');
        $rows=$q->fetchAll();
        $q=$this->db->prepare('SELECT tin_tim_viec_id,trang_thai FROM ket_noi_nha_tuyen_dung_nguoi_lao_dong WHERE nha_cung_ung_id=?');$q->execute([$sid]);$map=[];foreach($q->fetchAll() as $x)$map[(int)$x['tin_tim_viec_id']]=$x['trang_thai'];
        foreach($rows as &$r)$r['trang_thai_ket_noi']=$map[(int)$r['id']]??null;
        Response::ok($rows);
    }

    public function connect(int $postId): never {
        $sid=Auth::supplierId();
        $q=$this->db->prepare('SELECT id,nguoi_lao_dong_id FROM tin_tim_viec_nguoi_lao_dong WHERE id=? AND trang_thai="dang_hien" LIMIT 1');$q->execute([$postId]);$post=$q->fetch();if(!$post)Response::error('Tin tìm việc không còn hiển thị.',404);
        $q=$this->db->prepare('SELECT id,trang_thai FROM ket_noi_nha_tuyen_dung_nguoi_lao_dong WHERE tin_tim_viec_id=? AND nha_cung_ung_id=? LIMIT 1');$q->execute([$postId,$sid]);$existing=$q->fetch();
        if($existing) Response::ok($existing,'Yêu cầu kết nối đã tồn tại.');
        $q=$this->db->prepare('INSERT INTO ket_noi_nha_tuyen_dung_nguoi_lao_dong (tin_tim_viec_id,nguoi_lao_dong_id,nha_cung_ung_id,trang_thai,ghi_chu) VALUES (?,?,?,"cho_nguoi_lao_dong_xac_nhan",?)');
        $q->execute([$postId,(int)$post['nguoi_lao_dong_id'],$sid,'Doanh nghiệp muốn kết nối với Người lao động qua Tin tìm việc.']);$id=(int)$this->db->lastInsertId();
        $this->audit->log('nha_cung_ung',$sid,null,'ket_noi_nha_tuyen_dung_nguoi_lao_dong','gui_yeu_cau_ket_noi',null,['id'=>$id,'tin_tim_viec_id'=>$postId]);
        Response::ok(['id'=>$id,'trang_thai'=>'cho_nguoi_lao_dong_xac_nhan'],'Đã gửi yêu cầu kết nối. Số điện thoại không được công khai.');
    }

    public function connections(): never {
        $id=WorkerAuth::workerId($this->db);
        $q=$this->db->prepare('SELECT k.id,k.tin_tim_viec_id,k.nha_cung_ung_id,k.trang_thai,k.ghi_chu,k.ngay_tao,k.ngay_cap_nhat,n.ten_don_vi,n.nguoi_dai_dien FROM ket_noi_nha_tuyen_dung_nguoi_lao_dong k JOIN nha_cung_ung n ON n.id=k.nha_cung_ung_id WHERE k.nguoi_lao_dong_id=? ORDER BY k.id DESC');$q->execute([$id]);Response::ok($q->fetchAll());
    }

    public function respondConnection(int $connectionId): never {
        $id=WorkerAuth::workerId($this->db);$status=(string)(Request::body()['trang_thai']??'');
        if(!in_array($status,['da_chap_nhan','tu_choi'],true))Response::error('Trạng thái kết nối không hợp lệ.');
        $q=$this->db->prepare('SELECT id FROM ket_noi_nha_tuyen_dung_nguoi_lao_dong WHERE id=? AND nguoi_lao_dong_id=? LIMIT 1');$q->execute([$connectionId,$id]);if(!$q->fetch())Response::error('Không tìm thấy yêu cầu kết nối.',404);
        $q=$this->db->prepare('UPDATE ket_noi_nha_tuyen_dung_nguoi_lao_dong SET trang_thai=?,ngay_cap_nhat=NOW() WHERE id=? AND nguoi_lao_dong_id=?');$q->execute([$status,$connectionId,$id]);
        $this->audit->log('nguoi_lao_dong',$id,null,'ket_noi_nha_tuyen_dung_nguoi_lao_dong','phan_hoi_ket_noi',null,['id'=>$connectionId,'trang_thai'=>$status]);
        Response::ok(null,$status==='da_chap_nhan'?'Đã chấp nhận kết nối.':'Đã từ chối kết nối.');
    }
}
