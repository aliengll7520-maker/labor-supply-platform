<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,Request,Response,WorkerAuth,AdminAuth};
use LaborPlatform\Services\{AuditService,ContentSafetyService};

final class TrustReputationController {
    public function __construct(private \PDO $db, private AuditService $audit) {}

    private function summary(string $type,int $id): array {
        $q=$this->db->prepare('SELECT COUNT(*) AS total, COALESCE(AVG(rating),0) AS average FROM trust_reviews WHERE reviewee_type=? AND reviewee_id=? AND status="cong_khai"');
        $q->execute([$type,$id]);
        $row=$q->fetch()?:['total'=>0,'average'=>0];
        $dist=[];
        $q=$this->db->prepare('SELECT rating,COUNT(*) total FROM trust_reviews WHERE reviewee_type=? AND reviewee_id=? AND status="cong_khai" GROUP BY rating ORDER BY rating DESC');
        $q->execute([$type,$id]);
        foreach($q->fetchAll() as $r) $dist[(string)$r['rating']]=(int)$r['total'];
        return ['diem_trung_binh'=>round((float)$row['average'],2),'luot_danh_gia'=>(int)$row['total'],'phan_bo'=>$dist];
    }

    private function reviews(string $type,int $id): array {
        $q=$this->db->prepare('SELECT id,reviewer_type,reviewer_id,rating,review_text,status,created_at,updated_at FROM trust_reviews WHERE reviewee_type=? AND reviewee_id=? AND status="cong_khai" ORDER BY id DESC LIMIT 100');
        $q->execute([$type,$id]);
        $rows=$q->fetchAll();
        foreach($rows as &$r){
            if($r['reviewer_type']==='worker'){
                $x=$this->db->prepare('SELECT ho_ten FROM nguoi_lao_dong WHERE id=? LIMIT 1');
            }else{
                $x=$this->db->prepare('SELECT ten_nha_cung_ung AS ho_ten FROM nha_cung_ung WHERE id=? LIMIT 1');
            }
            $x->execute([(int)$r['reviewer_id']]);
            $r['nguoi_danh_gia']=(string)($x->fetchColumn()?:'Thành viên');
        }
        return $rows;
    }

    public function publicEmployer(int $id): never {
        $this->assertEmployerExists($id);
        Response::ok(['doi_tuong_type'=>'employer','doi_tuong_id'=>$id,'danh_tieng'=>$this->summary('employer',$id),'danh_gia'=>$this->reviews('employer',$id)]);
    }
    public function publicWorker(int $id): never {
        $this->assertWorkerExists($id);
        Response::ok(['doi_tuong_type'=>'worker','doi_tuong_id'=>$id,'danh_tieng'=>$this->summary('worker',$id),'danh_gia'=>$this->reviews('worker',$id)]);
    }

    private function assertEmployerExists(int $id): void {
        $q=$this->db->prepare('SELECT id FROM nha_cung_ung WHERE id=? LIMIT 1');$q->execute([$id]);
        if(!$q->fetchColumn()) Response::error('Không tìm thấy Doanh nghiệp.',404);
    }
    private function assertWorkerExists(int $id): void {
        $q=$this->db->prepare('SELECT id FROM nguoi_lao_dong WHERE id=? LIMIT 1');$q->execute([$id]);
        if(!$q->fetchColumn()) Response::error('Không tìm thấy Người lao động.',404);
    }

    private function applicationForWorker(int $applicationId,int $workerId): array {
        $q=$this->db->prepare('SELECT id,nguoi_lao_dong_id,nha_cung_ung_id,tin_tuyen_dung_id,trang_thai FROM dang_ky_ho_so_phong_van WHERE id=? AND nguoi_lao_dong_id=? LIMIT 1');
        $q->execute([$applicationId,$workerId]);$row=$q->fetch();
        if(!$row) Response::error('Không tìm thấy Đăng ký hồ sơ hợp lệ.',404);
        if(!in_array($row['trang_thai'],['da_xem','da_lien_he','khong_lien_he_duoc'],true)) Response::error('Chưa đủ điều kiện để đánh giá từ mối liên hệ này.',409);
        return $row;
    }
    private function applicationForEmployer(int $applicationId,int $supplierId): array {
        $q=$this->db->prepare('SELECT id,nguoi_lao_dong_id,nha_cung_ung_id,tin_tuyen_dung_id,trang_thai FROM dang_ky_ho_so_phong_van WHERE id=? AND nha_cung_ung_id=? LIMIT 1');
        $q->execute([$applicationId,$supplierId]);$row=$q->fetch();
        if(!$row) Response::error('Không tìm thấy Đăng ký hồ sơ hợp lệ.',404);
        if(!in_array($row['trang_thai'],['da_xem','da_lien_he','khong_lien_he_duoc'],true)) Response::error('Chưa đủ điều kiện để đánh giá từ mối liên hệ này.',409);
        return $row;
    }

    public function reviewEmployer(int $employerId): never {
        $workerId=WorkerAuth::workerId($this->db);
        $b=Request::body();$applicationId=(int)($b['application_id']??0);$rating=(int)($b['rating']??0);$text=trim((string)($b['review_text']??''));
        if($rating<1||$rating>5) Response::error('Số sao phải từ 1 đến 5.',422);
        if(mb_strlen($text)>1000) Response::error('Nhận xét tối đa 1000 ký tự.',422);
        ContentSafetyService::assertSafe($text,'Nhận xét');
        $app=$this->applicationForWorker($applicationId,$workerId);
        if((int)$app['nha_cung_ung_id']!==$employerId) Response::error('Đăng ký hồ sơ không thuộc Doanh nghiệp này.',403);
        $this->saveReview('worker',$workerId,'employer',$employerId,$applicationId,$rating,$text);
    }

    public function reviewWorker(int $workerId): never {
        $supplierId=Auth::supplierId();
        $b=Request::body();$applicationId=(int)($b['application_id']??0);$rating=(int)($b['rating']??0);$text=trim((string)($b['review_text']??''));
        if($rating<1||$rating>5) Response::error('Số sao phải từ 1 đến 5.',422);
        if(mb_strlen($text)>1000) Response::error('Nhận xét tối đa 1000 ký tự.',422);
        ContentSafetyService::assertSafe($text,'Nhận xét');
        $app=$this->applicationForEmployer($applicationId,$supplierId);
        if((int)$app['nguoi_lao_dong_id']!==$workerId) Response::error('Đăng ký hồ sơ không thuộc Người lao động này.',403);
        $this->saveReview('employer',$supplierId,'worker',$workerId,$applicationId,$rating,$text);
    }

    private function saveReview(string $reviewerType,int $reviewerId,string $revieweeType,int $revieweeId,int $applicationId,int $rating,string $text): never {
        if($reviewerType===$revieweeType && $reviewerId===$revieweeId) Response::error('Không thể tự đánh giá chính mình.',422);
        $q=$this->db->prepare('SELECT id FROM trust_reviews WHERE reviewer_type=? AND reviewer_id=? AND reviewee_type=? AND reviewee_id=? AND context_type="application" AND context_id=? LIMIT 1');
        $q->execute([$reviewerType,$reviewerId,$revieweeType,$revieweeId,$applicationId]);
        if($q->fetchColumn()) Response::error('Bạn đã đánh giá mối liên hệ này.',409);
        $q=$this->db->prepare('INSERT INTO trust_reviews (reviewer_type,reviewer_id,reviewee_type,reviewee_id,context_type,context_id,rating,review_text,status) VALUES (?,?,?,?,?,?,?,?,?)');
        $q->execute([$reviewerType,$reviewerId,$revieweeType,$revieweeId,'application',$applicationId,$rating,$text?:null,'cong_khai']);
        $id=(int)$this->db->lastInsertId();
        $this->audit->log($reviewerType,$reviewerId,$applicationId,'trust_review','tao',null,['id'=>$id,'reviewee_type'=>$revieweeType,'reviewee_id'=>$revieweeId,'rating'=>$rating]);
        Response::ok(['id'=>$id,'rating'=>$rating,'review_text'=>$text,'status'=>'cong_khai'],'Đã gửi đánh giá.');
    }

    public function report(int $reviewId): never {
        $b=Request::body();$reason=trim((string)($b['reason']??''));$description=trim((string)($b['description']??''));
        if($reason==='') Response::error('Vui lòng chọn lý do báo cáo.',422);
        if(mb_strlen($description)>500) Response::error('Mô tả báo cáo tối đa 500 ký tự.',422);
        ContentSafetyService::assertSafe($description,'Mô tả báo cáo');
        $reviewerType='worker';$reviewerId=WorkerAuth::workerId($this->db,false);
        if($reviewerId<=0){$reviewerType='employer';$reviewerId=Auth::supplierId();}
        $q=$this->db->prepare('SELECT id FROM trust_reviews WHERE id=? AND status<>"an" LIMIT 1');$q->execute([$reviewId]);
        if(!$q->fetchColumn()) Response::error('Không tìm thấy đánh giá.',404);
        $q=$this->db->prepare('INSERT INTO trust_review_reports (review_id,reporter_type,reporter_id,reason,description,status) VALUES (?,?,?,?,?,"mo")');
        $q->execute([$reviewId,$reviewerType,$reviewerId,$reason,$description?:null]);
        Response::ok(null,'Đã tiếp nhận báo cáo.');
    }

    public function adminReviews(): never {
        AdminAuth::requirePermission('trust.reviews.view');
        $q=$this->db->query('SELECT r.*,rp.reason,rp.description,rp.status AS report_status FROM trust_reviews r LEFT JOIN trust_review_reports rp ON rp.review_id=r.id WHERE r.status IN ("cho_xu_ly","an") OR rp.id IS NOT NULL ORDER BY r.id DESC LIMIT 500');
        Response::ok(['reviews'=>$q->fetchAll()]);
    }
    public function adminModerate(int $id): never {
        AdminAuth::requirePermission('trust.reviews.manage');
        $b=Request::body();$status=(string)($b['status']??'');$reason=trim((string)($b['reason']??''));
        if(!in_array($status,['cong_khai','an','cho_xu_ly'],true)) Response::error('Trạng thái đánh giá không hợp lệ.',422);
        $q=$this->db->prepare('UPDATE trust_reviews SET status=?,moderation_reason=?,updated_at=NOW() WHERE id=?');$q->execute([$status,$reason?:null,$id]);
        if($q->rowCount()<1) Response::error('Không tìm thấy đánh giá.',404);
        $this->audit->log('admin',AdminAuth::accountId(),$id,'trust_review','moderate',null,['status'=>$status,'reason'=>$reason]);
        Response::ok(null,'Đã cập nhật đánh giá.');
    }
    public function adminReport(int $id): never {
        AdminAuth::requirePermission('trust.reviews.manage');
        $b=Request::body();$status=(string)($b['status']??'');
        if(!in_array($status,['dang_xu_ly','da_xu_ly','tu_choi'],true)) Response::error('Trạng thái báo cáo không hợp lệ.',422);
        $q=$this->db->prepare('UPDATE trust_review_reports SET status=?,updated_at=NOW() WHERE id=?');$q->execute([$status,$id]);
        if($q->rowCount()<1) Response::error('Không tìm thấy báo cáo.',404);
        Response::ok(null,'Đã cập nhật báo cáo.');
    }
}
