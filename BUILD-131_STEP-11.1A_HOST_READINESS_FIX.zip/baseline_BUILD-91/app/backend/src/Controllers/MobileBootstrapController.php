<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Response,MobileAuth};
use LaborPlatform\Services\{IdentityService,MobileBootstrapService};

final class MobileBootstrapController
{
    public function __construct(
        private \PDO $db,
        private IdentityService $identity,
        private MobileBootstrapService $bootstrap
    ) {}

    public function show(): never
    {
        $session = MobileAuth::resolve($this->db);
        $identity = $this->identity->current((int)$session['identity_id']);
        Response::ok($this->bootstrap->bootstrap($session, $identity), 'Mobile bootstrap OK.');
    }
}
