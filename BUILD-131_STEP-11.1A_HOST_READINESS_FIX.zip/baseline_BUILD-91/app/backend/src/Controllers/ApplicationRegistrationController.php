<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,Response,Request,WorkerAuth};
use LaborPlatform\Services\PhoneMaskService;
use LaborPlatform\Queue\QueueService;
use LaborPlatform\Services\{AuditService,NotificationService,WorkerNotificationEventService,ApplicationStatusWorkflowService};

final class ApplicationRegistrationController {
    public function __construct(
        private \PDO $db,
        private AuditService $audit,
        private NotificationService $notify,
        private WorkerNotificationEventService $workerEvents,
        private QueueService $queue,
        private ApplicationStatusWorkflowService $workflow
    ) {}

    private function getOwned(int $id,int $sid): array {
        $s=$this->db->prepare(
            'SELECT h.*,t.tieu_de,t.ma_tin,t.trang_thai AS tin_trang_thai,
                    n.ho_ten,n.so_dien_thoai AS so_dien_thoai_nguoi_lao_dong,n.que_quan
             FROM dang_ky_ho_so_phong_van h
             JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id
             JOIN nguoi_lao_dong n ON n.id=h.nguoi_lao_dong_id
             WHERE h.id=? AND h.nha_cung_ung_id=? LIMIT 1'
        );
        $s->execute([$id,$sid]);$row=$s->fetch();
        if(!$row)Response::error('Không tìm thấy Đăng ký hồ sơ.',404);
        return $row;
    }

    private function getOwnedForUpdate(int $id,int $sid): array {
        $s=$this->db->prepare(
            'SELECT h.*,t.tieu_de,t.ma_tin,t.trang_thai AS tin_trang_thai,
                    n.ho_ten,n.so_dien_thoai AS so_dien_thoai_nguoi_lao_dong,n.que_quan
             FROM dang_ky_ho_so_phong_van h
             JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id
             JOIN nguoi_lao_dong n ON n.id=h.nguoi_lao_dong_id
             WHERE h.id=? AND h.nha_cung_ung_id=? LIMIT 1 FOR UPDATE'
        );
        $s->execute([$id,$sid]);$row=$s->fetch();
        if(!$row)Response::error('Không tìm thấy Đăng ký hồ sơ.',404);
        return $row;
    }

    public function list(): never {
        $sid=Auth::supplierId();
        $s=$this->db->prepare(
            'SELECT h.*,t.tieu_de,t.ma_tin,
                    n.ho_ten,n.so_dien_thoai AS so_dien_thoai_nguoi_lao_dong,n.que_quan
             FROM dang_ky_ho_so_phong_van h
             JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id
             JOIN nguoi_lao_dong n ON n.id=h.nguoi_lao_dong_id
             WHERE h.nha_cung_ung_id=? ORDER BY h.id DESC'
        );
        $s->execute([$sid]);
        $rows=$s->fetchAll();
        foreach($rows as &$row){
            $row['so_dien_thoai_nguoi_lao_dong_day_du']=null;
            $row['so_dien_thoai_nguoi_lao_dong']=PhoneMaskService::mask($row['so_dien_thoai_nguoi_lao_dong']??'');
        }
        Response::ok($rows);
    }

    public function detail(int $id): never {
        $sid=Auth::supplierId();
        $row=$this->getOwned($id,$sid);
        $q=$this->db->prepare(
            'SELECT * FROM qua_trinh_dang_ky_ho_so_phong_van
             WHERE dang_ky_ho_so_phong_van_id=?
             ORDER BY thoi_gian ASC,id ASC'
        );
        $q->execute([$id]);$row['timeline']=$q->fetchAll();
        $row['so_dien_thoai_nguoi_lao_dong_day_du']=null;
        $row['so_dien_thoai_nguoi_lao_dong']=PhoneMaskService::mask($row['so_dien_thoai_nguoi_lao_dong']??'');
        Response::ok($row);
    }
    public function createPublic(): never {
        $b=Request::body();

        $jobId=(int)($b['tin_tuyen_dung_id']??0);
        $hoTen=trim((string)($b['ho_ten']??''));
        $phone=trim((string)($b['so_dien_thoai']??''));
        $queQuan=trim((string)($b['que_quan']??''));

        /*
         * Worker App: Bearer token is the source of identity.
         * The App may omit personal fields; Backend resolves them from the token.
         */
        $authenticatedWorkerId=null;
        if(!empty($_SERVER['HTTP_AUTHORIZATION'])){
            $authenticatedWorkerId=WorkerAuth::workerId($this->db);

            $q=$this->db->prepare(
                'SELECT id,ho_ten,so_dien_thoai,que_quan,trang_thai
                 FROM nguoi_lao_dong
                 WHERE id=?
                 LIMIT 1'
            );
            $q->execute([$authenticatedWorkerId]);
            $authWorker=$q->fetch();

            if(!$authWorker)
                Response::error('Không tìm thấy Người lao động.',404);

            if($authWorker['trang_thai']!=='hoat_dong')
                Response::error('Tài khoản Người lao động hiện không hoạt động.',403);

            $hoTen=(string)$authWorker['ho_ten'];
            $phone=(string)$authWorker['so_dien_thoai'];
            $queQuan=(string)$authWorker['que_quan'];
        }

        if($jobId<=0)
            Response::error('Không xác định được Tin tuyển dụng.');

        if($hoTen==='')
            Response::error('Vui lòng nhập Họ tên.');

        if($phone==='')
            Response::error('Vui lòng nhập Số điện thoại.');

        if($queQuan==='')
            Response::error('Vui lòng nhập Quê quán.');

        if(!preg_match('/^[0-9+\-\s().]{8,20}$/',$phone))
            Response::error('Số điện thoại không hợp lệ.');

        $this->db->beginTransaction();

        try{

            /*
             * Chỉ cho phép đăng ký vào Tin đang công khai và
             * Nhà cung ứng đang hoạt động + đã xác minh.
             */
            $q=$this->db->prepare(
                'SELECT
                    t.id,
                    t.ma_tin,
                    t.tieu_de,
                    t.nha_cung_ung_id,
                    n.ten_nha_cung_ung,
                    n.so_dien_thoai AS so_dien_thoai_nha_cung_ung
                 FROM tin_tuyen_dung t
                 JOIN nha_cung_ung n
                   ON n.id=t.nha_cung_ung_id
                 WHERE t.id=?
                   AND t.trang_thai="dang_tuyen"
                   AND n.trang_thai="hoat_dong"
                   AND n.xac_minh="da_xac_minh"
                   AND (
                       t.ngay_het_han IS NULL
                       OR t.ngay_het_han>NOW()
                   )
                 LIMIT 1
                 FOR UPDATE'
            );

            $q->execute([$jobId]);
            $job=$q->fetch();

            if(!$job)
                Response::error(
                    'Tin tuyển dụng không còn nhận hồ sơ.',
                    409
                );

            /*
             * Một Người lao động có thể ứng tuyển nhiều Tin khác nhau,
             * nhưng không tạo hai hồ sơ đang hoạt động cho cùng một Tin.
             */
            if($authenticatedWorkerId){
                $q=$this->db->prepare(
                    'SELECT id,ma_ho_so,trang_thai
                     FROM dang_ky_ho_so_phong_van
                     WHERE nguoi_lao_dong_id=?
                     AND tin_tuyen_dung_id=?
                     AND trang_thai<>"da_huy"
                     ORDER BY id DESC
                     LIMIT 1
                     FOR UPDATE'
                );
                $q->execute([$authenticatedWorkerId,$jobId]);
            }else{
                $q=$this->db->prepare(
                    'SELECT id,ma_ho_so,trang_thai
                     FROM dang_ky_ho_so_phong_van
                     WHERE nguoi_lao_dong_id IN (
                         SELECT id FROM nguoi_lao_dong
                         WHERE so_dien_thoai=? LIMIT 1
                     )
                     AND tin_tuyen_dung_id=?
                     AND trang_thai<>"da_huy"
                     ORDER BY id DESC
                     LIMIT 1
                     FOR UPDATE'
                );
                $q->execute([$phone,$jobId]);
            }

            $existing=$q->fetch();

            if($existing)
                Response::error(
                    'Số điện thoại này đã đăng ký hồ sơ cho Tin tuyển dụng này.',
                    409
                );

            /*
             * Tìm Người lao động theo Số điện thoại.
             * Nếu chưa có thì tạo mới.
             */
            if($authenticatedWorkerId){
                $q=$this->db->prepare(
                    'SELECT *
                     FROM nguoi_lao_dong
                     WHERE id=?
                     LIMIT 1
                     FOR UPDATE'
                );
                $q->execute([$authenticatedWorkerId]);
            }else{
                $q=$this->db->prepare(
                    'SELECT *
                     FROM nguoi_lao_dong
                     WHERE so_dien_thoai=?
                     LIMIT 1
                     FOR UPDATE'
                );
                $q->execute([$phone]);
            }
            $worker=$q->fetch();

            if($worker){

                $workerId=(int)$worker['id'];

                if($worker['trang_thai']!=='hoat_dong')
                    Response::error(
                        'Tài khoản Người lao động hiện không hoạt động.',
                        403
                    );

            }else{

                $workerCode='LD'.date('YmdHis').bin2hex(random_bytes(3));

                $q=$this->db->prepare(
                    'INSERT INTO nguoi_lao_dong
                     (
                        ma_nguoi_lao_dong,
                        ho_ten,
                        so_dien_thoai,
                        que_quan,
                        lan_hoat_dong_cuoi
                     )
                     VALUES (?,?,?,?,NOW())'
                );

                $q->execute([
                    $workerCode,
                    $hoTen,
                    $phone,
                    $queQuan
                ]);

                $workerId=(int)$this->db->lastInsertId();
            }

            /*
             * Mã hồ sơ phải duy nhất trên toàn hệ thống.
             */
            do{

                $maHoSo='HS'.date('YmdHis').bin2hex(random_bytes(3));

                $q=$this->db->prepare(
                    'SELECT id
                     FROM dang_ky_ho_so_phong_van
                     WHERE ma_ho_so=?
                     LIMIT 1'
                );

                $q->execute([$maHoSo]);

            }while($q->fetch());

            /*
             * Tạo Đăng ký hồ sơ.
             *
             * Ngay khi tạo:
             * - trạng thái = da_mo_so
             * - được cấp quyền xem số Nhà cung ứng
             * - ghi nhận thời điểm mở số.
             */
            $q=$this->db->prepare(
                'INSERT INTO dang_ky_ho_so_phong_van
                 (
                    ma_ho_so,
                    nguoi_lao_dong_id,
                    nha_cung_ung_id,
                    tin_tuyen_dung_id,
                    ho_ten,
                    so_dien_thoai,
                    que_quan,
                    da_mo_so_dien_thoai,
                    thoi_gian_mo_so,
                    trang_thai
                 )
                 VALUES (?,?,?,?,?,?,?,1,NOW(),"da_mo_so")'
            );

            $q->execute([
                $maHoSo,
                $workerId,
                $job['nha_cung_ung_id'],
                $jobId,
                $hoTen,
                $phone,
                $queQuan
            ]);

            $registrationId=(int)$this->db->lastInsertId();

            /*
             * Ghi Timeline ngay khi đăng ký thành công.
             */
            $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                 (
                    dang_ky_ho_so_phong_van_id,
                    nguoi_thuc_hien,
                    nguoi_thuc_hien_id,
                    hanh_dong,
                    ghi_chu
                 )
                 VALUES (?,"nguoi_lao_dong",?,"da_mo_so",?)'
            )->execute([
                $registrationId,
                $workerId,
                'Người lao động đã đăng ký hồ sơ đăng ký.'
            ]);

            /*
             * Cập nhật bộ đếm Người lao động.
             */
            $this->db->prepare(
                'UPDATE nguoi_lao_dong
                 SET tong_lan_mo_so=tong_lan_mo_so+1,
                     tong_dang_ky_ho_so_phong_van=tong_dang_ky_ho_so_phong_van+1,
                     lan_hoat_dong_cuoi=NOW(),
                     ngay_cap_nhat=NOW()
                 WHERE id=?'
            )->execute([$workerId]);

            /*
             * Cập nhật bộ đếm Nhà cung ứng.
             */
            $this->refreshSupplierCounters(
                (int)$job['nha_cung_ung_id']
            );

            /*
             * Audit.
             */
            $this->audit->log(
                'nguoi_lao_dong',
                $workerId,
                $registrationId,
                'dang_ky_ho_so_phong_van',
                'tao_ho_so_phong_van',
                null,
                [
                    'id'=>$registrationId,
                    'ma_ho_so'=>$maHoSo,
                    'tin_tuyen_dung_id'=>$jobId,
                    'nha_cung_ung_id'=>(int)$job['nha_cung_ung_id'],
                    'trang_thai'=>'da_mo_so'
                ]
            );

            /*
             * Thông báo cho Nhà cung ứng.
             */
            $this->notify->supplier(
                (int)$job['nha_cung_ung_id'],
                'Có hồ sơ đăng ký mới',
                'Tin '.$job['ma_tin'].' vừa nhận một hồ sơ mới. Mã hồ sơ '.$maHoSo.'.',
                'ho_so_moi',
                $registrationId
            );

            $this->db->commit();

            $sms=null;
            try {
                $smsService=new \LaborPlatform\Services\SupplierCommunicationService($this->db, $this->queue);
                $sms=$smsService->sendInitialSms($registrationId);
            } catch(\Throwable $smsError) {
                $sms=['trang_thai'=>'that_bai','loi'=>$smsError->getMessage()];
                $this->audit->log(
                    'he_thong',null,$registrationId,'lien_he_tu_dong_nguoi_lao_dong','sms_that_bai',null,$sms
                );
            }

            Response::ok(
                [
                    'id'=>$registrationId,
                    'ma_ho_so'=>$maHoSo,
                    'so_dien_thoai_nha_cung_ung'=>PhoneMaskService::mask($job['so_dien_thoai_nha_cung_ung']),
                    'ten_nha_cung_ung'=>$job['ten_nha_cung_ung'],
                    'trang_thai'=>'da_mo_so',
                    'sms_tu_dong'=>$sms ? ['trang_thai'=>$sms['trang_thai']??null] : null
                ],
                'Đăng ký hồ sơ thành công.'
            );

        }catch(\Throwable $e){

            if($this->db->inTransaction())
                $this->db->rollBack();

            if($e instanceof \RuntimeException)
                throw $e;

            Response::error(
                'Không thể đăng ký hồ sơ đăng ký.',
                500
            );
        }
    }
    public function acknowledge(int $id): never {
        $sid=Auth::supplierId();
        $this->db->beginTransaction();
        try{
            $old=$this->getOwnedForUpdate($id,$sid);
            try {
                $this->workflow->assertTransition((string)$old['trang_thai'], 'da_xem');
            } catch (\RuntimeException $e) {
                Response::error('Đăng ký hồ sơ này đã được tiếp nhận hoặc xử lý.',409);
            }

            $this->db->prepare(
                'UPDATE dang_ky_ho_so_phong_van
                 SET trang_thai="da_xem",nha_cung_ung_xac_nhan=1,ngay_cap_nhat=NOW()
                 WHERE id=?'
            )->execute([$id]);

            $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                 (dang_ky_ho_so_phong_van_id,nguoi_thuc_hien,nguoi_thuc_hien_id,hanh_dong,ghi_chu)
                 VALUES (?,"nha_cung_ung",?,"da_xem",?)'
            )->execute([$id,$sid,'Nhà cung ứng đã tiếp nhận Đăng ký hồ sơ.']);

            $this->audit->log(
                'nha_cung_ung',$sid,$id,'dang_ky_ho_so_phong_van',
                'tiep_nhan',$old,['trang_thai'=>'da_xem']
            );
            $this->notify->supplier(
                $sid,'Đã tiếp nhận Đăng ký hồ sơ',
                'Hồ sơ '.$old['ma_ho_so'].' đã được tiếp nhận.',
                'cap_nhat_trang_thai',$id
            );

            $this->db->commit();

            $this->workerEvents->applicationStatusChanged(
                (int)$old['nguoi_lao_dong_id'],
                $id,
                'da_xem',
                'Hồ sơ '.$old['ma_ho_so'].' đã được Nhà cung ứng tiếp nhận.',
                (string)$old['ma_ho_so']
            );

            Response::ok(null,'Đã tiếp nhận Đăng ký hồ sơ.');
        }catch(\Throwable $e){
            if($this->db->inTransaction())$this->db->rollBack();
            if($e instanceof \RuntimeException)throw $e;
            Response::error('Không thể tiếp nhận hồ sơ.',500);
        }
    }
        public function contact(int $id): never {
        $sid=Auth::supplierId();
        $b=Request::body();

        $this->db->beginTransaction();
        try{
            $old=$this->getOwnedForUpdate($id,$sid);

            if(!in_array($old['trang_thai'],['da_xem','da_lien_he','khong_lien_he_duoc'],true))
                Response::error('Hồ sơ chưa ở trạng thái có thể ghi nhận liên hệ.',409);

            if((int)($old['nguoi_lao_dong_da_phan_hoi']??0)!==1)
                Response::error('Người lao động chưa phản hồi SMS đầu tiên. Nhà cung ứng chưa được liên hệ trực tiếp.',409);

            $contactType=(string)($b['loai_lien_he']??'');
            $result=(string)($b['ket_qua']??'');
            $note=trim((string)($b['ghi_chu']??''));

            if(!in_array($contactType,['dien_thoai','zalo','truc_tiep','khac'],true))
                Response::error('Loại liên hệ không hợp lệ.');

            if(!in_array($result,['da_lien_he','khong_lien_he_duoc'],true))
                Response::error('Kết quả liên hệ không hợp lệ.');

            if($result==='khong_lien_he_duoc')
                $newStatus='khong_lien_he_duoc';
            else
                $newStatus='da_lien_he';

            try {
                $this->workflow->assertTransition((string)$old['trang_thai'], $newStatus);
            } catch (\RuntimeException $e) {
                Response::error($e->getMessage(), 409);
            }

            $this->db->prepare(
                'INSERT INTO lien_he_dang_ky_ho_so_phong_van
                 (dang_ky_ho_so_phong_van_id,
                  nha_cung_ung_id,
                  loai_lien_he,
                  ket_qua,
                  ghi_chu,
                  thoi_gian_lien_he)
                 VALUES (?,?,?,?,?,NOW())'
            )->execute([
                $id,
                $sid,
                $contactType,
                $result,
                $note?:null
            ]);

            $this->db->prepare(
                'UPDATE dang_ky_ho_so_phong_van
                 SET trang_thai=?,
                     nha_cung_ung_xac_nhan=1,
                     ngay_cap_nhat=NOW()
                 WHERE id=? AND nha_cung_ung_id=?'
            )->execute([
                $newStatus,
                $id,
                $sid
            ]);

            $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                 (dang_ky_ho_so_phong_van_id,
                  nguoi_thuc_hien,
                  nguoi_thuc_hien_id,
                  hanh_dong,
                  ghi_chu)
                 VALUES (?,"nha_cung_ung",?,?,?)'
            )->execute([
                $id,
                $sid,
                $newStatus,
                $note?:null
            ]);

            $after=$this->getOwned($id,$sid);

            $contact=$this->db->prepare(
                'SELECT * FROM lien_he_dang_ky_ho_so_phong_van
                 WHERE dang_ky_ho_so_phong_van_id=?
                 ORDER BY id DESC LIMIT 1'
            );
            $contact->execute([$id]);
            $contactRow=$contact->fetch();

            $this->audit->log(
                'nha_cung_ung',
                $sid,
                $id,
                'lien_he_dang_ky_ho_so_phong_van',
                'ghi_nhan_lien_he',
                $old,
                [
                    'ho_so'=>$after,
                    'lien_he'=>$contactRow
                ]
            );

            $this->refreshSupplierCounters($sid);
            $this->db->commit();

            if($newStatus!==$old['trang_thai']){
                $this->workerEvents->applicationStatusChanged(
                    (int)$old['nguoi_lao_dong_id'],
                    $id,
                    $newStatus,
                    'Hồ sơ '.$old['ma_ho_so'].' đã chuyển sang '.$newStatus.'.',
                    (string)$old['ma_ho_so']
                );
            }

            Response::ok([
                'trang_thai'=>$newStatus
            ],'Đã ghi nhận lần liên hệ.');

        }catch(\Throwable $e){
            if($this->db->inTransaction())
                $this->db->rollBack();

            if($e instanceof \RuntimeException)
                throw $e;

            Response::error('Không thể ghi nhận liên hệ.',500);
        }
        }
        public function workerLookup(): never {

        $b=Request::body();

        $phone=trim(
            (string)($b['so_dien_thoai']??'')
        );

        $code=trim(
            (string)($b['ma_ho_so']??'')
        );

        if($phone===''||$code==='')
            Response::error(
                'Vui lòng nhập Số điện thoại và Mã hồ sơ.'
            );

        $q=$this->db->prepare(
            'SELECT h.id,h.ma_ho_so,h.ho_ten,h.que_quan,h.trang_thai,h.ngay_tao,h.ngay_cap_nhat,
                    h.nha_cung_ung_xac_nhan,h.nguoi_lao_dong_xac_nhan,
                    t.ma_tin,t.tieu_de,t.dia_diem,
                    n.ten_nha_cung_ung
             FROM dang_ky_ho_so_phong_van h
             JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id
             JOIN nha_cung_ung n ON n.id=h.nha_cung_ung_id
             WHERE h.so_dien_thoai=? AND h.ma_ho_so=? LIMIT 1'
        );

        $q->execute([
            $phone,
            $code
        ]);

        $row=$q->fetch();

        if(!$row)
            Response::error(
                'Không tìm thấy Đăng ký hồ sơ. Kiểm tra lại thông tin.',
                404
            );

        $q=$this->db->prepare(
            'SELECT hanh_dong,ghi_chu,thoi_gian
             FROM qua_trinh_dang_ky_ho_so_phong_van
             WHERE dang_ky_ho_so_phong_van_id=?
             ORDER BY thoi_gian ASC,id ASC'
        );

        $q->execute([
            (int)$row['id']
        ]);

        $row['timeline']=$q->fetchAll();


        Response::ok($row);
    }

    public function workerCancel(int $id): never {

        $b=Request::body();

        $phone=trim(
            (string)($b['so_dien_thoai']??'')
        );

        $code=trim(
            (string)($b['ma_ho_so']??'')
        );

        $reason=trim(
            (string)($b['ly_do']??'')
        );

        if(
            $phone===''||
            $code===''||
            $reason===''
        )
            Response::error(
                'Vui lòng nhập Số điện thoại, Mã hồ sơ và lý do hủy.'
            );

        $this->db->beginTransaction();

        try{

            $q=$this->db->prepare(
                'SELECT * FROM dang_ky_ho_so_phong_van
                 WHERE id=? AND so_dien_thoai=? AND ma_ho_so=? LIMIT 1 FOR UPDATE'
            );

            $q->execute([
                $id,
                $phone,
                $code
            ]);

            $old=$q->fetch();

            if(!$old)
                Response::error(
                    'Không tìm thấy Đăng ký hồ sơ.',
                    404
                );

            try {
                $this->workflow->assertTransition((string)$old['trang_thai'], 'da_huy');
            } catch (\RuntimeException $e) {
                Response::error('Hồ sơ đã đi qua giai đoạn không thể tự hủy.', 409);
            }

            $this->db->prepare(
                'UPDATE dang_ky_ho_so_phong_van
                 SET trang_thai="da_huy",
                     nguoi_lao_dong_xac_nhan=1,
                     ghi_chu=?,
                     ngay_cap_nhat=NOW()
                 WHERE id=?'
            )->execute([
                $reason,
                $id
            ]);

            $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                 (dang_ky_ho_so_phong_van_id,nguoi_thuc_hien,nguoi_thuc_hien_id,hanh_dong,ghi_chu)
                 VALUES (?,"nguoi_lao_dong",?, "da_huy",?)'
            )->execute([
                $id,
                $old['nguoi_lao_dong_id'],
                $reason
            ]);

            $this->audit->log(
                'nguoi_lao_dong',
                (int)$old['nguoi_lao_dong_id'],
                $id,
                'dang_ky_ho_so_phong_van',
                'nguoi_lao_dong_huy',
                $old,
                [
                    'trang_thai'=>'da_huy',
                    'ly_do'=>$reason
                ]
            );

            $this->notify->supplier(
                (int)$old['nha_cung_ung_id'],
                'Người lao động đã hủy Đăng ký hồ sơ',
                'Hồ sơ '.$old['ma_ho_so'].' đã được hủy.',
                'cap_nhat_trang_thai',
                $id
            );

            $this->db->commit();

            Response::ok(
                ['trang_thai'=>'da_huy'],
                'Đã hủy Đăng ký hồ sơ.'
            );

        }catch(\Throwable $e){

            if($this->db->inTransaction())
                $this->db->rollBack();

            if($e instanceof \RuntimeException)
                throw $e;

            Response::error(
                'Không thể hủy Đăng ký hồ sơ.',
                500
            );
        }
    }
    private function refreshSupplierCounters(int $sid): void {

        $this->db->prepare(
            'UPDATE nha_cung_ung n SET
             tong_dang_ky_ho_so_phong_van=(SELECT COUNT(*) FROM dang_ky_ho_so_phong_van h WHERE h.nha_cung_ung_id=n.id),
             tong_lien_he=(SELECT COUNT(*) FROM dang_ky_ho_so_phong_van h WHERE h.nha_cung_ung_id=n.id AND h.trang_thai="da_lien_he"),
             tong_khong_phu_hop=(SELECT COUNT(*) FROM dang_ky_ho_so_phong_van h WHERE h.nha_cung_ung_id=n.id AND h.trang_thai="khong_phu_hop"),
             tong_huy=(SELECT COUNT(*) FROM dang_ky_ho_so_phong_van h WHERE h.nha_cung_ung_id=n.id AND h.trang_thai="da_huy")
             WHERE n.id=?'
        )->execute([$sid]);
    }

    public function status(int $id): never {
        $sid=Auth::supplierId();
        $b=Request::body();
        $status=(string)($b['trang_thai']??'');
        $note=trim((string)($b['ghi_chu']??''));

        $allowedStatuses=['da_xem','da_lien_he','khong_lien_he_duoc','da_huy'];
        if(!in_array($status,$allowedStatuses,true))
            Response::error('Trạng thái Đăng ký hồ sơ không hợp lệ.');

        $this->db->beginTransaction();

        try{

            $old=$this->getOwnedForUpdate($id,$sid);

            try {
                $this->workflow->assertTransition((string)$old['trang_thai'], $status);
            } catch (\RuntimeException $e) {
                Response::error($e->getMessage(), 409);
            }

            $this->db->prepare(
                'UPDATE dang_ky_ho_so_phong_van
                 SET trang_thai=?,
                     nha_cung_ung_xac_nhan=1,
                     ngay_cap_nhat=NOW()
                 WHERE id=? AND nha_cung_ung_id=?'
            )->execute([
                $status,
                $id,
                $sid
            ]);

            $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                 (dang_ky_ho_so_phong_van_id,
                  nguoi_thuc_hien,
                  nguoi_thuc_hien_id,
                  hanh_dong,
                  ghi_chu)
                 VALUES (?,"nha_cung_ung",?,?,?)'
            )->execute([
                $id,
                $sid,
                $status,
                $note?:null
            ]);

            $after=$this->getOwned($id,$sid);

            $this->audit->log(
                'nha_cung_ung',
                $sid,
                $id,
                'dang_ky_ho_so_phong_van',
                'cap_nhat_trang_thai',
                $old,
                [
                    'ho_so'=>$after,
                    'ghi_chu'=>$note
                ]
            );

            $this->refreshSupplierCounters(
                $sid
            );

            $this->notify->supplier(
                $sid,
                'Đã cập nhật Đăng ký hồ sơ',
                'Hồ sơ '.$old['ma_ho_so'].
                ' đã chuyển sang '.
                $status.'.',
                'cap_nhat_trang_thai',
                $id
            );

            $this->db->commit();

            $this->workerEvents->applicationStatusChanged(
                (int)$old['nguoi_lao_dong_id'],
                $id,
                $status,
                'Hồ sơ '.$old['ma_ho_so'].' đã chuyển sang '.$status.'.',
                (string)$old['ma_ho_so']
            );

            Response::ok(
                [
                    'id'=>$id,
                    'trang_thai'=>$status
                ],
                'Đã cập nhật trạng thái Đăng ký hồ sơ.'
            );

        }catch(\Throwable $e){

            if($this->db->inTransaction())
                $this->db->rollBack();

            if($e instanceof \RuntimeException)
                throw $e;

            Response::error(
                'Không thể cập nhật trạng thái Đăng ký hồ sơ.',
                500
            );
        }
    }
}
