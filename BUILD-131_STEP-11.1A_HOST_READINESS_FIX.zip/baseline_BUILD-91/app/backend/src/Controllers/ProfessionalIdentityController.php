<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Auth,Request,Response,WorkerAuth};
use LaborPlatform\Services\AuditService;

final class ProfessionalIdentityController {
    public function __construct(private \PDO $db, private AuditService $audit) {}

    public function worker(): never {
        $id=WorkerAuth::workerId($this->db);
        $this->workerResponse($id,true);
    }

    public function workerPublic(int $id): never { $this->workerResponse($id,false); }

    private function workerResponse(int $id,bool $private): never {
        $q=$this->db->prepare('SELECT n.id,n.ma_nguoi_lao_dong,n.ho_ten,n.trang_thai,p.occupation,p.skills,p.experience,p.education,p.avatar_url,p.bio,p.desired_position,p.desired_location,p.desired_salary,p.province,p.district FROM nguoi_lao_dong n LEFT JOIN ho_so_nghe_nghiep_nguoi_lao_dong p ON p.nguoi_lao_dong_id=n.id WHERE n.id=? LIMIT 1');
        $q->execute([$id]);$worker=$q->fetch();if(!$worker)Response::error('Không tìm thấy hồ sơ nghề nghiệp.',404);
        if($worker['trang_thai']!=='hoat_dong')Response::error('Hồ sơ nghề nghiệp không khả dụng.',404);
        $q=$this->db->prepare('SELECT id,ten_chung_chi,don_vi_cap,nam_cap,mo_ta,tep_dinh_kem_url FROM ho_so_nghe_nghiep_chung_chi WHERE nguoi_lao_dong_id=? AND trang_thai="hien_thi" ORDER BY nam_cap DESC,id DESC');$q->execute([$id]);$certs=$q->fetchAll();
        $q=$this->db->prepare('SELECT id,ten_cong_viec,ten_don_vi,tu_thang,den_thang,mo_ta FROM ho_so_nghe_nghiep_kinh_nghiem WHERE nguoi_lao_dong_id=? AND trang_thai="hien_thi" ORDER BY tu_thang DESC,id DESC');$q->execute([$id]);$history=$q->fetchAll();
        $q=$this->db->prepare('SELECT COUNT(*) FROM social_bai_dang WHERE loai_tac_gia="nguoi_lao_dong" AND tac_gia_id=? AND trang_thai="cong_khai"');$q->execute([$id]);$posts=(int)$q->fetchColumn();
        $q=$this->db->prepare('SELECT COUNT(*) FROM social_theo_doi WHERE doi_tuong_type="nguoi_lao_dong" AND doi_tuong_id=? AND trang_thai="dang_theo_doi"');$q->execute([$id]);$followers=(int)$q->fetchColumn();
        $q=$this->db->prepare('SELECT COUNT(*) FROM social_theo_doi WHERE nguoi_theo_doi_type="nguoi_lao_dong" AND nguoi_theo_doi_id=? AND trang_thai="dang_theo_doi"');$q->execute([$id]);$following=(int)$q->fetchColumn();
        $ratingQ=$this->db->prepare('SELECT COUNT(*) AS total, COALESCE(AVG(rating),0) AS average FROM trust_reviews WHERE reviewee_type="worker" AND reviewee_id=? AND status="cong_khai"');$ratingQ->execute([$id]);$ratingRow=$ratingQ->fetch()?:['total'=>0,'average'=>0];$rating=['luot_danh_gia'=>(int)$ratingRow['total'],'diem_danh_gia'=>(float)$ratingRow['average']];
        $fields=['occupation','skills','experience','education','bio','desired_position','desired_location','desired_salary'];$filled=0;foreach($fields as $f){if(trim((string)($worker[$f]??''))!=='')$filled++;}$filled+=count($certs)>0?1:0;$filled+=count($history)>0?1:0;$percent=(int)round(($filled/10)*100);
        if(!$private){unset($worker['trang_thai']);}
        Response::ok(['loai'=>'nguoi_lao_dong','ho_so'=>$worker,'chung_chi'=>$certs,'kinh_nghiem'=>$history,'danh_tinh'=>['muc_do_hoan_thien'=>$percent,'bai_dang'=>$posts,'nguoi_theo_doi'=>$followers,'dang_theo_doi'=>$following,'diem_danh_gia'=>round((float)$rating['diem_danh_gia'],2),'luot_danh_gia'=>(int)$rating['luot_danh_gia']],'bao_mat'=>['so_dien_thoai'=>'khong_cong_khai','thong_tin_lien_he'=>'chi_chia_se_khi_duoc_cho_phep']]);
    }

    public function updateWorker(): never {
        $id=WorkerAuth::workerId($this->db);$b=Request::body();
        $q=$this->db->prepare('INSERT INTO ho_so_nghe_nghiep_nguoi_lao_dong (nguoi_lao_dong_id,occupation,skills,experience,education,avatar_url,bio,desired_position,desired_location,desired_salary,province,district) VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE occupation=VALUES(occupation),skills=VALUES(skills),experience=VALUES(experience),education=VALUES(education),avatar_url=VALUES(avatar_url),bio=VALUES(bio),desired_position=VALUES(desired_position),desired_location=VALUES(desired_location),desired_salary=VALUES(desired_salary),province=VALUES(province),district=VALUES(district)');
        $q->execute([$id,$b['occupation']??null,$b['skills']??null,$b['experience']??null,$b['education']??null,$b['avatar_url']??null,$b['bio']??null,$b['desired_position']??null,$b['desired_location']??null,$b['desired_salary']??null,$b['province']??null,$b['district']??null]);
        $this->audit->log('nguoi_lao_dong',$id,null,'ho_so_danh_tinh','cap_nhat',null,['loai'=>'professional_identity']);$this->workerResponse($id,true);
    }

    public function addCertificate(): never { $id=WorkerAuth::workerId($this->db);$b=Request::body();$name=trim((string)($b['ten_chung_chi']??''));if($name==='')Response::error('Tên chứng chỉ không được để trống.');$q=$this->db->prepare('INSERT INTO ho_so_nghe_nghiep_chung_chi (nguoi_lao_dong_id,ten_chung_chi,don_vi_cap,nam_cap,mo_ta,tep_dinh_kem_url) VALUES (?,?,?,?,?,?)');$q->execute([$id,$name,$b['don_vi_cap']??null,$b['nam_cap']??null,$b['mo_ta']??null,$b['tep_dinh_kem_url']??null]);$this->audit->log('nguoi_lao_dong',$id,null,'ho_so_nghe_nghiep_chung_chi','them',null,['id'=>(int)$this->db->lastInsertId()]);Response::ok(null,'Đã thêm chứng chỉ.'); }
    public function addExperience(): never { $id=WorkerAuth::workerId($this->db);$b=Request::body();$job=trim((string)($b['ten_cong_viec']??''));if($job==='')Response::error('Tên công việc không được để trống.');$q=$this->db->prepare('INSERT INTO ho_so_nghe_nghiep_kinh_nghiem (nguoi_lao_dong_id,ten_cong_viec,ten_don_vi,tu_thang,den_thang,mo_ta) VALUES (?,?,?,?,?,?)');$q->execute([$id,$job,$b['ten_don_vi']??null,$b['tu_thang']??null,$b['den_thang']??null,$b['mo_ta']??null]);$this->audit->log('nguoi_lao_dong',$id,null,'ho_so_nghe_nghiep_kinh_nghiem','them',null,['id'=>(int)$this->db->lastInsertId()]);Response::ok(null,'Đã thêm kinh nghiệm.'); }

    public function employer(): never { $id=Auth::supplierId();$this->employerResponse($id,true); }
    public function employerPublic(int $id): never { $this->employerResponse($id,false); }
    private function employerResponse(int $id,bool $private): never {
        $q=$this->db->prepare('SELECT id,ma_nha_cung_ung,ten_don_vi,loai_don_vi,ma_so_thue,nguoi_dai_dien,email,dia_chi,logo,gioi_thieu,giay_phep,xac_minh,ngay_xac_minh,diem_minh_bach,tong_tin_tuyen_dung,ti_le_phan_hoi FROM nha_cung_ung WHERE id=? LIMIT 1');$q->execute([$id]);$employer=$q->fetch();if(!$employer)Response::error('Không tìm thấy hồ sơ đơn vị.',404);
        $q=$this->db->prepare('SELECT linh_vuc,quy_mo,website,moi_truong_lam_viec,gioi_thieu_tuyen_dung,phuc_loi_tong_quat,video_gioi_thieu_url FROM ho_so_danh_tinh_nha_su_dung_lao_dong WHERE nha_cung_ung_id=? LIMIT 1');$q->execute([$id]);$extra=$q->fetch()?:[];
        if($private){
            $rating=['luot_danh_gia'=>0,'diem_danh_gia'=>0];
        } else {
            $ratingQ=$this->db->prepare('SELECT COUNT(*) AS total, COALESCE(AVG(rating),0) AS average FROM trust_reviews WHERE reviewee_type="employer" AND reviewee_id=? AND status="cong_khai"');
            $ratingQ->execute([$id]);
            $ratingRow=$ratingQ->fetch()?:['total'=>0,'average'=>0];
            $rating=['luot_danh_gia'=>(int)$ratingRow['total'],'diem_danh_gia'=>(float)$ratingRow['average']];
        }
        $q=$this->db->prepare('SELECT COUNT(*) FROM social_theo_doi WHERE doi_tuong_type="nha_cung_ung" AND doi_tuong_id=? AND trang_thai="dang_theo_doi"');$q->execute([$id]);$followers=(int)$q->fetchColumn();
        $fields=['linh_vuc','quy_mo','website','moi_truong_lam_viec','gioi_thieu_tuyen_dung','phuc_loi_tong_quat'];$filled=0;foreach($fields as $f){if(trim((string)($extra[$f]??''))!=='')$filled++;}$filled+=($employer['logo']?'1':'0');$percent=(int)round(($filled/7)*100);
        unset($employer['ma_so_thue'],$employer['email'],$employer['dia_chi'],$employer['nguoi_dai_dien']);
        Response::ok(['loai'=>'nha_su_dung_lao_dong','ho_so'=>array_merge($employer,$extra),'danh_tieng'=>['xac_minh'=>$employer['xac_minh'],'diem_minh_bach'=>(float)$employer['diem_minh_bach'],'diem_danh_gia'=>round((float)$rating['diem_danh_gia'],2),'luot_danh_gia'=>(int)$rating['luot_danh_gia'],'nguoi_theo_doi'=>$followers,'ti_le_phan_hoi'=>(float)$employer['ti_le_phan_hoi']], 'muc_do_hoan_thien'=>$percent,'bao_mat'=>['thong_tin_lien_he'=>'khong_cong_khai_tren_ho_so_cong_khai']]);
    }
    public function updateEmployer(): never { $id=Auth::supplierId();$b=Request::body();$q=$this->db->prepare('INSERT INTO ho_so_danh_tinh_nha_su_dung_lao_dong (nha_cung_ung_id,linh_vuc,quy_mo,website,moi_truong_lam_viec,gioi_thieu_tuyen_dung,phuc_loi_tong_quat,video_gioi_thieu_url) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE linh_vuc=VALUES(linh_vuc),quy_mo=VALUES(quy_mo),website=VALUES(website),moi_truong_lam_viec=VALUES(moi_truong_lam_viec),gioi_thieu_tuyen_dung=VALUES(gioi_thieu_tuyen_dung),phuc_loi_tong_quat=VALUES(phuc_loi_tong_quat),video_gioi_thieu_url=VALUES(video_gioi_thieu_url)');$q->execute([$id,$b['linh_vuc']??null,$b['quy_mo']??null,$b['website']??null,$b['moi_truong_lam_viec']??null,$b['gioi_thieu_tuyen_dung']??null,$b['phuc_loi_tong_quat']??null,$b['video_gioi_thieu_url']??null]);$this->audit->log('nha_cung_ung',$id,null,'ho_so_danh_tinh','cap_nhat',null,['loai'=>'professional_identity']);$this->employerResponse($id,true); }
}
