<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentSearchService;

final class ContentSearchController
{
    public function __construct(private ContentSearchService $search) {}

    public function publicJobs(): never
    {
        try {
            Response::ok($this->search->searchPublicJobs($_GET));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\Throwable $e) {
            Response::error('Không thể thực hiện tìm kiếm.', 500);
        }
    }

    public function warm(array $config): never
    {
        $expected=(string)($config['content_discovery_warm']['token']??'');
        $provided=trim((string)($_SERVER['HTTP_X_LABOR_WARM_TOKEN']??''));
        if($expected==='' || $provided==='' || !hash_equals($expected,$provided)) { Response::error('Không được phép.',403); }
        try {
            $result=$this->search->warmLocationSnapshots(['Tất cả','Hà Nội','TP.HCM','Đà Nẵng']);
            Response::ok($result);
        } catch (\Throwable $e) {
            Response::error('Không thể warm Content Discovery.',500);
        }
    }
}
