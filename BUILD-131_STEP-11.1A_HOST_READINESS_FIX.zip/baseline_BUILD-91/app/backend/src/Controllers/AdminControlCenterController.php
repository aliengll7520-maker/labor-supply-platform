<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{AdminAuth,Response};

final class AdminControlCenterController {
    public function __construct(private \PDO $db) {}

    public function csrf(): never {
        $token=AdminAuth::csrfToken();
        Response::ok(['token'=>$token]);
    }

    public function permissions(): never {
        $id=AdminAuth::accountId();
        $q=$this->db->prepare('SELECT id,ten_dang_nhap,email,ho_ten,vai_tro,trang_thai,lan_dang_nhap_cuoi FROM tai_khoan_quan_tri WHERE id=? LIMIT 1');
        $q->execute([$id]);
        Response::ok(['tai_khoan'=>$q->fetch(),'quyen'=>AdminAuth::permissions()]);
    }

    public function users(): never {
        AdminAuth::requirePermission('users.view');
        $workers=(int)$this->db->query('SELECT COUNT(*) FROM nguoi_lao_dong')->fetchColumn();
        $suppliers=(int)$this->db->query('SELECT COUNT(*) FROM nha_cung_ung')->fetchColumn();
        $activeWorkers=(int)$this->db->query('SELECT COUNT(*) FROM tai_khoan_nguoi_lao_dong WHERE trang_thai="hoat_dong"')->fetchColumn();
        Response::ok(['nguoi_lao_dong'=>$workers,'don_vi_su_dung_lao_dong'=>$suppliers,'tai_khoan_nguoi_lao_dong_hoat_dong'=>$activeWorkers]);
    }


    public function unions(): never {
        AdminAuth::requirePermission('unions.view');
        $q=$this->db->query('SELECT id,ten_nha_cung_ung,cong_doan_trang_thai,cong_doan_ten,cong_doan_lien_he FROM nha_cung_ung ORDER BY id DESC LIMIT 200');
        Response::ok(['cong_doan'=>$q->fetchAll()]);
    }

    public function security(): never {
        AdminAuth::requirePermission('security.view');
        $exists=(int)$this->db->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='bao_mat_su_kien'")->fetchColumn();
        $rows=[]; if($exists){$rows=$this->db->query('SELECT * FROM bao_mat_su_kien ORDER BY id DESC LIMIT 100')->fetchAll();}
        Response::ok(['su_kien'=>$rows]);
    }

    public function system(): never {
        AdminAuth::requirePermission('system.view');
        $this->db->query('SELECT 1');
        $config = require __DIR__ . '/../../config/config.php';
        Response::ok([
            'database'=>'ready',
            'php'=>PHP_VERSION,
            'source_version'=>$config['app']['source_version'],
            'release_id'=>$config['app']['release_id'],
            'build_id'=>$config['app']['build_id'],
            'time'=>date('c')
        ]);
    }
}
