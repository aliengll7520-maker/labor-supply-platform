<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Auth,Response,WorkerAuth};
use LaborPlatform\Services\{IdentityService,IdentityOnboardingService};
final class IdentityOnboardingController {
    public function __construct(private \PDO $db,private IdentityService $identity,private IdentityOnboardingService $onboarding) {}
    public function me(): never {
        $header=$_SERVER['HTTP_AUTHORIZATION']??'';
        if(preg_match('/^Bearer\s+(.+)$/i',$header)){
            $workerId=WorkerAuth::workerId(false); if($workerId>0){$id=$this->identity->syncWorker($workerId); Response::ok($this->onboarding->refresh($id));}
        }
        $sid=Auth::supplierId(false);$aid=Auth::accountId(); if($sid<=0||$aid<=0)Response::error('Chưa đăng nhập.',401);
        $id=$this->identity->syncEmployerAccount($aid,$sid); Response::ok($this->onboarding->refresh($id));
    }
}
