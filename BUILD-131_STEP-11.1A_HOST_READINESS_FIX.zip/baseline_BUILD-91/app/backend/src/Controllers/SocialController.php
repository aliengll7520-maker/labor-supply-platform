<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,Request,Response,WorkerAuth,AdminAuth};
use LaborPlatform\Services\{AuditService,NotificationService};
use LaborPlatform\Queue\QueueService;

final class SocialController {
    public function __construct(private \PDO $db, private AuditService $audit, private NotificationService $notify, private QueueService $queue) {}

    private function actor(bool $required=true): ?array {
        $header=$_SERVER['HTTP_AUTHORIZATION']??'';
        if(preg_match('/^Bearer\s+(.+)$/i',$header)) {
            $id=WorkerAuth::workerId($this->db,false);
            if($id>0) return ['type'=>'nguoi_lao_dong','id'=>$id];
        }
        $accountId=Auth::accountId();
        if($accountId>0) {
            $sid=Auth::supplierId(true);
            if($sid>0) return ['type'=>'nha_cung_ung','id'=>$sid];
        }
        if($required) Response::error('Chưa đăng nhập.',401);
        return null;
    }

    private function maxPostImages(): int {
        try {
            $q=$this->db->query("SELECT gia_tri FROM cau_hinh_he_thong WHERE ma_cau_hinh='social_post_max_images' AND trang_thai='bat' LIMIT 1");
            $value=(int)$q->fetchColumn();
            return max(1,min(6,$value ?: 6));
        } catch (\Throwable) { return 6; }
    }

    private function authorName(string $type,int $id): string {
        if($type==='nguoi_lao_dong') {
            $q=$this->db->prepare('SELECT ho_ten FROM nguoi_lao_dong WHERE id=? LIMIT 1');
            $q->execute([$id]); return (string)($q->fetchColumn() ?: 'Người lao động');
        }
        $q=$this->db->prepare('SELECT COALESCE(NULLIF(ten_don_vi,""),ten_nha_cung_ung) FROM nha_cung_ung WHERE id=? LIMIT 1');
        $q->execute([$id]); return (string)($q->fetchColumn() ?: 'Đơn vị sử dụng lao động');
    }

    private function isBlocked(string $viewerType,int $viewerId,string $targetType,int $targetId): bool {
        $q=$this->db->prepare('SELECT id FROM social_chan WHERE nguoi_chan_type=? AND nguoi_chan_id=? AND doi_tuong_type=? AND doi_tuong_id=? AND trang_thai="dang_chan" LIMIT 1');
        $q->execute([$viewerType,$viewerId,$targetType,$targetId]);
        if($q->fetch()) return true;
        $q=$this->db->prepare('SELECT id FROM social_chan WHERE nguoi_chan_type=? AND nguoi_chan_id=? AND doi_tuong_type=? AND doi_tuong_id=? AND trang_thai="dang_chan" LIMIT 1');
        $q->execute([$targetType,$targetId,$viewerType,$viewerId]);
        return (bool)$q->fetch();
    }

    public function feed(): never {
        $actor=$this->actor(false);
        $limit=min(max((int)($_GET['limit']??20),1),50);
        $cursorRaw=trim((string)($_GET['cursor']??''));
        $cursorFollow=null;
        $cursorId=0;
        if($cursorRaw!==''){
            $decoded=json_decode((string)base64_decode(strtr($cursorRaw,'-_','+/')),true);
            if(is_array($decoded)&&isset($decoded['f'],$decoded['id'])){
                // Personalized {f,id} cursors are meaningful only for authenticated Feed.
                // For public Feed, safely fall back to the stable post id cursor.
                $cursorId=max((int)$decoded['id'],0);
                if($actor) $cursorFollow=(int)$decoded['f'];
            } elseif(ctype_digit($cursorRaw)) {
                $cursorId=(int)$cursorRaw;
            }
        }

        $where=['s.trang_thai="cong_khai"'];
        $params=[];
        $likeSelect='0 AS da_thich';
        $followSelect='0 AS dang_theo_doi';
        $joins='';
        if($actor) {
            $where[]='NOT EXISTS (SELECT 1 FROM social_chan b WHERE b.trang_thai="dang_chan" AND ((b.nguoi_chan_type=? AND b.nguoi_chan_id=? AND b.doi_tuong_type=s.loai_tac_gia AND b.doi_tuong_id=s.tac_gia_id) OR (b.nguoi_chan_type=s.loai_tac_gia AND b.nguoi_chan_id=s.tac_gia_id AND b.doi_tuong_type=? AND b.doi_tuong_id=?)))';
            $joins.=' LEFT JOIN social_thich l ON l.bai_dang_id=s.id AND l.tac_gia_type=? AND l.tac_gia_id=?';
            $joins.=' LEFT JOIN social_theo_doi f ON f.nguoi_theo_doi_type=? AND f.nguoi_theo_doi_id=? AND f.doi_tuong_type=s.loai_tac_gia AND f.doi_tuong_id=s.tac_gia_id AND f.trang_thai="dang_theo_doi"';
            $likeSelect='CASE WHEN l.id IS NULL THEN 0 ELSE 1 END AS da_thich';
            $followSelect='CASE WHEN f.id IS NULL THEN 0 ELSE 1 END AS dang_theo_doi';
            $params=[$actor['type'],$actor['id'],$actor['type'],$actor['id'],$actor['type'],$actor['id'],$actor['type'],$actor['id']];
        }

        if($actor && $cursorFollow!==null && $cursorId>0){
            $where[]='(CASE WHEN f.id IS NULL THEN 0 ELSE 1 END < ? OR (CASE WHEN f.id IS NULL THEN 0 ELSE 1 END = ? AND s.id < ?))';
            $params[]=$cursorFollow;$params[]=$cursorFollow;$params[]=$cursorId;
        } elseif($cursorId>0) {
            $where[]='s.id < ?';
            $params[]=$cursorId;
        }

        $sql='SELECT s.id,s.loai_tac_gia,s.tac_gia_id,s.loai_bai_dang,s.noi_dung,s.anh_urls,s.hashtag,s.luot_thich,s.luot_binh_luan,s.luot_chia_se,s.ngay_tao,s.ngay_cap_nhat,
          CASE WHEN s.loai_tac_gia="nguoi_lao_dong" THEN n.ho_ten ELSE COALESCE(NULLIF(u.ten_don_vi,""),u.ten_nha_cung_ung) END AS ten_tac_gia,
          '.$likeSelect.', '.$followSelect.'
          FROM social_bai_dang s
          LEFT JOIN nguoi_lao_dong n ON s.loai_tac_gia="nguoi_lao_dong" AND n.id=s.tac_gia_id
          LEFT JOIN nha_cung_ung u ON s.loai_tac_gia="nha_cung_ung" AND u.id=s.tac_gia_id
          '.$joins.' WHERE '.implode(' AND ',$where).'
          ORDER BY '.($actor ? '(CASE WHEN f.id IS NULL THEN 0 ELSE 1 END) DESC,s.id DESC' : 's.id DESC').' LIMIT '.$limit;

        $q=$this->db->prepare($sql);
        $q->execute($params);
        $posts=$q->fetchAll();
        $last=$posts[count($posts)-1]??null;
        $nextCursor=null;
        if(count($posts)===$limit&&$last){
            if($actor){
                $payload=json_encode(['f'=>(int)$last['dang_theo_doi'],'id'=>(int)$last['id']],JSON_UNESCAPED_SLASHES);
                $nextCursor=rtrim(strtr(base64_encode((string)$payload),'+/','-_'),'=');
            } else {
                $nextCursor=(string)(int)$last['id'];
            }
        }
        $posts=array_map(static function(array $post): array {
            $images=[];
            if(isset($post['anh_urls']) && is_string($post['anh_urls']) && $post['anh_urls']!==''){
                $decoded=json_decode($post['anh_urls'],true);
                if(is_array($decoded)){
                    $images=array_values(array_filter(array_map(static fn($u)=>trim((string)$u),$decoded),static fn($u)=>$u!==''&&filter_var($u,FILTER_VALIDATE_URL)));
                    $images=array_slice($images,0,$this->maxPostImages());
                }
            }
            $post['anh_urls']=$images;
            return $post;
        },$posts);
        Response::ok(['posts'=>$posts,'limit'=>$limit,'offset'=>0,'cursor'=>$cursorRaw,'next_cursor'=>$nextCursor,'social_core'=>true]);
    }

    public function mine(): never {
        $a=$this->actor();$q=$this->db->prepare('SELECT id,loai_bai_dang,noi_dung,hashtag,trang_thai,luot_thich,luot_binh_luan,luot_chia_se,ngay_tao,ngay_cap_nhat FROM social_bai_dang WHERE loai_tac_gia=? AND tac_gia_id=? ORDER BY id DESC');$q->execute([$a['type'],$a['id']]);Response::ok(['posts'=>$q->fetchAll()]);
    }

    public function create(): never {
        $a=$this->actor();$b=Request::body();$content=trim((string)($b['noi_dung']??''));
        \LaborPlatform\Services\ContentSafetyService::assertSafe($content,'Nội dung bài đăng');$type=(string)($b['loai_bai_dang']??'cap_nhat');$tags=trim((string)($b['hashtag']??''));$images=$b['anh_urls']??[];if(!is_array($images))$images=[];$images=array_values(array_filter(array_map(fn($u)=>trim((string)$u),$images),fn($u)=>$u!==''&&filter_var($u,FILTER_VALIDATE_URL)));$maxImages=$this->maxPostImages();if(count($images)>$maxImages)Response::error('Mỗi bài viết tối đa '.$maxImages.' ảnh.');
        $allowed=['cap_nhat','viec_lam','tim_viec','kien_thuc','hoi_dap'];
        if($content==='') Response::error('Nội dung bài đăng không được để trống.');
        if(mb_strlen($content)>5000) Response::error('Nội dung bài đăng tối đa 5000 ký tự.');
        if(!in_array($type,$allowed,true)) Response::error('Loại bài đăng không hợp lệ.');
        if(mb_strlen($tags)>1000) Response::error('Hashtag quá dài.');
        $sourceType=trim((string)($b['loai_nguon']??''));$sourceId=(int)($b['nguon_id']??0);if($sourceType!==''&&!in_array($sourceType,['tin_tuyen_dung'],true))Response::error('Nguồn bài viết không hợp lệ.');if($sourceType==='tin_tuyen_dung'&&$sourceId<=0)Response::error('Tin tuyển dụng nguồn không hợp lệ.');$q=$this->db->prepare('INSERT INTO social_bai_dang (loai_tac_gia,tac_gia_id,loai_bai_dang,loai_nguon,nguon_id,noi_dung,anh_urls,hashtag,trang_thai) VALUES (?,?,?,?,?,?,?,?,"cho_duyet")');$q->execute([$a['type'],$a['id'],$type,$sourceType?:null,$sourceId?:null,$content,$images?json_encode($images,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):null,$tags?:null]);$id=(int)$this->db->lastInsertId();
        $this->audit->log($a['type'],$a['id'],null,'social_bai_dang','tao_bai_dang',null,['id'=>$id,'loai_bai_dang'=>$type]);
        $this->queue->enqueue('moderation','moderation.social_post',['post_id'=>$id,'actor_type'=>$a['type'],'actor_id'=>$a['id']],200,'social_post:'.$id);
        Response::ok(['id'=>$id,'trang_thai'=>'cho_duyet'],'Đã nhận bài. Hệ thống đang tự động kiểm tra trước khi hiển thị.');
    }

    public function like(int $postId): never {
        $a=$this->actor();$q=$this->db->prepare('SELECT id,loai_tac_gia,tac_gia_id,trang_thai FROM social_bai_dang WHERE id=? LIMIT 1');$q->execute([$postId]);$post=$q->fetch();if(!$post||$post['trang_thai']!=='cong_khai')Response::error('Không tìm thấy bài đăng.',404);
        if($this->isBlocked($a['type'],$a['id'],$post['loai_tac_gia'],(int)$post['tac_gia_id']))Response::error('Không thể tương tác với tài khoản này.',403);
        $q=$this->db->prepare('SELECT id FROM social_thich WHERE bai_dang_id=? AND tac_gia_type=? AND tac_gia_id=? LIMIT 1');$q->execute([$postId,$a['type'],$a['id']]);
        if($q->fetch()){ $this->db->prepare('DELETE FROM social_thich WHERE bai_dang_id=? AND tac_gia_type=? AND tac_gia_id=?')->execute([$postId,$a['type'],$a['id']]);$liked=false; } else { $this->db->prepare('INSERT INTO social_thich (bai_dang_id,tac_gia_type,tac_gia_id) VALUES (?,?,?)')->execute([$postId,$a['type'],$a['id']]);$liked=true; if($post['loai_tac_gia']!==$a['type']||$post['tac_gia_id']!=$a['id']) $this->sendNotification($post,$a,'Bài đăng nhận được lượt thích','Có người vừa thích bài đăng của bạn.','social_like'); }
        $this->db->prepare('UPDATE social_bai_dang SET luot_thich=GREATEST(0,luot_thich '.($liked?'+ 1':'- 1').') WHERE id=?')->execute([$postId]);$this->audit->log($a['type'],$a['id'],null,'social_thich',$liked?'thich':'bo_thich',null,['bai_dang_id'=>$postId]);$countQ=$this->db->prepare('SELECT luot_thich FROM social_bai_dang WHERE id=?');$countQ->execute([$postId]);Response::ok(['da_thich'=>$liked,'luot_thich'=>(int)$countQ->fetchColumn()]);
    }

    public function comments(int $postId): never {
        $limit=min(max((int)($_GET['limit']??20),1),50);$cursor=max((int)($_GET['cursor']??0),0);$where='c.bai_dang_id=? AND c.trang_thai="cong_khai"';$params=[$postId];if($cursor>0){$where.=' AND c.id > ?';$params[]=$cursor;}$q=$this->db->prepare('SELECT c.id,c.bai_dang_id,c.tra_loi_cho_id,c.tac_gia_type,c.tac_gia_id,c.noi_dung,c.ngay_tao,CASE WHEN c.tac_gia_type="nguoi_lao_dong" THEN n.ho_ten ELSE COALESCE(NULLIF(u.ten_don_vi,""),u.ten_nha_cung_ung) END AS ten_tac_gia FROM social_binh_luan c LEFT JOIN nguoi_lao_dong n ON c.tac_gia_type="nguoi_lao_dong" AND n.id=c.tac_gia_id LEFT JOIN nha_cung_ung u ON c.tac_gia_type="nha_cung_ung" AND u.id=c.tac_gia_id WHERE '.$where.' ORDER BY c.id ASC LIMIT '.$limit);$q->execute($params);$comments=$q->fetchAll();$nextCursor=count($comments)===$limit?(int)$comments[count($comments)-1]['id']:null;Response::ok(['comments'=>$comments,'limit'=>$limit,'cursor'=>$cursor,'next_cursor'=>$nextCursor]);
    }

    public function comment(int $postId): never {
        $a=$this->actor();$b=Request::body();$text=trim((string)($b['noi_dung']??''));
        \LaborPlatform\Services\ContentSafetyService::assertSafe($text,'Bình luận');
        $parentId=(int)($b['tra_loi_cho_id']??0);if($text==='')Response::error('Bình luận không được để trống.');if(mb_strlen($text)>2000)Response::error('Bình luận tối đa 2000 ký tự.');
        $q=$this->db->prepare('SELECT id,loai_tac_gia,tac_gia_id,trang_thai FROM social_bai_dang WHERE id=? LIMIT 1');$q->execute([$postId]);$post=$q->fetch();if(!$post||$post['trang_thai']!=='cong_khai')Response::error('Không tìm thấy bài đăng.',404);if($this->isBlocked($a['type'],$a['id'],$post['loai_tac_gia'],(int)$post['tac_gia_id']))Response::error('Không thể bình luận bài đăng này.',403);
        if($parentId>0){$q=$this->db->prepare('SELECT id,tac_gia_type,tac_gia_id,trang_thai FROM social_binh_luan WHERE id=? AND bai_dang_id=? LIMIT 1');$q->execute([$parentId,$postId]);$parent=$q->fetch();if(!$parent||$parent['trang_thai']!=='cong_khai')Response::error('Bình luận cần trả lời không tồn tại hoặc chưa được công khai.',404);}else{$parent=null;}
        $q=$this->db->prepare('INSERT INTO social_binh_luan (bai_dang_id,tra_loi_cho_id,tac_gia_type,tac_gia_id,noi_dung,trang_thai) VALUES (?,?,?,?,?,"cho_duyet")');$q->execute([$postId,$parentId?:null,$a['type'],$a['id'],$text]);$id=(int)$this->db->lastInsertId();$this->audit->log($a['type'],$a['id'],null,'social_binh_luan','tao_binh_luan',null,['id'=>$id,'bai_dang_id'=>$postId]);
        $this->queue->enqueue('moderation','moderation.social_comment',['comment_id'=>$id,'post_id'=>$postId,'actor_type'=>$a['type'],'actor_id'=>$a['id']],150,'social_comment:'.$id);if($parent && ($parent['tac_gia_type']!==$a['type']||$parent['tac_gia_id']!=$a['id'])){$this->sendNotification(['loai_tac_gia'=>$parent['tac_gia_type'],'tac_gia_id'=>$parent['tac_gia_id']],$a,'Có người trả lời bình luận của bạn','Một thành viên vừa trả lời bình luận của bạn.','social_comment');}elseif($post['loai_tac_gia']!==$a['type']||$post['tac_gia_id']!=$a['id']){$this->sendNotification($post,$a,'Bài đăng có bình luận mới','Có người vừa bình luận bài đăng của bạn.','social_comment');}Response::ok(['id'=>$id,'tra_loi_cho_id'=>$parentId?:null,'trang_thai'=>'cho_duyet'],'Đã nhận bình luận. Hệ thống đang tự động kiểm tra trước khi hiển thị.');
    }

    public function share(int $postId): never {
        $a=$this->actor();$b=Request::body();$note=trim((string)($b['ghi_chu']??''));
        \LaborPlatform\Services\ContentSafetyService::assertSafe($note,'Ghi chú chia sẻ');if(mb_strlen($note)>500)Response::error('Ghi chú chia sẻ tối đa 500 ký tự.');
        $q=$this->db->prepare('SELECT id,loai_tac_gia,tac_gia_id,trang_thai FROM social_bai_dang WHERE id=? LIMIT 1');$q->execute([$postId]);$post=$q->fetch();if(!$post||$post['trang_thai']!=='cong_khai')Response::error('Không tìm thấy bài đăng.',404);
        $this->db->prepare('INSERT INTO social_chia_se (bai_dang_id,tac_gia_type,tac_gia_id,ghi_chu) VALUES (?,?,?,?)')->execute([$postId,$a['type'],$a['id'],$note?:null]);$this->db->prepare('UPDATE social_bai_dang SET luot_chia_se=luot_chia_se+1 WHERE id=?')->execute([$postId]);$this->audit->log($a['type'],$a['id'],null,'social_chia_se','chia_se',null,['bai_dang_id'=>$postId]);if($post['loai_tac_gia']!==$a['type']||$post['tac_gia_id']!=$a['id'])$this->sendNotification($post,$a,'Bài đăng được chia sẻ','Bài đăng của bạn vừa được chia sẻ.','social_share');$countQ=$this->db->prepare('SELECT luot_chia_se FROM social_bai_dang WHERE id=?');$countQ->execute([$postId]);Response::ok(['luot_chia_se'=>(int)$countQ->fetchColumn()],'Đã chia sẻ bài đăng.');
    }

    public function follow(string $type,int $id): never {
        $a=$this->actor();
        if(!in_array($type,['nguoi_lao_dong','nha_cung_ung'],true) || $id<=0) Response::error('Đối tượng theo dõi không hợp lệ.');
        $table=$type==='nguoi_lao_dong'?'nguoi_lao_dong':'nha_cung_ung';
        $q=$this->db->prepare("SELECT id FROM {$table} WHERE id=? LIMIT 1");
        $q->execute([$id]);
        if(!$q->fetch()) Response::error('Không tìm thấy tài khoản.',404);
        if($a['type']===$type && $a['id']===$id) Response::error('Không thể tự theo dõi chính mình.');
        if($this->isBlocked($a['type'],$a['id'],$type,$id)) Response::error('Không thể theo dõi tài khoản này.',403);
        $q=$this->db->prepare('SELECT id,trang_thai FROM social_theo_doi WHERE nguoi_theo_doi_type=? AND nguoi_theo_doi_id=? AND doi_tuong_type=? AND doi_tuong_id=? LIMIT 1');
        $q->execute([$a['type'],$a['id'],$type,$id]);
        $row=$q->fetch();
        if($row){
            $following=$row['trang_thai']!=='dang_theo_doi';
            $new=$following?'dang_theo_doi':'da_bo_theo_doi';
            $q=$this->db->prepare('UPDATE social_theo_doi SET trang_thai=?,ngay_cap_nhat=NOW() WHERE id=?');
            $q->execute([$new,(int)$row['id']]);
        } else {
            $following=true;
            $q=$this->db->prepare('INSERT INTO social_theo_doi (nguoi_theo_doi_type,nguoi_theo_doi_id,doi_tuong_type,doi_tuong_id) VALUES (?,?,?,?)');
            $q->execute([$a['type'],$a['id'],$type,$id]);
        }
        $this->audit->log($a['type'],$a['id'],null,'social_theo_doi',$following?'theo_doi':'bo_theo_doi',null,['doi_tuong_type'=>$type,'doi_tuong_id'=>$id]);
        if($following){
            $target=['loai_tac_gia'=>$type,'tac_gia_id'=>$id];
            $this->sendNotification($target,$a,'Bạn có người theo dõi mới','Một thành viên vừa bắt đầu theo dõi bạn.','social_follow');
        }
        Response::ok(['dang_theo_doi'=>$following]);
    }

    public function shareJob(int $jobId): never {
        $a=$this->actor(); if($a['type']!=='nguoi_lao_dong')Response::error('Chỉ tài khoản Người lao động có thể chia sẻ lên trang cá nhân.',403);
        $b=Request::body();$note=trim((string)($b['ghi_chu']??''));if(mb_strlen($note)>500)Response::error('Lời giới thiệu tối đa 500 ký tự.');
        $q=$this->db->prepare('SELECT id,tieu_de,nganh_nghe,dia_diem,trang_thai FROM tin_tuyen_dung WHERE id=? AND trang_thai="dang_tuyen" LIMIT 1');$q->execute([$jobId]);$job=$q->fetch();if(!$job)Response::error('Không tìm thấy Tin tuyển dụng.',404);
        $text=$note!==''?$note:'Chia sẻ một cơ hội việc làm.';
        $q=$this->db->prepare('INSERT INTO social_bai_dang (loai_tac_gia,tac_gia_id,loai_bai_dang,loai_nguon,nguon_id,noi_dung,trang_thai) VALUES (?,?,"viec_lam","tin_tuyen_dung",?,?,"cho_duyet")');$q->execute([$a['type'],$a['id'],$jobId,$text]);$id=(int)$this->db->lastInsertId();
        $this->audit->log($a['type'],$a['id'],null,'social_bai_dang','chia_se_tin_tuyen_dung',null,['id'=>$id,'tin_tuyen_dung_id'=>$jobId]);$this->queue->enqueue('moderation','moderation.social_post',['post_id'=>$id,'actor_type'=>$a['type'],'actor_id'=>$a['id']],180,'social_post:'.$id);Response::ok(['id'=>$id,'trang_thai'=>'cho_duyet','tin_tuyen_dung'=>$job],'Đã gửi chia sẻ tin tuyển dụng lên trang cá nhân.');
    }

    public function reportComment(int $commentId): never {
        $a=$this->actor();
        $b=Request::body();
        $reason=(string)($b['ly_do']??'');
        $desc=trim((string)($b['mo_ta']??''));
        $allowed=['spam','lua_dao','noi_dung_khong_phu_hop','quay_roi','thong_tin_sai','khac'];
        if(!in_array($reason,$allowed,true)) Response::error('Lý do báo cáo không hợp lệ.');
        if(mb_strlen($desc)>1000) Response::error('Mô tả báo cáo quá dài.');

        $this->db->beginTransaction();
        try {
            // PR-08: lock the target comment row so concurrent report requests for the same actor/target serialize.
            $q=$this->db->prepare('SELECT id,bai_dang_id,trang_thai FROM social_binh_luan WHERE id=? FOR UPDATE');
            $q->execute([$commentId]);
            $c=$q->fetch();
            if(!$c||$c['trang_thai']!=='cong_khai'){ $this->db->rollBack(); Response::error('Không tìm thấy bình luận.',404); }
            $q=$this->db->prepare('SELECT id FROM social_bao_cao WHERE binh_luan_id=? AND nguoi_bao_cao_type=? AND nguoi_bao_cao_id=? AND trang_thai IN ("moi","dang_xu_ly") AND ngay_tao>=DATE_SUB(NOW(),INTERVAL 24 HOUR) LIMIT 1 FOR UPDATE');
            $q->execute([$commentId,$a['type'],$a['id']]);
            if($q->fetch()){ $this->db->rollBack(); Response::error('Bạn đã báo cáo bình luận này và đang chờ xử lý.',409); }
            $this->db->prepare('INSERT INTO social_bao_cao (binh_luan_id,nguoi_bao_cao_type,nguoi_bao_cao_id,ly_do,mo_ta) VALUES (?,?,?,?,?)')->execute([$commentId,$a['type'],$a['id'],$reason,$desc?:null]);
            $this->db->commit();
        } catch(\Throwable $e) {
            if($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
        $this->audit->log($a['type'],$a['id'],null,'social_bao_cao','bao_cao_binh_luan',null,['binh_luan_id'=>$commentId,'bai_dang_id'=>$c['bai_dang_id'],'ly_do'=>$reason]);
        Response::ok(null,'Đã tiếp nhận báo cáo bình luận.');
    }

    public function reportPost(int $postId): never {
        $a=$this->actor();
        $b=Request::body();
        $reason=(string)($b['ly_do']??'');
        $desc=trim((string)($b['mo_ta']??''));
        $allowed=['spam','lua_dao','noi_dung_khong_phu_hop','quay_roi','thong_tin_sai','khac'];
        if(!in_array($reason,$allowed,true)) Response::error('Lý do báo cáo không hợp lệ.');
        if(mb_strlen($desc)>1000) Response::error('Mô tả báo cáo quá dài.');

        $this->db->beginTransaction();
        try {
            // PR-08: lock the target post row so concurrent report requests for the same actor/target serialize.
            $q=$this->db->prepare('SELECT id FROM social_bai_dang WHERE id=? AND trang_thai="cong_khai" FOR UPDATE');
            $q->execute([$postId]);
            if(!$q->fetch()){ $this->db->rollBack(); Response::error('Không tìm thấy bài đăng.',404); }
            $q=$this->db->prepare('SELECT id FROM social_bao_cao WHERE bai_dang_id=? AND nguoi_bao_cao_type=? AND nguoi_bao_cao_id=? AND trang_thai IN ("moi","dang_xu_ly") AND ngay_tao>=DATE_SUB(NOW(),INTERVAL 24 HOUR) LIMIT 1 FOR UPDATE');
            $q->execute([$postId,$a['type'],$a['id']]);
            if($q->fetch()){ $this->db->rollBack(); Response::error('Bạn đã báo cáo bài đăng này và đang chờ xử lý.',409); }
            $this->db->prepare('INSERT INTO social_bao_cao (bai_dang_id,nguoi_bao_cao_type,nguoi_bao_cao_id,ly_do,mo_ta) VALUES (?,?,?,?,?)')->execute([$postId,$a['type'],$a['id'],$reason,$desc?:null]);
            $this->db->commit();
        } catch(\Throwable $e) {
            if($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
        $this->audit->log($a['type'],$a['id'],null,'social_bao_cao','bao_cao_bai_dang',null,['bai_dang_id'=>$postId,'ly_do'=>$reason]);
        Response::ok(null,'Đã tiếp nhận báo cáo.');
    }

    public function block(string $type,int $id): never {
        $a=$this->actor();if(!in_array($type,['nguoi_lao_dong','nha_cung_ung'],true)||$id<=0)Response::error('Đối tượng chặn không hợp lệ.');if($a['type']===$type&&$a['id']===$id)Response::error('Không thể tự chặn chính mình.');$q=$this->db->prepare('INSERT INTO social_chan (nguoi_chan_type,nguoi_chan_id,doi_tuong_type,doi_tuong_id,trang_thai) VALUES (?,?,?,?,"dang_chan") ON DUPLICATE KEY UPDATE trang_thai="dang_chan",ngay_cap_nhat=NOW()');$q->execute([$a['type'],$a['id'],$type,$id]);$this->db->prepare('UPDATE social_theo_doi SET trang_thai="da_bo_theo_doi" WHERE nguoi_theo_doi_type=? AND nguoi_theo_doi_id=? AND doi_tuong_type=? AND doi_tuong_id=?')->execute([$a['type'],$a['id'],$type,$id]);$this->audit->log($a['type'],$a['id'],null,'social_chan','chan_tai_khoan',null,['doi_tuong_type'=>$type,'doi_tuong_id'=>$id]);Response::ok(null,'Đã chặn tài khoản.');
    }

    public function adminModerate(int $postId): never { AdminAuth::requirePermission('social.moderate');$b=Request::body();$status=(string)($b['trang_thai']??'');$reason=trim((string)($b['ly_do']??''));if(!in_array($status,['cong_khai','an','tu_choi'],true))Response::error('Trạng thái kiểm duyệt không hợp lệ.');$q=$this->db->prepare('UPDATE social_bai_dang SET trang_thai=?,ly_do_kiem_duyet=? WHERE id=?');$q->execute([$status,$reason?:null,$postId]);if($q->rowCount()<1)Response::error('Không tìm thấy bài đăng.',404);$this->audit->log('admin',AdminAuth::accountId(),null,'social_bai_dang','kiem_duyet',null,['id'=>$postId,'trang_thai'=>$status,'ly_do'=>$reason]);Response::ok(null,'Đã cập nhật kiểm duyệt.'); }

    private function count(string $table,int $postId): int {if(!in_array($table,['social_thich','social_chia_se'],true))return 0;$q=$this->db->prepare("SELECT COUNT(*) FROM {$table} WHERE bai_dang_id=?");$q->execute([$postId]);return (int)$q->fetchColumn();}
    private function sendNotification(array $post,array $actor,string $title,string $content,string $type): void {try {if(($post['loai_tac_gia']??'')==='nguoi_lao_dong')$this->notify->worker((int)$post['tac_gia_id'],$title,$content,$type);elseif(($post['loai_tac_gia']??'')==='nha_cung_ung')$this->notify->supplier((int)$post['tac_gia_id'],$title,$content,$type);} catch(\Throwable $e) { /* notification failure must not break social action */ }}
}
