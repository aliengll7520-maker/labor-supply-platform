<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{AdminAuth,Response};
use LaborPlatform\Services\OperationsService;

final class OperationsController
{
    public function __construct(private OperationsService $operations) {}

    public function overview(): never
    {
        AdminAuth::requirePermission('operations.view');
        $snapshot = $this->operations->snapshot();
        Response::ok($snapshot);
    }

    public function alerts(): never
    {
        AdminAuth::requirePermission('operations.view');
        Response::ok(['alerts'=>$this->operations->openAlerts()]);
    }

    public function exceptions(): never
    {
        AdminAuth::requirePermission('operations.view');
        $limit=(int)($_GET['limit'] ?? 100);
        Response::ok($this->operations->exceptionCenter($limit));
    }

    public function snapshots(): never
    {
        AdminAuth::requirePermission('operations.view');
        Response::ok(['snapshots'=>$this->operations->recentSnapshots()]);
    }
}
