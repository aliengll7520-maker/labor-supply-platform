<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Request, Response};

final class WorkerNotificationController
{
    public function __construct(private \PDO $db)
    {
    }

    public function index(): never
    {
        $workerId = $this->resolveWorkerId();

        $q = $this->db->prepare(
            'SELECT id, loai AS type, tieu_de AS title, noi_dung AS message,
                    da_doc AS is_read, du_lieu_json AS data, ngay_tao AS created_at
             FROM thong_bao_nguoi_lao_dong
             WHERE nguoi_lao_dong_id=?
             ORDER BY ngay_tao DESC
             LIMIT 100'
        );
        $q->execute([$workerId]);

        $rows = $q->fetchAll();
        foreach ($rows as &$row) {
            $row['is_read'] = (bool)$row['is_read'];
            $row['data'] = $row['data'] ? json_decode($row['data'], true) : [];
        }

        Response::ok($rows);
    }

    public function markRead(int $id): never
    {
        $workerId = $this->resolveWorkerId();

        $q = $this->db->prepare(
            'UPDATE thong_bao_nguoi_lao_dong
             SET da_doc=1
             WHERE id=? AND nguoi_lao_dong_id=?'
        );
        $q->execute([$id, $workerId]);

        Response::ok(null, 'Đã đánh dấu đã đọc.');
    }

    private function resolveWorkerId(): int
    {
        $phone = trim((string)Request::input('so_dien_thoai'));
        $code = trim((string)Request::input('ma_nguoi_lao_dong'));

        if ($phone === '' || $code === '') {
            Response::error('Thiếu thông tin Người lao động.', 401);
        }

        $q = $this->db->prepare(
            'SELECT id FROM nguoi_lao_dong
             WHERE so_dien_thoai=? AND ma_nguoi_lao_dong=?
             LIMIT 1'
        );
        $q->execute([$phone, $code]);

        $id = (int)$q->fetchColumn();
        if ($id <= 0) {
            Response::error('Không xác định được Người lao động.', 401);
        }

        return $id;
    }
}
