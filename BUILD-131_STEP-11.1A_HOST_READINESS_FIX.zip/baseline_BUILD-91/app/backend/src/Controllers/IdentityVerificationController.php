<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Auth,Request,Response,WorkerAuth};
use LaborPlatform\Services\{IdentityService,IdentityVerificationService,IdentityOnboardingService};

final class IdentityVerificationController {
    public function __construct(private \PDO $db, private IdentityService $identity, private IdentityVerificationService $verification, private ?IdentityOnboardingService $onboarding=null) {}
    private function actor(): array {
        $header=$_SERVER['HTTP_AUTHORIZATION']??'';
        if(preg_match('/^Bearer\s+(.+)$/i',$header)){
            $workerId=WorkerAuth::workerId(false); if($workerId>0){ $id=$this->identity->syncWorker($workerId); return [$id,'worker',$workerId,null]; }
        }
        $supplierId=Auth::supplierId(false); $accountId=Auth::accountId();
        if($supplierId>0 && $accountId>0){ $id=$this->identity->syncEmployerAccount($accountId,$supplierId); return [$id,'employer',null,$supplierId]; }
        Response::error('Chưa đăng nhập.',401);
    }
    public function status(): never { [$id]= $this->actor(); Response::ok(['identity_id'=>$id,'verifications'=>$this->verification->status($id)]); }
    public function request(): never { [$id,$role,$workerId,$supplierId]=$this->actor(); $b=Request::body(); $channel=trim((string)($b['channel']??'phone')); $destination=trim((string)($b['destination']??'')); if($destination===''){ if($role==='worker'){ $q=$this->db->prepare('SELECT so_dien_thoai FROM nguoi_lao_dong WHERE id=?');$q->execute([$workerId]);$destination=(string)$q->fetchColumn(); } else { $q=$this->db->prepare('SELECT so_dien_thoai,email FROM nha_cung_ung WHERE id=?');$q->execute([$supplierId]);$r=$q->fetch();$destination=$channel==='email'?(string)($r['email']??''):(string)($r['so_dien_thoai']??''); } } if($destination==='')Response::error('Không có thông tin liên hệ để xác minh.'); try{Response::ok($this->verification->request($id,$role,$channel,$destination,(string)($b['provider']??''?:null)),'Đã tạo yêu cầu xác minh.');}catch(\Throwable $e){Response::error($e->getMessage(),400);} }
    public function confirm(): never { [$id,$role]=$this->actor(); $b=Request::body(); try{Response::ok(array_merge($this->verification->confirm($id,$role,trim((string)($b['channel']??'phone')),trim((string)($b['code']??''))),['onboarding'=>$this->onboarding?$this->onboarding->refresh($id):null]),'Xác minh thành công.');}catch(\Throwable $e){Response::error($e->getMessage(),400);} }
}
