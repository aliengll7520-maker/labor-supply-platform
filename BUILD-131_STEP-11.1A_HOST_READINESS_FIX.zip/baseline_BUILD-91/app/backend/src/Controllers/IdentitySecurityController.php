<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Request,Response,WorkerAuth,Auth};
use LaborPlatform\Services\IdentitySecurityService;

final class IdentitySecurityController {
 public function __construct(private IdentitySecurityService $security, private ?\LaborPlatform\Services\IdentityService $identity=null) {}
 public function requestReset(): never { $b=Request::body(); try { Response::ok($this->security->requestPasswordReset((string)($b['role']??''),(string)($b['identifier']??$b['phone']??$b['email']??$b['login']??'')),'Nếu tài khoản tồn tại, yêu cầu khôi phục đã được tiếp nhận.'); } catch(\Throwable $e){ Response::error($e->getMessage(),429); } }
 public function confirmReset(): never { $b=Request::body(); try { Response::ok($this->security->confirmPasswordReset((string)($b['role']??''),(string)($b['token']??''),(string)($b['new_password']??$b['mat_khau_moi']??'')),'Đã đặt lại mật khẩu.'); } catch(\Throwable $e){ Response::error($e->getMessage(),400); } }
 public function status(): never { $id=0; $header=$_SERVER['HTTP_AUTHORIZATION']??''; if(preg_match('/^Bearer\s+(.+)$/i',$header)) $id=(int)WorkerAuth::workerId(false); if($id<=0){$sid=Auth::supplierId(false);$aid=Auth::accountId(); if($sid>0&&$aid>0&&$this->identity){$id=(int)$this->identity->currentEmployer($aid,$sid)['id'];}} if($id<=0) Response::error('Chưa đăng nhập.',401); Response::ok($this->security->securityStatus($id)); }
}
