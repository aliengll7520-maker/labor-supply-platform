<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Services\ContentDiscoveryOrchestratorService;

final class ContentDiscoveryOrchestratorController
{
    public function __construct(private ContentDiscoveryOrchestratorService $service) {}

    public function dispatch(int $jobId): void
    {
        \Response::ok($this->service->dispatchJob($jobId, [
            'actor_type' => 'admin',
            'actor_id' => null,
            'request_id' => class_exists('RequestContext') ? \RequestContext::id() : null,
            'reason' => 'admin_manual_orchestration',
        ]));
    }

    public function status(int $jobId): void
    {
        \Response::ok($this->service->status($jobId));
    }
}
