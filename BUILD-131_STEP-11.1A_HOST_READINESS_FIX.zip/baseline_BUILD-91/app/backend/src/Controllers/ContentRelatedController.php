<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentRelatedService;

final class ContentRelatedController
{
    public function __construct(private ContentRelatedService $related) {}

    public function publicJob(int $jobId): never
    {
        try {
            Response::ok($this->related->relatedJob($jobId, $_GET));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tải nội dung liên quan.', 500);
        }
    }
}
