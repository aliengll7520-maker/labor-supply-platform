<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,AdminAuth,Response,WorkerAuth};

final class NotificationController {
    public function __construct(private \PDO $db) {}

    public function supplierList(): never {
        $sid=Auth::supplierId();

        $q=$this->db->prepare(
            'SELECT *
             FROM thong_bao
             WHERE doi_tuong="nha_cung_ung"
             AND doi_tuong_id=?
             ORDER BY id DESC
             LIMIT 100'
        );
        $q->execute([$sid]);

        Response::ok($q->fetchAll());
    }

    public function supplierRead(int $id): never {
        $sid=Auth::supplierId();

        $q=$this->db->prepare(
            'UPDATE thong_bao
             SET da_doc=1,thoi_gian_doc=NOW()
             WHERE id=?
             AND doi_tuong="nha_cung_ung"
             AND doi_tuong_id=?'
        );
        $q->execute([$id,$sid]);

        Response::ok(null,'Đã đánh dấu thông báo đã đọc.');
    }

    public function supplierReadAll(): never {
        $sid=Auth::supplierId();

        $q=$this->db->prepare(
            'UPDATE thong_bao
             SET da_doc=1,thoi_gian_doc=NOW()
             WHERE doi_tuong="nha_cung_ung"
             AND doi_tuong_id=?
             AND da_doc=0'
        );
        $q->execute([$sid]);

        Response::ok(null,'Đã đánh dấu tất cả thông báo đã đọc.');
    }

    public function workerList(): never {
        $workerId=WorkerAuth::workerId($this->db);

        $q=$this->db->prepare(
            'SELECT id,
                    loai AS type,
                    tieu_de AS title,
                    noi_dung AS message,
                    da_doc AS is_read,
                    dang_ky_ho_so_phong_van_id AS application_id,
                    ngay_tao AS created_at
             FROM thong_bao
             WHERE doi_tuong="nguoi_lao_dong"
             AND doi_tuong_id=?
             ORDER BY id DESC
             LIMIT 100'
        );
        $q->execute([$workerId]);

        $rows=$q->fetchAll();
        foreach($rows as &$row){
            $row['is_read']=(bool)$row['is_read'];
        }

        Response::ok($rows);
    }

    public function workerRead(int $id): never {
        $workerId=WorkerAuth::workerId($this->db);

        $q=$this->db->prepare(
            'UPDATE thong_bao
             SET da_doc=1,thoi_gian_doc=NOW()
             WHERE id=?
             AND doi_tuong="nguoi_lao_dong"
             AND doi_tuong_id=?'
        );
        $q->execute([$id,$workerId]);

        Response::ok(null,'Đã đánh dấu thông báo đã đọc.');
    }

    public function adminList(): never {
        AdminAuth::requirePermission('notifications.view');

        $q=$this->db->query(
            'SELECT *
             FROM thong_bao
             WHERE doi_tuong="quan_tri"
             ORDER BY id DESC
             LIMIT 100'
        );

        Response::ok($q->fetchAll());
    }

    public function adminRead(int $id): never {
        AdminAuth::requirePermission('notifications.view');

        $q=$this->db->prepare(
            'UPDATE thong_bao
             SET da_doc=1,thoi_gian_doc=NOW()
             WHERE id=?
             AND doi_tuong="quan_tri"'
        );
        $q->execute([$id]);

        Response::ok(null,'Đã đánh dấu thông báo đã đọc.');
    }

    public function adminReadAll(): never {
        AdminAuth::requirePermission('notifications.view');

        $q=$this->db->query(
            'UPDATE thong_bao
             SET da_doc=1,thoi_gian_doc=NOW()
             WHERE doi_tuong="quan_tri"
             AND da_doc=0'
        );

        Response::ok(null,'Đã đánh dấu tất cả thông báo đã đọc.');
    }
}
