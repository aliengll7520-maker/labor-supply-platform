<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\AdminAuth;
use LaborPlatform\Core\Request;
use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentDiscoveryAdminOverrideService;

final class ContentDiscoveryAdminOverrideController
{
    public function __construct(private ContentDiscoveryAdminOverrideService $service) {}
    public function list(int $jobId): never { try { Response::ok($this->service->list($jobId)); } catch(\Throwable $e){ Response::error($e->getMessage(), $e instanceof \InvalidArgumentException ? 400 : 500); } }
    public function set(int $jobId): never { try { $b=Request::body(); Response::ok($this->service->set($jobId,(string)($b['field']??''),(string)($b['value']??''),(string)($b['reason']??''))); } catch(\Throwable $e){ Response::error($e->getMessage(), $e instanceof \InvalidArgumentException ? 400 : 500); } }
    public function remove(int $jobId): never { try { $b=Request::body(); Response::ok($this->service->remove($jobId,(string)($b['field']??''))); } catch(\Throwable $e){ Response::error($e->getMessage(), $e instanceof \InvalidArgumentException ? 400 : 500); } }
}
