<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,Response,Request,Pagination};
use LaborPlatform\Services\{AuditService,NotificationService,AutoJobModerationService,JobMatchingService,ContentDiscoveryEventService};

final class JobController {
    public function __construct(
        private \PDO $db,
        private AuditService $audit,
        private NotificationService $notify,
        private AutoJobModerationService $moderation,
        private JobMatchingService $matching,
        private ContentDiscoveryEventService $discoveryEvents
    ) {}

    private array $fields=[
        'tieu_de','nganh_nghe','so_luong','dia_diem','google_maps',
        'luong_co_ban','tong_thu_nhap_du_kien',
        'ho_tro_tien_xe_nguoi_lao_dong_o_xa',
        'chuyen_can','nha_o','xang_xe','hieu_suat','phu_cap_khac',
        'thuong','ho_tro','tang_ca','chinh_sach_tra_luong',
        'hop_dong','bao_hiem','che_do_khac','dieu_kien_tuyen_dung',
        'mo_ta_cong_viec','hinh_anh','video','ngay_het_han'
    ];

    private function validate(
        array $b,
        bool $partial=false
    ): array {

        $required=[
            'tieu_de'=>'Tiêu đề',
            'nganh_nghe'=>'Ngành nghề',
            'so_luong'=>'Số lượng',
            'dia_diem'=>'Địa điểm',
            'tong_thu_nhap_du_kien'=>'Tổng thu nhập dự kiến',
            'ho_tro_tien_xe_nguoi_lao_dong_o_xa'=>'Hỗ trợ tiền xe cho Người lao động ở xa'
        ];

        foreach($required as $f=>$label){

            if(
                $partial &&
                !array_key_exists($f,$b)
            )
                continue;

            if(
                trim(
                    (string)($b[$f]??'')
                )===''
            )
                Response::error(
                    "Thiếu trường: $label."
                );
        }

        foreach(['tieu_de','nganh_nghe','dia_diem','chinh_sach_tra_luong','hop_dong','bao_hiem','che_do_khac','dieu_kien_tuyen_dung','mo_ta_cong_viec','thuong','ho_tro','tang_ca'] as $safeField){ if(array_key_exists($safeField,$b)) \LaborPlatform\Services\ContentSafetyService::assertSafe((string)$b[$safeField], $safeField); }

        if(
            array_key_exists('tieu_de',$b) &&
            mb_strlen(
                trim(
                    (string)$b['tieu_de']
                )
            )>255
        )
            Response::error(
                'Tiêu đề không được vượt quá 255 ký tự.'
            );

        if(
            array_key_exists('so_luong',$b) &&
            (
                !is_numeric($b['so_luong']) ||
                (int)$b['so_luong']<1
            )
        )
            Response::error(
                'Số lượng tuyển phải từ 1 trở lên.'
            );

        foreach([
                            'luong_co_ban',
            'tong_thu_nhap_du_kien',
            'ho_tro_tien_xe_nguoi_lao_dong_o_xa',
            'chuyen_can',
            'nha_o',
            'xang_xe',
            'hieu_suat',
            'phu_cap_khac'
        ] as $f){

            if(
                array_key_exists($f,$b) &&
                $b[$f]!=='' &&
                (
                    !is_numeric($b[$f]) ||
                    (float)$b[$f]<0
                )
            )
                Response::error(
                    "Giá trị $f không hợp lệ."
                );
        }

        if(
            array_key_exists(
                'tong_thu_nhap_du_kien',
                $b
            ) &&
            (
                !is_numeric(
                    $b['tong_thu_nhap_du_kien']
                ) ||
                (float)$b['tong_thu_nhap_du_kien']<=0
            )
        )
            Response::error(
                'Tổng thu nhập dự kiến phải lớn hơn 0.'
            );

        if(
            array_key_exists(
                'ngay_het_han',
                $b
            ) &&
            !empty(
                $b['ngay_het_han']
            ) &&
            strtotime(
                (string)$b['ngay_het_han']
            )===false
        )
            Response::error(
                'Ngày hết hạn không hợp lệ.'
            );

        return $b;
    }

    private function getOwned(
        int $jobId,
        int $supplierId
    ): array {

        $s=$this->db->prepare(
            'SELECT *
             FROM tin_tuyen_dung
             WHERE id=?
               AND nha_cung_ung_id=?
             LIMIT 1'
        );

        $s->execute([
            $jobId,
            $supplierId
        ]);

        $job=$s->fetch(
            \PDO::FETCH_ASSOC
        );

        if(!$job)
            Response::error(
                'Không tìm thấy Tin tuyển dụng.',
                404
            );

        return $job;
    }

    private function requireOperationalSupplier(
        int $supplierId
    ): void {

        $s=$this->db->prepare(
            'SELECT trang_thai
             FROM nha_cung_ung
             WHERE id=?
             LIMIT 1'
        );

        $s->execute([
            $supplierId
        ]);

        $status=$s->fetchColumn();

        if(
            $status===false ||
            $status!=='hoat_dong'
        )
            Response::error(
                'Nhà cung ứng chưa ở trạng thái hoạt động.',
                403
            );
    }
        public function publicList(): never {
        $perPage = Pagination::limit(50, 100);
        $offset = Pagination::offset();
        $page = max(1, (int)($_GET['page'] ?? 1));

        // Preserve the legacy limit/offset contract while allowing the scalable
        // page/per_page contract used by clients.
        if (array_key_exists('per_page', $_GET)) {
            $perPage = min(max((int)$_GET['per_page'], 1), 100);
            $offset = ($page - 1) * $perPage;
        } else {
            $page = (int)floor($offset / max(1, $perPage)) + 1;
        }

        $where = ['t.trang_thai="dang_tuyen"'];
        $params = [];

        $q = trim((string)($_GET['q'] ?? ''));
        if ($q !== '') {
            $searchQuery = $this->booleanSearchQuery($q);
            if ($searchQuery === '') Response::error('Từ khóa tìm kiếm không hợp lệ.', 400);
            $where[] = 'MATCH(t.tieu_de,t.nganh_nghe,t.dia_diem) AGAINST(:search_q IN BOOLEAN MODE)';
            $params[':search_q'] = $searchQuery;
        }

        $province = trim((string)($_GET['province'] ?? $_GET['dia_diem'] ?? ''));
        if ($province !== '') {
            $where[] = 't.dia_diem LIKE :province';
            $params[':province'] = '%'.$province.'%';
        }

        $district = trim((string)($_GET['district'] ?? ''));
        if ($district !== '') {
            $where[] = 't.dia_diem LIKE :district';
            $params[':district'] = '%'.$district.'%';
        }

        if (isset($_GET['salary_min']) && $_GET['salary_min'] !== '') {
            $salaryMin = (float)$_GET['salary_min'];
            if ($salaryMin < 0) Response::error('salary_min không hợp lệ.', 400);
            $where[] = 't.tong_thu_nhap_du_kien >= :salary_min';
            $params[':salary_min'] = $salaryMin;
        }

        if (isset($_GET['salary_max']) && $_GET['salary_max'] !== '') {
            $salaryMax = (float)$_GET['salary_max'];
            if ($salaryMax < 0) Response::error('salary_max không hợp lệ.', 400);
            $where[] = 't.tong_thu_nhap_du_kien <= :salary_max';
            $params[':salary_max'] = $salaryMax;
        }

        if (isset($_GET['salary_min'], $_GET['salary_max']) && $_GET['salary_min'] !== '' && $_GET['salary_max'] !== '' && (float)$_GET['salary_min'] > (float)$_GET['salary_max']) {
            Response::error('Khoảng thu nhập không hợp lệ.', 400);
        }

        $sql = 'SELECT t.*
                FROM tin_tuyen_dung t
                WHERE '.implode(' AND ', $where).'
                ORDER BY t.ngay_dang DESC,t.id DESC
                LIMIT :limit OFFSET :offset';

        $s=$this->db->prepare($sql);
        foreach ($params as $key=>$value) {
            $s->bindValue($key, $value, is_float($value) ? \PDO::PARAM_STR : \PDO::PARAM_STR);
        }
        $s->bindValue(':limit',$perPage,\PDO::PARAM_INT);
        $s->bindValue(':offset',$offset,\PDO::PARAM_INT);
        $s->execute();

        $items=$s->fetchAll(\PDO::FETCH_ASSOC);
        $hasMore = count($items)===$perPage;
        header('X-Search-Page: '.$page);
        header('X-Search-Per-Page: '.$perPage);
        header('X-Search-Has-More: '.($hasMore ? 'true' : 'false'));
        header('Cache-Control: public, max-age=10, stale-while-revalidate=30');
        header('Vary: Accept-Encoding');
        Response::ok($items);
    }

    private function booleanSearchQuery(string $query): string {
        $terms = preg_split('/\s+/u', trim($query), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $terms = array_values(array_filter(array_map(static function(string $term): string {
            $term = preg_replace('/[^\p{L}\p{N}_-]+/u', '', $term) ?? '';
            return $term === '' ? '' : $term.'*';
        }, $terms)));
        return implode(' ', $terms);
    }

    public function publicDetail(
        int $jobId
    ): never {

        $s=$this->db->prepare(
            'SELECT *
             FROM tin_tuyen_dung
             WHERE id=?
               AND trang_thai="dang_tuyen"
             LIMIT 1'
        );

        $s->execute([
            $jobId
        ]);

        $job=$s->fetch(
            \PDO::FETCH_ASSOC
        );

        if(!$job)
            Response::error(
                'Không tìm thấy Tin tuyển dụng.',
                404
            );

        Response::ok(
            $job
        );
    }

    public function create(): never {

        $id=Auth::supplierId();

        $this->requireOperationalSupplier($id);

        $b=$this->validate(
            Request::body()
        );

        $code='TIN-'.
            date('YmdHis').
            '-'.
            random_int(
                1000,
                9999
            );

        $fields=[
            'nha_cung_ung_id',
            'ma_tin'
        ];

        $values=[
            $id,
            $code
        ];

        foreach($this->fields as $f){

            if(
                array_key_exists(
                    $f,
                    $b
                )
            ){
                $fields[]=$f;
                $values[]=
                    $b[$f]===''
                    ?null
                    :$b[$f];
            }
        }

        $placeholders=
            implode(
                ',',
                array_fill(
                    0,
                    count($values),
                    '?'
                )
            );

        $this->db->beginTransaction();

        try{

            $s=$this->db->prepare(
                'INSERT INTO tin_tuyen_dung ('.
                implode(',',$fields).
                ')
                 VALUES ('.
                $placeholders.
                ')'
            );

            $s->execute(
                $values
            );

            $jid=(int)
                $this->db
                    ->lastInsertId();

            $moderation=$this->moderation->apply($jid);

            $this->audit->log(
                'nha_cung_ung',
                $id,
                null,
                'tin_tuyen_dung',
                'tao_tin',
                null,
                [
                    'id'=>$jid,
                    'ma_tin'=>$code
                ]
            );

            $this->discoveryEvents->publishJobChanged($jid, 'created', [
                'actor_type' => 'supplier', 'actor_id' => $id, 'reason' => 'job_created'
            ]);

            $this->db->commit();
            \LaborPlatform\Services\ContentSearchService::invalidateCache();

            if($moderation['decision']==='auto_approved') $this->matching->enqueueForJob($jid);

            Response::ok(
                [
                    'id'=>$jid,
                    'ma_tin'=>$code,
                    'trang_thai'=>$moderation['decision']==='auto_approved' ? 'dang_tuyen' : 'cho_duyet',
                    'moderation'=>$moderation
                ],
                $moderation['decision']==='auto_approved'
                    ? 'Tin đã được hệ thống tự động kiểm tra và công khai.'
                    : ($moderation['decision']==='blocked'
                        ? 'Tin chưa được công khai vì hệ thống phát hiện dấu hiệu cần chặn.'
                        : 'Tin đã được gửi vào hàng chờ kiểm tra.')
            );

        }catch(\Throwable $e){

            if(
                $this->db->inTransaction()
            )
                $this->db->rollBack();

            Response::error(
                'Không thể tạo Tin tuyển dụng.',
                500
            );
        }
    }
    public function update(
        int $jobId
    ): never {

        $id=Auth::supplierId();

        $b=$this->validate(
            Request::body(),
            true
        );

        if(!$b)
            Response::error(
                'Không có dữ liệu cập nhật.'
            );

        $old=$this->getOwned(
            $jobId,
            $id
        );

        if(
            in_array(
                $old['trang_thai'],
                [
                    'da_dong',
                    'het_han'
                ],
                true
            )
        )
            Response::error(
                'Tin đã đóng hoặc hết hạn không thể chỉnh sửa.',
                409
            );

        $sets=[];
        $vals=[];

        foreach($this->fields as $f){

            if(
                array_key_exists(
                    $f,
                    $b
                )
            ){

                $sets[]="$f=?";

                $vals[]=
                    $b[$f]===''
                    ?null
                    :$b[$f];
            }
        }

        $vals[]=$jobId;
        $vals[]=$id;

        $this->db->beginTransaction();

        try{

            $s=$this->db->prepare(
                'UPDATE tin_tuyen_dung
                 SET '.
                implode(',',$sets).
                '
                 WHERE id=?
                   AND nha_cung_ung_id=?'
            );

            $s->execute($vals);

            $this->audit->log(
                'nha_cung_ung',
                $id,
                null,
                'tin_tuyen_dung',
                'cap_nhat_tin',
                $old,
                [
                    'id'=>$jobId,
                    'fields'=>array_keys($b)
                ]
            );

            $this->discoveryEvents->publishJobChanged($jobId, 'updated', [
                'actor_type' => 'supplier', 'actor_id' => $id, 'reason' => 'job_updated'
            ]);

            $this->db->commit();
            \LaborPlatform\Services\ContentSearchService::invalidateCache();

            Response::ok(
                [
                    'id'=>$jobId
                ],
                'Cập nhật Tin tuyển dụng thành công.'
            );

        }catch(\Throwable $e){

            if($this->db->inTransaction())
                $this->db->rollBack();

            Response::error(
                'Không thể cập nhật Tin tuyển dụng.',
                500
            );
        }
    }
            public function submitReview(
        int $jobId
    ): never {

        $id=Auth::supplierId();
        $this->requireOperationalSupplier($id);

        $old=$this->getOwned(
            $jobId,
            $id
        );

        if(
            !in_array(
                $old['trang_thai'],
                [
                    'cho_duyet',
                    'can_chinh_sua'
                ],
                true
            )
        )
            Response::error(
                'Chỉ Tin tuyển dụng đang chờ duyệt hoặc cần chỉnh sửa mới được gửi lại duyệt.',
                409
            );

        $required=[
            'tieu_de',
            'nganh_nghe',
            'so_luong',
            'dia_diem',
            'mo_ta_cong_viec',
            'tong_thu_nhap_du_kien',
            'ho_tro_tien_xe_nguoi_lao_dong_o_xa'
        ];

        foreach($required as $f){

            if(
                trim(
                    (string)($old[$f]??'')
                )===''
            )
                Response::error(
                    "Tin chưa đủ nội dung bắt buộc: $f."
                );
        }

        if(
            !empty($old['ngay_het_han']) &&
            strtotime(
                $old['ngay_het_han']
            )<=time()
        )
            Response::error(
                'Ngày hết hạn không hợp lệ.'
            );

        $this->db->beginTransaction();

        try{

            $s=$this->db->prepare(
                'UPDATE tin_tuyen_dung
                 SET trang_thai="cho_duyet",
                     ngay_cap_nhat=NOW()
                 WHERE id=?
                   AND nha_cung_ung_id=?
                   AND trang_thai IN ("cho_duyet","can_chinh_sua")'
            );

            $s->execute([
                $jobId,
                $id
            ]);

            if(
                $s->rowCount()!==1
            )
                throw new \RuntimeException(
                    'Tin tuyển dụng không còn ở trạng thái có thể gửi duyệt.'
                );

            $moderation=$this->moderation->apply($jobId);

            $this->audit->log(
                'nha_cung_ung',
                $id,
                null,
                'tin_tuyen_dung',
                'gui_duyet',
                $old,
                [
                    'id'=>$jobId,
                    'trang_thai'=>$moderation['decision']==='auto_approved' ? 'dang_tuyen' : 'cho_duyet',
                    'trang_thai_truoc'=>$old['trang_thai'],
                    'moderation'=>$moderation
                ]
            );

            if($moderation['decision']!=='auto_approved')
                $this->notify->admin(
                    'Tin tuyển dụng cần kiểm tra',
                    'Tin #'.$jobId.' được đưa vào hàng chờ do hệ thống tự động phát hiện dấu hiệu cần kiểm tra.',
                    'tin_tuyen_dung'
                );

            $this->discoveryEvents->publishJobChanged($jobId, 'submitted', [
                'actor_type' => 'supplier', 'actor_id' => $id, 'reason' => 'job_submitted_for_review'
            ]);

            $this->db->commit();
            \LaborPlatform\Services\ContentSearchService::invalidateCache();

            if($moderation['decision']==='auto_approved') $this->matching->enqueueForJob($jobId);

            Response::ok(
                [
                    'id'=>$jobId,
                    'trang_thai'=>$moderation['decision']==='auto_approved' ? 'dang_tuyen' : 'cho_duyet',
                    'moderation'=>$moderation
                ],
                $moderation['decision']==='auto_approved'
                    ? 'Tin đã được hệ thống tự động kiểm tra và công khai.'
                    : 'Tin đã được đưa vào hàng chờ kiểm tra.'
            );

        }catch(
            \Throwable $e
        ){

            if(
                $this->db->inTransaction()
            )
                $this->db->rollBack();

            if(
                $e instanceof \RuntimeException
            )
                throw $e;

            Response::error(
                'Không thể gửi Tin tuyển dụng để duyệt.',
                500
            );
        }
            }
        public function status(
        int $jobId
    ): never {

        $id=Auth::supplierId();
        $this->requireOperationalSupplier($id);

        $b=Request::body();

        $new=(string)(
            $b['trang_thai']??''
        );

        $old=$this->getOwned(
            $jobId,
            $id
        );

        $allowed=[];

        if(
            $old['trang_thai']==='dang_tuyen'
        )
            $allowed=[
                'tam_dung',
                'da_dong'
            ];

        elseif(
            $old['trang_thai']==='tam_dung'
        )
            $allowed=[
                'dang_tuyen',
                'da_dong'
            ];

        elseif(
            $old['trang_thai']==='cho_duyet'
        )
            $allowed=[
                'da_dong'
            ];

        if(
            !in_array(
                $new,
                $allowed,
                true
            )
        )
            Response::error(
                'Chuyển trạng thái Tin tuyển dụng không được phép.',
                409
            );

        $dateSql=
            $new==='dang_tuyen'
            ?', ngay_dang=COALESCE(ngay_dang,NOW())'
            :'';

        $this->db->beginTransaction();

        try {
            $s=$this->db->prepare(
            'UPDATE tin_tuyen_dung
             SET trang_thai=?,
                 ngay_cap_nhat=NOW()'.
            $dateSql.
            '
             WHERE id=?
               AND nha_cung_ung_id=?'
        );

        $s->execute([
            $new,
            $jobId,
            $id
        ]);

        $this->audit->log(
            'nha_cung_ung',
            $id,
            null,
            'tin_tuyen_dung',
            'doi_trang_thai',
            $old,
            [
                'id'=>$jobId,
                'trang_thai'=>$new
            ]
        );

            $this->discoveryEvents->publishJobChanged($jobId, 'status_changed', [
                'actor_type' => 'supplier', 'actor_id' => $id, 'reason' => 'job_status_changed'
            ]);

            if($new==='dang_tuyen') $this->matching->enqueueForJob($jobId);

            $this->db->commit();
            \LaborPlatform\Services\ContentSearchService::invalidateCache();

            Response::ok(
                [
                    'id'=>$jobId,
                    'trang_thai'=>$new
                ],
                'Đã cập nhật trạng thái Tin tuyển dụng.'
            );
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            Response::error('Không thể cập nhật trạng thái Tin tuyển dụng.', 500);
        }
    }

    public function list(): never {

        $id=Auth::supplierId();

        $this->expireDueJobs(
            $id
        );

        $s=$this->db->prepare(
            'SELECT *
             FROM tin_tuyen_dung
             WHERE nha_cung_ung_id=?
             ORDER BY id DESC'
        );

        $s->execute([
            $id
        ]);

        Response::ok(
            $s->fetchAll(
                \PDO::FETCH_ASSOC
            )
        );
    }
        public function delete(
        int $jobId
    ): never {

        $id=Auth::supplierId();

        $old=$this->getOwned(
            $jobId,
            $id
        );

        if(
            in_array(
                $old['trang_thai'],
                [
                    'da_dong',
                    'het_han'
                ],
                true
            )
        )
            Response::error(
                'Tin đã đóng hoặc hết hạn, không thể xóa khỏi trang công khai.',
                409
            );

        /*
         * XÓA TIN = SOFT DELETE.
         *
         * Không DELETE bản ghi trong database.
         *
         * Tin chuyển sang da_dong để:
         *
         * - không còn xuất hiện công khai;
         * - không nhận Đăng ký hồ sơ mới;
         * - vẫn giữ toàn bộ lịch sử;
         * - vẫn giữ lịch sử Tin tuyển dụng;
         * - không khôi phục các nghiệp vụ hậu tuyển dụng;
         * - phục vụ nhật ký nghiệp vụ.
         */

        $this->db->beginTransaction();

        try{

            $s=$this->db->prepare(
                'UPDATE tin_tuyen_dung
                 SET trang_thai="da_dong",
                     ngay_cap_nhat=NOW()
                 WHERE id=?
                   AND nha_cung_ung_id=?'
            );

            $s->execute([
                $jobId,
                $id
            ]);

            $this->audit->log(
                'nha_cung_ung',
                $id,
                null,
                'tin_tuyen_dung',
                'xoa_tin',
                $old,
                [
                    'id'=>$jobId,
                    'trang_thai'=>'da_dong'
                ]
            );

            $this->discoveryEvents->publishJobChanged($jobId, 'deleted', [
                'actor_type' => 'supplier', 'actor_id' => $id, 'reason' => 'job_soft_deleted'
            ]);

            $this->db->commit();
            \LaborPlatform\Services\ContentSearchService::invalidateCache();

            Response::ok(
                null,
                'Đã đóng Tin tuyển dụng.'
            );

        }catch(\Throwable $e){

            if(
                $this->db->inTransaction()
            )
                $this->db->rollBack();

            Response::error(
                'Không thể đóng Tin tuyển dụng.',
                500
            );
        }
    }

    public function detail(
        int $jobId
    ): never {

        $supplierId=Auth::supplierId();

        $job=$this->getOwned(
            $jobId,
            $supplierId
        );

        Response::ok(
            $job
        );
    }

    private function expireDueJobs(
        int $supplierId
    ): void {

        $idsStmt=$this->db->prepare(
            'SELECT id FROM tin_tuyen_dung
             WHERE nha_cung_ung_id=?
               AND ngay_het_han IS NOT NULL
               AND ngay_het_han<=NOW()
               AND trang_thai IN ("dang_tuyen","tam_dung")'
        );
        $idsStmt->execute([$supplierId]);
        $expiredIds=array_map('intval',$idsStmt->fetchAll(\PDO::FETCH_COLUMN));

        if(!$expiredIds) return;

        $s=$this->db->prepare(
            'UPDATE tin_tuyen_dung
             SET trang_thai="het_han", ngay_cap_nhat=NOW()
             WHERE nha_cung_ung_id=?
               AND ngay_het_han IS NOT NULL
               AND ngay_het_han<=NOW()
               AND trang_thai IN ("dang_tuyen","tam_dung")'
        );
        $s->execute([$supplierId]);

        foreach($expiredIds as $expiredId){
            $this->discoveryEvents->publishJobChanged($expiredId, 'expired', [
                'actor_type' => 'system', 'actor_id' => 0, 'reason' => 'job_expired'
            ]);
        }
    }
}

    
    
                
