<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Request,Response,WorkerAuth};

final class WorkerFavoriteController {
    public function __construct(private \PDO $db) {}
    public function index(): never {
        $id=WorkerAuth::workerId($this->db);
        $q=$this->db->prepare('SELECT f.id,f.job_id,j.tieu_de AS title,j.dia_diem AS location,j.luong_co_ban AS salary FROM nguoi_lao_dong_tin_yeu_thich f JOIN tin_tuyen_dung j ON j.id=f.job_id WHERE f.nguoi_lao_dong_id=? ORDER BY f.id DESC');
        $q->execute([$id]);Response::ok($q->fetchAll());
    }
    public function add(): never {
        $id=WorkerAuth::workerId($this->db);$job=(int)(Request::input('job_id')??0);
        if($job<=0)Response::error('Tin tuyển dụng không hợp lệ.');
        $q=$this->db->prepare('SELECT id FROM tin_tuyen_dung WHERE id=? AND trang_thai="dang_tuyen" LIMIT 1');$q->execute([$job]);
        if(!$q->fetch())Response::error('Tin tuyển dụng không tồn tại hoặc chưa công khai.',404);
        $this->db->prepare('INSERT IGNORE INTO nguoi_lao_dong_tin_yeu_thich (nguoi_lao_dong_id,job_id) VALUES (?,?)')->execute([$id,$job]);
        Response::ok(null,'Đã lưu Tin tuyển dụng.');
    }
    public function remove(): never {
        $id=WorkerAuth::workerId($this->db);$job=(int)(Request::input('job_id')??0);
        $this->db->prepare('DELETE FROM nguoi_lao_dong_tin_yeu_thich WHERE nguoi_lao_dong_id=? AND job_id=?')->execute([$id,$job]);
        Response::ok(null,'Đã bỏ lưu Tin tuyển dụng.');
    }
}
