<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentTopicLocationService;

final class ContentTopicLocationController
{
    public function __construct(private ContentTopicLocationService $taxonomy) {}

    public function publicJob(int $jobId): never
    {
        try {
            Response::ok($this->taxonomy->generatePublicJobTaxonomy($jobId));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), $e->getCode() === 404 ? 404 : 400);
        }
    }
}
