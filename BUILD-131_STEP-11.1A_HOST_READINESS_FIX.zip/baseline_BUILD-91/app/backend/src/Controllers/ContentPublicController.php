<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentPublicService;

final class ContentPublicController
{
    public function __construct(private ContentPublicService $publicContent) {}

    public function publicJob(int $jobId): never
    {
        try {
            Response::ok($this->publicContent->publicJob($jobId));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tải nội dung công khai.', 500);
        }
    }
}
