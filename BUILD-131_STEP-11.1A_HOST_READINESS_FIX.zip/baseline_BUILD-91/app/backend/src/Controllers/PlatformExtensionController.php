<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\Response;
use LaborPlatform\Services\PlatformExtensionService;

final class PlatformExtensionController {
    public function __construct(private PlatformExtensionService $service) {}

    public function modules(): never {
        Response::ok($this->service->modules(),'Danh sách module khả dụng.');
    }

    public function dictionary(): never {
        $type=trim((string)($_GET['type']??''));
        if($type==='') Response::error('Thiếu loại danh mục.');
        Response::ok(['type'=>$type,'items'=>$this->service->dictionary($type)]);
    }

    public function profileSchema(): never {
        $subject=trim((string)($_GET['subject']??''));
        if(!in_array($subject,['worker','supplier'],true)) Response::error('Đối tượng hồ sơ không hợp lệ.');
        Response::ok(['subject'=>$subject,'fields'=>$this->service->profileSchema($subject)]);
    }

    public function apiVersion(): never {
        Response::ok([
            'platform_version'=>'1.0',
            'api_contract_version'=>'v1',
            'backward_compatibility'=>true,
            'build'=>'76'
        ]);
    }
}
