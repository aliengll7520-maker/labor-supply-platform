<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{
    AdminAuth,
    Response,
    Request
};

use LaborPlatform\Services\{
    AuditService,
    NotificationService,
    ContentDiscoveryEventService
};

final class AdminJobController
{
    public function __construct(
        private \PDO $db,
        private AuditService $audit,
        private NotificationService $notify,
        private ContentDiscoveryEventService $discoveryEvents
    ) {}

    private function getJob(
        int $jobId
    ): array {

        $stmt = $this->db->prepare(
            'SELECT
                t.*,
                n.ten_nha_cung_ung,
                n.trang_thai AS nha_cung_ung_trang_thai,
                n.xac_minh AS nha_cung_ung_xac_minh
             FROM tin_tuyen_dung t
             JOIN nha_cung_ung n
               ON n.id=t.nha_cung_ung_id
             WHERE t.id=?
             LIMIT 1'
        );

        $stmt->execute([
            $jobId
        ]);

        $row=$stmt->fetch();

        if(!$row)
            Response::error(
                'Không tìm thấy Tin tuyển dụng.',
                404
            );

        return $row;
    }

    public function list(): never
    {
        AdminAuth::requirePermission('jobs.view');

        $status=trim(
            (string)(
                $_GET['trang_thai']
                ?? 'cho_duyet'
            )
        );

        $allowed=[
            'cho_duyet',
            'can_chinh_sua',
            'dang_tuyen',
            'tam_dung',
            'het_han',
            'da_dong'
        ];

        if(
            !in_array(
                $status,
                $allowed,
                true
            )
        )
            Response::error(
                'Trạng thái Tin tuyển dụng không hợp lệ.'
            );

        $stmt=$this->db->prepare(
            'SELECT
                t.id,
                t.ma_tin,
                t.tieu_de,
                t.nganh_nghe,
                t.so_luong,
                t.dia_diem,
                t.tong_thu_nhap_du_kien,
                t.trang_thai,
                t.moderation_status,
                t.moderation_risk_score,
                t.moderation_version,
                t.moderation_reasons,
                t.moderation_at,
                t.ngay_tao,
                t.ngay_het_han,
                n.id AS nha_cung_ung_id,
                n.ma_nha_cung_ung,
                n.ten_nha_cung_ung,
                n.trang_thai AS nha_cung_ung_trang_thai,
                n.xac_minh AS nha_cung_ung_xac_minh
             FROM tin_tuyen_dung t
             JOIN nha_cung_ung n
               ON n.id=t.nha_cung_ung_id
             WHERE t.trang_thai=?
             ORDER BY
                t.ngay_tao ASC,
                t.id ASC'
        );

        $stmt->execute([
            $status
        ]);

        Response::ok(
            $stmt->fetchAll()
        );
    }

    public function action(
        int $jobId
    ): never {

        $adminId=
            AdminAuth::requirePermission('jobs.manage');

        $body=
            Request::body();

        $action=trim(
            (string)(
                $body['hanh_dong']
                ?? ''
            )
        );

        $note=trim(
            (string)(
                $body['ghi_chu']
                ?? ''
            )
        );

        if(
            !in_array(
                $action,
                [
                    'duyet',
                    'tu_choi'
                ],
                true
            )
        )
            Response::error(
                'Hành động duyệt Tin tuyển dụng không hợp lệ.'
            );

        $job=$this->getJob(
            $jobId
        );

        if(
            $job['trang_thai']
            !== 'cho_duyet'
        )
            Response::error(
                'Chỉ Tin tuyển dụng đang chờ duyệt mới được xử lý.',
                409
            );


        /*
         * KIỂM TRA ĐIỀU KIỆN CÔNG KHAI
         */

        if(
            $action==='duyet'
        ){

            if(
                $job['nha_cung_ung_trang_thai']
                !== 'hoat_dong'
                ||
                $job['nha_cung_ung_xac_minh']
                !== 'da_xac_minh'
            )
                Response::error(
                    'Nhà cung ứng chưa được xác minh và kích hoạt nên Tin không thể công khai.',
                    409
                );

            foreach(
                [
                    'tieu_de',
                    'nganh_nghe',
                    'so_luong',
                    'dia_diem',
                    'mo_ta_cong_viec',
                    'tong_thu_nhap_du_kien',
                    'ho_tro_tien_xe_nguoi_lao_dong_o_xa'
                ] as $field
            ){

                if(
                    trim(
                        (string)(
                            $job[$field]
                            ?? ''
                        )
                    )===''
                )
                    Response::error(
                        "Tin chưa đủ nội dung bắt buộc: {$field}.",
                        409
                    );
            }

            if(
                !empty(
                    $job['ngay_het_han']
                )
                &&
                strtotime(
                    $job['ngay_het_han']
                )<=time()
            )
                Response::error(
                    'Tin đã quá hạn nên không thể công khai.',
                    409
                );
        }


        $this->db->beginTransaction();

        try{

            /*
             * DUYỆT
             *
             * cho_duyet
             *      ↓
             * dang_tuyen
             */

            if(
                $action==='duyet'
            ){

                $stmt=$this->db->prepare(
                    'UPDATE tin_tuyen_dung
                     SET
                        trang_thai="dang_tuyen",
                        ngay_dang=
                            COALESCE(
                                ngay_dang,
                                NOW()
                            ),
                        ngay_cap_nhat=NOW()
                     WHERE id=?
                       AND trang_thai="cho_duyet"'
                );

                $stmt->execute([
                    $jobId
                ]);

                if(
                    $stmt->rowCount()!==1
                )
                    throw new \RuntimeException(
                        'Tin tuyển dụng không còn ở trạng thái chờ duyệt.'
                    );

                $this->audit->log(
                    'quan_tri',
                    $adminId,
                    $job['nha_cung_ung_id'],
                    'tin_tuyen_dung',
                    'duyet_cong_khai',
                    $job,
                    [
                        'id'=>$jobId,
                        'trang_thai'=>'dang_tuyen',
                        'ghi_chu'=>$note
                    ]
                );

                $this->notify->supplier(
                    (int)$job['nha_cung_ung_id'],
                    'Tin tuyển dụng đã được duyệt',
                    'Tin "'.$job['tieu_de'].'" đã được Quản trị duyệt và đang hiển thị công khai.',
                    'cap_nhat_trang_thai'
                );

                $message=
                    'Đã duyệt Tin tuyển dụng và công khai.';
            }


            /*
             * YÊU CẦU CHỈNH SỬA
             *
             * cho_duyet
             *      ↓
             * can_chinh_sua
             */

            else{

                $stmt=$this->db->prepare(
                    'UPDATE tin_tuyen_dung
                     SET
                        trang_thai="can_chinh_sua",
                        ngay_cap_nhat=NOW()
                     WHERE id=?
                       AND trang_thai="cho_duyet"'
                );

                $stmt->execute([
                    $jobId
                ]);

                if(
                    $stmt->rowCount()!==1
                )
                    throw new \RuntimeException(
                        'Tin tuyển dụng không còn ở trạng thái chờ duyệt.'
                    );

                $this->audit->log(
                    'quan_tri',
                    $adminId,
                    $job['nha_cung_ung_id'],
                    'tin_tuyen_dung',
                    'yeu_cau_chinh_sua',
                    $job,
                    [
                        'id'=>$jobId,
                        'trang_thai'=>'can_chinh_sua',
                        'ghi_chu'=>$note
                    ]
                );

                $this->notify->supplier(
                    (int)$job['nha_cung_ung_id'],
                    'Tin tuyển dụng cần chỉnh sửa',
                    'Tin "'.$job['tieu_de'].'" cần được chỉnh sửa trước khi có thể công khai.'
                    .
                    (
                        $note!==''
                        ? ' Ghi chú: '.$note
                        : ''
                    ),
                    'cap_nhat_trang_thai'
                );

                $message=
                    'Đã chuyển Tin tuyển dụng sang trạng thái cần chỉnh sửa.';
            }


            $this->discoveryEvents->publishJobChanged(
                $jobId,
                $action==='duyet' ? 'approved' : 'review_requested',
                [
                    'actor_type' => 'admin',
                    'actor_id' => $adminId,
                    'reason' => 'admin_job_action'
                ]
            );

            $this->db->commit();
                    \LaborPlatform\Services\ContentSearchService::invalidateCache();

            Response::ok(
                [
                    'id'=>$jobId,
                    'trang_thai'=>
                        $action==='duyet'
                        ? 'dang_tuyen'
                        : 'can_chinh_sua'
                ],
                $message
            );

        }catch(
            \Throwable $e
        ){

            if(
                $this->db->inTransaction()
            )
                $this->db->rollBack();

            if(
                $e instanceof \RuntimeException
            )
                throw $e;

            Response::error(
                'Không thể xử lý duyệt Tin tuyển dụng.',
                500
            );
        }
    }
}
