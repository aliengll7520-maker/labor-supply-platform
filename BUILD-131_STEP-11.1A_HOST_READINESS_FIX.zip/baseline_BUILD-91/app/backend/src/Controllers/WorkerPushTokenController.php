<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Request, Response};
use LaborPlatform\Services\PushNotificationService;

final class WorkerPushTokenController
{
    public function __construct(
        private \PDO $db,
        private PushNotificationService $push
    ) {
    }

    public function register(): never
    {
        $b = Request::body();

        $phone = trim((string)($b['so_dien_thoai'] ?? ''));
        $code = trim((string)($b['ma_nguoi_lao_dong'] ?? ''));
        $token = trim((string)($b['token'] ?? ''));
        $platform = strtolower(trim((string)($b['platform'] ?? '')));

        if ($phone === '' || $code === '' || $token === '' || $platform === '') {
            Response::error(
                'Vui lòng cung cấp Số điện thoại, Mã người lao động, Push token và nền tảng.'
            );
        }

        $q = $this->db->prepare(
            'SELECT id
             FROM nguoi_lao_dong
             WHERE so_dien_thoai=?
               AND ma_nguoi_lao_dong=?
               AND trang_thai="hoat_dong"
             LIMIT 1'
        );
        $q->execute([$phone, $code]);
        $workerId = (int)$q->fetchColumn();

        if ($workerId <= 0) {
            Response::error('Thông tin Người lao động không hợp lệ.', 401);
        }

        $this->push->registerWorkerToken($workerId, $token, $platform);

        Response::ok(null, 'Đã đăng ký thiết bị nhận thông báo.');
    }
}
