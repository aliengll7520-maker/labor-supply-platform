<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{AdminAuth,Response};
use LaborPlatform\Services\DataProtectionService;

final class AdminDataProtectionController
{
    public function __construct(private DataProtectionService $dataProtection) {}

    public function dataMap(): never
    {
        AdminAuth::requirePermission('security.view');
        Response::ok(['data_map'=>$this->dataProtection->dataMap()]);
    }

    public function accessMatrix(): never
    {
        AdminAuth::requirePermission('security.view');
        Response::ok(['access_matrix'=>$this->dataProtection->accessMatrix()]);
    }

    public function accessLog(): never
    {
        AdminAuth::requirePermission('security.view');
        $q=(new \ReflectionClass($this->dataProtection))->getProperty('db');
        $q->setAccessible(true);
        /** @var \PDO $db */
        $db=$q->getValue($this->dataProtection);
        $rows=$db->query('SELECT * FROM nhat_ky_truy_cap_du_lieu ORDER BY id DESC LIMIT 200')->fetchAll();
        Response::ok(['access_log'=>$rows]);
    }
}
