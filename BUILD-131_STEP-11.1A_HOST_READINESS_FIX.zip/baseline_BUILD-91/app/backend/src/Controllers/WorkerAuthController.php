<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Request,Response,WorkerAuth};
use LaborPlatform\Services\GoogleOAuthService;
use LaborPlatform\Services\PhoneMaskService;
use LaborPlatform\Services\IdentityService;

final class WorkerAuthController {
    public function __construct(private \PDO $db, private ?GoogleOAuthService $google=null, private ?IdentityService $identity=null) {}

    public function googleStart(): never {
        if (!$this->google || !$this->google->enabled()) Response::error('Đăng nhập Google chưa được cấu hình.',503);
        $state=bin2hex(random_bytes(32));
        $_SESSION['worker_google_oauth_state']=$state;
        $_SESSION['worker_google_oauth_started']=time();
        header('Location: '.$this->google->authorizationUrl($state), true, 302);
        exit;
    }

    public function googleCallback(): never {
        $state=trim((string)($_GET['state']??''));
        $expected=(string)($_SESSION['worker_google_oauth_state']??'');
        $started=(int)($_SESSION['worker_google_oauth_started']??0);
        unset($_SESSION['worker_google_oauth_state'],$_SESSION['worker_google_oauth_started']);
        if($state===''||$expected===''||!hash_equals($expected,$state)||$started<=0||time()-$started>600) $this->googleFailure('Phiên đăng nhập Google không hợp lệ hoặc đã hết hạn.');
        $code=trim((string)($_GET['code']??''));
        if($code==='') $this->googleFailure('Google không trả về mã xác thực.');
        try{$profile=$this->google?->exchangeCode($code);if(!$profile) throw new \RuntimeException('Google OAuth chưa được cấu hình.');}
        catch(\Throwable $e){$this->googleFailure('Không thể hoàn tất đăng nhập bằng Google.');}

        $q=$this->db->prepare('SELECT nguoi_lao_dong_id FROM nguoi_lao_dong_dang_nhap_lien_ket WHERE nha_cung_cap="google" AND provider_subject=? AND trang_thai="hoat_dong" LIMIT 1');
        $q->execute([$profile['sub']]); $workerId=(int)$q->fetchColumn();
        $isNew=false;
        if($workerId<=0){
            $q=$this->db->prepare('SELECT id FROM nguoi_lao_dong WHERE email=? LIMIT 1');
            $q->execute([$profile['email']]); $workerId=(int)$q->fetchColumn();
        }
        if($workerId<=0){
            $name=$profile['name']!==''?$profile['name']:'Người lao động';
            $codeWorker='NLD'.date('YmdHis').random_int(100,999);
            $this->db->beginTransaction();
            try{
                $q=$this->db->prepare('INSERT INTO nguoi_lao_dong (ma_nguoi_lao_dong,ho_ten,so_dien_thoai,email,que_quan,trang_thai) VALUES (?,?,?,?,?,"hoat_dong")');
                $q->execute([$codeWorker,$name,null,$profile['email'],'Chưa cập nhật']);
                $workerId=(int)$this->db->lastInsertId();
                $q=$this->db->prepare('INSERT INTO tai_khoan_nguoi_lao_dong (nguoi_lao_dong_id,mat_khau_hash,trang_thai) VALUES (?,"", "hoat_dong")');
                $q->execute([$workerId]);
                $isNew=true;
            }catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();$this->googleFailure('Không thể tạo tài khoản Người lao động.');}
        }
        $q=$this->db->prepare('SELECT n.ma_nguoi_lao_dong,n.ho_ten,n.so_dien_thoai,n.email,n.trang_thai,a.trang_thai AS account_status FROM nguoi_lao_dong n JOIN tai_khoan_nguoi_lao_dong a ON a.nguoi_lao_dong_id=n.id WHERE n.id=? LIMIT 1');
        $q->execute([$workerId]);$u=$q->fetch();
        if(!$u||$u['trang_thai']!=='hoat_dong'||$u['account_status']!=='hoat_dong') $this->googleFailure('Tài khoản Người lao động đang bị khóa.');
        if(!$this->db->inTransaction()) $this->db->beginTransaction();
        try {
            $q=$this->db->prepare('SELECT id FROM nguoi_lao_dong_dang_nhap_lien_ket WHERE nha_cung_cap="google" AND provider_subject=? LIMIT 1');
            $q->execute([$profile['sub']]);
            if(!$q->fetch()){
                $q=$this->db->prepare('INSERT INTO nguoi_lao_dong_dang_nhap_lien_ket (nguoi_lao_dong_id,nha_cung_cap,provider_subject,provider_email) VALUES (?,"google",?,?)');
                $q->execute([$workerId,$profile['sub'],$profile['email']]);
            } else {
                $this->db->prepare('UPDATE nguoi_lao_dong_dang_nhap_lien_ket SET ngay_su_dung_cuoi=NOW() WHERE nha_cung_cap="google" AND provider_subject=?')->execute([$profile['sub']]);
            }
            if((string)$u['email']==='') $this->db->prepare('UPDATE nguoi_lao_dong SET email=? WHERE id=?')->execute([$profile['email'],$workerId]);
            $token=bin2hex(random_bytes(32));
            $this->db->prepare('INSERT INTO nguoi_lao_dong_access_token (nguoi_lao_dong_id,token_hash,het_han_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))')->execute([$workerId,hash('sha256',$token)]);
            if($this->identity) $this->identity->syncWorker($workerId);
            $this->db->commit();
        } catch(\Throwable $e) {
            if($this->db->inTransaction()) $this->db->rollBack();
            $this->googleFailure('Không thể đồng bộ Identity. Vui lòng thử lại sau.');
        }
        $payload=['token'=>$token,'user'=>['id'=>$workerId,'name'=>$u['ho_ten'],'phone'=>PhoneMaskService::mask($u['so_dien_thoai']),'email'=>$profile['email'],'worker_code'=>$u['ma_nguoi_lao_dong']]];
        $frontend=(string)($_ENV['LABOR_FRONTEND_URL']??'');
        $frontend=$frontend!==''?$frontend:'/';
        header('Content-Type: text/html; charset=utf-8');
        $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<!doctype html><meta charset="utf-8"><title>Đăng nhập Google</title><script>const p='. $json .'; localStorage.setItem("worker_access_token",p.token); localStorage.setItem("worker_user",JSON.stringify(p.user)); location.replace("'.htmlspecialchars($frontend,ENT_QUOTES).'#/dashboard");</script><p>Đang hoàn tất đăng nhập...</p>';
        exit;
    }

    public function linkGoogleUrl(): never {
        $workerId=WorkerAuth::workerId($this->db);
        if (!$this->google || !$this->google->enabled()) Response::error('Đăng nhập Google chưa được cấu hình.',503);
        $state=bin2hex(random_bytes(32));
        $_SESSION['worker_google_link_state']=$state;
        $_SESSION['worker_google_link_worker_id']=$workerId;
        $_SESSION['worker_google_link_started']=time();
        Response::ok(['url'=>$this->google->authorizationUrl($state, $this->linkRedirectUri())],'Đã tạo liên kết Google.');
    }

    public function googleLinkCallback(): never {
        $state=trim((string)($_GET['state']??''));$expected=(string)($_SESSION['worker_google_link_state']??'');$workerId=(int)($_SESSION['worker_google_link_worker_id']??0);$started=(int)($_SESSION['worker_google_link_started']??0);
        unset($_SESSION['worker_google_link_state'],$_SESSION['worker_google_link_worker_id'],$_SESSION['worker_google_link_started']);
        if($state===''||$expected===''||$workerId<=0||!hash_equals($expected,$state)||time()-$started>600) $this->googleFailure('Phiên liên kết Google không hợp lệ hoặc đã hết hạn.');
        $code=trim((string)($_GET['code']??''));if($code==='')$this->googleFailure('Google không trả về mã xác thực.');
        try{$profile=$this->google?->exchangeCode($code, $this->linkRedirectUri());if(!$profile)throw new \RuntimeException();}catch(\Throwable $e){$this->googleFailure('Không thể liên kết Google.');}
        if(!$this->db->inTransaction()) $this->db->beginTransaction();
        try {
            $q=$this->db->prepare('SELECT nguoi_lao_dong_id FROM nguoi_lao_dong_dang_nhap_lien_ket WHERE nha_cung_cap="google" AND provider_subject=? LIMIT 1');$q->execute([$profile['sub']]);$existing=(int)$q->fetchColumn();
            if($existing>0 && $existing!==$workerId){ if($this->db->inTransaction()) $this->db->rollBack(); $this->googleFailure('Tài khoản Google này đã được liên kết với một tài khoản khác.'); }
            $q=$this->db->prepare('INSERT INTO nguoi_lao_dong_dang_nhap_lien_ket (nguoi_lao_dong_id,nha_cung_cap,provider_subject,provider_email) VALUES (?,"google",?,?) ON DUPLICATE KEY UPDATE trang_thai="hoat_dong",provider_email=VALUES(provider_email),ngay_su_dung_cuoi=NOW()');$q->execute([$workerId,$profile['sub'],$profile['email']]);
            $this->db->prepare('UPDATE nguoi_lao_dong SET email=COALESCE(NULLIF(email,""),?) WHERE id=?')->execute([$profile['email'],$workerId]);
            $this->db->prepare('INSERT INTO nguoi_lao_dong_lien_ket_audit (nguoi_lao_dong_id,hanh_dong,nha_cung_cap) VALUES (?,"link", "google")')->execute([$workerId]);
            if($this->identity) $this->identity->syncWorker($workerId);
            $this->db->commit();
        } catch(\Throwable $e) {
            if($this->db->inTransaction()) $this->db->rollBack();
            $this->googleFailure('Không thể liên kết Google và đồng bộ Identity.');
        }
        $frontend=(string)($_ENV['LABOR_FRONTEND_URL']??'');$frontend=$frontend!==''?$frontend:'/';header('Content-Type: text/html; charset=utf-8');echo '<!doctype html><meta charset="utf-8"><script>location.replace("'.htmlspecialchars($frontend,ENT_QUOTES).'#/profile?google_linked=1");</script><p>Đã liên kết Google.</p>';exit;
    }


    private function linkRedirectUri(): string {
        $base=(string)(getenv('GOOGLE_REDIRECT_URI') ?: '');
        if($base!=='') return preg_replace('#/callback$#','/link/callback',$base) ?: $base;
        return '/api/worker/auth/google/link/callback';
    }

    private function googleFailure(string $message): never {
        $frontend=(string)($_ENV['LABOR_FRONTEND_URL']??'');$frontend=$frontend!==''?$frontend:'/';header('Content-Type: text/html; charset=utf-8');echo '<!doctype html><meta charset="utf-8"><script>location.replace("'.htmlspecialchars($frontend,ENT_QUOTES).'#/login?google_error='.rawurlencode($message).'");</script><p>'.htmlspecialchars($message,ENT_QUOTES).'</p>';exit;
    }

    public function register(): never {
        $b=Request::body();
        $name=trim((string)($b['name']??$b['ho_ten']??''));
        $phone=trim((string)($b['phone']??$b['so_dien_thoai']??''));
        $pass=(string)($b['password']??$b['mat_khau']??'');
        if($name===''||$phone===''||strlen($pass)<6) Response::error('Vui lòng nhập họ tên, số điện thoại và mật khẩu từ 6 ký tự.');
        $q=$this->db->prepare('SELECT id FROM nguoi_lao_dong WHERE so_dien_thoai=? LIMIT 1');$q->execute([$phone]);
        if($q->fetch()) Response::error('Số điện thoại đã được đăng ký.',409);
        $code='NLD'.date('YmdHis').random_int(100,999);
        $this->db->beginTransaction();
        try{
            $q=$this->db->prepare('INSERT INTO nguoi_lao_dong (ma_nguoi_lao_dong,ho_ten,so_dien_thoai,que_quan,trang_thai) VALUES (?,?,?,?, "hoat_dong")');
            $q->execute([$code,$name,$phone,'Chưa cập nhật']);
            $id=(int)$this->db->lastInsertId();
            $q=$this->db->prepare('INSERT INTO tai_khoan_nguoi_lao_dong (nguoi_lao_dong_id,mat_khau_hash,trang_thai) VALUES (?,?, "hoat_dong")');
            $q->execute([$id,password_hash($pass,PASSWORD_DEFAULT)]);
            $token=bin2hex(random_bytes(32));
            $q=$this->db->prepare('INSERT INTO nguoi_lao_dong_access_token (nguoi_lao_dong_id,token_hash,het_han_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))');
            $q->execute([$id,hash('sha256',$token)]);
            if($this->identity) $this->identity->syncWorker($id);
            $this->db->commit();
            Response::ok(['token'=>$token,'user'=>['id'=>$id,'name'=>$name,'phone'=>PhoneMaskService::mask($phone),'worker_code'=>$code]],'Đăng ký thành công.',201);
        }catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();Response::error('Không thể đăng ký tài khoản.',500);}
    }
    public function login(): never {
        $b=Request::body();$login=trim((string)($b['identifier']??$b['phone']??$b['so_dien_thoai']??''));$pass=(string)($b['password']??$b['mat_khau']??'');
        if($login===''||$pass==='')Response::error('Vui lòng nhập thông tin đăng nhập.');
        $q=$this->db->prepare('SELECT a.id AS account_id,a.nguoi_lao_dong_id,a.mat_khau_hash,n.ma_nguoi_lao_dong,n.ho_ten,n.so_dien_thoai,n.trang_thai FROM tai_khoan_nguoi_lao_dong a JOIN nguoi_lao_dong n ON n.id=a.nguoi_lao_dong_id WHERE n.so_dien_thoai=? AND a.trang_thai="hoat_dong" LIMIT 1');
        $q->execute([$login]);$u=$q->fetch();
        if(!$u||!password_verify($pass,$u['mat_khau_hash']))Response::error('Thông tin đăng nhập không đúng.',401);
        if($u['trang_thai']!=='hoat_dong')Response::error('Tài khoản Người lao động đang bị khóa.',403);
        $token=bin2hex(random_bytes(32));
        $this->db->beginTransaction();
        try {
            $this->db->prepare('INSERT INTO nguoi_lao_dong_access_token (nguoi_lao_dong_id,token_hash,het_han_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))')->execute([(int)$u['nguoi_lao_dong_id'],hash('sha256',$token)]);
            if($this->identity) $this->identity->syncWorker((int)$u['nguoi_lao_dong_id']);
            $this->db->commit();
        } catch(\Throwable $e) {
            if($this->db->inTransaction()) $this->db->rollBack();
            Response::error('Không thể đồng bộ Identity. Vui lòng thử lại sau.',500);
        }
        Response::ok(['token'=>$token,'user'=>['id'=>(int)$u['nguoi_lao_dong_id'],'name'=>$u['ho_ten'],'phone'=>PhoneMaskService::mask($u['so_dien_thoai']),'worker_code'=>$u['ma_nguoi_lao_dong']]],'Đăng nhập thành công.');
    }
}
