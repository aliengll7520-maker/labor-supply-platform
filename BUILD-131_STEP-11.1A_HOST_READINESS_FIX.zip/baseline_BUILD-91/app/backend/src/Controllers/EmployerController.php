<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,Response,Request,AdminAuth};
use LaborPlatform\Services\AuditService;
use LaborPlatform\Services\PhoneMaskService;

final class EmployerController {
    public function __construct(private \PDO $db, private AuditService $audit, private bool $liveEnabled = true) {}

    private function assertLiveEnabled(): void {
        if (!$this->liveEnabled) Response::error('Live Production đang được tạm dừng.',503);
    }

    public function candidateDetail(int $candidateId): never {
        $supplierId=Auth::supplierId();
        $q=$this->db->prepare('SELECT h.id,h.ma_ho_so,h.ho_ten,h.que_quan,h.trang_thai,h.nha_cung_ung_xac_nhan,h.nguoi_lao_dong_xac_nhan,h.ket_qua_doi_chieu,h.ghi_chu,h.ngay_tao,h.ngay_cap_nhat,t.id AS tin_id,t.ma_tin,t.tieu_de,t.dia_diem,t.luong_co_ban FROM dang_ky_ho_so_phong_van h JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id WHERE h.id=? AND h.nha_cung_ung_id=? LIMIT 1');
        $q->execute([$candidateId,$supplierId]); $candidate=$q->fetch();
        if(!$candidate) Response::error('Không tìm thấy hồ sơ ứng viên.',404);
        $q=$this->db->prepare('SELECT id,nguoi_thuc_hien,phuong_thuc,chieu_lien_he,ket_qua,thoi_gian,ghi_chu FROM lien_he_dang_ky_ho_so_phong_van WHERE dang_ky_ho_so_phong_van_id=? ORDER BY id DESC');
        $q->execute([$candidateId]); $contacts=$q->fetchAll();
        Response::ok(['ung_vien'=>$candidate,'lich_su_lien_he'=>$contacts]);
    }

    public function accounts(): never {
        $sid=Auth::supplierId();
        $q=$this->db->prepare('SELECT id,ten_dang_nhap,email,so_dien_thoai,ten_hien_thi,vai_tro,co_quyen_live,trang_thai,lan_dang_nhap_cuoi,ngay_tao FROM tai_khoan_nha_cung_ung WHERE nha_cung_ung_id=? ORDER BY id ASC');
        $q->execute([$sid]); $rows=$q->fetchAll(); foreach($rows as &$r){$r['so_dien_thoai']=PhoneMaskService::mask($r['so_dien_thoai']??null);} Response::ok($rows);
    }
    public function createAccount(): never {
        $sid=Auth::supplierId(); if(!Auth::canManageAccounts()) Response::error('Chỉ Chủ sở hữu hoặc Quản lý được quản lý tài khoản thành viên.',403);
        $b=Request::body(); $username=trim((string)($b['ten_dang_nhap']??'')); $password=(string)($b['mat_khau']??''); $name=trim((string)($b['ten_hien_thi']??'')); $role=(string)($b['vai_tro']??'nhan_vien'); $live=!empty($b['co_quyen_live']);
        if(!preg_match('/^[A-Za-z0-9_.-]{4,100}$/',$username)) Response::error('Tên đăng nhập 4-100 ký tự, chỉ gồm chữ, số, ., _, -.');
        if(strlen($password)<8) Response::error('Mật khẩu phải có ít nhất 8 ký tự.');
        if(!in_array($role,['quan_ly','nhan_vien'],true)) Response::error('Vai trò tài khoản không hợp lệ.');
        $q=$this->db->prepare('SELECT id FROM tai_khoan_nha_cung_ung WHERE ten_dang_nhap=? LIMIT 1'); $q->execute([$username]); if($q->fetch()) Response::error('Tên đăng nhập đã tồn tại.',409);
        $q=$this->db->prepare('INSERT INTO tai_khoan_nha_cung_ung (nha_cung_ung_id,ten_dang_nhap,mat_khau_hash,trang_thai,vai_tro,ten_hien_thi,co_quyen_live) VALUES (?,?,?,?,?,?,?)');
        $q->execute([$sid,$username,password_hash($password,PASSWORD_DEFAULT),'hoat_dong',$role,$name?:$username,$live?1:0]); $id=(int)$this->db->lastInsertId();
        $this->audit->log('nha_cung_ung',$sid,null,'tai_khoan_nha_cung_ung','tao_tai_khoan_thanh_vien',null,['tai_khoan_id'=>$id,'vai_tro'=>$role,'co_quyen_live'=>$live]);
        Response::ok(['id'=>$id,'ten_dang_nhap'=>$username,'vai_tro'=>$role,'co_quyen_live'=>$live],'Đã tạo tài khoản thành viên. Tài khoản có thể đăng nhập đồng thời với các tài khoản khác của cùng đơn vị.');
    }
    public function updateAccount(int $accountId): never {
        $sid=Auth::supplierId(); if(!Auth::canManageAccounts()) Response::error('Chỉ Chủ sở hữu hoặc Quản lý được quản lý tài khoản thành viên.',403);
        if($accountId===Auth::accountId()) Response::error('Không dùng chức năng này để sửa tài khoản đang đăng nhập.',400);
        $b=Request::body(); $role=(string)($b['vai_tro']??'nhan_vien'); $live=!empty($b['co_quyen_live']); $status=(string)($b['trang_thai']??'hoat_dong');
        if(!in_array($role,['quan_ly','nhan_vien'],true)||!in_array($status,['hoat_dong','khoa'],true)) Response::error('Dữ liệu tài khoản không hợp lệ.');
        $q=$this->db->prepare('SELECT id FROM tai_khoan_nha_cung_ung WHERE id=? AND nha_cung_ung_id=?');$q->execute([$accountId,$sid]);if(!$q->fetch())Response::error('Không tìm thấy tài khoản.',404);
        $this->db->prepare('UPDATE tai_khoan_nha_cung_ung SET vai_tro=?,co_quyen_live=?,trang_thai=? WHERE id=? AND nha_cung_ung_id=?')->execute([$role,$live?1:0,$status,$accountId,$sid]);
        $this->audit->log('nha_cung_ung',$sid,null,'tai_khoan_nha_cung_ung','cap_nhat_quyen_thanh_vien',null,['tai_khoan_id'=>$accountId,'vai_tro'=>$role,'co_quyen_live'=>$live,'trang_thai'=>$status]); Response::ok(null,'Đã cập nhật quyền tài khoản.');
    }
    public function liveRooms(): never { $sid=Auth::supplierId(); $q=$this->db->prepare('SELECT id,tieu_de,mo_ta,trang_thai,bat_dau_du_kien,bat_dau_thuc_te,ket_thuc,room_key,ngay_tao FROM phong_live_nha_cung_ung WHERE nha_cung_ung_id=? ORDER BY id DESC LIMIT 50');$q->execute([$sid]);Response::ok($q->fetchAll()); }
    public function createLiveRoom(): never { $this->assertLiveEnabled(); $sid=Auth::supplierId(); if(!Auth::canLive())Response::error('Tài khoản chưa được cấp quyền Live.',403); $b=Request::body();$title=trim((string)($b['tieu_de']??''));if($title==='')Response::error('Tiêu đề Live không được để trống.');$key='live-'.$sid.'-'.bin2hex(random_bytes(8));$q=$this->db->prepare('INSERT INTO phong_live_nha_cung_ung (nha_cung_ung_id,nguoi_tao_tai_khoan_id,tieu_de,mo_ta,trang_thai,bat_dau_du_kien,room_key) VALUES (?,?,?,?,"nhap",?,?)');$q->execute([$sid,Auth::accountId(),$title,trim((string)($b['mo_ta']??''))?:null,($b['bat_dau_du_kien']??null),$key]);$id=(int)$this->db->lastInsertId();$this->audit->log('nha_cung_ung',$sid,null,'phong_live_nha_cung_ung','tao_phong_live',null,['id'=>$id,'room_key'=>$key]);Response::ok(['id'=>$id,'room_key'=>$key,'trang_thai'=>'nhap'],'Đã tạo phòng Live. Hệ thống chưa thu phí nền tảng.'); }

}
