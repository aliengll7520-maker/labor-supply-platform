<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentFeedService;

final class ContentFeedController
{
    public function __construct(private ContentFeedService $feed) {}

    public function publicJobs(): never
    {
        try {
            Response::ok($this->feed->publicJobs($_GET));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tải bảng tin.', 500);
        }
    }
}
