<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Request,Response,WorkerAuth};
use LaborPlatform\Services\PhoneMaskService;
final class WorkerProfileController {
 public function __construct(private \PDO $db) {}
 public function show(): never {
  $id=WorkerAuth::workerId($this->db);
  $q=$this->db->prepare('SELECT n.id,n.ma_nguoi_lao_dong AS worker_code,n.ho_ten AS full_name,n.so_dien_thoai AS phone,n.que_quan AS address,n.trang_thai FROM nguoi_lao_dong n WHERE n.id=?');
  $q->execute([$id]);$row=$q->fetch();if(!$row)Response::error('Không tìm thấy hồ sơ.',404);
  $row['phone']=PhoneMaskService::mask($row['phone']??null);
  $q=$this->db->prepare('SELECT ngay_sinh AS date_of_birth,gioi_tinh AS gender,province,district,occupation,skills,experience,education,avatar_url,bio,desired_position,desired_location,desired_salary,cong_doan_trang_thai,cong_doan_ten FROM ho_so_nghe_nghiep_nguoi_lao_dong WHERE nguoi_lao_dong_id=? LIMIT 1');
  $q->execute([$id]);$extra=$q->fetch() ?: [];Response::ok(array_merge($row,$extra));
 }
 public function update(): never {
  $id=WorkerAuth::workerId($this->db);$b=Request::body();
  $status=(string)($b['cong_doan_trang_thai']??'khong_khai_bao');
  if(!in_array($status,['co','khong','khong_khai_bao'],true))Response::error('Trạng thái Công đoàn không hợp lệ.');
  $unionName=trim((string)($b['cong_doan_ten']??''));if($status==='co'&&$unionName==='')Response::error('Vui lòng khai báo tên Công đoàn.');
  $q=$this->db->prepare('INSERT INTO ho_so_nghe_nghiep_nguoi_lao_dong (nguoi_lao_dong_id,ngay_sinh,gioi_tinh,province,district,occupation,skills,experience,education,avatar_url,bio,desired_position,desired_location,desired_salary,cong_doan_trang_thai,cong_doan_ten) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE ngay_sinh=VALUES(ngay_sinh),gioi_tinh=VALUES(gioi_tinh),province=VALUES(province),district=VALUES(district),occupation=VALUES(occupation),skills=VALUES(skills),experience=VALUES(experience),education=VALUES(education),avatar_url=VALUES(avatar_url),bio=VALUES(bio),desired_position=VALUES(desired_position),desired_location=VALUES(desired_location),desired_salary=VALUES(desired_salary),cong_doan_trang_thai=VALUES(cong_doan_trang_thai),cong_doan_ten=VALUES(cong_doan_ten)');
  $q->execute([$id,$b['date_of_birth']??null,$b['gender']??null,$b['province']??null,$b['district']??null,$b['occupation']??null,$b['skills']??null,$b['experience']??null,$b['education']??null,$b['avatar_url']??null,$b['bio']??null,$b['desired_position']??null,$b['desired_location']??null,$b['desired_salary']??null,$status,$status==='co'?$unionName:null]);$this->show();
 }
}
