<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{AdminAuth,Response,Request};
use LaborPlatform\Services\{AuditService,NotificationService};

final class AdminSupplierController {
 public function __construct(private \PDO $db,private AuditService $audit,private NotificationService $notify){}

 private function supplier(int $id): array {
  $q=$this->db->prepare(
   'SELECT n.id,n.ma_nha_cung_ung,n.ten_nha_cung_ung,n.ten_don_vi,n.loai_don_vi,
           n.ma_so_thue,n.nguoi_dai_dien,n.xac_minh,n.trang_thai,
           n.tong_tin_tuyen_dung,n.tong_dang_ky_ho_so_phong_van,
           n.ti_le_phan_hoi,n.ngay_tao,n.ngay_cap_nhat,n.ghi_chu_quan_tri,
           a.id AS tai_khoan_id,a.ten_dang_nhap,a.trang_thai AS tai_khoan_trang_thai
    FROM nha_cung_ung n LEFT JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id
    WHERE n.id=? ORDER BY a.id ASC LIMIT 1'
  );
  $q->execute([$id]);$row=$q->fetch();
  if(!$row)Response::error('Không tìm thấy Nhà cung ứng.',404);
  return $row;
 }

 public function login(): never {
  $b=Request::body();$login=trim((string)($b['login']??''));$pass=(string)($b['mat_khau']??'');
  if($login===''||$pass==='')Response::error('Vui lòng nhập thông tin đăng nhập.');
  $q=$this->db->prepare('SELECT * FROM tai_khoan_quan_tri WHERE (ten_dang_nhap=? OR email=?) LIMIT 1');
  $q->execute([$login,$login]);$a=$q->fetch();
  if(!$a||!password_verify($pass,$a['mat_khau_hash']))Response::error('Thông tin đăng nhập không đúng.',401);
  if($a['trang_thai']!=='hoat_dong')Response::error('Tài khoản Quản trị đang bị khóa.',403);
  $this->db->prepare('UPDATE tai_khoan_quan_tri SET lan_dang_nhap_cuoi=NOW() WHERE id=?')->execute([$a['id']]);
  AdminAuth::login((int)$a['id'],$a['vai_tro']);
  Response::ok(['ho_ten'=>$a['ho_ten'],'vai_tro'=>$a['vai_tro']],'Đăng nhập Quản trị thành công.');
 }
 public function logout(): never{AdminAuth::accountId();AdminAuth::logout();Response::ok(null,'Đã đăng xuất Quản trị.');}
 public function me(): never{
  $id=AdminAuth::accountId();$q=$this->db->prepare('SELECT id,ten_dang_nhap,email,ho_ten,vai_tro,trang_thai,lan_dang_nhap_cuoi FROM tai_khoan_quan_tri WHERE id=?');$q->execute([$id]);Response::ok($q->fetch());
 }

 public function list(): never {
  AdminAuth::requirePermission('suppliers.view');
  $status=$_GET['trang_thai']??'';
  $sql='SELECT n.id,n.ma_nha_cung_ung,n.ten_nha_cung_ung,n.nguoi_dai_dien,n.xac_minh,n.trang_thai,n.tong_tin_tuyen_dung,n.tong_dang_ky_ho_so_phong_van,n.ti_le_phan_hoi,n.ngay_cap_nhat,a.trang_thai AS tai_khoan_trang_thai
        FROM nha_cung_ung n LEFT JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id';
  $params=[];
  if($status!==''){$sql.=' WHERE n.trang_thai=?';$params[]=$status;}
  $sql.=' ORDER BY n.ngay_cap_nhat DESC,n.id DESC';
  $q=$this->db->prepare($sql);$q->execute($params);Response::ok($q->fetchAll());
 }

 public function detail(int $id): never {
  AdminAuth::requirePermission('suppliers.view');$n=$this->supplier($id);
  // Admin chỉ xem thông tin cần thiết để bảo vệ hệ thống và xử lý ngoại lệ.
  // Không tải hồ sơ ứng viên, lịch hẹn, hồ sơ làm việc hoặc dữ liệu vận hành của Doanh nghiệp/Nhà cung ứng.
  $data=[];
  $q=$this->db->prepare('SELECT * FROM nhat_ky_he_thong WHERE doi_tuong="nha_cung_ung" AND doi_tuong_id=? ORDER BY id DESC LIMIT 100');$q->execute([$id]);$data['nhat_ky']=$q->fetchAll();
  Response::ok(['nha_cung_ung'=>$n,'du_lieu'=>$data]);
 }

 public function action(int $id): never {
  $aid=AdminAuth::requirePermission('suppliers.manage');$b=Request::body();$action=(string)($b['hanh_dong']??'');
  $allowed=['duyet_kich_hoat','tu_choi_xac_minh','yeu_cau_xac_minh_lai','khoa','mo_khoa','tam_dung','hoat_dong'];
  if(!in_array($action,$allowed,true))Response::error('Hành động Quản trị không hợp lệ.');
  $old=$this->supplier($id);
  $this->db->beginTransaction();
  try{
   $status=$old['trang_thai'];$verify=$old['xac_minh'];$account=$old['tai_khoan_trang_thai'];
   if($action==='duyet_kich_hoat'){
    if(!in_array($verify,['dang_xac_minh','can_xac_minh_lai'],true))Response::error('Nhà cung ứng chưa có hồ sơ xác minh cần duyệt.',409);
    $status='hoat_dong';$verify='da_xac_minh';$account='hoat_dong';
   }elseif($action==='tu_choi_xac_minh'||$action==='yeu_cau_xac_minh_lai'){
    $verify='can_xac_minh_lai';$status='cho_duyet';$account='cho_xac_minh';
   }elseif($action==='khoa'){
    $status='tam_khoa';$account='khoa';
   }elseif($action==='mo_khoa'){
    $status='hoat_dong';$account='hoat_dong';
   }elseif($action==='tam_dung'){
    $status='tam_khoa';$account='hoat_dong';
   }elseif($action==='hoat_dong'){
    $status='hoat_dong';$account='hoat_dong';
   }
   $note=trim((string)($b['ghi_chu']??''));
   $this->db->prepare('UPDATE nha_cung_ung SET trang_thai=?,xac_minh=?,ghi_chu_quan_tri=? WHERE id=?')->execute([$status,$verify,$note?:null,$id]);
   if($old['tai_khoan_id'])$this->db->prepare('UPDATE tai_khoan_nha_cung_ung SET trang_thai=? WHERE id=?')->execute([$account,$old['tai_khoan_id']]);
   $this->audit->log('quan_tri',$aid,$id,'nha_cung_ung',$action,$old,['trang_thai'=>$status,'xac_minh'=>$verify,'tai_khoan_trang_thai'=>$account,'ghi_chu'=>$note]);
   $this->notify->supplier($id,'Cập nhật trạng thái Nhà cung ứng','Quản trị viên đã cập nhật trạng thái: '.$action.'.','cap_nhat_trang_thai',null);
   $this->db->commit();Response::ok(null,'Đã cập nhật Nhà cung ứng.');
  }catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();if($e instanceof \RuntimeException)throw $e;Response::error('Không thể cập nhật Nhà cung ứng.',500);}
 }
}
