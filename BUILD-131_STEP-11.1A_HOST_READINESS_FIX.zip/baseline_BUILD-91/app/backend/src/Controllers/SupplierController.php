<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Auth,Response,Request};
use LaborPlatform\Services\AuditService;
use LaborPlatform\Services\IdentityService;

final class SupplierController {
 public function __construct(private \PDO $db, private AuditService $audit, private ?IdentityService $identity=null, private ?\LaborPlatform\Services\TaxAuthorityVerificationService $taxVerification=null) {}
 public function register(): never {
  $b=Request::body();
  foreach(['loai_don_vi','ten_don_vi','nguoi_dai_dien','so_dien_thoai','mat_khau'] as $f) if(trim((string)($b[$f]??''))==='') Response::error("Thiếu trường: $f");
  if(strlen((string)$b['mat_khau'])<8) Response::error('Mật khẩu phải có ít nhất 8 ký tự.');
  $phone=trim((string)$b['so_dien_thoai']); if(!preg_match('/^[0-9+ .()-]{8,20}$/',$phone)) Response::error('Số điện thoại không hợp lệ.');
  $email=trim((string)($b['email']??'')); if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL)) Response::error('Email không hợp lệ.');
  $loaiDonVi=trim((string)$b['loai_don_vi']);
  $tenDonVi=trim((string)$b['ten_don_vi']);
  $allowedTypes=['doanh_nghiep','ho_kinh_doanh','hop_tac_xa','to_chuc','ca_nhan'];
  if(!in_array($loaiDonVi,$allowedTypes,true)) Response::error('Loại đơn vị sử dụng lao động không hợp lệ.');

  $taxCode=$this->taxVerification?->normalize((string)($b['ma_so_thue']??'')) ?? '';
  $tax=['ok'=>false,'status'=>'not_required','tax_code'=>$taxCode];
  if($loaiDonVi==='doanh_nghiep') {
   if($taxCode==='') Response::error('Mã số thuế là bắt buộc đối với doanh nghiệp.');
   if(!$this->taxVerification) Response::error('Dịch vụ xác thực Mã số thuế chưa được cấu hình.',503);
   // Verify before opening the DB transaction: external latency must never hold DB locks.
   $tax=$this->taxVerification->verify($taxCode);
   if(!$tax['ok']) Response::error((string)$tax['message'], in_array($tax['status'],['provider_unavailable','provider_not_configured','provider_invalid_response'],true)?503:422);
  }

  $supplierStatus=($loaiDonVi==='doanh_nghiep' && $tax['ok'])?'hoat_dong':'cho_duyet';
  $verifyStatus=($loaiDonVi==='doanh_nghiep' && $tax['ok'])?'da_xac_minh':'chua_xac_minh';
  $accountStatus=$supplierStatus==='hoat_dong'?'hoat_dong':'cho_xac_minh';
  $this->db->beginTransaction();
  try {
   $q=$this->db->prepare('SELECT id FROM nha_cung_ung WHERE so_dien_thoai=? LIMIT 1');$q->execute([$phone]);if($q->fetch())Response::error('Số điện thoại đã được đăng ký.',409);
   if($email!==''){ $q=$this->db->prepare('SELECT id FROM nha_cung_ung WHERE email=? LIMIT 1');$q->execute([$email]);if($q->fetch())Response::error('Email đã được đăng ký.',409); }
   if($taxCode!==''){ $q=$this->db->prepare('SELECT id FROM nha_cung_ung WHERE ma_so_thue=? LIMIT 1');$q->execute([$taxCode]);if($q->fetch())Response::error('Mã số thuế đã được đăng ký.',409); }
   $code='NLD'.date('YmdHis').random_int(100,999);
   $q=$this->db->prepare('INSERT INTO nha_cung_ung (ma_nha_cung_ung,ten_nha_cung_ung,ten_don_vi,loai_don_vi,ma_so_thue,nguoi_dai_dien,so_dien_thoai,email,dia_chi,google_maps,trang_thai,xac_minh,tax_status,tax_verified_at,tax_verification_source,tax_provider_request_id,tax_response_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
   $q->execute([$code,$tenDonVi,$tenDonVi,$loaiDonVi,$taxCode!==''?$taxCode:null,trim((string)$b['nguoi_dai_dien']),$phone,$email?:null,$b['dia_chi']??null,$b['google_maps']??null,$supplierStatus,$verifyStatus,$tax['status']??'not_required',null,$tax['ok']?'tax_authority_adapter':null,$tax['verification_evidence']['provider_request_id']??null,$tax['verification_evidence']['response_hash']??null]);
   // PDO cannot bind NOW() as an expression; normalize the timestamp immediately after insert.
   $sid=(int)$this->db->lastInsertId();
   if($tax['ok']) $this->db->prepare('UPDATE nha_cung_ung SET tax_verified_at=NOW() WHERE id=?')->execute([$sid]);
   $q=$this->db->prepare('INSERT INTO tai_khoan_nha_cung_ung (nha_cung_ung_id,email,so_dien_thoai,mat_khau_hash,ten_dang_nhap,trang_thai,vai_tro,co_quyen_live,ten_hien_thi) VALUES (?,?,?,?,?,?,?,?,?)');
   $q->execute([$sid,$email?:null,$phone,password_hash($b['mat_khau'],PASSWORD_DEFAULT),$code,$accountStatus,$supplierStatus==='hoat_dong'?'chu_so_huu':'chu_so_huu',$supplierStatus==='hoat_dong'?1:0,$tenDonVi]);$aid=(int)$this->db->lastInsertId();
   $this->audit->log('nha_cung_ung',$sid,null,'nha_cung_ung','dang_ky',null,['id'=>$sid,'ma'=>$code,'loai_don_vi'=>$loaiDonVi,'ten_don_vi'=>$tenDonVi,'tax_verification'=>['status'=>$tax['status'],'provider_status'=>$tax['provider_status']??null]]);
   // Identity sync is part of the same DB transaction: if it fails, supplier/account creation rolls back atomically.
   if($this->identity) $this->identity->syncEmployerAccount($aid,$sid);
   $this->db->commit();
   Auth::login($aid,$sid,$supplierStatus==='hoat_dong');
   Auth::setAccountContext('chu_so_huu',$supplierStatus==='hoat_dong');
   Response::ok(['id'=>$sid,'ma_nha_cung_ung'=>$code,'trang_thai'=>$supplierStatus,'xac_minh'=>$verifyStatus,'tax_verification'=>$tax['status'],'can_post_jobs'=>$supplierStatus==='hoat_dong'],'Đăng ký thành công. Mã số thuế đã được xác thực và tài khoản đã được kích hoạt.');
  }catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();if($e instanceof \RuntimeException)throw $e;Response::error('Không thể đăng ký Đơn vị sử dụng lao động.',500);}
 }
 public function login(): never {
  $b=Request::body();$login=trim((string)($b['login']??''));$pass=(string)($b['mat_khau']??'');if($login===''||$pass==='')Response::error('Vui lòng nhập thông tin đăng nhập.');
  $q=$this->db->prepare('SELECT a.*,n.trang_thai AS supplier_trang_thai,n.xac_minh FROM tai_khoan_nha_cung_ung a JOIN nha_cung_ung n ON n.id=a.nha_cung_ung_id WHERE a.email=? OR a.so_dien_thoai=? OR a.ten_dang_nhap=? LIMIT 1');$q->execute([$login,$login,$login]);$a=$q->fetch();
  if(!$a||!password_verify($pass,$a['mat_khau_hash']))Response::error('Thông tin đăng nhập không đúng.',401);
  if($a['trang_thai']==='khoa'||in_array($a['supplier_trang_thai'],['tam_khoa','ngung_hoat_dong'],true))Response::error('Tài khoản Đơn vị sử dụng lao động đang bị khóa hoặc ngừng hoạt động.',403);
  if($a['trang_thai']!=='hoat_dong'||$a['supplier_trang_thai']!=='hoat_dong'||$a['xac_minh']!=='da_xac_minh')Response::error('Tài khoản chưa được xác minh và kích hoạt. Vui lòng hoàn thiện hồ sơ và chờ Quản trị viên duyệt.',403);
  $this->db->beginTransaction();
  try {
   $this->db->prepare('UPDATE tai_khoan_nha_cung_ung SET lan_dang_nhap_cuoi=NOW() WHERE id=?')->execute([$a['id']]);
   if($this->identity) $this->identity->syncEmployerAccount((int)$a['id'],(int)$a['nha_cung_ung_id']);
   $this->db->commit();
  } catch(\Throwable $e) {
   if($this->db->inTransaction()) $this->db->rollBack();
   Response::error('Không thể đồng bộ Identity. Vui lòng thử lại sau.',500);
  }
  Auth::login((int)$a['id'],(int)$a['nha_cung_ung_id'],true);Auth::setAccountContext((string)($a['vai_tro']??'nhan_vien'),(bool)($a['co_quyen_live']??false));Response::ok(['nha_cung_ung_id'=>(int)$a['nha_cung_ung_id']],'Đăng nhập thành công.');
 }
 public function logout(): never{Auth::logout();Response::ok(null,'Đã đăng xuất.');}
 public function me(): never{
  $id=Auth::supplierId(false);
  $q=$this->db->prepare('SELECT n.id,n.ma_nha_cung_ung,n.ten_nha_cung_ung,n.ten_don_vi,n.loai_don_vi,n.ma_so_thue,n.tax_status,n.tax_verified_at,n.tax_verification_source,n.tax_provider_request_id,n.tax_response_hash,n.nguoi_dai_dien,n.so_dien_thoai,n.so_dien_thoai_da_xac_minh,n.email,n.dia_chi,n.google_maps,n.logo,n.gioi_thieu,n.sms_mau_tin_dau_tien,n.giay_phep,n.xac_minh,n.ngay_xac_minh,n.diem_minh_bach,n.tong_tin_tuyen_dung,n.tong_dang_ky_ho_so_phong_van,n.tong_lien_he,n.tong_khong_phu_hop,n.tong_huy,n.ti_le_phan_hoi,n.thoi_gian_phan_hoi_trung_binh,n.trang_thai,n.ghi_chu_quan_tri,n.ngay_tao,n.ngay_cap_nhat,a.id AS tai_khoan_id,a.ten_dang_nhap,a.email AS tai_khoan_email,a.so_dien_thoai AS tai_khoan_so_dien_thoai,a.trang_thai AS tai_khoan_trang_thai,a.vai_tro,a.ten_hien_thi,a.co_quyen_live,a.lan_dang_nhap_cuoi FROM nha_cung_ung n JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id WHERE n.id=? ORDER BY a.id ASC LIMIT 1');
  $q->execute([$id]);$row=$q->fetch();if(!$row)Response::error('Không tìm thấy Đơn vị sử dụng lao động.',404);
  $required=[
   'ten_don_vi'=>'Tên đơn vị sử dụng lao động',
   'loai_don_vi'=>'Loại đơn vị',
   'nguoi_dai_dien'=>'Người đại diện',
   'so_dien_thoai'=>'Số điện thoại',
   'email'=>'Email',
   'dia_chi'=>'Địa chỉ',
   'google_maps'=>'Google Maps',
   'gioi_thieu'=>'Giới thiệu',
   'giay_phep'=>'Thông tin/giấy phép xác minh'
  ];
  $missing=[];$completed=0;
  foreach($required as $field=>$label){
   if(trim((string)($row[$field]??''))==='')$missing[]=['field'=>$field,'label'=>$label];
   else $completed++;
  }
  $total=count($required);$percent=$total?round(($completed/$total)*100,2):0;
  foreach(['so_dien_thoai','so_dien_thoai_da_xac_minh','tai_khoan_so_dien_thoai'] as $k){ if(array_key_exists($k,$row)) $row[$k]=PhoneMaskService::mask($row[$k]); }
  $row['ho_so_hoan_thien_phan_tram']=$percent;
  $row['ho_so_da_hoan_thien']=($percent===100.0);
  $row['ho_so_con_thieu']=$missing;
  $row['co_the_gui_xac_minh']=($percent===100.0 && in_array($row['trang_thai'],['cho_duyet','hoat_dong'],true) && $row['xac_minh']!=='dang_xac_minh');
  Response::ok($row);
 }

 public function update(): never{
  $id=Auth::supplierId(false);$b=Request::body();
  $allowed=['ten_don_vi','loai_don_vi','ma_so_thue','ten_nha_cung_ung','nguoi_dai_dien','email','dia_chi','google_maps','logo','gioi_thieu','sms_mau_tin_dau_tien','giay_phep'];
  $sets=[];$vals=[];
  foreach($allowed as $f){
   if(!array_key_exists($f,$b))continue;
   $value=is_string($b[$f])?trim($b[$f]):$b[$f];
   if($f==='email'&&$value!==''&&!filter_var($value,FILTER_VALIDATE_EMAIL))Response::error('Email không hợp lệ.');
   if($f==='sms_mau_tin_dau_tien'){ if($value==='')Response::error('Mẫu SMS đầu tiên không được để trống.'); if(mb_strlen((string)$value)>500)Response::error('Mẫu SMS đầu tiên tối đa 500 ký tự.'); }
   if($f==='ten_don_vi'&&$value==='')Response::error('Tên đơn vị sử dụng lao động không được để trống.');
   if($f==='loai_don_vi'&&!in_array((string)$value,['doanh_nghiep','ho_kinh_doanh','hop_tac_xa','to_chuc','ca_nhan'],true))Response::error('Loại đơn vị sử dụng lao động không hợp lệ.');
   if($f==='nguoi_dai_dien'&&$value==='')Response::error('Người đại diện không được để trống.');
   $sets[]="$f=?";$vals[]=$value===''?null:$value;
  }
  if(!$sets)Response::error('Không có dữ liệu cập nhật.');
  $q=$this->db->prepare('SELECT * FROM nha_cung_ung WHERE id=?');$q->execute([$id]);$old=$q->fetch();if(!$old)Response::error('Không tìm thấy Đơn vị sử dụng lao động.',404);

  $criticalChanged=false;
  foreach(['ten_don_vi','loai_don_vi','ma_so_thue','nguoi_dai_dien','email','giay_phep'] as $f){
   if(array_key_exists($f,$b) && (string)($old[$f]??'')!==(string)($b[$f]??'')){$criticalChanged=true;break;}
  }

  $this->db->beginTransaction();
  try{
   $vals[]=$id;
   $this->db->prepare('UPDATE nha_cung_ung SET '.implode(',',$sets).' WHERE id=?')->execute($vals);
   if(array_key_exists('ten_don_vi',$b)){ $this->db->prepare('UPDATE nha_cung_ung SET ten_nha_cung_ung=? WHERE id=?')->execute([trim((string)$b['ten_don_vi']),$id]); }

   if(array_key_exists('email',$b)){
    $this->db->prepare('UPDATE tai_khoan_nha_cung_ung SET email=? WHERE nha_cung_ung_id=?')
      ->execute([trim((string)$b['email'])!==''?trim((string)$b['email']):null,$id]);
   }

   $auditNew=$b;
   $auditNew['_critical_profile_change']=$criticalChanged;
   $this->audit->log('nha_cung_ung',$id,null,'nha_cung_ung','cap_nhat_ho_so',$old,$auditNew);

   if($criticalChanged && $old['xac_minh']==='da_xac_minh'){
    $this->db->prepare('UPDATE nha_cung_ung SET xac_minh="can_xac_minh_lai",trang_thai="cho_duyet" WHERE id=?')->execute([$id]);
    $this->audit->log('nha_cung_ung',$id,null,'nha_cung_ung','yeu_cau_xac_minh_lai',$old,['xac_minh'=>'can_xac_minh_lai','trang_thai'=>'cho_duyet']);
    $_SESSION['supplier_access_active']=false;
   }

   $this->db->commit();
   Response::ok(['can_xac_minh_lai'=>$criticalChanged && $old['xac_minh']==='da_xac_minh'],'Đã cập nhật hồ sơ Đơn vị sử dụng lao động.');
  }catch(\Throwable $e){
   if($this->db->inTransaction())$this->db->rollBack();
   Response::error('Không thể cập nhật hồ sơ Đơn vị sử dụng lao động.',500);
  }
 }

 public function changePassword(): never {
  $sid=Auth::supplierId(false);$aid=Auth::accountId();$b=Request::body();
  $current=(string)($b['mat_khau_hien_tai']??'');$new=(string)($b['mat_khau_moi']??'');
  if($current===''||$new==='')Response::error('Vui lòng nhập mật khẩu hiện tại và mật khẩu mới.');
  if(strlen($new)<8)Response::error('Mật khẩu mới phải có ít nhất 8 ký tự.');
  $q=$this->db->prepare('SELECT mat_khau_hash FROM tai_khoan_nha_cung_ung WHERE id=? AND nha_cung_ung_id=?');$q->execute([$aid,$sid]);$account=$q->fetch();
  if(!$account||!password_verify($current,$account['mat_khau_hash']))Response::error('Mật khẩu hiện tại không đúng.',401);
  $this->db->prepare('UPDATE tai_khoan_nha_cung_ung SET mat_khau_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$aid]);
  $this->audit->log('nha_cung_ung',$sid,null,'tai_khoan_nha_cung_ung','doi_mat_khau',null,['tai_khoan_id'=>$aid]);
  Response::ok(null,'Đã đổi mật khẩu.');
 }

 public function submitVerification(): never{
  $id=Auth::supplierId(false);$q=$this->db->prepare('SELECT * FROM nha_cung_ung WHERE id=?');$q->execute([$id]);$supplier=$q->fetch();if(!$supplier)Response::error('Không tìm thấy Đơn vị sử dụng lao động.',404);
  if(!in_array($supplier['trang_thai'],['cho_duyet','hoat_dong'],true))Response::error('Đơn vị sử dụng lao động hiện không thể gửi hồ sơ xác minh.',403);
  $required=[
   'ten_don_vi','loai_don_vi','nguoi_dai_dien','so_dien_thoai','email',
   'dia_chi','google_maps','gioi_thieu','giay_phep'
  ];
  foreach($required as $f){
   if(trim((string)($supplier[$f]??''))===''){
    Response::error('Hồ sơ chưa hoàn thiện. Còn thiếu: '.$f.'.',409);
   }
  }
  $this->db->beginTransaction();try{$this->db->prepare('UPDATE nha_cung_ung SET xac_minh="dang_xac_minh",trang_thai="cho_duyet" WHERE id=?')->execute([$id]);$this->audit->log('nha_cung_ung',$id,null,'nha_cung_ung','gui_ho_so_xac_minh',$supplier,['xac_minh'=>'dang_xac_minh','trang_thai'=>'cho_duyet']);
   $this->db->commit();Response::ok(null,'Đã gửi hồ sơ xác minh. Quản trị viên sẽ kiểm tra và kích hoạt tài khoản.');}catch(\Throwable $e){if($this->db->inTransaction())$this->db->rollBack();Response::error('Không thể gửi hồ sơ xác minh.',500);}
 }
}
