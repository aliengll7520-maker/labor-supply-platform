<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Services\ContentSitemapService;

final class ContentSitemapController
{
    public function __construct(private ContentSitemapService $sitemap) {}

    public function jobs(): never
    {
        try {
            $payload = $this->sitemap->publicJobsSitemap();
            http_response_code(200);
            header('Content-Type: application/xml; charset=utf-8');
            echo $payload['xml'];
            exit;
        } catch (\Throwable $e) {
            http_response_code(500);
            header('Content-Type: application/xml; charset=utf-8');
            echo '<?xml version="1.0" encoding="UTF-8"?><error>Unable to generate sitemap.</error>';
            exit;
        }
    }
}
