<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentUrlService;

final class ContentUrlController
{
    public function __construct(private ContentUrlService $urlService) {}

    public function publicJobUrl(int $jobId): never
    {
        try {
            Response::ok($this->urlService->publicJobUrl($jobId));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tạo URL nội dung công khai.', 500);
        }
    }
}
