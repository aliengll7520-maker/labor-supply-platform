<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Services\ContentSeoLifecycleService;

final class ContentSeoLifecycleController
{
    public function __construct(private ContentSeoLifecycleService $service) {}

    public function show(int $id): void
    {
        try {
            $payload = $this->service->get($id);
            if ($payload === null) { http_response_code(404); echo json_encode(['error'=>'Not found']); return; }
            http_response_code(200);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } catch (\Throwable $e) {
            http_response_code(500); echo json_encode(['error'=>'Unable to resolve SEO lifecycle.']);
        }
    }
}
