<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentDiscoveryDeliveryService;

final class ContentDiscoveryDeliveryController
{
    public function __construct(private ContentDiscoveryDeliveryService $delivery) {}

    public function job(int $jobId): never
    {
        try {
            Response::ok($this->delivery->job($jobId, $_GET));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\RuntimeException $e) {
            Response::error($e->getMessage(), $e->getCode() === 404 ? 404 : 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tải Content Delivery.', 500);
        }
    }
}
