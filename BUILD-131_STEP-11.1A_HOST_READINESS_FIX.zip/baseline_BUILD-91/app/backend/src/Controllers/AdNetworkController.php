<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;

/**
 * BUILD 101 - Third-party Ad Network Integration.
 *
 * The platform does not sell advertising directly, create campaigns, accept
 * advertiser orders, set advertiser budgets, or collect advertiser payments.
 * A third-party ad network is responsible for ad selection, delivery,
 * impression/click measurement and revenue settlement.
 */
final class AdNetworkController {
    public function __construct(private \PDO $db, private array $config) {}

    public function config(): never {
        $network = $this->config['ad_network'] ?? [];
        $dbConfig = $this->loadDbConfig();
        $enabled = $this->toBool($dbConfig['build_101_ad_network_enabled'] ?? ($network['enabled'] ?? false));

        Response::ok([
            'enabled' => $enabled,
            'provider' => $dbConfig['ad_network_provider'] ?? (string)($network['provider'] ?? ''),
            'publisher_id' => $dbConfig['ad_network_publisher_id'] ?? (string)($network['publisher_id'] ?? ''),
            'script_url' => $dbConfig['ad_network_script_url'] ?? (string)($network['script_url'] ?? ''),
            'slots' => [
                'feed' => $dbConfig['ad_network_feed_slot'] ?? (string)($network['feed_slot'] ?? 'feed'),
                'job_detail' => $dbConfig['ad_network_job_detail_slot'] ?? (string)($network['job_detail_slot'] ?? 'job_detail'),
                'video' => $dbConfig['ad_network_video_slot'] ?? (string)($network['video_slot'] ?? 'video'),
                'live' => $dbConfig['ad_network_live_slot'] ?? (string)($network['live_slot'] ?? 'live'),
            ],
        ]);
    }

    private function loadDbConfig(): array {
        try {
            $rows = $this->db->query("SELECT ma_cau_hinh, gia_tri FROM cau_hinh_he_thong WHERE nhom='ad_network'")->fetchAll(\PDO::FETCH_KEY_PAIR);
            return is_array($rows) ? $rows : [];
        } catch (\Throwable) {
            return [];
        }
    }

    private function toBool(mixed $value): bool {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }
}
