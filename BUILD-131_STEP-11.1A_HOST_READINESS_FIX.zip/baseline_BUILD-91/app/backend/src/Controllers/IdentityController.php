<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Auth,Response,WorkerAuth};
use LaborPlatform\Services\IdentityService;

final class IdentityController {
    public function __construct(private \PDO $db, private IdentityService $identity) {}
    public function me(): never {
        $header=$_SERVER['HTTP_AUTHORIZATION']??'';
        if(preg_match('/^Bearer\s+(.+)$/i',$header)) {
            $workerId=WorkerAuth::workerId(false);
            if($workerId>0) Response::ok($this->identity->currentWorker($workerId));
        }
        $supplierId=Auth::supplierId(false);
        $accountId=Auth::accountId();
        if($supplierId<=0||$accountId<=0) Response::error('Chưa đăng nhập.',401);
        Response::ok($this->identity->currentEmployer($accountId,$supplierId));
    }
}
