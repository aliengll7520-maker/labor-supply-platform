<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{AdminAuth,Response,Request};
final class ModerationAdminController {
 public function __construct(private \PDO $db) {}
 public function queue(): never { AdminAuth::requirePermission('social.reports.view'); $q=$this->db->query('SELECT id,content_type,content_id,actor_type,actor_id,risk_score,reasons_json,status,created_at FROM content_abuse_events WHERE status IN ("open","reviewing") ORDER BY risk_score DESC,id DESC LIMIT 500'); Response::ok(['events'=>$q->fetchAll()]); }
 public function resolve(int $id): never { AdminAuth::requirePermission('social.moderate'); $status=(string)(Request::body()['status']??''); if(!in_array($status,['resolved','dismissed'],true)) Response::error('Trạng thái xử lý không hợp lệ.'); $q=$this->db->prepare('UPDATE content_abuse_events SET status=?,resolved_at=NOW() WHERE id=?'); $q->execute([$status,$id]); if($q->rowCount()<1) Response::error('Không tìm thấy sự kiện lạm dụng.',404); Response::ok(null,'Đã cập nhật sự kiện lạm dụng.'); }
}
