<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\Response;
use LaborPlatform\Services\ContentRecommendationService;

final class ContentRecommendationController
{
    public function __construct(private ContentRecommendationService $recommendation) {}

    public function publicJob(int $jobId): never
    {
        try {
            Response::ok($this->recommendation->recommendJob($jobId, $_GET));
        } catch (\InvalidArgumentException $e) {
            Response::error($e->getMessage(), 400);
        } catch (\Throwable $e) {
            Response::error('Không thể tải nội dung đề xuất.', 500);
        }
    }
}
