<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,Request,Response,WorkerAuth};
use LaborPlatform\Services\AuditService;
use LaborPlatform\Queue\QueueService;

final class MediaController {
    public function __construct(private \PDO $db, private AuditService $audit, private QueueService $queue, private \LaborPlatform\Services\Media\MediaStorageService $mediaStorage, private array $imageConfig = [], private ?\LaborPlatform\Services\Media\MediaSecurityService $mediaSecurity = null, private string $storageDriver = 'local', private ?\LaborPlatform\Services\Media\MediaCleanupService $mediaCleanup = null, private ?\LaborPlatform\Services\Media\MediaPolicyService $mediaPolicy = null, private bool $liveEnabled = true) {}

    private function actor(bool $required=true): ?array {
        $header=$_SERVER['HTTP_AUTHORIZATION']??'';
        if(preg_match('/^Bearer\s+(.+)$/i',$header)) {
            $id=WorkerAuth::workerId($this->db,false);
            if($id>0) return ['type'=>'nguoi_lao_dong','id'=>$id];
        }
        $accountId=Auth::accountId();
        if($accountId>0) return ['type'=>'nha_cung_ung','id'=>Auth::supplierId(true),'account_id'=>$accountId];
        if($required) Response::error('Chưa đăng nhập.',401);
        return null;
    }



    /**
     * PR-03.3: Multipart upload pipeline foundation.
     * Accepts one authenticated image/video file, validates the real MIME,
     * stores it through MediaStorageService and creates a media_asset record.
     * Processing/thumbnail/CDN are intentionally deferred to later PR-03 steps.
     */
    public function upload(?string $forcedPurpose=null): never {
        $actor=$this->actor();
        if (empty($_FILES['file']) || !is_array($_FILES['file'])) Response::error('Thiếu file Media.');
        $file=$_FILES['file'];
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) Response::error('Upload Media thất bại.');
        $tmp=(string)($file['tmp_name']??'');
        $original=trim((string)($file['name']??'media'));
        $size=(int)($file['size']??0);
        // BUILD-69: profile images (avatar/logo) have a much smaller ingress
        // ceiling than generic media. The final profile variant is still capped
        // at 200x200 and 50KiB by ImageProcessingService.
        $purpose = strtolower(trim((string)($forcedPurpose ?? ($_POST['purpose'] ?? $_GET['purpose'] ?? ''))));
        if (!in_array($purpose, ['', 'profile'], true)) {
            Response::error('Mục đích Media không hợp lệ.',400);
        }
        $genericMax=(int)(getenv('LABOR_MEDIA_UPLOAD_MAX_BYTES') ?: 5242880);
        $profileMax=(int)(getenv('LABOR_PROFILE_MEDIA_UPLOAD_MAX_BYTES') ?: 524288);
        $max = $purpose === 'profile' ? min($genericMax, max(65536, $profileMax)) : $genericMax;
        if ($size<=0 || $size>$max) Response::error(
            $purpose === 'profile'
                ? 'Ảnh đại diện/logo vượt quá giới hạn tải lên cho ảnh hồ sơ.'
                : 'File Media vượt quá giới hạn cho phép.'
        );
        if (!is_uploaded_file($tmp)) Response::error('Nguồn upload không hợp lệ.');
        $finfo=new \finfo(FILEINFO_MIME_TYPE);
        $mime=(string)$finfo->file($tmp);
        $profilePixels=(int)(getenv('LABOR_PROFILE_MEDIA_MAX_PIXELS') ?: 4000000);
        $securityMaxPixels=(int)($this->imageConfig['max_pixels'] ?? 25000000);
        if ($purpose === 'profile') $securityMaxPixels=min($securityMaxPixels, max(100000, $profilePixels));
        $security=$this->mediaSecurity ?? new \LaborPlatform\Services\Media\MediaSecurityService($securityMaxPixels);
        $secure=$security->validateUpload($tmp,$original,$mime,$size);
        if ($purpose === 'profile' && str_starts_with($mime,'image/')) {
            $w=(int)($secure['width']??0); $h=(int)($secure['height']??0);
            if ($w>2000 || $h>2000) Response::error('Ảnh đại diện/logo có kích thước điểm ảnh đầu vào quá lớn.',413);
        }
        $policy=$this->mediaPolicy ?? new \LaborPlatform\Services\Media\MediaPolicyService();
        try { $policy->assertCanUploadMime($actor['type'],$mime); } catch (\InvalidArgumentException $e) { Response::error($e->getMessage(),403); }
        $allowed=[
            'image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp',
            'video/mp4'=>'mp4','video/webm'=>'webm'
        ];
        if (!isset($allowed[$mime])) Response::error('Định dạng Media chưa được hỗ trợ.');
        $ext=$allowed[$mime];
        $key=$actor['type'].'/'.$actor['id'].'/'.date('Y/m').'/'.bin2hex(random_bytes(16)).'.'.$ext;
        
        $metadata=['mime_type'=>$mime];
        if (isset($secure['width'])) $metadata['width']=(int)$secure['width'];
        if (isset($secure['height'])) $metadata['height']=(int)$secure['height'];
        $stored=$this->mediaStorage->store($tmp,$key,$metadata);
        $q=$this->db->prepare('INSERT INTO media_asset (owner_type,owner_id,storage_driver,storage_key,original_name,mime_type,size_bytes,sha256,width,height,duration_seconds,trang_thai,public_access) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0)');
        try {
            $q->execute([$actor['type'],$actor['id'],$this->storageDriver,$stored['storage_key'],$secure['safe_name'],$mime,$stored['size_bytes'],$stored['sha256'],$stored['width']??null,$stored['height']??null,null,'stored']);
        } catch (\Throwable $e) {
            try {
                $this->mediaStorage->delete($key);
            } catch (\Throwable $cleanupError) {
                if ($this->mediaCleanup !== null) {
                    try { $this->mediaCleanup->enqueueObject($key, 'upload_db_rollback'); } catch (\Throwable) {}
                }
            }
            throw $e;
        }
        $id=(int)$this->db->lastInsertId();
        $this->audit->log($actor['type'],$actor['id'],null,'media_asset','upload_media',null,['id'=>$id,'mime_type'=>$mime,'size_bytes'=>$size]);
        if (str_starts_with($mime,'image/')) {
            $this->db->prepare('UPDATE media_asset SET trang_thai="processing" WHERE id=?')->execute([$id]);
            try { $this->queue->enqueue('media','media.process_image',['media_id'=>$id],150,'media:image:'.$id); }
            catch (\Throwable $e) { $this->db->prepare('UPDATE media_asset SET trang_thai="failed" WHERE id=?')->execute([$id]); throw $e; }
        }
        Response::ok(['id'=>$id,'trang_thai'=>str_starts_with($mime,'image/')?'processing':'stored','storage_key'=>$stored['storage_key'],'mime_type'=>$mime,'size_bytes'=>$stored['size_bytes']],'Đã nhận Media.');
    }

    /** BUILD-69: dedicated ingress for avatar/company-logo uploads. */
    public function uploadProfile(): never {
        $this->upload('profile');
    }

    public function assetUrl(int $id, \LaborPlatform\Services\Media\MediaCdnService $cdn): never {
        $q = $this->db->prepare('SELECT id,storage_key,mime_type,trang_thai,public_access FROM media_asset WHERE id=? LIMIT 1');
        $q->execute([$id]);
        $asset = $q->fetch();
        if (!$asset) Response::error('Media không tồn tại.',404);
        if ((int)$asset['public_access'] !== 1) Response::error('Media riêng tư không có URL CDN công khai.',403);
        if (!in_array((string)$asset['trang_thai'], ['stored','ready'], true)) Response::error('Media chưa sẵn sàng để phân phối.',409);

        $variant = trim((string)($_GET['variant'] ?? ''));
        $storageKey = (string)$asset['storage_key'];
        if ($variant !== '') {
            if (!in_array($variant, ['web','thumb','profile'], true)) Response::error('Variant Media không hợp lệ.',400);
            $vq = $this->db->prepare('SELECT storage_key,trang_thai FROM media_asset_variant WHERE media_asset_id=? AND variant_key=? LIMIT 1');
            $vq->execute([$id,$variant]);
            $v = $vq->fetch();
            if (!$v || $v['trang_thai'] !== 'ready') Response::error('Variant Media chưa sẵn sàng.',409);
            $storageKey = (string)$v['storage_key'];
        }

        if (!$cdn->isEnabled()) {
            Response::error('Media CDN chưa được bật.',503);
        }
        $url = $cdn->publicUrl($storageKey, true);
        if ($url === '') Response::error('Media chưa có URL phân phối công khai.',503);
        Response::ok([
            'id'=>$id,
            'variant'=>$variant !== '' ? $variant : null,
            'url'=>$url,
            'cache_seconds'=>$cdn->cacheSeconds(),
        ]);
    }

    public function videoFeed(): never {
        $a=$this->actor(false); $limit=min(max((int)($_GET['limit']??20),1),50); $offset=max((int)($_GET['offset']??0),0);
        $params=[]; $where='m.mime_type IN ("video/mp4","video/webm") AND m.owner_type="nha_cung_ung" AND m.public_access=1 AND m.trang_thai IN ("stored","ready") AND m.video_trang_thai="cong_khai"';
        if($a){$where.=' AND NOT EXISTS (SELECT 1 FROM media_chan c WHERE c.chan_type=? AND c.chan_id=? AND c.doi_tuong_type=m.owner_type AND c.doi_tuong_id=m.owner_id)';$params=[$a['type'],$a['id']];}
        $sql='SELECT m.id,m.owner_type tac_gia_type,m.owner_id tac_gia_id,m.video_tieu_de tieu_de,m.video_mo_ta mo_ta,m.storage_key media_storage_key,m.video_thumbnail_storage_key thumbnail_storage_key,m.mime_type loai_media,m.duration_seconds thoi_luong_giay,m.video_luot_xem luot_xem,m.video_luot_thich luot_thich,m.created_at ngay_tao,CASE WHEN m.owner_type="nguoi_lao_dong" THEN n.ho_ten ELSE COALESCE(NULLIF(u.ten_don_vi,""),u.ten_nha_cung_ung) END ten_tac_gia FROM media_asset m LEFT JOIN nguoi_lao_dong n ON m.owner_type="nguoi_lao_dong" AND n.id=m.owner_id LEFT JOIN nha_cung_ung u ON m.owner_type="nha_cung_ung" AND u.id=m.owner_id WHERE '.$where.' ORDER BY m.id DESC LIMIT '.$limit.' OFFSET '.$offset;
        $q=$this->db->prepare($sql);$q->execute($params);Response::ok(['videos'=>$q->fetchAll(),'limit'=>$limit,'offset'=>$offset]);
    }

    public function createVideo(): never {
        Response::error('API video cũ đã ngừng ghi vào media_video. Hãy dùng Media Storage mới.',410);
    }

    public function publishVideoAsset(int $id): never {
        $a=$this->actor();
        if ($a['type'] !== 'nha_cung_ung') Response::error('Người lao động không được đăng video không Live.',403);
        $b=Request::body();
        $title=trim((string)($b['tieu_de']??''));
        $description=trim((string)($b['mo_ta']??''));
        if($title==='') Response::error('Tiêu đề video không được để trống.');
        if(mb_strlen($title)>255 || mb_strlen($description)>5000) Response::error('Thông tin video quá dài.');
        $q=$this->db->prepare('SELECT id,owner_type,owner_id,mime_type,trang_thai FROM media_asset WHERE id=? LIMIT 1');
        $q->execute([$id]); $asset=$q->fetch();
        if(!$asset || $asset['owner_type']!=='nha_cung_ung' || (int)$asset['owner_id']!==(int)$a['id']) Response::error('Không tìm thấy Media video thuộc tài khoản.',404);
        if(!in_array((string)$asset['mime_type'],['video/mp4','video/webm'],true)) Response::error('Media này không phải video.',400);
        if(!in_array((string)$asset['trang_thai'],['stored','ready'],true)) Response::error('Video chưa sẵn sàng để gửi kiểm duyệt.',409);
        $this->db->prepare('UPDATE media_asset SET video_tieu_de=?,video_mo_ta=?,video_trang_thai="cho_duyet",public_access=0 WHERE id=?')->execute([$title,$description,$id]);
        $this->queue->enqueue('moderation','moderation.media_asset',['media_asset_id'=>$id,'actor_type'=>$a['type'],'actor_id'=>$a['id']],180,'media-asset:'.$id);
        $this->audit->log($a['type'],$a['id'],null,'media_asset','gui_video_kiem_duyet',null,['id'=>$id]);
        Response::ok(['id'=>$id,'trang_thai'=>'cho_duyet'],'Đã gửi video chờ kiểm duyệt.');
    }

    public function videoView(int $id): never {
        $q=$this->db->prepare('SELECT id,trang_thai,public_access,video_trang_thai FROM media_asset WHERE id=? AND mime_type IN ("video/mp4","video/webm") LIMIT 1');$q->execute([$id]);$v=$q->fetch();
        if(!$v || !in_array((string)$v['trang_thai'],['stored','ready'],true) || (int)$v['public_access']!==1 || $v['video_trang_thai']!=='cong_khai') Response::error('Video không tồn tại hoặc chưa được công khai.',404);
        $this->db->prepare('UPDATE media_asset SET video_luot_xem=video_luot_xem+1 WHERE id=?')->execute([$id]);Response::ok(['id'=>$id,'recorded_view'=>true]);
    }

    private function liveConfig(string $key, string $default): string {
        try {
            $q=$this->db->prepare('SELECT gia_tri FROM cau_hinh_he_thong WHERE ma_cau_hinh=? AND nhom="live" AND trang_thai="bat" LIMIT 1');
            $q->execute([$key]);
            $value=$q->fetchColumn();
            return $value===false || $value===null ? $default : (string)$value;
        } catch (\Throwable) { return $default; }
    }

    private function liveRecordingEnabled(): bool {
        return filter_var($this->liveConfig('live_recording_enabled','false'), FILTER_VALIDATE_BOOLEAN);
    }

    private function assertLiveEnabled(): void {
        if (!$this->liveEnabled) Response::error('Live Production đang được tạm dừng.',503);
    }

    public function liveRooms(): never {
        $this->assertLiveEnabled();
        $q=$this->db->query('SELECT r.id,r.nha_cung_ung_id,r.nguoi_tao_tai_khoan_id,r.tieu_de,r.mo_ta,r.trang_thai,r.bat_dau_du_kien,r.bat_dau_thuc_te,r.ket_thuc,r.room_key,r.ngay_tao,COALESCE(NULLIF(u.ten_don_vi,""),u.ten_nha_cung_ung) ten_don_vi FROM phong_live_nha_cung_ung r JOIN nha_cung_ung u ON u.id=r.nha_cung_ung_id WHERE r.trang_thai IN ("da_len_lich","dang_live") ORDER BY (r.trang_thai="dang_live") DESC,r.id DESC LIMIT 100');Response::ok(['rooms'=>$q->fetchAll()]);
    }

    public function startLive(int $roomId): never {
        $this->assertLiveEnabled();
        $sid=Auth::supplierId(true);if(!Auth::canLive())Response::error('Tài khoản chưa được cấp quyền Live.',403);
        $q=$this->db->prepare('SELECT id,trang_thai,nha_cung_ung_id FROM phong_live_nha_cung_ung WHERE id=? AND nha_cung_ung_id=? LIMIT 1');$q->execute([$roomId,$sid]);$r=$q->fetch();if(!$r)Response::error('Không tìm thấy phòng Live.',404);if(!in_array($r['trang_thai'],['nhap','da_len_lich'],true))Response::error('Phòng Live không thể bắt đầu ở trạng thái hiện tại.',409);
        $u=$this->db->prepare('UPDATE phong_live_nha_cung_ung SET trang_thai="dang_live",bat_dau_thuc_te=NOW(),live_heartbeat_at=NULL WHERE id=? AND nha_cung_ung_id=? AND trang_thai IN ("nhap","da_len_lich")');$u->execute([$roomId,$sid]);if($u->rowCount()!==1)Response::error('Phòng Live vừa được thay đổi hoặc đã bắt đầu bởi một yêu cầu khác.',409);
        // State hardening: only nhap/da_len_lich may transition to dang_live; heartbeat never performs this transition.
        $this->audit->log('nha_cung_ung',$sid,null,'phong_live_nha_cung_ung','bat_dau_live',null,['id'=>$roomId]);Response::ok(['id'=>$roomId,'trang_thai'=>'dang_live'],'Live đã bắt đầu.');
    }

    public function endLive(int $roomId): never {
        $this->assertLiveEnabled();
        $sid=Auth::supplierId(true);$q=$this->db->prepare('SELECT id,trang_thai FROM phong_live_nha_cung_ung WHERE id=? AND nha_cung_ung_id=? LIMIT 1');$q->execute([$roomId,$sid]);$r=$q->fetch();if(!$r)Response::error('Không tìm thấy phòng Live.',404);if($r['trang_thai']!=='dang_live')Response::error('Phòng Live chưa ở trạng thái đang Live.',409);
        $u=$this->db->prepare('UPDATE phong_live_nha_cung_ung SET trang_thai="da_ket_thuc",ket_thuc=NOW() WHERE id=? AND nha_cung_ung_id=? AND trang_thai="dang_live"');$u->execute([$roomId,$sid]);if($u->rowCount()!==1)Response::error('Phòng Live vừa được kết thúc bởi một yêu cầu khác.',409);
        // BUILD 32: read Live retention policy from the single system configuration source.
        $retention=max(0,(int)$this->liveConfig('live_chat_retention_after_end_seconds','0'));
        $recordingEnabled=$this->liveRecordingEnabled();
        if($retention===0){
            $this->db->prepare('DELETE FROM live_chat WHERE phong_live_id=?')->execute([$roomId]);
            $chatRetained=false;
        }else{
            $this->queue->enqueue('media','live.cleanup_ended_chat',['room_id'=>$roomId,'retention_seconds'=>$retention],180,'live-chat-cleanup:'.$roomId);
            $chatRetained=true;
        }
        // Recording is deliberately unsupported by this product policy. A future transport must not silently create Replay.
        if($recordingEnabled){
            $this->audit->log('nha_cung_ung',$sid,null,'phong_live_nha_cung_ung','live_recording_policy_violation',null,['id'=>$roomId,'recording_enabled_config'=>true]);
        }
        $this->audit->log('nha_cung_ung',$sid,null,'phong_live_nha_cung_ung','ket_thuc_live',null,['id'=>$roomId,'chat_retained'=>$chatRetained,'recording_retained'=>false]);
        Response::ok(['id'=>$roomId,'trang_thai'=>'da_ket_thuc','chat_retained'=>$chatRetained,'recording_retained'=>false],'Live đã kết thúc; dữ liệu Live tạm thời được xử lý theo chính sách tự dọn.');
    }


    public function heartbeatLive(int $roomId): never {
        $this->assertLiveEnabled();
        $sid=Auth::supplierId(true);
        if(!Auth::canLive()) Response::error('Tài khoản chưa được cấp quyền Live.',403);
        $q=$this->db->prepare('SELECT id,trang_thai,nha_cung_ung_id FROM phong_live_nha_cung_ung WHERE id=? AND nha_cung_ung_id=? LIMIT 1');
        $q->execute([$roomId,$sid]);
        $r=$q->fetch();
        if(!$r) Response::error('Không tìm thấy phòng Live.',404);
        if($r['trang_thai']!=='dang_live') Response::error('Heartbeat chỉ hợp lệ khi phòng đang Live.',409);
        $this->db->prepare('UPDATE phong_live_nha_cung_ung SET live_heartbeat_at=NOW() WHERE id=?')->execute([$roomId]);
        Response::ok(['id'=>$roomId,'trang_thai'=>'dang_live','heartbeat_at'=>date('c')],'Heartbeat Live đã được ghi nhận.');
    }

    public function chat(int $roomId): never {
        $this->assertLiveEnabled();
        $q=$this->db->prepare('SELECT c.id,c.tac_gia_type,c.tac_gia_id,c.noi_dung,c.ngay_tao,CASE WHEN c.tac_gia_type="nguoi_lao_dong" THEN n.ho_ten ELSE COALESCE(NULLIF(u.ten_don_vi,""),u.ten_nha_cung_ung) END ten_tac_gia FROM live_chat c LEFT JOIN nguoi_lao_dong n ON c.tac_gia_type="nguoi_lao_dong" AND n.id=c.tac_gia_id LEFT JOIN nha_cung_ung u ON c.tac_gia_type="nha_cung_ung" AND u.id=c.tac_gia_id WHERE c.phong_live_id=? AND c.trang_thai="cong_khai" ORDER BY c.id DESC LIMIT 100');$q->execute([$roomId]);Response::ok(['messages'=>array_reverse($q->fetchAll())]);
    }

    public function sendChat(int $roomId): never {
        $this->assertLiveEnabled();
        $a=$this->actor();$b=Request::body();$text=trim((string)($b['noi_dung']??''));if($text==='')Response::error('Nội dung chat không được để trống.');if(mb_strlen($text)>1000)Response::error('Nội dung chat tối đa 1000 ký tự.');
        $q=$this->db->prepare('SELECT id FROM phong_live_nha_cung_ung WHERE id=? AND trang_thai="dang_live" LIMIT 1');$q->execute([$roomId]);if(!$q->fetch())Response::error('Phòng Live không đang hoạt động.',409);
        $this->db->prepare('INSERT INTO live_chat (phong_live_id,tac_gia_type,tac_gia_id,noi_dung,trang_thai) VALUES (?,?,?,?,"cong_khai")')->execute([$roomId,$a['type'],$a['id'],$text]);$id=(int)$this->db->lastInsertId();Response::ok(['id'=>$id],'Đã gửi bình luận Live.');
    }
}
