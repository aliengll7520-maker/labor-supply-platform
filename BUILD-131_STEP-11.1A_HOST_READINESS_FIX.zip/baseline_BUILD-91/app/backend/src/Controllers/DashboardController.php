<?php
declare(strict_types=1);

namespace LaborPlatform\Controllers;

use LaborPlatform\Core\{Auth,AdminAuth,Response,Request};

final class DashboardController {
    public function __construct(private \PDO $db) {}

    public function supplier(): never {
        $sid=Auth::supplierId();
        $q=$this->db->prepare('SELECT COUNT(*) tong_tin_tuyen_dung,SUM(trang_thai="dang_tuyen") tin_dang_tuyen FROM tin_tuyen_dung WHERE nha_cung_ung_id=?');
        $q->execute([$sid]); $jobs=$q->fetch() ?: [];
        $q=$this->db->prepare('SELECT COUNT(*) tong_dang_ky,SUM(trang_thai IN ("da_mo_so","da_xem")) ho_so_moi,SUM(trang_thai IN ("da_mo_so","da_xem")) can_lien_he FROM dang_ky_ho_so_phong_van WHERE nha_cung_ung_id=?');
        $q->execute([$sid]); $r=$q->fetch() ?: [];
        $q=$this->db->prepare('SELECT COUNT(*) FROM thong_bao WHERE doi_tuong="nha_cung_ung" AND doi_tuong_id=? AND da_doc=0');
        $q->execute([$sid]); $unread=(int)$q->fetchColumn();
        Response::ok([
          'tin_tuyen_dung'=>(int)($jobs['tong_tin_tuyen_dung']??0),
          'tin_dang_tuyen'=>(int)($jobs['tin_dang_tuyen']??0),
          'ho_so_moi'=>(int)($r['ho_so_moi']??0),
          'can_lien_he'=>(int)($r['can_lien_he']??0),
          'thong_bao_chua_doc'=>$unread
        ]);
    }

    public function worker(): never {
        $b=Request::body(); $phone=trim((string)($b['so_dien_thoai']??'')); $code=trim((string)($b['ma_ho_so']??''));
        if($phone===''||$code==='') Response::error('Vui lòng cung cấp Số điện thoại và Mã hồ sơ.');
        $q=$this->db->prepare('SELECT id,ho_ten,so_dien_thoai,ma_ho_so,trang_thai FROM nguoi_lao_dong WHERE so_dien_thoai=? AND ma_ho_so=? LIMIT 1');
        $q->execute([$phone,$code]); $worker=$q->fetch(); if(!$worker) Response::error('Không tìm thấy hồ sơ Người lao động.',404);
        $q=$this->db->prepare('SELECT h.id,h.ma_ho_so,h.trang_thai,t.tieu_de,n.ten_nha_cung_ung FROM dang_ky_ho_so_phong_van h JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id JOIN nha_cung_ung n ON n.id=h.nha_cung_ung_id WHERE h.nguoi_lao_dong_id=? ORDER BY h.id DESC LIMIT 1');
        $q->execute([(int)$worker['id']]); $hoSo=$q->fetch();
        $q=$this->db->prepare('SELECT COUNT(*) FROM thong_bao WHERE doi_tuong="nguoi_lao_dong" AND doi_tuong_id=? AND da_doc=0'); $q->execute([(int)$worker['id']]); $unread=(int)$q->fetchColumn();
        Response::ok(['nguoi_lao_dong'=>$worker,'ho_so'=>$hoSo?:['tieu_de'=>'Chưa có hồ sơ ứng tuyển','ten_nha_cung_ung'=>'','trang_thai'=>'chua_co'],'thong_bao_chua_doc'=>$unread]);
    }

    public function admin(): never {
        AdminAuth::requirePermission('dashboard.view');
        $suppliers=$this->db->query('SELECT COUNT(*) tong_nha_cung_ung,SUM(trang_thai="hoat_dong") dang_hoat_dong,SUM(xac_minh="da_xac_minh") da_xac_minh FROM nha_cung_ung')->fetch() ?: [];
        $q=$this->db->query('SELECT COUNT(*) FROM nha_cung_ung WHERE trang_thai="cho_duyet" OR trang_thai="tam_khoa"');
        $nccChoDuyet=(int)$q->fetchColumn();
        $q=$this->db->query('SELECT id,ma_nha_cung_ung,ten_nha_cung_ung,xac_minh,trang_thai FROM nha_cung_ung WHERE trang_thai="cho_duyet" OR trang_thai="tam_khoa" ORDER BY id DESC LIMIT 10');
        $nccCanXuLy=$q->fetchAll();
        $jobs=$this->db->query('SELECT COUNT(*) tong_tin,SUM(trang_thai="dang_tuyen") dang_tuyen FROM tin_tuyen_dung')->fetch() ?: [];
        $registrations=$this->db->query('SELECT COUNT(*) tong_dang_ky,SUM(trang_thai IN ("da_mo_so","da_xem")) ho_so_moi,SUM(trang_thai="da_lien_he") da_lien_he FROM dang_ky_ho_so_phong_van')->fetch() ?: [];
        $unread=(int)$this->db->query('SELECT COUNT(*) FROM thong_bao WHERE da_doc=0')->fetchColumn();
        Response::ok([
          'nha_cung_ung'=>(int)($suppliers['tong_nha_cung_ung']??0),
          'ncc_cho_duyet'=>$nccChoDuyet,
          'tin_dang_tuyen'=>(int)($jobs['dang_tuyen']??0),
          'ho_so_moi'=>(int)($registrations['ho_so_moi']??0),
          'da_lien_he'=>(int)($registrations['da_lien_he']??0),
          'thong_bao_chua_doc'=>$unread,
          'ncc_can_xu_ly'=>$nccCanXuLy,
          'chi_tiet'=>['nha_cung_ung'=>$suppliers,'tin_tuyen_dung'=>$jobs,'dang_ky_ho_so_phong_van'=>$registrations]
        ]);
    }

}
