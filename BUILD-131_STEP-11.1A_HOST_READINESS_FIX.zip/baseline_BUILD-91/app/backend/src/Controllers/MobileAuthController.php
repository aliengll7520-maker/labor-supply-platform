<?php
declare(strict_types=1);
namespace LaborPlatform\Controllers;
use LaborPlatform\Core\{Request,Response,MobileAuth};
use LaborPlatform\Services\IdentityService;

final class MobileAuthController {
    public function __construct(private \PDO $db, private IdentityService $identity) {}

    public function login(): never {
        $b=Request::body(); $role=trim((string)($b['role']??'')); $login=trim((string)($b['login']??$b['identifier']??$b['phone']??$b['so_dien_thoai']??'')); $pass=(string)($b['password']??$b['mat_khau']??'');
        if(!in_array($role,['worker','employer'],true)||$login===''||$pass==='') Response::error('Thiếu thông tin đăng nhập Mobile.');
        $device=trim((string)($b['device_id']??'')); if($device!=='' && strlen($device)>128) Response::error('device_id không hợp lệ.');
        if($role==='worker') $this->loginWorker($login,$pass,$device); else $this->loginEmployer($login,$pass,$device);
    }

    private function loginWorker(string $login,string $pass,string $device): never {
        $q=$this->db->prepare('SELECT a.id AS account_id,a.nguoi_lao_dong_id,a.mat_khau_hash,n.ma_nguoi_lao_dong,n.ho_ten,n.so_dien_thoai,n.email,n.trang_thai FROM tai_khoan_nguoi_lao_dong a JOIN nguoi_lao_dong n ON n.id=a.nguoi_lao_dong_id WHERE n.so_dien_thoai=? AND a.trang_thai="hoat_dong" LIMIT 1'); $q->execute([$login]); $u=$q->fetch();
        if(!$u||!password_verify($pass,$u['mat_khau_hash'])) Response::error('Thông tin đăng nhập không đúng.',401);
        if($u['trang_thai']!=='hoat_dong') Response::error('Tài khoản Người lao động đang bị khóa.',403);
        $identityId=$this->identity->syncWorker((int)$u['nguoi_lao_dong_id']);
        $tokens=MobileAuth::issue($this->db,$identityId,'worker',(int)$u['nguoi_lao_dong_id'],null,null,$device?:null);
        Response::ok(['tokens'=>$tokens,'user'=>['id'=>(int)$u['nguoi_lao_dong_id'],'name'=>$u['ho_ten'],'phone'=>$u['so_dien_thoai'],'worker_code'=>$u['ma_nguoi_lao_dong']]],'Đăng nhập Mobile thành công.');
    }

    private function loginEmployer(string $login,string $pass,string $device): never {
        $q=$this->db->prepare('SELECT a.*,n.trang_thai AS supplier_trang_thai,n.xac_minh,n.ten_nha_cung_ung FROM tai_khoan_nha_cung_ung a JOIN nha_cung_ung n ON n.id=a.nha_cung_ung_id WHERE a.email=? OR a.so_dien_thoai=? OR a.ten_dang_nhap=? LIMIT 1'); $q->execute([$login,$login,$login]); $a=$q->fetch();
        if(!$a||!password_verify($pass,$a['mat_khau_hash'])) Response::error('Thông tin đăng nhập không đúng.',401);
        if($a['trang_thai']==='khoa'||in_array($a['supplier_trang_thai'],['tam_khoa','ngung_hoat_dong'],true)) Response::error('Tài khoản Đơn vị sử dụng lao động đang bị khóa hoặc ngừng hoạt động.',403);
        if($a['trang_thai']!=='hoat_dong'||$a['supplier_trang_thai']!=='hoat_dong'||$a['xac_minh']!=='da_xac_minh') Response::error('Tài khoản chưa được xác minh và kích hoạt.',403);
        $identityId=$this->identity->syncEmployerAccount((int)$a['id'],(int)$a['nha_cung_ung_id']);
        $tokens=MobileAuth::issue($this->db,$identityId,'employer',null,(int)$a['nha_cung_ung_id'],(int)$a['id'],$device?:null);
        Response::ok(['tokens'=>$tokens,'user'=>['supplier_id'=>(int)$a['nha_cung_ung_id'],'account_id'=>(int)$a['id'],'name'=>$a['ten_hien_thi']?:$a['ten_nha_cung_ung'],'role'=>$a['vai_tro']??'nhan_vien']],'Đăng nhập Mobile thành công.');
    }

    public function refresh(): never {
        $b=Request::body(); $token=trim((string)($b['refresh_token']??'')); if($token==='') Response::error('Thiếu refresh_token.',401);
        try { Response::ok(['tokens'=>MobileAuth::refresh($this->db,$token)],'Đã làm mới phiên Mobile.'); }
        catch(\RuntimeException $e){ $m=$e->getMessage(); if($m==='ACCOUNT_BLOCKED') Response::error('Tài khoản không còn được phép truy cập.',403);
            if($m==='REFRESH_REUSE_DETECTED') Response::error('Refresh Token đã bị sử dụng lại. Vui lòng đăng nhập lại.',401);
            Response::error('Refresh Token không hợp lệ hoặc đã hết hạn.',401); }
        catch(\Throwable) { Response::error('Không thể làm mới phiên Mobile.',500); }
    }

    public function logout(): never { $s=MobileAuth::resolve($this->db); MobileAuth::revokeCurrent($this->db,$s); Response::ok(null,'Đã đăng xuất thiết bị hiện tại.'); }
    public function logoutDevice(): never { $s=MobileAuth::resolve($this->db); $id=(int)(Request::body()['session_id']??0); if($id<=0) Response::error('session_id không hợp lệ.'); MobileAuth::revokeSession($this->db,$s,$id); Response::ok(null,'Đã đăng xuất thiết bị.'); }
    public function logoutAll(): never { $s=MobileAuth::resolve($this->db); MobileAuth::revokeAll($this->db,$s); Response::ok(null,'Đã đăng xuất tất cả thiết bị.'); }

    public function me(): never {
        $s=MobileAuth::resolve($this->db); $identity=$this->identity->current((int)$s['identity_id']);
        Response::ok(['session_id'=>(int)$s['id'],'role'=>$s['role_code'],'device_id'=>$s['device_id'],'identity'=>$identity,'access_expires_at'=>$s['access_expires_at'],'refresh_expires_at'=>$s['refresh_expires_at']]);
    }
}
