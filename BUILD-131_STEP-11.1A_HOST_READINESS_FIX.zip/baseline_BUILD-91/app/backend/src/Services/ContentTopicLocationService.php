<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 04 — deterministic Topic / Location projection for Content Discovery.
 * Source of truth remains tin_tuyen_dung; this projection is disposable.
 */
final class ContentTopicLocationService
{
    public const VERSION = '04.0.0';

    public function __construct(private \PDO $db) {}

    public function generatePublicJobTaxonomy(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, nganh_nghe, dia_diem, ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE id=? AND trang_thai="dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([$jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$job) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng đang công khai.', 404);
        }

        $taxonomy = [
            'topics' => $this->topics($job),
            'location' => $this->location($job),
        ];
        $fingerprint = hash('sha256', json_encode($taxonomy, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));

        $save = $this->db->prepare(
            'INSERT INTO content_discovery_topic_locations
                (content_type, source_table, source_id, source_key,
                 taxonomy_json, taxonomy_fingerprint, source_updated_at, generated_at)
             VALUES
                (:content_type, :source_table, :source_id, :source_key,
                 :taxonomy_json, :fingerprint, :source_updated_at, NOW())
             ON DUPLICATE KEY UPDATE
                source_key=VALUES(source_key),
                taxonomy_json=VALUES(taxonomy_json),
                taxonomy_fingerprint=VALUES(taxonomy_fingerprint),
                source_updated_at=VALUES(source_updated_at),
                generated_at=NOW()'
        );
        $save->execute([
            ':content_type' => 'job',
            ':source_table' => 'tin_tuyen_dung',
            ':source_id' => $jobId,
            ':source_key' => (string)$job['ma_tin'],
            ':taxonomy_json' => json_encode($taxonomy, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ':fingerprint' => $fingerprint,
            ':source_updated_at' => $this->nullableDate($job['ngay_cap_nhat'] ?? null),
        ]);

        return [
            'version' => self::VERSION,
            'source' => ['type'=>'job','table'=>'tin_tuyen_dung','id'=>$jobId,'key'=>(string)$job['ma_tin']],
            'taxonomy' => $taxonomy,
            'fingerprint' => $fingerprint,
        ];
    }

    private function topics(array $job): array
    {
        $industry = trim((string)($job['nganh_nghe'] ?? ''));
        $title = trim((string)($job['tieu_de'] ?? ''));
        $items = [];
        foreach ([['type'=>'industry','label'=>$industry], ['type'=>'job_title','label'=>$title]] as $item) {
            $label = $item['label'];
            $slug = $this->slug($label);
            if ($label !== '' && $slug !== '') {
                $items[] = ['type'=>$item['type'],'label'=>$label,'key'=>$slug];
            }
        }
        return $items;
    }

    private function location(array $job): array
    {
        $raw = trim((string)($job['dia_diem'] ?? ''));
        $parts = array_values(array_filter(array_map('trim', preg_split('/[,;|]+/', $raw) ?: []), static fn($v) => $v !== ''));
        $nodes = [];
        foreach ($parts as $index => $part) {
            $nodes[] = ['level'=>$index + 1,'label'=>$part,'key'=>$this->slug($part)];
        }
        return ['raw'=>$raw,'nodes'=>$nodes,'path'=>array_column($nodes,'key')];
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value));
        if ($value === '') return '';
        $map = ['à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a','è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e','ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i','ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o','ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u','ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d'];
        return trim(preg_replace('/[^a-z0-9]+/', '-', strtr($value,$map)) ?? '', '-');
    }

    private function nullableDate(mixed $value): ?string
    {
        $value = trim((string)($value ?? ''));
        return $value === '' ? null : $value;
    }
}
