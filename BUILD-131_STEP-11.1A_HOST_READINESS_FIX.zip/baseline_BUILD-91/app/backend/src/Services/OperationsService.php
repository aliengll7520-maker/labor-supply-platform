<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

use LaborPlatform\Queue\QueueService;

final class OperationsService
{
    private const QUEUES = ['notifications','moderation','search','feed','media','audit','matching'];

    public function __construct(private \PDO $db, private QueueService $queue, private array $config = []) {}

    public function snapshot(): array
    {
        $started = microtime(true);
        $queues = [];
        $alerts = [];
        foreach (self::QUEUES as $name) {
            $stats = $this->queue->stats($name);
            $oldest = $this->oldestQueuedAge($name);
            $queues[$name] = $stats + ['oldest_queued_seconds' => $oldest];
            $this->queueAlerts($alerts, $name, $stats, $oldest);
        }

        $dead = array_sum(array_map(static fn(array $s): int => (int)$s['dead'], $queues));
        $processing = array_sum(array_map(static fn(array $s): int => (int)$s['processing'], $queues));
        $queued = array_sum(array_map(static fn(array $s): int => (int)$s['queued'], $queues));

        $disk = $this->diskStats();
        if ($disk['free_percent'] !== null) {
            $warn = (float)($this->config['disk_warn_percent'] ?? 15);
            $critical = (float)($this->config['disk_critical_percent'] ?? 8);
            if ($disk['free_percent'] <= $critical) {
                $alerts[] = $this->alert('critical','storage','disk','Dung lượng đĩa trống rất thấp.', ['free_percent'=>$disk['free_percent']]);
            } elseif ($disk['free_percent'] <= $warn) {
                $alerts[] = $this->alert('warning','storage','disk','Dung lượng đĩa trống đang thấp.', ['free_percent'=>$disk['free_percent']]);
            }
        }

        $memory = $this->memoryStats();
        if ($memory['usage_percent'] !== null) {
            $warn = (float)($this->config['memory_warn_percent'] ?? 80);
            $critical = (float)($this->config['memory_critical_percent'] ?? 90);
            if ($memory['usage_percent'] >= $critical) {
                $alerts[] = $this->alert('critical','runtime','memory','Bộ nhớ PHP đang sử dụng ở mức cao.', ['usage_percent'=>$memory['usage_percent']]);
            } elseif ($memory['usage_percent'] >= $warn) {
                $alerts[] = $this->alert('warning','runtime','memory','Bộ nhớ PHP đang sử dụng cao.', ['usage_percent'=>$memory['usage_percent']]);
            }
        }

        $dbHealth = $this->databaseStats();
        if (($dbHealth['status'] ?? 'unknown') !== 'ready') {
            $alerts[] = $this->alert('critical','database','unavailable','Database không sẵn sàng.', $dbHealth);
        } elseif (($dbHealth['latency_ms'] ?? 0) >= (int)($this->config['db_latency_critical_ms'] ?? 1000)) {
            $alerts[] = $this->alert('critical','database','latency','Database phản hồi quá chậm.', ['latency_ms'=>(int)$dbHealth['latency_ms']]);
        } elseif (($dbHealth['latency_ms'] ?? 0) >= (int)($this->config['db_latency_warn_ms'] ?? 300)) {
            $alerts[] = $this->alert('warning','database','latency','Database phản hồi chậm.', ['latency_ms'=>(int)$dbHealth['latency_ms']]);
        }

        $requestMetrics = $this->requestMetrics();
        if (($requestMetrics['sampled_requests'] ?? 0) >= (int)($this->config['request_min_samples'] ?? 20)) {
            $errorWarn = (float)($this->config['request_error_warn_percent'] ?? 5);
            $errorCritical = (float)($this->config['request_error_critical_percent'] ?? 15);
            $latWarn = (int)($this->config['request_latency_warn_ms'] ?? 800);
            $latCritical = (int)($this->config['request_latency_critical_ms'] ?? 2000);
            if (($requestMetrics['error_rate_percent'] ?? 0) >= $errorCritical) {
                $alerts[] = $this->alert('critical','api','error_rate','Tỷ lệ lỗi API đang ở mức cao.', $requestMetrics);
            } elseif (($requestMetrics['error_rate_percent'] ?? 0) >= $errorWarn) {
                $alerts[] = $this->alert('warning','api','error_rate','Tỷ lệ lỗi API đang tăng cao.', $requestMetrics);
            }
            if (($requestMetrics['p95_latency_ms'] ?? 0) >= $latCritical) {
                $alerts[] = $this->alert('critical','api','latency_p95','Độ trễ P95 API đang quá cao.', $requestMetrics);
            } elseif (($requestMetrics['p95_latency_ms'] ?? 0) >= $latWarn) {
                $alerts[] = $this->alert('warning','api','latency_p95','Độ trễ P95 API đang cao.', $requestMetrics);
            }
        }

        $worker = $this->workerObservability();
        if (($worker['sampled_jobs'] ?? 0) >= (int)($this->config['worker_min_samples'] ?? 20)) {
            $warn = (float)($this->config['worker_retry_warn_percent'] ?? 10);
            $critical = (float)($this->config['worker_retry_critical_percent'] ?? 25);
            if (($worker['retry_rate_percent'] ?? 0) >= $critical) {
                $alerts[] = $this->alert('critical','worker','retry_rate','Tỷ lệ Job phải retry đang ở mức cao.', $worker);
            } elseif (($worker['retry_rate_percent'] ?? 0) >= $warn) {
                $alerts[] = $this->alert('warning','worker','retry_rate','Tỷ lệ Job phải retry đang tăng cao.', $worker);
            }
        }

        $fcm = $this->fcmObservability();
        if (($fcm['sampled'] ?? 0) >= (int)($this->config['fcm_min_samples'] ?? 20)) {
            $failureWarn = (float)($this->config['fcm_failure_warn_percent'] ?? 5);
            $failureCritical = (float)($this->config['fcm_failure_critical_percent'] ?? 15);
            $latWarn = (int)($this->config['fcm_latency_warn_ms'] ?? 1500);
            $latCritical = (int)($this->config['fcm_latency_critical_ms'] ?? 5000);
            if (($fcm['failure_rate_percent'] ?? 0) >= $failureCritical) {
                $alerts[] = $this->alert('critical','fcm','failure_rate','Tỷ lệ FCM provider failure đang ở mức cao.', $fcm);
            } elseif (($fcm['failure_rate_percent'] ?? 0) >= $failureWarn) {
                $alerts[] = $this->alert('warning','fcm','failure_rate','Tỷ lệ FCM provider failure đang tăng cao.', $fcm);
            }
            if (($fcm['p95_latency_ms'] ?? 0) >= $latCritical) {
                $alerts[] = $this->alert('critical','fcm','latency_p95','FCM provider latency P95 quá cao.', $fcm);
            } elseif (($fcm['p95_latency_ms'] ?? 0) >= $latWarn) {
                $alerts[] = $this->alert('warning','fcm','latency_p95','FCM provider latency P95 cao.', $fcm);
            }
        }

        $load = $this->loadAverage();
        $status = 'healthy';
        foreach ($alerts as $a) {
            if ($a['severity'] === 'critical') { $status = 'critical'; break; }
            if ($a['severity'] === 'warning') $status = 'warning';
        }

        return [
            'status' => $status,
            'collected_at' => date('c'),
            'collection_ms' => (int)round((microtime(true)-$started)*1000),
            'api' => $requestMetrics,
            'runtime' => [
                'php' => PHP_VERSION,
                'memory' => $memory,
                'load_average' => $load,
            ],
            'database' => $dbHealth,
            'health' => [
                'liveness' => 'ok',
                'readiness' => ($dbHealth['status'] ?? 'unknown') === 'ready' ? 'ready' : 'not_ready',
            ],
            'storage' => $disk,
            'queues' => $queues,
            'summary' => [
                'queued' => $queued,
                'processing' => $processing,
                'dead' => $dead,
                'open_alerts' => count($alerts),
            ],
            'discovery' => $this->discoveryObservability(),
            'worker' => $worker,
            'fcm' => $fcm,
            'alerts' => $alerts,
        ];
    }

    public function persist(array $snapshot): void
    {
        $stmt = $this->db->prepare('INSERT INTO operations_health_snapshots (status,summary_json,details_json,created_at) VALUES (?,?,?,CURRENT_TIMESTAMP)');
        $stmt->execute([$snapshot['status'] ?? 'unknown', json_encode($snapshot['summary'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), json_encode($snapshot, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);

        $retention = max(1, min(3650, (int)($this->config['snapshot_retention_days'] ?? 30)));
        $cleanup = $this->db->prepare('DELETE FROM operations_health_snapshots WHERE created_at < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? DAY) LIMIT 5000');
        $cleanup->execute([$retention]);
        $metricRetention = max($retention, min(3650, (int)($this->config['request_metrics_retention_days'] ?? 7)));
        $metricCleanup = $this->db->prepare('DELETE FROM operations_request_metrics WHERE created_at < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? DAY) LIMIT 10000');
        $metricCleanup->execute([$metricRetention]);

        $this->db->beginTransaction();
        try {
            foreach ((array)($snapshot['alerts'] ?? []) as $alert) {
                $fingerprint = (string)$alert['fingerprint'];
                $q = $this->db->prepare('SELECT id FROM operations_alerts WHERE fingerprint=? AND status="open" LIMIT 1');
                $q->execute([$fingerprint]);
                if ($q->fetchColumn() === false) {
                    $i = $this->db->prepare('INSERT INTO operations_alerts (fingerprint,severity,source,code,message,details_json,status,first_seen_at,last_seen_at) VALUES (?,?,?,?,?,?,"open",CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)');
                    $i->execute([$fingerprint,$alert['severity'],$alert['source'],$alert['code'],$alert['message'],json_encode($alert['details'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
                } else {
                    $u = $this->db->prepare('UPDATE operations_alerts SET severity=?,message=?,details_json=?,last_seen_at=CURRENT_TIMESTAMP WHERE fingerprint=? AND status="open"');
                    $u->execute([$alert['severity'],$alert['message'],json_encode($alert['details'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$fingerprint]);
                }
            }
            $open = $this->db->query('SELECT id,fingerprint FROM operations_alerts WHERE status="open"')->fetchAll();
            $active = [];
            foreach ((array)($snapshot['alerts'] ?? []) as $alert) $active[(string)$alert['fingerprint']] = true;
            $resolve = $this->db->prepare('UPDATE operations_alerts SET status="resolved",resolved_at=CURRENT_TIMESTAMP WHERE id=? AND status="open"');
            foreach ($open as $row) if (!isset($active[(string)$row['fingerprint']])) $resolve->execute([(int)$row['id']]);
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function openAlerts(int $limit = 100): array
    {
        $limit = max(1, min(500, $limit));
        $q = $this->db->query('SELECT id,fingerprint,severity,source,code,message,details_json,status,first_seen_at,last_seen_at,resolved_at FROM operations_alerts WHERE status="open" ORDER BY FIELD(severity,"critical","warning","info"), last_seen_at DESC LIMIT '.$limit);
        return array_map(static function(array $row): array {
            $row['details'] = json_decode((string)$row['details_json'], true) ?: [];
            unset($row['details_json']);
            return $row;
        }, $q->fetchAll());
    }

    public function recentSnapshots(int $limit = 30): array
    {
        $limit = max(1, min(200, $limit));
        $q = $this->db->query('SELECT id,status,summary_json,created_at FROM operations_health_snapshots ORDER BY id DESC LIMIT '.$limit);
        return array_map(static function(array $row): array {
            $row['summary'] = json_decode((string)$row['summary_json'], true) ?: [];
            unset($row['summary_json']);
            return $row;
        }, $q->fetchAll());
    }

    public function exceptionCenter(int $limit = 100): array
    {
        $limit = max(1, min(500, $limit));
        $snapshot = $this->snapshot();
        $alerts = $this->openAlerts($limit);
        $exceptions = [];
        foreach ($alerts as $alert) {
            $exceptions[] = [
                'id' => (int)$alert['id'],
                'severity' => $alert['severity'],
                'source' => $alert['source'],
                'code' => $alert['code'],
                'message' => $alert['message'],
                'details' => $alert['details'],
                'first_seen_at' => $alert['first_seen_at'],
                'last_seen_at' => $alert['last_seen_at'],
                'auto_recovery' => $this->autoRecoveryHint((string)$alert['source'], (string)$alert['code']),
            ];
        }
        return [
            'status' => $snapshot['status'],
            'collected_at' => $snapshot['collected_at'],
            'summary' => $snapshot['summary'],
            'exceptions' => $exceptions,
            'discovery' => $snapshot['discovery'],
            'recent_snapshots' => $this->recentSnapshots(10),
        ];
    }

    private function workerObservability(): array
    {
        $window = max(60, min(3600, (int)($this->config['worker_metrics_window_seconds'] ?? 300)));
        try {
            $q = $this->db->prepare(
                'SELECT COUNT(*) sampled,
                        SUM(attempts > 0) retried,
                        SUM(status="dead") dead
                 FROM queue_jobs
                 WHERE updated_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? SECOND)'
            );
            $q->execute([$window]);
            $r = $q->fetch(\PDO::FETCH_ASSOC) ?: [];
            $sampled=(int)($r['sampled']??0); $retried=(int)($r['retried']??0);
            return [
                'window_seconds'=>$window,
                'sampled_jobs'=>$sampled,
                'retried_jobs'=>$retried,
                'dead_jobs'=>(int)($r['dead']??0),
                'retry_rate_percent'=>$sampled>0?round(($retried/$sampled)*100,2):0,
            ];
        } catch (\Throwable) {
            return ['window_seconds'=>$window,'sampled_jobs'=>0,'retried_jobs'=>0,'dead_jobs'=>0,'retry_rate_percent'=>0,'status'=>'unavailable'];
        }
    }

    private function fcmObservability(): array
    {
        $window = max(60, min(3600, (int)($this->config['fcm_metrics_window_seconds'] ?? 900)));
        try {
            $q=$this->db->prepare(
                "SELECT status, COUNT(*) total
                 FROM fcm_delivery_metrics
                 WHERE occurred_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? SECOND)
                 GROUP BY status"
            );
            $q->execute([$window]);
            $counts=[];
            foreach($q->fetchAll(\PDO::FETCH_ASSOC) as $row) $counts[(string)$row['status']]=(int)$row['total'];
            $sampled=array_sum($counts);
            $failed=(int)($counts['failed']??0);
            $lat=$this->db->prepare(
                "SELECT latency_ms FROM fcm_delivery_metrics
                 WHERE occurred_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? SECOND)
                   AND latency_ms IS NOT NULL
                 ORDER BY latency_ms ASC LIMIT 5000"
            );
            $lat->execute([$window]);
            $latencies=array_map(static fn(array $r): int=>(int)$r['latency_ms'],$lat->fetchAll(\PDO::FETCH_ASSOC));
            $n=count($latencies);
            $p95=$n? $latencies[min($n-1,(int)ceil($n*0.95)-1)] : 0;
            return [
                'window_seconds'=>$window,
                'sampled'=>$sampled,
                'accepted'=>(int)($counts['accepted']??0),
                'failed'=>$failed,
                'invalid_token'=>(int)($counts['invalid_token']??0),
                'delivery_unknown'=>(int)($counts['delivery_unknown']??0),
                'delivered_to_device'=>(int)($counts['delivered_to_device']??0),
                'failure_rate_percent'=>$sampled?round(($failed/$sampled)*100,2):0,
                'p95_latency_ms'=>$p95,
            ];
        } catch (\Throwable) {
            return ['window_seconds'=>$window,'sampled'=>0,'accepted'=>0,'failed'=>0,'invalid_token'=>0,'delivery_unknown'=>0,'delivered_to_device'=>0,'failure_rate_percent'=>0,'p95_latency_ms'=>0,'status'=>'unavailable'];
        }
    }

    private function discoveryObservability(): array
    {
        $out = ['reconciliation_runs_24h'=>0,'requeued_24h'=>0,'failed_requeued_24h'=>0,'orphaned_24h'=>0,'last_run_at'=>null];
        try {
            $q=$this->db->query("SELECT COUNT(*) runs, COALESCE(SUM(requeued_count),0) requeued, COALESCE(SUM(failed_requeued_count),0) failed_requeued, COALESCE(SUM(orphaned_count),0) orphaned, MAX(created_at) last_run_at FROM content_discovery_reconciliation_runs WHERE created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 24 HOUR)");
            $r=$q->fetch(\PDO::FETCH_ASSOC) ?: [];
            $out['reconciliation_runs_24h']=(int)($r['runs']??0); $out['requeued_24h']=(int)($r['requeued']??0); $out['failed_requeued_24h']=(int)($r['failed_requeued']??0); $out['orphaned_24h']=(int)($r['orphaned']??0); $out['last_run_at']=$r['last_run_at']??null;
            $e=$this->db->query("SELECT COUNT(*) FROM content_discovery_events WHERE status='failed' AND created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 24 HOUR)");
            $out['failed_events_24h']=(int)$e->fetchColumn();
        } catch (\Throwable) { $out['status']='unavailable'; }
        return $out;
    }

    private function autoRecoveryHint(string $source, string $code): array
    {
        if ($source === 'queue') return ['enabled'=>true,'mode'=>'retry_or_dead_letter','admin_action'=>'Chỉ xử lý nếu job vẫn nằm trong Dead Letter.'];
        if ($source === 'database') return ['enabled'=>false,'mode'=>'manual','admin_action'=>'Kiểm tra hạ tầng database.'];
        if ($source === 'storage') return ['enabled'=>false,'mode'=>'manual','admin_action'=>'Giải phóng hoặc mở rộng dung lượng.'];
        if ($source === 'api') return ['enabled'=>true,'mode'=>'observe_and_recover','admin_action'=>'Chỉ can thiệp nếu lỗi kéo dài.'];
        return ['enabled'=>true,'mode'=>'reconciliation_or_worker','admin_action'=>'Chờ self-healing; chỉ can thiệp khi ngoại lệ không tự hồi phục.'];
    }

    private function queueAlerts(array &$alerts, string $name, array $stats, int $oldest): void
    {
        $warn = (int)($this->config['queue_warn_depth'] ?? 5000);
        $critical = (int)($this->config['queue_critical_depth'] ?? 20000);
        if ((int)$stats['depth'] >= $critical) $alerts[] = $this->alert('critical','queue',$name,'Queue đang ở mức quá tải.', ['depth'=>(int)$stats['depth']]);
        elseif ((int)$stats['depth'] >= $warn) $alerts[] = $this->alert('warning','queue',$name,'Queue đang tăng cao.', ['depth'=>(int)$stats['depth']]);
        if ((int)$stats['dead'] > 0) $alerts[] = $this->alert('critical','queue',$name,'Queue có job thất bại đã vào Dead Letter.', ['dead'=>(int)$stats['dead']]);
        $stale = (int)($this->config['stale_processing_seconds'] ?? 600);
        if ($oldest > $stale) $alerts[] = $this->alert('warning','queue',$name,'Queue có công việc chờ xử lý quá lâu.', ['oldest_queued_seconds'=>$oldest]);
        $processingStale = $this->staleProcessingCount($name, $stale);
        if ($processingStale > 0) $alerts[] = $this->alert('warning','queue',$name.'_processing_stale','Queue có job đang processing quá lâu.', ['stale_processing_count'=>$processingStale,'threshold_seconds'=>$stale]);
    }


    private function staleProcessingCount(string $queue, int $threshold): int
    {
        $threshold = max(1, $threshold);
        $q = $this->db->prepare('SELECT COUNT(*) FROM queue_jobs WHERE queue_name=? AND status="processing" AND (lease_until IS NULL OR lease_until < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? SECOND))');
        $q->execute([$queue, $threshold]);
        return (int)$q->fetchColumn();
    }

    private function oldestQueuedAge(string $queue): int
    {
        $q = $this->db->prepare('SELECT UNIX_TIMESTAMP(CURRENT_TIMESTAMP)-UNIX_TIMESTAMP(MIN(created_at)) FROM queue_jobs WHERE queue_name=? AND status="queued"');
        $q->execute([$queue]);
        return max(0, (int)($q->fetchColumn() ?: 0));
    }


    private function requestMetrics(): array
    {
        $window = max(60, min(3600, (int)($this->config['request_metrics_window_seconds'] ?? 300)));
        try {
            $q = $this->db->prepare('SELECT status_code,duration_ms FROM operations_request_metrics WHERE created_at >= DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? SECOND) ORDER BY duration_ms ASC LIMIT 5000');
            $q->execute([$window]);
            $rows = $q->fetchAll();
            $count = count($rows);
            if ($count === 0) return ['window_seconds'=>$window,'sampled_requests'=>0,'error_rate_percent'=>0,'avg_latency_ms'=>0,'p95_latency_ms'=>0];
            $durations = array_map(static fn(array $r): int => (int)$r['duration_ms'], $rows);
            $errors = 0; $sum = 0;
            foreach ($rows as $row) { if ((int)$row['status_code'] >= 500) $errors++; $sum += (int)$row['duration_ms']; }
            $idx = min($count - 1, (int)ceil($count * 0.95) - 1);
            return ['window_seconds'=>$window,'sampled_requests'=>$count,'error_count'=>$errors,'error_rate_percent'=>round(($errors/$count)*100,2),'avg_latency_ms'=>round($sum/$count,2),'p95_latency_ms'=>$durations[$idx] ?? 0];
        } catch (\Throwable) {
            return ['window_seconds'=>$window,'sampled_requests'=>0,'error_rate_percent'=>0,'avg_latency_ms'=>0,'p95_latency_ms'=>0,'status'=>'unavailable'];
        }
    }

    private function databaseStats(): array
    {
        $started = microtime(true);
        try {
            $this->db->query('SELECT 1')->fetchColumn();
            return ['status'=>'ready','latency_ms'=>(int)round((microtime(true)-$started)*1000)];
        } catch (\Throwable $e) {
            return ['status'=>'not_ready','latency_ms'=>(int)round((microtime(true)-$started)*1000),'error_class'=>get_class($e)];
        }
    }

    private function memoryStats(): array
    {
        $limit = $this->parseIniBytes((string)ini_get('memory_limit'));
        $usage = memory_get_usage(true);
        return ['usage_bytes'=>$usage,'limit_bytes'=>$limit,'usage_percent'=>$limit > 0 ? round(($usage/$limit)*100,2) : null];
    }

    private function diskStats(): array
    {
        $path = dirname(__DIR__, 2);
        $free = @disk_free_space($path);
        $total = @disk_total_space($path);
        return ['free_bytes'=>$free === false ? null : (int)$free,'total_bytes'=>$total === false ? null : (int)$total,'free_percent'=>($free !== false && $total) ? round(((float)$free/(float)$total)*100,2) : null];
    }

    private function loadAverage(): ?array
    {
        if (!function_exists('sys_getloadavg')) return null;
        $load = sys_getloadavg();
        return is_array($load) ? ['1m'=>$load[0] ?? null,'5m'=>$load[1] ?? null,'15m'=>$load[2] ?? null] : null;
    }

    private function parseIniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '-1') return 0;
        $unit = strtolower(substr($value, -1));
        $number = (float)$value;
        return match ($unit) { 'g' => (int)($number*1024*1024*1024), 'm' => (int)($number*1024*1024), 'k' => (int)($number*1024), default => (int)$number };
    }

    private function alert(string $severity, string $source, string $code, string $message, array $details): array
    {
        $fingerprint = hash('sha256', $source.'|'.$code);
        return compact('severity','source','code','message','details','fingerprint');
    }
}
