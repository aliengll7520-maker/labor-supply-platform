<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 01 — Content Discovery Foundation.
 *
 * The registry is deliberately source-neutral. Existing business tables remain
 * authoritative; this layer records a normalized discovery projection only.
 */
final class ContentDiscoveryService
{
    public const VERSION = '01.0.0';
    private const JOB_TYPE = 'job';
    private const JOB_TABLE = 'tin_tuyen_dung';

    public function __construct(private \PDO $db) {}

    public function discoverPublicJob(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, nganh_nghe, so_luong, dia_diem,
                    google_maps, luong_co_ban, tong_thu_nhap_du_kien,
                    ho_tro_tien_xe_nguoi_lao_dong_o_xa, chuyen_can, nha_o,
                    xang_xe, hieu_suat, phu_cap_khac, thuong, ho_tro,
                    tang_ca, chinh_sach_tra_luong, hop_dong, bao_hiem,
                    che_do_khac, dieu_kien_tuyen_dung, mo_ta_cong_viec,
                    hinh_anh, video, trang_thai, ngay_dang, ngay_het_han,
                    ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE id=? AND trang_thai="dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([$jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$job) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng đang công khai.', 404);
        }

        $payload = $this->normalizeJob($job);
        $fingerprint = $this->fingerprint($payload);
        $sourceUpdatedAt = $this->nullableDate($job['ngay_cap_nhat'] ?? null);

        $sql =
            'INSERT INTO content_discovery_registry
                (content_type, source_table, source_id, source_key, title,
                 visibility, source_status, location_text, payload_json,
                 content_fingerprint, discovered_at, source_updated_at,
                 last_processed_at)
             VALUES
                (:content_type, :source_table, :source_id, :source_key, :title,
                 :visibility, :source_status, :location_text, :payload_json,
                 :fingerprint, NOW(), :source_updated_at, NOW())
             ON DUPLICATE KEY UPDATE
                source_key=VALUES(source_key),
                title=VALUES(title),
                visibility=VALUES(visibility),
                source_status=VALUES(source_status),
                location_text=VALUES(location_text),
                payload_json=VALUES(payload_json),
                content_fingerprint=VALUES(content_fingerprint),
                source_updated_at=VALUES(source_updated_at),
                last_processed_at=NOW()';

        $save = $this->db->prepare($sql);
        $save->execute([
            ':content_type' => self::JOB_TYPE,
            ':source_table' => self::JOB_TABLE,
            ':source_id' => $jobId,
            ':source_key' => (string)$job['ma_tin'],
            ':title' => (string)$job['tieu_de'],
            ':visibility' => 'public',
            ':source_status' => (string)$job['trang_thai'],
            ':location_text' => (string)$job['dia_diem'],
            ':payload_json' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ':fingerprint' => $fingerprint,
            ':source_updated_at' => $sourceUpdatedAt,
        ]);

        return $this->findBySource(self::JOB_TYPE, self::JOB_TABLE, $jobId) ?? [
            'content_type' => self::JOB_TYPE,
            'source_table' => self::JOB_TABLE,
            'source_id' => $jobId,
            'fingerprint' => $fingerprint,
            'payload' => $payload,
        ];
    }

    public function findBySource(string $contentType, string $sourceTable, int $sourceId): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT id, content_type, source_table, source_id, source_key, title,
                    visibility, source_status, location_text, payload_json,
                    content_fingerprint, discovered_at, source_updated_at,
                    last_processed_at, created_at, updated_at
             FROM content_discovery_registry
             WHERE content_type=? AND source_table=? AND source_id=?
             LIMIT 1'
        );
        $stmt->execute([$contentType, $sourceTable, $sourceId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }

        $row['payload'] = $this->decodePayload((string)($row['payload_json'] ?? ''));
        unset($row['payload_json']);
        return $row;
    }

    /** @return array<string,mixed> */
    private function normalizeJob(array $job): array
    {
        return [
            'type' => self::JOB_TYPE,
            'source' => [
                'table' => self::JOB_TABLE,
                'id' => (int)$job['id'],
                'key' => (string)$job['ma_tin'],
            ],
            'title' => trim((string)$job['tieu_de']),
            'classification' => [
                'industry' => trim((string)$job['nganh_nghe']),
            ],
            'location' => [
                'text' => trim((string)$job['dia_diem']),
                'google_maps' => $this->nullableString($job['google_maps'] ?? null),
            ],
            'employment' => [
                'quantity' => (int)$job['so_luong'],
                'contract' => $this->nullableString($job['hop_dong'] ?? null),
                'work_overtime' => $this->nullableString($job['tang_ca'] ?? null),
            ],
            'income' => [
                'base_salary' => $this->number($job['luong_co_ban'] ?? null),
                'expected_total' => $this->number($job['tong_thu_nhap_du_kien'] ?? null),
                'vehicle_support' => $this->number($job['ho_tro_tien_xe_nguoi_lao_dong_o_xa'] ?? null),
                'attendance' => $this->number($job['chuyen_can'] ?? null),
                'housing' => $this->number($job['nha_o'] ?? null),
                'transport' => $this->number($job['xang_xe'] ?? null),
                'performance' => $this->number($job['hieu_suat'] ?? null),
                'other_allowance' => $this->number($job['phu_cap_khac'] ?? null),
                'bonus' => $this->number($job['thuong'] ?? null),
                'support' => $this->number($job['ho_tro'] ?? null),
            ],
            'policy' => [
                'salary_payment' => $this->nullableString($job['chinh_sach_tra_luong'] ?? null),
                'insurance' => $this->nullableString($job['bao_hiem'] ?? null),
                'other_benefits' => $this->nullableString($job['che_do_khac'] ?? null),
            ],
            'requirements' => $this->nullableString($job['dieu_kien_tuyen_dung'] ?? null),
            'description' => $this->nullableString($job['mo_ta_cong_viec'] ?? null),
            'media' => [
                'images' => $this->decodeList($job['hinh_anh'] ?? null),
                'videos' => $this->decodeList($job['video'] ?? null),
            ],
            'lifecycle' => [
                'status' => (string)$job['trang_thai'],
                'published_at' => $this->nullableDate($job['ngay_dang'] ?? null),
                'expires_at' => $this->nullableDate($job['ngay_het_han'] ?? null),
                'updated_at' => $this->nullableDate($job['ngay_cap_nhat'] ?? null),
            ],
            'discovery' => [
                'version' => self::VERSION,
                'ready_for' => [
                    'classification',
                    'tagging',
                    'search',
                    'feed',
                    'related',
                    'recommendation',
                    'seo',
                    'structured_data',
                    'sitemap',
                ],
            ],
        ];
    }

    private function fingerprint(array $payload): string
    {
        return hash(
            'sha256',
            json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
        );
    }

    private function decodePayload(string $json): array
    {
        if ($json === '') {
            return [];
        }
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function decodeList(mixed $value): array
    {
        if (is_array($value)) {
            return array_values($value);
        }
        $value = trim((string)$value);
        if ($value === '') {
            return [];
        }
        $decoded = json_decode($value, true);
        if (is_array($decoded)) {
            return array_values($decoded);
        }
        return array_values(array_filter(array_map('trim', preg_split('/[,\n]+/', $value) ?: [])));
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string)($value ?? ''));
        return $value === '' ? null : $value;
    }

    private function nullableDate(mixed $value): ?string
    {
        $value = trim((string)($value ?? ''));
        return $value === '' ? null : $value;
    }

    private function number(mixed $value): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }
        return (float)$value;
    }
}
