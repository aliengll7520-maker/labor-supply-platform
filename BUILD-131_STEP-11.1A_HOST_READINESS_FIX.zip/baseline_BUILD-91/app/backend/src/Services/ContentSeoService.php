<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 11 — deterministic SEO projection for public Content Discovery jobs. */
final class ContentSeoService
{
    public const VERSION = '11.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function publicJobSeo(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, tieu_de, nganh_nghe, dia_diem, mo_ta_cong_viec,
                    dieu_kien_tuyen_dung, luong_co_ban, tong_thu_nhap_du_kien,
                    ngay_cap_nhat, trang_thai
             FROM tin_tuyen_dung
             WHERE id = :id AND trang_thai = "dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([':id' => $jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$job) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng công khai.', 404);
        }

        $title = $this->clean((string)$job['tieu_de']);
        $industry = $this->clean((string)($job['nganh_nghe'] ?? ''));
        $location = $this->clean((string)($job['dia_diem'] ?? ''));
        $description = $this->clean((string)($job['mo_ta_cong_viec'] ?? ''));
        $requirements = $this->clean((string)($job['dieu_kien_tuyen_dung'] ?? ''));

        $metaTitle = $this->limit($title !== '' ? $title : 'Việc làm mới', 60);
        $metaDescription = $this->buildDescription($industry, $location, $description, $requirements);
        $canonical = '/viec-lam/' . $jobId . '-' . $this->slug($title);
        if (substr($canonical, -1) === '-') {
            $canonical = '/viec-lam/' . $jobId;
        }

        $payload = [
            'version' => self::VERSION,
            'type' => 'seo',
            'content_type' => 'job',
            'content_id' => $jobId,
            'meta' => [
                'title' => $metaTitle,
                'description' => $metaDescription,
                'canonical_path' => $canonical,
                'robots' => 'index,follow',
            ],
            'signals' => [
                'industry' => $industry !== '' ? $industry : null,
                'location' => $location !== '' ? $location : null,
                'updated_at' => $this->nullableString($job['ngay_cap_nhat'] ?? null),
            ],
            'source_of_truth' => 'tin_tuyen_dung',
            'visibility' => 'public',
        ];

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $fingerprint = hash('sha256', $json);

        $save = $this->db->prepare(
            'INSERT INTO content_discovery_seo
                (content_type, source_table, source_id, seo_json, seo_fingerprint, source_updated_at, generated_at)
             VALUES (:content_type, :source_table, :source_id, :seo_json, :fingerprint, :source_updated_at, NOW())
             ON DUPLICATE KEY UPDATE
                seo_json=VALUES(seo_json), seo_fingerprint=VALUES(seo_fingerprint),
                source_updated_at=VALUES(source_updated_at), generated_at=NOW()'
        );
        $save->execute([
            ':content_type' => 'job',
            ':source_table' => 'tin_tuyen_dung',
            ':source_id' => $jobId,
            ':seo_json' => $json,
            ':fingerprint' => $fingerprint,
            ':source_updated_at' => $this->nullableString($job['ngay_cap_nhat'] ?? null),
        ]);

        $payload['fingerprint'] = $fingerprint;
        return $payload;
    }

    private function buildDescription(string $industry, string $location, string $description, string $requirements): string
    {
        $parts = [];
        if ($industry !== '') $parts[] = 'Tuyển ' . $industry;
        if ($location !== '') $parts[] = 'tại ' . $location;
        if ($description !== '') $parts[] = $description;
        elseif ($requirements !== '') $parts[] = $requirements;
        $text = preg_replace('/\s+/u', ' ', trim(implode('. ', $parts))) ?? '';
        return $this->limit($text, 160);
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value, 'UTF-8'));
        $value = preg_replace('/[^\pL\pN]+/u', '-', $value) ?? '';
        $value = trim($value, '-');
        if (function_exists('iconv')) {
            $value = (string)(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value);
        }
        $value = preg_replace('/[^a-z0-9-]+/i', '-', $value) ?? '';
        return trim($value, '-');
    }

    private function clean(string $value): string
    {
        return trim(preg_replace('/\s+/u', ' ', strip_tags($value)) ?? '');
    }

    private function limit(string $value, int $length): string
    {
        if (mb_strlen($value, 'UTF-8') <= $length) return $value;
        return rtrim(mb_substr($value, 0, $length - 1, 'UTF-8')) . '…';
    }

    private function nullableString(mixed $value): ?string
    {
        $value = trim((string)($value ?? ''));
        return $value === '' ? null : $value;
    }
}
