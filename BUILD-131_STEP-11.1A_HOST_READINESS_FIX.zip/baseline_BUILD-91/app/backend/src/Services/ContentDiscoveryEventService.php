<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

use LaborPlatform\Queue\QueueService;

/**
 * BUILD 19 — source-change event bridge for Content Discovery.
 *
 * Business tables remain authoritative. A source change is recorded once and
 * converted into a deduplicated queue job; workers rebuild disposable projections.
 */
final class ContentDiscoveryEventService
{
    public const VERSION = '19.0.0';
    public const QUEUE = 'content-discovery';
    public const JOB_TYPE = 'content.discovery.refresh';

    public function __construct(private \PDO $db, private QueueService $queue) {}

    /** @return array<string,mixed> */
    public function publishJobChanged(int $jobId, string $event = 'upsert', array $context = []): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }
        $event = trim($event);
        if ($event === '' || !preg_match('/^[a-z0-9._:-]+$/', $event)) {
            throw new \InvalidArgumentException('Loại Content Discovery event không hợp lệ.');
        }

        $payload = [
            'version' => self::VERSION,
            'event' => $event,
            'content_type' => 'job',
            'source_table' => 'tin_tuyen_dung',
            'source_id' => $jobId,
            'context' => $this->safeContext($context),
        ];
        $dedupeKey = 'job:' . $jobId . ':' . $event;

        $ownsTransaction = !$this->db->inTransaction();
        if ($ownsTransaction) {
            $this->db->beginTransaction();
        }

        try {
            $stmt = $this->db->prepare(
                'INSERT INTO content_discovery_events
                    (event_key, event_type, content_type, source_table, source_id, payload_json, status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, "queued", CURRENT_TIMESTAMP)
                 ON DUPLICATE KEY UPDATE
                    payload_json=VALUES(payload_json), updated_at=CURRENT_TIMESTAMP, status="queued"'
            );
            $stmt->execute([
                $dedupeKey,
                $event,
                'job',
                'tin_tuyen_dung',
                $jobId,
                json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ]);

            $queueId = $this->queue->enqueue(
                self::QUEUE,
                self::JOB_TYPE,
                $payload,
                150,
                $dedupeKey
            );

            $update = $this->db->prepare(
                'UPDATE content_discovery_events
                 SET queue_job_id=?, status="queued", updated_at=CURRENT_TIMESTAMP
                 WHERE event_key=?'
            );
            $update->execute([$queueId, $dedupeKey]);

            if ($ownsTransaction) {
                $this->db->commit();
            }

            return [
                'version' => self::VERSION,
                'event_key' => $dedupeKey,
                'queue_job_id' => $queueId,
                'payload' => $payload,
            ];
        } catch (\Throwable $e) {
            if ($ownsTransaction && $this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }

    /** @return array<string,mixed> */
    public function markProcessed(string $eventKey): array
    {
        $q = $this->db->prepare(
            'UPDATE content_discovery_events
             SET status="processed", processed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP
             WHERE event_key=?'
        );
        $q->execute([$eventKey]);
        return ['event_key' => $eventKey, 'status' => 'processed'];
    }

    /** @return array<string,mixed> */
    public function markFailed(string $eventKey, string $error): array
    {
        $q = $this->db->prepare(
            'UPDATE content_discovery_events
             SET status="failed", last_error=?, updated_at=CURRENT_TIMESTAMP
             WHERE event_key=?'
        );
        $q->execute([mb_substr(trim($error), 0, 4000), $eventKey]);
        return ['event_key' => $eventKey, 'status' => 'failed'];
    }

    private function safeContext(array $context): array
    {
        $allowed = ['actor_type', 'actor_id', 'reason', 'request_id', 'source_version'];
        $out = [];
        foreach ($allowed as $key) {
            if (array_key_exists($key, $context)) {
                $out[$key] = is_scalar($context[$key]) ? $context[$key] : null;
            }
        }
        return $out;
    }
}
