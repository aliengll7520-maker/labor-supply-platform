<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 12 — deterministic JSON-LD projection for public job content. */
final class ContentStructuredDataService
{
    public const VERSION = '12.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function publicJobStructuredData(int $jobId): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');

        $stmt = $this->db->prepare(
            'SELECT id, tieu_de, nganh_nghe, dia_diem, mo_ta_cong_viec,
                    luong_co_ban, tong_thu_nhap_du_kien, ngay_cap_nhat, trang_thai
             FROM tin_tuyen_dung
             WHERE id = :id AND trang_thai = "dang_tuyen" LIMIT 1'
        );
        $stmt->execute([':id' => $jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$job) throw new \RuntimeException('Không tìm thấy Tin tuyển dụng công khai.', 404);

        $title = $this->clean((string)($job['tieu_de'] ?? '')) ?: 'Việc làm';
        $industry = $this->clean((string)($job['nganh_nghe'] ?? ''));
        $location = $this->clean((string)($job['dia_diem'] ?? ''));
        $description = $this->clean((string)($job['mo_ta_cong_viec'] ?? ''));
        $updated = $this->nullable((string)($job['ngay_cap_nhat'] ?? ''));

        $schema = [
            '@context' => 'https://schema.org',
            '@type' => 'JobPosting',
            'title' => $title,
            'description' => $description !== '' ? $description : $title,
            'url' => '/viec-lam/' . $jobId . '-' . $this->slug($title),
            'datePosted' => $updated,
            'identifier' => [
                '@type' => 'PropertyValue',
                'name' => 'Labor Supply Platform',
                'value' => (string)$jobId,
            ],
        ];
        if ($industry !== '') $schema['industry'] = $industry;
        if ($location !== '') {
            $schema['jobLocation'] = [
                '@type' => 'Place',
                'name' => $location,
                'address' => [
                    '@type' => 'PostalAddress',
                    'addressLocality' => $location,
                ],
            ];
        }
        $salary = $this->salary((string)($job['luong_co_ban'] ?? ''), (string)($job['tong_thu_nhap_du_kien'] ?? ''));
        if ($salary !== null) $schema['baseSalary'] = $salary;

        $payload = [
            'version' => self::VERSION,
            'type' => 'structured_data',
            'content_type' => 'job',
            'content_id' => $jobId,
            'schema' => $schema,
            'source_of_truth' => 'tin_tuyen_dung',
            'visibility' => 'public',
        ];
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $fingerprint = hash('sha256', $json);

        $save = $this->db->prepare(
            'INSERT INTO content_discovery_structured_data
                (content_type, source_table, source_id, schema_json, schema_fingerprint, source_updated_at, generated_at)
             VALUES (:content_type, :source_table, :source_id, :schema_json, :fingerprint, :source_updated_at, NOW())
             ON DUPLICATE KEY UPDATE
                schema_json=VALUES(schema_json), schema_fingerprint=VALUES(schema_fingerprint),
                source_updated_at=VALUES(source_updated_at), generated_at=NOW()'
        );
        $save->execute([
            ':content_type' => 'job', ':source_table' => 'tin_tuyen_dung', ':source_id' => $jobId,
            ':schema_json' => $json, ':fingerprint' => $fingerprint, ':source_updated_at' => $updated,
        ]);
        $payload['fingerprint'] = $fingerprint;
        return $payload;
    }

    private function salary(string $base, string $total): ?array
    {
        $text = $this->clean($base !== '' ? $base : $total);
        if ($text === '') return null;
        preg_match_all('/\d+(?:[.,]\d+)?/u', $text, $m);
        $nums = [];
        foreach ($m[0] as $n) {
            $v = (float)str_replace(',', '.', str_replace('.', '', $n));
            if ($v > 0) $nums[] = $v;
        }
        if (!$nums) return ['@type' => 'MonetaryAmount', 'currency' => 'VND', 'value' => $text];
        $value = count($nums) > 1 ? ['@type'=>'QuantitativeValue','minValue'=>min($nums),'maxValue'=>max($nums),'unitText'=>'VND'] : ['@type'=>'QuantitativeValue','value'=>$nums[0],'unitText'=>'VND'];
        return ['@type'=>'MonetaryAmount','currency'=>'VND','value'=>$value];
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value, 'UTF-8'));
        $value = preg_replace('/[^\pL\pN]+/u', '-', $value) ?? '';
        $value = trim($value, '-');
        if (function_exists('iconv')) $value = (string)(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value);
        return trim(preg_replace('/[^a-z0-9-]+/i', '-', $value) ?? '', '-');
    }
    private function clean(string $value): string { return trim(preg_replace('/\s+/u', ' ', strip_tags($value)) ?? ''); }
    private function nullable(string $value): ?string { $value = trim($value); return $value === '' ? null : $value; }
}
