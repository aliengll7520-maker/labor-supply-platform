<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 03 — deterministic Tag / Hashtag projection for Content Discovery.
 * Source data remains tin_tuyen_dung; generated tags are disposable projections.
 */
final class ContentTagService
{
    public const VERSION = '03.0.0';

    public function __construct(private \PDO $db) {}

    public function generatePublicJobTags(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, nganh_nghe, dia_diem, so_luong,
                    tong_thu_nhap_du_kien, hop_dong, tang_ca, ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE id=? AND trang_thai="dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([$jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$job) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng đang công khai.', 404);
        }

        $items = $this->buildTags($job);
        $payload = [
            'content_type' => 'job',
            'source_table' => 'tin_tuyen_dung',
            'source_id' => $jobId,
            'source_key' => (string)$job['ma_tin'],
            'tags' => $items['tags'],
            'hashtags' => $items['hashtags'],
        ];

        $fingerprint = hash(
            'sha256',
            json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
        );

        $save = $this->db->prepare(
            'INSERT INTO content_discovery_tags
                (content_type, source_table, source_id, source_key,
                 tags_json, hashtags_json, tag_fingerprint, source_updated_at, generated_at)
             VALUES
                (:content_type, :source_table, :source_id, :source_key,
                 :tags_json, :hashtags_json, :fingerprint, :source_updated_at, NOW())
             ON DUPLICATE KEY UPDATE
                source_key=VALUES(source_key),
                tags_json=VALUES(tags_json),
                hashtags_json=VALUES(hashtags_json),
                tag_fingerprint=VALUES(tag_fingerprint),
                source_updated_at=VALUES(source_updated_at),
                generated_at=NOW()'
        );
        $save->execute([
            ':content_type' => 'job',
            ':source_table' => 'tin_tuyen_dung',
            ':source_id' => $jobId,
            ':source_key' => (string)$job['ma_tin'],
            ':tags_json' => json_encode($items['tags'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ':hashtags_json' => json_encode($items['hashtags'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ':fingerprint' => $fingerprint,
            ':source_updated_at' => $this->nullableDate($job['ngay_cap_nhat'] ?? null),
        ]);

        return [
            'version' => self::VERSION,
            'source' => [
                'type' => 'job',
                'table' => 'tin_tuyen_dung',
                'id' => $jobId,
                'key' => (string)$job['ma_tin'],
            ],
            'tags' => $items['tags'],
            'hashtags' => $items['hashtags'],
            'fingerprint' => $fingerprint,
        ];
    }

    /** @return array{tags:array<int,array<string,string>>,hashtags:array<int,string>} */
    private function buildTags(array $job): array
    {
        $candidates = [
            ['type' => 'industry', 'label' => trim((string)($job['nganh_nghe'] ?? ''))],
            ['type' => 'location', 'label' => trim((string)($job['dia_diem'] ?? ''))],
            ['type' => 'contract', 'label' => trim((string)($job['hop_dong'] ?? ''))],
            ['type' => 'overtime', 'label' => trim((string)($job['tang_ca'] ?? ''))],
        ];

        $salary = (float)($job['tong_thu_nhap_du_kien'] ?? 0);
        if ($salary > 0) {
            $candidates[] = ['type' => 'income', 'label' => $this->incomeLabel($salary)];
        }

        $quantity = (int)($job['so_luong'] ?? 0);
        if ($quantity > 0) {
            $candidates[] = ['type' => 'scale', 'label' => 'Tuyển ' . $quantity . ' người'];
        }

        $tags = [];
        $hashtags = [];
        $seen = [];

        foreach ($candidates as $candidate) {
            $label = trim($candidate['label']);
            $slug = $this->slug($label);
            if ($label === '' || $slug === '' || isset($seen[$slug])) {
                continue;
            }
            $seen[$slug] = true;
            $tags[] = [
                'type' => $candidate['type'],
                'label' => $label,
                'slug' => $slug,
            ];
            $hashtags[] = '#' . str_replace('-', '', $slug);
        }

        return ['tags' => $tags, 'hashtags' => array_values(array_unique($hashtags))];
    }

    private function incomeLabel(float $amount): string
    {
        return match (true) {
            $amount < 7000000 => 'Thu nhập dưới 7 triệu',
            $amount < 10000000 => 'Thu nhập 7-10 triệu',
            $amount < 15000000 => 'Thu nhập 10-15 triệu',
            $amount < 20000000 => 'Thu nhập 15-20 triệu',
            default => 'Thu nhập từ 20 triệu',
        };
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value));
        if ($value === '') return '';
        $map = [
            'à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a',
            'è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
            'ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i','ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o',
            'ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u','ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d',
        ];
        $value = strtr($value, $map);
        return trim(preg_replace('/[^a-z0-9]+/', '-', $value) ?? '', '-');
    }

    private function nullableDate(mixed $value): ?string
    {
        $value = trim((string)($value ?? ''));
        return $value === '' ? null : $value;
    }
}
