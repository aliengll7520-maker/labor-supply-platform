<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class AuditService {
    public function __construct(private \PDO $db) {}

    /**
     * Ghi Audit Log bằng chính PDO connection được truyền vào.
     * Service không tự mở/commit/rollback transaction để caller có thể
     * đưa Audit vào cùng transaction với nghiệp vụ chính.
     */
    public function log(
        string $actor,
        ?int $actorId,
        ?int $applicationRegistrationId,
        string $table,
        string $action,
        mixed $old = null,
        mixed $new = null,
        ?string $note = null
    ): void {
        $stmt = $this->db->prepare(
            'INSERT INTO nhat_ky_he_thong
            (
                ma_nhat_ky,
                doi_tuong,
                doi_tuong_id,
                dang_ky_ho_so_phong_van_id,
                bang_du_lieu,
                hanh_dong,
                du_lieu_cu,
                du_lieu_moi,
                dia_chi_ip,
                thiet_bi,
                ghi_chu
            )
            VALUES (?,?,?,?,?,?,?,?,?,?,?)'
        );

        $stmt->execute([
            $this->makeAuditId(),
            $actor,
            $actorId,
            $applicationRegistrationId,
            $table,
            $action,
            $this->encodePayload($old),
            $this->encodePayload($new),
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            $note
        ]);
    }

    private function encodePayload(mixed $payload): ?string
    {
        if ($payload === null) {
            return null;
        }

        $payload=DataProtectionService::redact($payload);

        return json_encode(
            $payload,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
        );
    }

    private function makeAuditId(): string
    {
        return 'NK' . date('YmdHis') . bin2hex(random_bytes(3));
    }
}
