<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class PlatformExtensionService {
    public function __construct(private \PDO $db) {}

    /** @return array<int,array<string,mixed>> */
    public function modules(): array {
        $q=$this->db->query("SELECT module_key,module_name,version,trang_thai FROM he_thong_module ORDER BY thu_tu ASC,id ASC");
        return $q->fetchAll() ?: [];
    }

    /** @return array<int,array<string,mixed>> */
    public function dictionary(string $type): array {
        $q=$this->db->prepare("SELECT ma,ten,mo_ta,thu_tu FROM danh_muc_chuan WHERE loai=? AND trang_thai='active' ORDER BY thu_tu ASC,id ASC");
        $q->execute([$type]);
        return $q->fetchAll() ?: [];
    }

    /** @return array<int,array<string,mixed>> */
    public function profileSchema(string $subject): array {
        $q=$this->db->prepare("SELECT field_key,field_label,field_type,required,trang_thai,thu_tu FROM mo_ta_truong_ho_so WHERE doi_tuong=? AND trang_thai='active' ORDER BY thu_tu ASC,id ASC");
        $q->execute([$subject]);
        return $q->fetchAll() ?: [];
    }

    public function recordEvent(string $eventKey, string $actorType, ?int $actorId, ?string $entityType, ?int $entityId, array $payload=[]): void {
        $q=$this->db->prepare("INSERT INTO su_kien_he_thong (event_key,actor_type,actor_id,entity_type,entity_id,payload_json,created_at) VALUES (?,?,?,?,?,?,NOW())");
        $q->execute([$eventKey,$actorType,$actorId,$entityType,$entityId,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    }
}
