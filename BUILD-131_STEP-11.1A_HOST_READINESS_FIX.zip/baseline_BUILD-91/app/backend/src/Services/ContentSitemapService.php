<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 13 — deterministic XML sitemap projection for public job content. */
final class ContentSitemapService
{
    public const VERSION = '13.0.0';

    public function __construct(private \PDO $db, private string $publicBaseUrl = '')
    {
        $this->publicBaseUrl = rtrim(trim($publicBaseUrl), '/');
    }

    /** @return array<string,mixed> */
    public function publicJobsSitemap(int $limit = 50000): array
    {
        $limit = max(1, min($limit, 50000));
        $stmt = $this->db->query(
            'SELECT id, tieu_de, ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE trang_thai = "dang_tuyen"
             ORDER BY id ASC
             LIMIT ' . $limit
        );
        $jobs = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $urls = [];
        foreach ($jobs as $job) {
            $id = (int)$job['id'];
            $title = $this->clean((string)($job['tieu_de'] ?? '')) ?: 'viec-lam';
            $path = '/viec-lam/' . $id . '-' . $this->slug($title);
            $urls[] = [
                'loc' => $this->absolute($path),
                'lastmod' => $this->nullable((string)($job['ngay_cap_nhat'] ?? '')),
            ];
        }

        $xml = $this->renderXml($urls);
        $fingerprint = hash('sha256', $xml);

        $save = $this->db->prepare(
            'INSERT INTO content_discovery_sitemaps
                (sitemap_type, source_table, item_count, sitemap_xml, sitemap_fingerprint, generated_at)
             VALUES (:type, :source_table, :item_count, :xml, :fingerprint, NOW())
             ON DUPLICATE KEY UPDATE
                item_count=VALUES(item_count), sitemap_xml=VALUES(sitemap_xml),
                sitemap_fingerprint=VALUES(sitemap_fingerprint), generated_at=NOW()'
        );
        $save->execute([
            ':type' => 'jobs',
            ':source_table' => 'tin_tuyen_dung',
            ':item_count' => count($urls),
            ':xml' => $xml,
            ':fingerprint' => $fingerprint,
        ]);

        return [
            'version' => self::VERSION,
            'type' => 'sitemap',
            'sitemap_type' => 'jobs',
            'item_count' => count($urls),
            'xml' => $xml,
            'fingerprint' => $fingerprint,
            'source_of_truth' => 'tin_tuyen_dung',
            'visibility' => 'public',
        ];
    }

    /** @param array<int,array{loc:string,lastmod:?string}> $urls */
    private function renderXml(array $urls): string
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        foreach ($urls as $url) {
            $xml .= '  <url><loc>' . htmlspecialchars($url['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc>';
            if ($url['lastmod']) {
                $xml .= '<lastmod>' . htmlspecialchars($url['lastmod'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</lastmod>';
            }
            $xml .= '</url>' . "\n";
        }
        return $xml . '</urlset>\n';
    }

    private function absolute(string $path): string
    {
        if ($this->publicBaseUrl !== '' && preg_match('#^https?://#i', $this->publicBaseUrl)) {
            return $this->publicBaseUrl . $path;
        }
        return $path;
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value, 'UTF-8'));
        $value = preg_replace('/[^\pL\pN]+/u', '-', $value) ?? '';
        $value = trim($value, '-');
        if (function_exists('iconv')) $value = (string)(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value);
        return trim(preg_replace('/[^a-z0-9-]+/i', '-', $value) ?? '', '-');
    }
    private function clean(string $value): string { return trim(preg_replace('/\s+/u', ' ', strip_tags($value)) ?? ''); }
    private function nullable(string $value): ?string { $value = trim($value); return $value === '' ? null : $value; }
}
