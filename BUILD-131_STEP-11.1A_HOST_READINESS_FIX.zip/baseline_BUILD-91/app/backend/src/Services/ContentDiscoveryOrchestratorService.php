<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 21 — System Orchestrator for the Content Discovery pipeline.
 *
 * The orchestrator owns sequencing only. Source data remains authoritative;
 * projection work stays asynchronous and rebuildable through BUILD 19.
 */
final class ContentDiscoveryOrchestratorService
{
    public const VERSION = '21.0.0';

    public function __construct(
        private \PDO $db,
        private ContentDiscoveryEventService $events
    ) {}

    /** @return array<string,mixed> */
    public function dispatchJob(int $jobId, array $context = []): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }

        $source = $this->loadSource($jobId);
        if (!$source) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng.');
        }

        $event = $this->events->publishJobChanged($jobId, 'upsert', [
            'actor_type' => $context['actor_type'] ?? 'system',
            'actor_id' => $context['actor_id'] ?? null,
            'reason' => $context['reason'] ?? 'content_discovery_orchestrator',
            'request_id' => $context['request_id'] ?? null,
            'source_version' => self::VERSION,
        ]);

        return [
            'version' => self::VERSION,
            'content_type' => 'job',
            'source_id' => $jobId,
            'source_status' => (string)($source['trang_thai'] ?? ''),
            'orchestration' => [
                'accepted' => true,
                'mode' => 'async',
                'pipeline' => [
                    'source', 'quality_gate', 'discovery', 'classification',
                    'tags', 'topic_location', 'search', 'feed', 'related',
                    'recommendation', 'public', 'url', 'seo',
                    'structured_data', 'sitemap', 'seo_lifecycle', 'delivery'
                ],
            ],
            'event' => $event,
        ];
    }

    /** @return array<string,mixed> */
    public function status(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }
        $stmt = $this->db->prepare(
            'SELECT event_key,event_type,status,queue_job_id,created_at,processed_at,last_error
             FROM content_discovery_events
             WHERE content_type="job" AND source_id=?
             ORDER BY id DESC LIMIT 20'
        );
        $stmt->execute([$jobId]);
        return [
            'version' => self::VERSION,
            'content_type' => 'job',
            'source_id' => $jobId,
            'events' => $stmt->fetchAll(\PDO::FETCH_ASSOC),
        ];
    }

    private function loadSource(int $jobId): ?array
    {
        $stmt = $this->db->prepare('SELECT id,trang_thai FROM tin_tuyen_dung WHERE id=? LIMIT 1');
        $stmt->execute([$jobId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
}
