<?php
declare(strict_types=1);

namespace Labor\Backend\Services;

final class OperationsQueueMetricsService
{
    public function __construct(
        private QueueMetricsService $queueMetrics
    ) {}

    public function run(): array
    {
        return [
            'metrics' => $this->queueMetrics->snapshot(),
            'alerts' => $this->queueMetrics->alerts(),
            'generated_at' => gmdate('c'),
        ];
    }
}
