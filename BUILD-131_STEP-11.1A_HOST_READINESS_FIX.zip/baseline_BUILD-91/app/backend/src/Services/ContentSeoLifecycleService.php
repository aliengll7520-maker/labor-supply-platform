<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 14 — SEO lifecycle state projection for public job content. */
final class ContentSeoLifecycleService
{
    public const VERSION = '14.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed>|null */
    public function get(int $jobId): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT id, tieu_de, trang_thai, ngay_tao, ngay_cap_nhat
             FROM tin_tuyen_dung WHERE id = :id LIMIT 1'
        );
        $stmt->execute([':id' => $jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$job) return null;

        $status = (string)($job['trang_thai'] ?? '');
        $state = match ($status) {
            'dang_tuyen' => 'indexable',
            'da_dong', 'het_han', 'da_huy' => 'retired',
            default => 'not_public',
        };

        $payload = [
            'version' => self::VERSION,
            'content_id' => (int)$job['id'],
            'content_type' => 'job',
            'source_of_truth' => 'tin_tuyen_dung',
            'status' => $status,
            'seo_state' => $state,
            'indexable' => $state === 'indexable',
            'canonical_required' => $state === 'indexable',
            'structured_data_allowed' => $state === 'indexable',
            'sitemap_allowed' => $state === 'indexable',
            'updated_at' => $job['ngay_cap_nhat'] ?? null,
            'fingerprint' => '',
        ];
        $copy = $payload;
        $copy['fingerprint'] = '';
        $payload['fingerprint'] = hash('sha256', json_encode($copy, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        $this->persist($payload);
        return $payload;
    }

    /** @param array<string,mixed> $payload */
    private function persist(array $payload): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO content_discovery_seo_lifecycle
             (content_id, content_type, seo_state, indexable, canonical_required,
              structured_data_allowed, sitemap_allowed, source_status, fingerprint, updated_at)
             VALUES (:content_id,:content_type,:seo_state,:indexable,:canonical_required,
              :structured_data_allowed,:sitemap_allowed,:source_status,:fingerprint,:updated_at)
             ON DUPLICATE KEY UPDATE
              seo_state=VALUES(seo_state), indexable=VALUES(indexable),
              canonical_required=VALUES(canonical_required), structured_data_allowed=VALUES(structured_data_allowed),
              sitemap_allowed=VALUES(sitemap_allowed), source_status=VALUES(source_status),
              fingerprint=VALUES(fingerprint), updated_at=VALUES(updated_at)'
        );
        $stmt->execute([
            ':content_id' => $payload['content_id'], ':content_type' => $payload['content_type'],
            ':seo_state' => $payload['seo_state'], ':indexable' => (int)$payload['indexable'],
            ':canonical_required' => (int)$payload['canonical_required'],
            ':structured_data_allowed' => (int)$payload['structured_data_allowed'],
            ':sitemap_allowed' => (int)$payload['sitemap_allowed'], ':source_status' => $payload['status'],
            ':fingerprint' => $payload['fingerprint'], ':updated_at' => $payload['updated_at'],
        ]);
    }
}
