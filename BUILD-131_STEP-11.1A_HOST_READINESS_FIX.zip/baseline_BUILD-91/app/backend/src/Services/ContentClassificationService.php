<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 02 — Job Content Classification.
 *
 * Converts the normalized Content Discovery object into deterministic,
 * source-derived classification dimensions. No source data is replaced.
 */
final class ContentClassificationService
{
    public const VERSION = '02.0.0';

    public function __construct(private \PDO $db) {}

    public function classifyPublicJob(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, nganh_nghe, so_luong, dia_diem,
                    tong_thu_nhap_du_kien, hop_dong, tang_ca,
                    ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE id=? AND trang_thai="dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([$jobId]);
        $job = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$job) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng đang công khai.', 404);
        }

        $classification = $this->buildClassification($job);
        $fingerprint = hash(
            'sha256',
            json_encode($classification, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
        );

        $sql =
            'INSERT INTO content_discovery_classifications
                (content_type, source_table, source_id, source_key,
                 classification_json, classification_fingerprint,
                 source_updated_at, classified_at)
             VALUES
                (:content_type, :source_table, :source_id, :source_key,
                 :classification_json, :fingerprint, :source_updated_at, NOW())
             ON DUPLICATE KEY UPDATE
                source_key=VALUES(source_key),
                classification_json=VALUES(classification_json),
                classification_fingerprint=VALUES(classification_fingerprint),
                source_updated_at=VALUES(source_updated_at),
                classified_at=NOW()';

        $save = $this->db->prepare($sql);
        $save->execute([
            ':content_type' => 'job',
            ':source_table' => 'tin_tuyen_dung',
            ':source_id' => $jobId,
            ':source_key' => (string)$job['ma_tin'],
            ':classification_json' => json_encode($classification, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
            ':fingerprint' => $fingerprint,
            ':source_updated_at' => $this->nullableDate($job['ngay_cap_nhat'] ?? null),
        ]);

        return [
            'version' => self::VERSION,
            'source' => [
                'type' => 'job',
                'table' => 'tin_tuyen_dung',
                'id' => $jobId,
                'key' => (string)$job['ma_tin'],
            ],
            'classification' => $classification,
            'fingerprint' => $fingerprint,
        ];
    }

    /** @return array<string,mixed> */
    private function buildClassification(array $job): array
    {
        $industryRaw = trim((string)($job['nganh_nghe'] ?? ''));
        $locationRaw = trim((string)($job['dia_diem'] ?? ''));
        $contractRaw = trim((string)($job['hop_dong'] ?? ''));
        $overtimeRaw = trim((string)($job['tang_ca'] ?? ''));
        $salary = (float)($job['tong_thu_nhap_du_kien'] ?? 0);
        $quantity = max(0, (int)($job['so_luong'] ?? 0));

        return [
            'content' => [
                'type' => 'job',
                'title' => trim((string)($job['tieu_de'] ?? '')),
            ],
            'industry' => [
                'raw' => $industryRaw,
                'key' => $this->slug($industryRaw),
            ],
            'location' => [
                'raw' => $locationRaw,
                'key' => $this->slug($locationRaw),
            ],
            'employment' => [
                'contract_raw' => $contractRaw !== '' ? $contractRaw : null,
                'contract_key' => $this->slug($contractRaw),
                'overtime_raw' => $overtimeRaw !== '' ? $overtimeRaw : null,
                'overtime_key' => $this->slug($overtimeRaw),
            ],
            'scale' => [
                'quantity' => $quantity,
                'quantity_band' => $this->quantityBand($quantity),
            ],
            'income' => [
                'expected_total' => $salary,
                'income_band' => $this->incomeBand($salary),
            ],
            'dimensions' => [
                'industry',
                'location',
                'employment',
                'scale',
                'income',
            ],
        ];
    }

    private function quantityBand(int $quantity): string
    {
        return match (true) {
            $quantity <= 1 => '1',
            $quantity <= 5 => '2-5',
            $quantity <= 20 => '6-20',
            $quantity <= 50 => '21-50',
            default => '51+',
        };
    }

    private function incomeBand(float $amount): string
    {
        return match (true) {
            $amount <= 0 => 'unknown',
            $amount < 7000000 => 'under-7m',
            $amount < 10000000 => '7m-10m',
            $amount < 15000000 => '10m-15m',
            $amount < 20000000 => '15m-20m',
            default => '20m-plus',
        };
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value));
        if ($value === '') {
            return '';
        }

        $map = [
            'à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a',
            'è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
            'ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i',
            'ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o',
            'ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u',
            'ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d',
        ];
        $value = strtr($value, $map);
        $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
        return trim($value, '-');
    }

    private function nullableDate(mixed $value): ?string
    {
        $value = trim((string)($value ?? ''));
        return $value === '' ? null : $value;
    }
}
