<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 06 — deterministic public Content Discovery feed.
 * The business table remains authoritative; this layer only exposes a
 * stable cursor-based discovery stream for published recruitment content.
 */
final class ContentFeedService
{
    public const VERSION = '06.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function publicJobs(array $input): array
    {
        $limit = min(50, max(1, (int)($input['limit'] ?? 20)));
        $cursor = max(0, (int)($input['cursor'] ?? 0));
        $topic = trim((string)($input['topic'] ?? ''));
        $location = trim((string)($input['location'] ?? ''));

        $where = ['j.trang_thai = "dang_tuyen"', 'j.id < :cursor'];
        $params = [':cursor' => $cursor > 0 ? $cursor : PHP_INT_MAX];

        if ($topic !== '') {
            $where[] = '(j.nganh_nghe LIKE :topic OR j.tieu_de LIKE :topic)';
            $params[':topic'] = '%' . $topic . '%';
        }
        if ($location !== '') {
            $where[] = 'j.dia_diem LIKE :location';
            $params[':location'] = '%' . $location . '%';
        }

        $sql = 'SELECT j.id, j.ma_tin, j.tieu_de, j.nganh_nghe, j.dia_diem,
                       j.luong_co_ban, j.tong_thu_nhap_du_kien, j.so_luong,
                       j.ngay_dang, j.ngay_cap_nhat
                FROM tin_tuyen_dung j
                WHERE ' . implode(' AND ', $where) . '
                ORDER BY j.id DESC
                LIMIT :limit';
        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? \PDO::PARAM_INT : \PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit', $limit + 1, \PDO::PARAM_INT);
        $stmt->execute();

        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        $hasMore = count($rows) > $limit;
        if ($hasMore) array_pop($rows);

        $items = array_map(static function (array $row): array {
            return [
                'id' => (int)$row['id'],
                'key' => (string)$row['ma_tin'],
                'title' => (string)$row['tieu_de'],
                'industry' => (string)$row['nganh_nghe'],
                'location' => (string)$row['dia_diem'],
                'salary' => [
                    'base' => $row['luong_co_ban'] === null ? null : (float)$row['luong_co_ban'],
                    'expected_total' => $row['tong_thu_nhap_du_kien'] === null ? null : (float)$row['tong_thu_nhap_du_kien'],
                ],
                'quantity' => (int)$row['so_luong'],
                'published_at' => $row['ngay_dang'],
                'updated_at' => $row['ngay_cap_nhat'],
            ];
        }, $rows);

        $next = $hasMore && $items ? (int)$items[count($items)-1]['id'] : null;

        return [
            'version' => self::VERSION,
            'cursor' => $cursor > 0 ? $cursor : null,
            'filters' => ['topic' => $topic, 'location' => $location],
            'pagination' => [
                'limit' => $limit,
                'has_more' => $hasMore,
                'next_cursor' => $next,
            ],
            'items' => $items,
        ];
    }
}
