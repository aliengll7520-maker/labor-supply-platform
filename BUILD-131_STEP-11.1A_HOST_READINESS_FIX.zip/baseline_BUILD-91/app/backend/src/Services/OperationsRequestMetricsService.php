<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class OperationsRequestMetricsService
{
    public function __construct(private \PDO $db, private array $config = []) {}

    public function register(string $method, string $path, float $startedAt): void
    {
        $rate = (float)($this->config['request_sample_rate'] ?? 0.10);
        if ($rate <= 0 || (random_int(0, 1000000) / 1000000) > min(1.0, $rate)) return;
        register_shutdown_function(function() use ($method, $path, $startedAt): void {
            try {
                $duration = (int)round((microtime(true) - $startedAt) * 1000);
                $status = http_response_code();
                if ($status < 100) $status = 200;
                $q = $this->db->prepare('INSERT INTO operations_request_metrics (method,path,status_code,duration_ms,created_at) VALUES (?,?,?,?,CURRENT_TIMESTAMP)');
                $q->execute([strtoupper(substr($method, 0, 10)), substr($path, 0, 255), $status, max(0, $duration)]);
            } catch (\Throwable) {
                // Monitoring must never break the application response.
            }
        });
    }
}
