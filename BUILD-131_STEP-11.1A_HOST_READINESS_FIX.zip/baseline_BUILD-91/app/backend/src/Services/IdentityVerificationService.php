<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class IdentityVerificationService {
    public function __construct(private \PDO $db, private int $ttlMinutes=10, private int $maxAttempts=5, private bool $exposeCode=false) {}

    public function request(int $identityId,string $role,string $channel,string $destination,?string $provider=null): array {
        if(!in_array($role,['worker','employer'],true)) throw new \RuntimeException('Vai trò xác minh không hợp lệ.');
        if(!in_array($channel,['phone','email','provider'],true)) throw new \RuntimeException('Kênh xác minh không hợp lệ.');
        $destination=trim($destination);
        if($destination==='') throw new \RuntimeException('Thiếu đích xác minh.');
        $this->db->prepare('UPDATE identity_verifications SET status="cancelled" WHERE identity_id=? AND role_code=? AND channel=? AND status="pending"')->execute([$identityId,$role,$channel]);
        if($channel==='provider') {
            $this->db->prepare('INSERT INTO identity_verifications(identity_id,role_code,channel,destination,provider,status,verified_at,metadata_json) VALUES(?,?,?,?,?,"verified",NOW(),?)')->execute([$identityId,$role,$channel,$destination,$provider,json_encode(['provider_verified'=>true],JSON_UNESCAPED_UNICODE)]);
            return ['status'=>'verified','channel'=>$channel,'provider'=>$provider];
        }
        $code=(string)random_int(100000,999999);
        $hash=hash('sha256',$code);
        $expires=date('Y-m-d H:i:s',time()+($this->ttlMinutes*60));
        $this->db->prepare('INSERT INTO identity_verifications(identity_id,role_code,channel,destination,challenge_hash,status,max_attempts,expires_at) VALUES(?,?,?,?,?,"pending",?,?,?)')->execute([$identityId,$role,$channel,$destination,$hash,$this->maxAttempts,$expires]);
        $out=['status'=>'pending','channel'=>$channel,'expires_at'=>$expires];
        if($this->exposeCode) $out['test_code']=$code;
        return $out;
    }

    public function confirm(int $identityId,string $role,string $channel,string $code): array {
        $q=$this->db->prepare('SELECT * FROM identity_verifications WHERE identity_id=? AND role_code=? AND channel=? AND status="pending" ORDER BY id DESC LIMIT 1');
        $q->execute([$identityId,$role,$channel]); $row=$q->fetch();
        if(!$row) throw new \RuntimeException('Không có mã xác minh đang chờ.');
        if($row['expires_at']!==null && strtotime($row['expires_at'])<time()){ $this->db->prepare('UPDATE identity_verifications SET status="expired" WHERE id=?')->execute([$row['id']]); throw new \RuntimeException('Mã xác minh đã hết hạn.'); }
        if((int)$row['attempts'] >= (int)$row['max_attempts']){ $this->db->prepare('UPDATE identity_verifications SET status="failed" WHERE id=?')->execute([$row['id']]); throw new \RuntimeException('Đã vượt quá số lần nhập mã cho phép.'); }
        $this->db->prepare('UPDATE identity_verifications SET attempts=attempts+1 WHERE id=?')->execute([$row['id']]);
        if(!hash_equals((string)$row['challenge_hash'],hash('sha256',trim($code)))) throw new \RuntimeException('Mã xác minh không đúng.');
        $this->db->prepare('UPDATE identity_verifications SET status="verified",verified_at=NOW() WHERE id=?')->execute([$row['id']]);
        $this->syncIdentity($identityId,$role,$channel,$row['destination']);
        return ['status'=>'verified','channel'=>$channel,'verified_at'=>date('c')];
    }

    public function status(int $identityId): array {
        $q=$this->db->prepare('SELECT role_code,channel,destination,status,expires_at,verified_at,ngay_tao FROM identity_verifications WHERE identity_id=? ORDER BY id DESC');
        $q->execute([$identityId]); return $q->fetchAll()?:[];
    }

    private function syncIdentity(int $identityId,string $role,string $channel,string $destination): void {
        $q=$this->db->prepare('SELECT role_status FROM identity_role_memberships WHERE identity_id=? AND role_code=? ORDER BY id DESC LIMIT 1');
        $q->execute([$identityId,$role]);
        $roleStatus=(string)$q->fetchColumn();
        $principalStatus=$roleStatus==='active'?'hoat_dong':'cho_xac_minh';
        $this->db->prepare('UPDATE identity_principals SET trang_thai=?,ngay_cap_nhat=CURRENT_TIMESTAMP WHERE id=?')->execute([$principalStatus,$identityId]);
        $this->db->prepare('UPDATE identity_role_memberships SET onboarding_status=CASE WHEN role_status="active" THEN "san_sang" ELSE onboarding_status END WHERE identity_id=? AND role_code=?')->execute([$identityId,$role]);
        $q=$this->db->prepare('INSERT INTO identity_onboarding_events(identity_id,role_code,event_code,event_status,metadata_json) VALUES(?,?,?,"completed",?)');
        $q->execute([$identityId,$role,'verification.'.$channel.'.verified',json_encode(['destination'=>$destination],JSON_UNESCAPED_UNICODE)]);
    }
}
