<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

final class ContentSearchService
{
    public const VERSION = '06.0.0';
    private const CACHE_TTL = 30;
    private const LOCATION_TTL = 0;
    private const LOCATION_CHUNK_SIZE = 100;

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function searchPublicJobs(array $input): array
    {
        $q = trim((string)($input['q'] ?? ''));
        $topic = trim((string)($input['topic'] ?? ''));
        $location = $this->normalizeLocation((string)($input['location'] ?? ''));
        $page = max(1, (int)($input['page'] ?? 1));
        $perPage = min(50, max(1, (int)($input['per_page'] ?? 20)));
        $generation = function_exists('apcu_fetch') ? (int)(apcu_fetch('labor:content-search:generation') ?: 1) : 1;
        $cacheKey = 'labor:content-search:v3:' . $generation . ':' . sha1(json_encode([$q,$topic,$location,$page,$perPage], JSON_UNESCAPED_UNICODE));

        if (function_exists('apcu_fetch')) {
            $cached = apcu_fetch($cacheKey, $hit);
            if ($hit && is_array($cached)) return $cached;
        }

        // Location-only public filters are RAM-only after a worker/CLI warm-up.
        // A cold index never falls back to a request-time database scan.
        if ($q === '' && $topic === '' && $location !== '') {
            $result = $this->searchFromLocationRam($location, $page, $perPage);
            if ($result !== null) {
                if (function_exists('apcu_store')) apcu_store($cacheKey, $result, self::CACHE_TTL);
                return $result;
            }
        }

        // Cache miss protection: coordinate concurrent API instances through a short
        // MySQL advisory lock. The lock is per cache key, so unrelated searches do not
        // block each other. The cache is checked again after the lock is acquired.
        $lockName = 'labor_content_search_' . sha1($cacheKey);
        $lockAcquired = false;
        try {
            $lockStmt = $this->db->prepare('SELECT GET_LOCK(?, 1)');
            $lockStmt->execute([$lockName]);
            $lockAcquired = ((int)$lockStmt->fetchColumn() === 1);
            if ($lockAcquired && function_exists('apcu_fetch')) {
                $cached = apcu_fetch($cacheKey, $hitAfterLock);
                if ($hitAfterLock && is_array($cached)) return $cached;
            }

            $where = ['j.trang_thai = "dang_tuyen"'];
            $params = [];
        if ($q !== '') {
            $where[] = 'MATCH(j.tieu_de,j.nganh_nghe,j.dia_diem,j.mo_ta_cong_viec,j.dieu_kien_tuyen_dung) AGAINST(:search_q IN BOOLEAN MODE)';
            $params[':search_q'] = $this->booleanQuery($q);
        }
        if ($topic !== '') {
            $where[] = 'MATCH(j.tieu_de,j.nganh_nghe) AGAINST(:topic_q IN BOOLEAN MODE)';
            $params[':topic_q'] = $this->booleanQuery($topic);
        }
        if ($location !== '' && $location !== '__all__') {
            $where[] = 'j.dia_diem LIKE :location';
            $params[':location'] = '%' . $location . '%';
        }
        $whereSql = implode(' AND ', $where);
        $count = $this->db->prepare('SELECT COUNT(*) FROM tin_tuyen_dung j WHERE ' . $whereSql);
        foreach ($params as $key=>$value) $count->bindValue($key,$value,\PDO::PARAM_STR);
        $count->execute();
        $total=(int)$count->fetchColumn();
        $offset=($page-1)*$perPage;
        $sql='SELECT j.id,j.ma_tin,j.tieu_de,j.nganh_nghe,j.dia_diem,j.luong_co_ban,j.tong_thu_nhap_du_kien,j.so_luong,j.ngay_dang,j.ngay_cap_nhat
              FROM tin_tuyen_dung j WHERE '.$whereSql.' ORDER BY j.ngay_cap_nhat DESC,j.id DESC LIMIT :limit OFFSET :offset';
        $stmt=$this->db->prepare($sql);
        foreach($params as $key=>$value) $stmt->bindValue($key,$value,\PDO::PARAM_STR);
        $stmt->bindValue(':limit',$perPage,\PDO::PARAM_INT); $stmt->bindValue(':offset',$offset,\PDO::PARAM_INT); $stmt->execute();
        $items=[];
        while($row=$stmt->fetch(\PDO::FETCH_ASSOC)) $items[]=$this->mapJobRow($row);
        $result=['version'=>self::VERSION,'query'=>['q'=>$q,'topic'=>$topic,'location'=>$location],'pagination'=>['page'=>$page,'per_page'=>$perPage,'total'=>$total,'total_pages'=>$total===0?0:(int)ceil($total/$perPage)],'items'=>$items];
            if(function_exists('apcu_store')) apcu_store($cacheKey,$result,self::CACHE_TTL);
            return $result;
        } finally {
            if ($lockAcquired) {
                try {
                    $releaseStmt = $this->db->prepare('SELECT RELEASE_LOCK(?)');
                    $releaseStmt->execute([$lockName]);
                } catch (\Throwable $e) {
                    // Never turn a successful search response into an error because
                    // advisory-lock cleanup failed.
                }
            }
        }
    }

    /**
     * Pre-warm common location indexes as bounded APCu chunks.
     * Database work happens only in worker/CLI, never in public request path.
     */
    public function warmLocationSnapshots(array $locations = ['__all__', 'Hà Nội', 'TP.HCM', 'Đà Nẵng']): array
    {
        if (!function_exists('apcu_store')) return ['enabled'=>false,'warmed'=>0,'reason'=>'APCu unavailable'];
        $result=[];
        foreach($locations as $rawLocation){
            $location=$this->normalizeLocation((string)$rawLocation);
            $where=['j.trang_thai = "dang_tuyen"']; $params=[];
            if($location!=='' && $location!=='__all__'){$where[]='j.dia_diem LIKE :location';$params[':location']='%'.$location.'%';}
            $stmt=$this->db->prepare('SELECT j.id,j.ma_tin,j.tieu_de,j.nganh_nghe,j.dia_diem,j.luong_co_ban,j.tong_thu_nhap_du_kien,j.so_luong,j.ngay_dang,j.ngay_cap_nhat FROM tin_tuyen_dung j WHERE '.implode(' AND ',$where).' ORDER BY j.ngay_cap_nhat DESC,j.id DESC');
            foreach($params as $k=>$v)$stmt->bindValue($k,$v,\PDO::PARAM_STR);
            $stmt->execute();
            $entries=[];$total=0;
            while($row=$stmt->fetch(\PDO::FETCH_ASSOC)){
                $item=$this->mapJobRow($row);$id=(int)$item['id'];$total++;
                apcu_store($this->jobItemCacheKey($id),$item,self::LOCATION_TTL);
                $entries[]=['id'=>$id,'updated_at'=>(string)$item['updated_at']];
            }
            $this->writeLocationIndex($location,$entries);
            $result[$location]=['total'=>$total,'chunks'=>(int)ceil($total/self::LOCATION_CHUNK_SIZE)];
        }
        return ['enabled'=>true,'warmed'=>count($result),'items'=>$result];
    }

    /** Location-only requests are RAM-only after warm-up. */
    private function searchFromLocationRam(string $location,int $page,int $perPage): ?array
    {
        if(!function_exists('apcu_fetch'))return $this->warmingResult($location,$page,$perPage);
        $meta=apcu_fetch($this->locationMetaKey($location),$hit);
        if(!$hit||!is_array($meta)||($meta['ready']??false)!==true)return $this->warmingResult($location,$page,$perPage);
        $total=(int)($meta['total']??0);$offset=($page-1)*$perPage;
        $base=['version'=>self::VERSION,'query'=>['q'=>'','topic'=>'','location'=>$location],'pagination'=>['page'=>$page,'per_page'=>$perPage,'total'=>$total,'total_pages'=>$total===0?0:(int)ceil($total/$perPage)]];
        if($offset >= $total)return $base+['items'=>[],'source'=>'location_ram'];
        $startChunk=intdiv($offset,self::LOCATION_CHUNK_SIZE);$endChunk=intdiv($offset+$perPage-1,self::LOCATION_CHUNK_SIZE);$ids=[];
        for($i=$startChunk;$i<=$endChunk;$i++){
            $chunk=apcu_fetch($this->locationChunkKey($location,$i),$chunkHit);
            if(!$chunkHit||!is_array($chunk))return $this->warmingResult($location,$page,$perPage);
            foreach($chunk as $entry)$ids[]=(int)($entry['id']??0);
        }
        $localOffset=$offset-($startChunk*self::LOCATION_CHUNK_SIZE);$ids=array_slice($ids,$localOffset,$perPage);$items=[];
        foreach($ids as $id){$item=apcu_fetch($this->jobItemCacheKey($id),$itemHit);if(!$itemHit||!is_array($item))return $this->warmingResult($location,$page,$perPage);$items[]=$item;}
        return $base+['items'=>$items,'source'=>'location_ram'];
    }

    private function warmingResult(string $location,int $page,int $perPage): array
    {
        return ['version'=>self::VERSION,'query'=>['q'=>'','topic'=>'','location'=>$location],'pagination'=>['page'=>$page,'per_page'=>$perPage,'total'=>0,'total_pages'=>0],'items'=>[],'source'=>'location_ram_warming','warming'=>true];
    }

    private function locationMetaKey(string $location): string { return 'labor:content-search:location:v2:meta:'.sha1($location); }
    private function locationChunkKey(string $location,int $chunk): string { return 'labor:content-search:location:v2:chunk:'.sha1($location).':'.$chunk; }
    private function jobItemCacheKey(int $jobId): string { return 'labor:content-search:job:v2:item:'.$jobId; }

    private function writeLocationIndex(string $location,array $entries): void
    {
        $old=apcu_fetch($this->locationMetaKey($location),$hit);
        $oldChunks=($hit&&is_array($old))?(int)($old['chunks']??0):0;
        $chunks=array_chunk($entries,self::LOCATION_CHUNK_SIZE);
        foreach($chunks as $i=>$chunk)apcu_store($this->locationChunkKey($location,$i),$chunk,self::LOCATION_TTL);
        for($i=count($chunks);$i<$oldChunks;$i++)apcu_delete($this->locationChunkKey($location,$i));
        apcu_store($this->locationMetaKey($location),['version'=>self::VERSION,'location'=>$location,'generated_at'=>gmdate('c'),'total'=>count($entries),'chunks'=>count($chunks),'chunk_size'=>self::LOCATION_CHUNK_SIZE,'ready'=>true],self::LOCATION_TTL);
    }

    private function removeJobFromLocationIndex(string $location,int $jobId): void
    {
        $meta=apcu_fetch($this->locationMetaKey($location),$hit);if(!$hit||!is_array($meta)||($meta['ready']??false)!==true)return;
        $entries=[];$n=(int)($meta['chunks']??0);
        for($i=0;$i<$n;$i++){ $chunk=apcu_fetch($this->locationChunkKey($location,$i),$ok); if(!$ok||!is_array($chunk))return; foreach($chunk as $entry)if((int)($entry['id']??0)!==$jobId)$entries[]=$entry; }
        $this->writeLocationIndex($location,$entries);
    }

    /** Invalidate bounded indexes; rebuild is done off the request path by worker/cron. */
    public function invalidateLocationSnapshots(): void
    {
        if(!function_exists('apcu_delete'))return;
        foreach(['__all__','Hà Nội','TP.HCM','Đà Nẵng'] as $location){
            $meta=apcu_fetch($this->locationMetaKey($location),$hit);
            if($hit&&is_array($meta)){for($i=0,$n=(int)($meta['chunks']??0);$i<$n;$i++)apcu_delete($this->locationChunkKey($location,$i));}
            apcu_delete($this->locationMetaKey($location));
        }
    }

    /** Source change updates the RAM index off the public request path. */
    public function syncWarmedJob(array $job): void
    {
        if(!function_exists('apcu_fetch')||!function_exists('apcu_store'))return;
        $jobId=(int)($job['id']??0);if($jobId<=0)return;
        $item=$this->mapJobRow($job);apcu_store($this->jobItemCacheKey($jobId),$item,self::LOCATION_TTL);
        foreach(['__all__','Hà Nội','TP.HCM','Đà Nẵng'] as $location){
            $meta=apcu_fetch($this->locationMetaKey($location),$hit);if(!$hit||!is_array($meta)||($meta['ready']??false)!==true)continue;
            $entries=[];$n=(int)($meta['chunks']??0);
            for($i=0;$i<$n;$i++){ $chunk=apcu_fetch($this->locationChunkKey($location,$i),$ok); if(!$ok||!is_array($chunk)){$entries=[];break;} foreach($chunk as $entry)if((int)($entry['id']??0)!==$jobId)$entries[]=$entry; }
            $status=(string)($job['trang_thai']??'');
            $matches=$status==='dang_tuyen'&&($location==='__all__'||mb_stripos((string)($job['dia_diem']??''),$location)!==false);
            if($matches){
                $entry=['id'=>$jobId,'updated_at'=>(string)($job['ngay_cap_nhat']??'')];
                $insertAt=count($entries);
                foreach($entries as $i=>$existing){$cmp=strcmp((string)$existing['updated_at'],$entry['updated_at']);if($cmp<0||($cmp===0&&(int)$existing['id']<$jobId)){$insertAt=$i;break;}}
                array_splice($entries,$insertAt,0,[$entry]);
            }
            $this->writeLocationIndex($location,$entries);
        }
    }

    public function syncWarmedJobById(int $jobId): void
    {
        if($jobId<=0)return;
        $stmt=$this->db->prepare('SELECT id,ma_tin,tieu_de,nganh_nghe,dia_diem,luong_co_ban,tong_thu_nhap_du_kien,so_luong,ngay_dang,ngay_cap_nhat,trang_thai FROM tin_tuyen_dung WHERE id=? LIMIT 1');
        $stmt->execute([$jobId]);$job=$stmt->fetch(\PDO::FETCH_ASSOC);
        if(!$job)$job=['id'=>$jobId,'trang_thai'=>''];
        $this->syncWarmedJob($job);
    }

    /** @return array<string,mixed> */
    private function mapJobRow(array $row): array
    {
        return [
            'id' => (int)$row['id'],
            'key' => (string)$row['ma_tin'],
            'title' => (string)$row['tieu_de'],
            'industry' => (string)$row['nganh_nghe'],
            'location' => (string)$row['dia_diem'],
            'salary' => [
                'base' => $row['luong_co_ban'] === null ? null : (float)$row['luong_co_ban'],
                'expected_total' => $row['tong_thu_nhap_du_kien'] === null ? null : (float)$row['tong_thu_nhap_du_kien']
            ],
            'quantity' => (int)$row['so_luong'],
            'published_at' => $row['ngay_dang'],
            'updated_at' => $row['ngay_cap_nhat']
        ];
    }

    public static function invalidateCache(): void
    {
        if(function_exists('apcu_inc')) {
            if(!apcu_inc('labor:content-search:generation', 1, $ok)) {
                apcu_store('labor:content-search:generation', 2, 86400);
            }
        } elseif(function_exists('apcu_store')) {
            apcu_store('labor:content-search:generation', 2, 86400);
        }
    }

    private function normalizeLocation(string $value): string
    {
        $value = trim($value);
        if ($value === '' || mb_strtolower($value) === mb_strtolower('Tất cả')) return '__all__';
        $aliases = [
            'TP HCM' => 'TP.HCM',
            'TP Hồ Chí Minh' => 'TP.HCM',
            'Thành phố Hồ Chí Minh' => 'TP.HCM',
            'Ho Chi Minh City' => 'TP.HCM',
        ];
        return $aliases[$value] ?? $value;
    }

    private function booleanQuery(string $value): string
    {
        $terms=preg_split('/\s+/u',preg_replace('/[^\p{L}\p{N}_-]+/u',' ',$value)??'');
        $terms=array_values(array_filter(array_map(static fn($v)=>trim((string)$v),$terms),static fn($v)=>$v!==''));
        return implode(' ',array_map(static fn($v)=>'+'.$v.'*',$terms));
    }
}
