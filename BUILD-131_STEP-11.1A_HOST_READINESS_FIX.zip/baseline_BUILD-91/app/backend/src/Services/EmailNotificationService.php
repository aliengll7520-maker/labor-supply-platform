<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 109 - Email delivery adapter.
 * The app/website does not become an email provider; delivery is delegated
 * to an externally configured HTTP email provider.
 */
final class EmailNotificationService
{
    public function __construct(private array $config = []) {}

    public function send(string $to, string $subject, string $body, array $meta = []): array
    {
        $to = trim($to);
        $subject = trim($subject);
        $body = trim($body);
        $endpoint = trim((string)($this->config['endpoint'] ?? ''));
        $token = trim((string)($this->config['token'] ?? ''));
        $sender = trim((string)($this->config['sender'] ?? ''));

        if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException('Email người nhận không hợp lệ.');
        }
        if ($subject === '' || mb_strlen($subject) > 255) {
            throw new \InvalidArgumentException('Tiêu đề email không hợp lệ.');
        }
        if ($body === '') {
            throw new \InvalidArgumentException('Nội dung email không được để trống.');
        }
        if ($endpoint === '' || !function_exists('curl_init')) {
            throw new \RuntimeException('Email provider chưa được cấu hình.');
        }

        $payload = json_encode([
            'to' => $to,
            'subject' => $subject,
            'body' => $body,
            'sender' => $sender,
            'meta' => $meta,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        $headers = ['Content-Type: application/json', 'Accept: application/json'];
        if ($token !== '') $headers[] = 'Authorization: Bearer '.$token;

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $error !== '') {
            throw new \RuntimeException($error ?: 'Không gửi được email.');
        }
        if ($http < 200 || $http >= 300) {
            throw new \RuntimeException('Email provider trả về HTTP '.$http.'.');
        }

        return ['sent' => 1, 'http_status' => $http, 'provider_response' => is_string($response) ? mb_substr($response, 0, 1000) : null];
    }
}
