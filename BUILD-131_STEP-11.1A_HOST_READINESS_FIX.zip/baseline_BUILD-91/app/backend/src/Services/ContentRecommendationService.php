<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 08 — deterministic content recommendation projection for public jobs. */
final class ContentRecommendationService
{
    public const VERSION = '08.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function recommendJob(int $jobId, array $input = []): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');
        $limit = min(20, max(1, (int)($input['limit'] ?? 10)));

        $base = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, nganh_nghe, dia_diem, luong_co_ban,
                    tong_thu_nhap_du_kien, so_luong, ngay_dang, ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE id = :id AND trang_thai = "dang_tuyen" LIMIT 1'
        );
        $base->execute([':id' => $jobId]);
        $source = $base->fetch(\PDO::FETCH_ASSOC);
        if (!$source) throw new \InvalidArgumentException('Không tìm thấy Tin tuyển dụng công khai.');

        $sourceSalary = $source['tong_thu_nhap_du_kien'] !== null
            ? (float)$source['tong_thu_nhap_du_kien']
            : ($source['luong_co_ban'] !== null ? (float)$source['luong_co_ban'] : null);

        $sql = 'SELECT id, ma_tin, tieu_de, nganh_nghe, dia_diem, luong_co_ban,
                       tong_thu_nhap_du_kien, so_luong, ngay_dang, ngay_cap_nhat,
                       (CASE WHEN nganh_nghe = :industry THEN 50 ELSE 0 END +
                        CASE WHEN dia_diem = :location THEN 30 ELSE 0 END +
                        CASE WHEN :source_salary IS NOT NULL AND COALESCE(tong_thu_nhap_du_kien, luong_co_ban) IS NOT NULL
                                  AND ABS(COALESCE(tong_thu_nhap_du_kien, luong_co_ban) - :source_salary_2) <= :salary_band
                             THEN 15 ELSE 0 END +
                        CASE WHEN ngay_dang >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY) THEN 5 ELSE 0 END) AS recommendation_score
                FROM tin_tuyen_dung
                WHERE trang_thai = "dang_tuyen"
                  AND id <> :id
                  AND (nganh_nghe = :industry_2 OR dia_diem = :location_2)
                ORDER BY recommendation_score DESC, ngay_dang DESC, id DESC
                LIMIT :limit';

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':industry', (string)$source['nganh_nghe'], \PDO::PARAM_STR);
        $stmt->bindValue(':industry_2', (string)$source['nganh_nghe'], \PDO::PARAM_STR);
        $stmt->bindValue(':location', (string)$source['dia_diem'], \PDO::PARAM_STR);
        $stmt->bindValue(':location_2', (string)$source['dia_diem'], \PDO::PARAM_STR);
        $stmt->bindValue(':source_salary', $sourceSalary, $sourceSalary === null ? \PDO::PARAM_NULL : \PDO::PARAM_STR);
        $stmt->bindValue(':source_salary_2', $sourceSalary, $sourceSalary === null ? \PDO::PARAM_NULL : \PDO::PARAM_STR);
        $stmt->bindValue(':salary_band', $sourceSalary === null ? 0 : max(1000000, abs($sourceSalary) * 0.20), \PDO::PARAM_STR);
        $stmt->bindValue(':id', $jobId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $items = array_map(static function (array $row): array {
            return [
                'id' => (int)$row['id'],
                'key' => (string)$row['ma_tin'],
                'title' => (string)$row['tieu_de'],
                'industry' => (string)$row['nganh_nghe'],
                'location' => (string)$row['dia_diem'],
                'salary' => [
                    'base' => $row['luong_co_ban'] === null ? null : (float)$row['luong_co_ban'],
                    'expected_total' => $row['tong_thu_nhap_du_kien'] === null ? null : (float)$row['tong_thu_nhap_du_kien'],
                ],
                'quantity' => (int)$row['so_luong'],
                'published_at' => $row['ngay_dang'],
                'updated_at' => $row['ngay_cap_nhat'],
                'recommendation_score' => (int)$row['recommendation_score'],
            ];
        }, $stmt->fetchAll(\PDO::FETCH_ASSOC));

        return [
            'version' => self::VERSION,
            'source' => ['id' => $jobId, 'key' => (string)$source['ma_tin']],
            'strategy' => 'industry_location_salary_recency',
            'personalization' => 'none',
            'items' => $items,
        ];
    }
}
