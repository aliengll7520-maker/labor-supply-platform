<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

use LaborPlatform\Core\AdminAuth;

/** BUILD 22 — final administrative control plane for Content Discovery. */
final class ContentDiscoveryControlService
{
    public const VERSION = '22.0.0';

    public function __construct(
        private \PDO $db,
        private ContentDiscoveryEventService $events
    ) {}

    /** @return array<string,mixed> */
    public function dashboard(): array
    {
        AdminAuth::requirePermission('system.view');
        return [
            'version' => self::VERSION,
            'source_of_truth' => 'tin_tuyen_dung',
            'pipeline' => ['quality_gate','discovery','classification','tags','topic_location','search','feed','related','recommendation','public','url','seo','structured_data','sitemap','delivery'],
            'jobs' => $this->jobStats(),
            'events' => $this->eventStats(),
            'overrides' => $this->overrideStats(),
        ];
    }

    /** @return array<string,mixed> */
    public function rebuildActive(int $limit = 100): array
    {
        $actor = AdminAuth::requirePermission('system.view');
        $limit = max(1, min($limit, 500));
        $q = $this->db->prepare('SELECT id FROM tin_tuyen_dung WHERE trang_thai="dang_tuyen" ORDER BY id ASC LIMIT ?');
        $q->bindValue(1, $limit, \PDO::PARAM_INT);
        $q->execute();
        $ids = array_map('intval', $q->fetchAll(\PDO::FETCH_COLUMN));
        $queued = [];
        foreach ($ids as $id) {
            $queued[] = $this->events->publishJobChanged($id, 'rebuild', [
                'actor_type' => 'admin',
                'actor_id' => $actor,
                'reason' => 'content_discovery_admin_rebuild',
                'source_version' => self::VERSION,
            ]);
        }
        return ['version'=>self::VERSION,'mode'=>'batch_rebuild','requested'=>$limit,'found'=>count($ids),'queued'=>count($queued),'events'=>$queued];
    }

    private function jobStats(): array
    {
        $q = $this->db->query('SELECT trang_thai, COUNT(*) total FROM tin_tuyen_dung GROUP BY trang_thai');
        return $q->fetchAll(\PDO::FETCH_ASSOC);
    }
    private function eventStats(): array
    {
        $q = $this->db->query('SELECT status, COUNT(*) total FROM content_discovery_events GROUP BY status');
        return $q->fetchAll(\PDO::FETCH_ASSOC);
    }
    private function overrideStats(): array
    {
        try {
            $q = $this->db->query('SELECT status, COUNT(*) total FROM content_discovery_admin_overrides GROUP BY status');
            return $q->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\Throwable) {
            return [];
        }
    }
}
