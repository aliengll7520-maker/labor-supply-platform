<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 19 — deterministic worker that rebuilds all discovery projections. */
final class ContentDiscoveryProjectionWorker
{
    public function __construct(
        private \PDO $db,
        private ContentDiscoveryService $discovery,
        private ContentClassificationService $classification,
        private ContentTagService $tags,
        private ContentTopicLocationService $taxonomy,
        private ContentSearchService $search,
        private ContentFeedService $feed,
        private ContentRelatedService $related,
        private ContentRecommendationService $recommendation,
        private ContentPublicService $public,
        private ContentUrlService $url,
        private ContentSeoService $seo,
        private ContentStructuredDataService $structuredData,
        private ContentSitemapService $sitemap,
        private ContentSeoLifecycleService $seoLifecycle,
        private AutoContentModerationService $quality,
    ) {}

    /** @return array<string,mixed> */
    public function refreshJob(int $jobId): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');

        $sourceStmt=$this->db->prepare(
            'SELECT id,nha_cung_ung_id,tieu_de,nganh_nghe,dia_diem,mo_ta_cong_viec,dieu_kien_tuyen_dung,trang_thai
             FROM tin_tuyen_dung WHERE id=? LIMIT 1'
        );
        $sourceStmt->execute([$jobId]);
        $source=$sourceStmt->fetch(\PDO::FETCH_ASSOC);
        if(!$source) throw new \RuntimeException('Không tìm thấy Tin tuyển dụng nguồn.');

        $content=implode(' ',array_map(static fn($v)=>(string)$v,[
            $source['tieu_de']??'', $source['nganh_nghe']??'', $source['dia_diem']??'',
            $source['mo_ta_cong_viec']??'', $source['dieu_kien_tuyen_dung']??''
        ]));
        $quality=$this->quality->evaluate($content,'supplier',(int)$source['nha_cung_ung_id'],'job',$jobId);
        $this->quality->log('job',$jobId,'supplier',(int)$source['nha_cung_ung_id'],$quality);
        $this->quality->abuseEvent('job',$jobId,'supplier',(int)$source['nha_cung_ung_id'],$quality);

        if($quality['decision']!=='auto_approved') {
            $this->search->syncWarmedJobById($jobId);
            return [
                'version' => '44.0.0',
                'content_type' => 'job',
                'source_id' => $jobId,
                'quality_gate' => $quality,
                'refreshed' => [],
                'delivery' => ['status'=>'held','reason'=>$quality['decision']]
            ];
        }

        $result = [];
        $result['quality_gate'] = $quality;
        $result['discovery'] = $this->discovery->discoverPublicJob($jobId);
        $result['classification'] = $this->classification->classifyPublicJob($jobId);
        $result['tags'] = $this->tags->generatePublicJobTags($jobId);
        $result['taxonomy'] = $this->taxonomy->generatePublicJobTaxonomy($jobId);
        $result['seo_lifecycle'] = $this->seoLifecycle->get($jobId);

        // Public-only projections are refreshed when the source is still indexable.
        if (($result['seo_lifecycle']['indexable'] ?? false) === true) {
            $result['seo'] = $this->seo->publicJobSeo($jobId);
            $result['structured_data'] = $this->structuredData->publicJobStructuredData($jobId);
            $result['url'] = $this->url->publicJobUrl($jobId);
        }

        // Sitemap is a global projection; refresh it after source status changes.
        $result['sitemap'] = $this->sitemap->publicJobsSitemap();

        $this->search->syncWarmedJobById($jobId);

        return [
            'version' => '44.0.0',
            'content_type' => 'job',
            'source_id' => $jobId,
            'refreshed' => array_keys($result),
        ];
    }

}
