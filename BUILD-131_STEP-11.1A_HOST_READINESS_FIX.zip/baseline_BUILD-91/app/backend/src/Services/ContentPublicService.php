<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 09 — public content projection for a published job. */
final class ContentPublicService
{
    public const VERSION = '09.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function publicJob(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, mo_ta, nganh_nghe, dia_diem,
                    luong_co_ban, tong_thu_nhap_du_kien, so_luong,
                    ngay_dang, ngay_cap_nhat, han_nop, trang_thai
             FROM tin_tuyen_dung
             WHERE id = :id AND trang_thai = "dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([':id' => $jobId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$row) {
            throw new \InvalidArgumentException('Không tìm thấy Tin tuyển dụng công khai.');
        }

        $key = (string)$row['ma_tin'];
        $slug = $this->slug((string)$row['tieu_de']);
        $canonicalPath = '/viec-lam/' . $jobId . '-' . ($slug !== '' ? $slug : $key);

        return [
            'version' => self::VERSION,
            'type' => 'job',
            'visibility' => 'public',
            'source_of_truth' => 'tin_tuyen_dung',
            'content' => [
                'id' => (int)$row['id'],
                'key' => $key,
                'title' => (string)$row['tieu_de'],
                'description' => $row['mo_ta'] === null ? null : (string)$row['mo_ta'],
                'industry' => (string)$row['nganh_nghe'],
                'location' => (string)$row['dia_diem'],
                'salary' => [
                    'base' => $row['luong_co_ban'] === null ? null : (float)$row['luong_co_ban'],
                    'expected_total' => $row['tong_thu_nhap_du_kien'] === null ? null : (float)$row['tong_thu_nhap_du_kien'],
                ],
                'quantity' => (int)$row['so_luong'],
                'published_at' => $row['ngay_dang'],
                'updated_at' => $row['ngay_cap_nhat'],
                'deadline' => $row['han_nop'],
            ],
            'public_url' => $canonicalPath,
            'capabilities' => [
                'discovery' => true,
                'search' => true,
                'feed' => true,
                'related' => true,
                'recommendation' => true,
            ],
        ];
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value, 'UTF-8'));
        $value = preg_replace('/[^\pL\pN]+/u', '-', $value) ?? '';
        $value = trim($value, '-');
        return function_exists('iconv') ? (string)(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value) : $value;
    }
}
