<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class AutoJobModerationService {
    public const VERSION = '83.0';
    public function __construct(private \PDO $db) {}

    public function evaluate(array $job): array {
        $text = mb_strtolower(trim(implode("\n", array_filter([
            $job['tieu_de'] ?? '', $job['nganh_nghe'] ?? '', $job['dieu_kien_tuyen_dung'] ?? '',
            $job['mo_ta_cong_viec'] ?? '', $job['thuong'] ?? '', $job['ho_tro'] ?? '',
            $job['chinh_sach_tra_luong'] ?? '', $job['hop_dong'] ?? '', $job['bao_hiem'] ?? '', $job['che_do_khac'] ?? ''
        ]))));

        $reasons=[]; $score=0; $decision='auto_approved';
        $critical=[
            'CONTENT_ADULT'=>['sex','tình dục','khiêu dâm','massage nhạy cảm','dịch vụ người lớn'],
            'CONTENT_ILLEGAL'=>['lừa đảo tuyển dụng','tuyển người để phạm pháp','bán ma túy','vũ khí trái phép','giấy tờ giả']
        ];
        $review=[
            'CONTENT_FEE'=>['đặt cọc','phí hồ sơ','phí tuyển dụng người lao động','nộp tiền trước','đóng tiền trước','mua đồng phục bắt buộc'],
            'CONTENT_DISCRIMINATION'=>['chỉ tuyển nam','chỉ tuyển nữ','ngoại hình bắt buộc','độc thân','đã kết hôn','tuổi từ','tuổi dưới','dân tộc','tôn giáo'],
            'CONTENT_SCAM'=>['việc nhẹ lương cao','thu nhập không giới hạn','nhận tiền ngay','chuyển khoản trước','cam kết 100%']
        ];
        foreach($critical as $code=>$terms){ foreach($terms as $term){ if(mb_stripos($text,$term)!==false){$reasons[]=$code.': '.$term;$score=100;$decision='blocked';break 2;} }}
        if($decision!=='blocked'){ foreach($review as $code=>$terms){ foreach($terms as $term){ if(mb_stripos($text,$term)!==false){$reasons[]=$code.': '.$term;$score=max($score,60);$decision='review';break;}}}}
        if(empty(trim((string)($job['tieu_de']??''))) || empty(trim((string)($job['mo_ta_cong_viec']??'')))) { $reasons[]='Thiếu thông tin cốt lõi'; $score=max($score,50); $decision='review'; }
        if((float)($job['tong_thu_nhap_du_kien']??0)<=0){$reasons[]='Thu nhập dự kiến không hợp lệ';$score=100;$decision='blocked';}
        if(($job['nha_cung_ung_trang_thai']??'')!=='hoat_dong' || ($job['nha_cung_ung_xac_minh']??'')!=='da_xac_minh'){ $reasons[]='Đơn vị sử dụng lao động chưa đủ điều kiện công khai';$score=max($score,80);$decision='review'; }
        return ['decision'=>$decision,'risk_score'=>$score,'reasons'=>$reasons,'version'=>self::VERSION];
    }

    public function apply(int $jobId, ?string $operationId = null): array
    {
        $operationId = $operationId ?: ('mod:' . $jobId . ':' . bin2hex(random_bytes(16)));

        $existing = $this->db->prepare(
            'SELECT id, ket_qua, risk_score, du_lieu_quyet_dinh
             FROM tin_tuyen_dung_moderation_log
             WHERE operation_id = ?
             LIMIT 1'
        );
        $existing->execute([$operationId]);
        $alreadyApplied = $existing->fetch(\PDO::FETCH_ASSOC);
        if ($alreadyApplied) {
            return [
                'status' => 'already_applied',
                'operation_id' => $operationId,
                'decision' => $alreadyApplied['ket_qua'],
                'risk_score' => (int) $alreadyApplied['risk_score'],
            ];
        }

        $r = $this->evaluate($jobId);
        $status = $r['decision'];
        $reasons = $r['reasons'];

        $this->db->beginTransaction();
        try {
            $lock = $this->db->prepare(
                'SELECT id FROM tin_tuyen_dung WHERE id = ? FOR UPDATE'
            );
            $lock->execute([$jobId]);
            if (!$lock->fetchColumn()) {
                throw new \RuntimeException('Job not found');
            }

            $this->db->prepare(
                "UPDATE tin_tuyen_dung
                 SET moderation_status=?,
                     moderation_risk_score=?,
                     moderation_version=?,
                     moderation_reasons=?,
                     moderation_at=NOW(),
                     trang_thai=CASE WHEN ?='auto_approved' THEN 'dang_tuyen' ELSE 'cho_duyet' END,
                     ngay_dang=CASE WHEN ?='auto_approved' THEN COALESCE(ngay_dang,NOW()) ELSE ngay_dang END,
                     ngay_cap_nhat=NOW()
                 WHERE id=?"
            )->execute([
                $status,
                $r['risk_score'],
                $r['version'],
                json_encode($reasons, JSON_UNESCAPED_UNICODE),
                $status,
                $status,
                $jobId
            ]);

            $this->db->prepare(
                'INSERT INTO tin_tuyen_dung_moderation_log
                 (operation_id,tin_tuyen_dung_id,engine_version,ket_qua,risk_score,ly_do,du_lieu_quyet_dinh)
                 VALUES (?,?,?,?,?,?,?)'
            )->execute([
                $operationId,
                $jobId,
                $r['version'],
                $status,
                $r['risk_score'],
                implode('; ', $reasons),
                json_encode(['reasons'=>$reasons], JSON_UNESCAPED_UNICODE)
            ]);

            $this->db->commit();

            return [
                'status' => 'applied',
                'operation_id' => $operationId,
                'decision' => $status,
                'risk_score' => $r['risk_score'],
            ];
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            // A concurrent retry may have committed the same operation.
            $existing = $this->db->prepare(
                'SELECT id, ket_qua, risk_score
                 FROM tin_tuyen_dung_moderation_log
                 WHERE operation_id = ?
                 LIMIT 1'
            );
            $existing->execute([$operationId]);
            $alreadyApplied = $existing->fetch(\PDO::FETCH_ASSOC);
            if ($alreadyApplied) {
                return [
                    'status' => 'already_applied',
                    'operation_id' => $operationId,
                    'decision' => $alreadyApplied['ket_qua'],
                    'risk_score' => (int) $alreadyApplied['risk_score'],
                ];
            }

            throw $e;
        }
    }
}
