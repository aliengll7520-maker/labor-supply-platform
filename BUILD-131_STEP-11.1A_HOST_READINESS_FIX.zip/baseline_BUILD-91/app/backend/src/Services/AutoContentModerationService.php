<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class AutoContentModerationService
{
    public const VERSION = '108.0';
    public function __construct(private \PDO $db) {}

    public function evaluate(string $content, string $actorType, int $actorId, string $contentType, int $contentId = 0): array
    {
        $text = mb_strtolower(trim($content));
        $reasons=[]; $score=0; $decision='auto_approved';
        if(ContentSafetyService::containsExternalLink($text)){ $reasons[]='EXTERNAL_LINK: liên kết bên ngoài App Website'; $score=100; $decision='blocked'; }
        if($decision!=='blocked' && ContentSafetyService::containsPhoneNumber($text)){ $reasons[]='PHONE_NUMBER: số điện thoại hoặc biến thể'; $score=100; $decision='blocked'; }
        $critical=[
            'ILLEGAL'=>['lừa đảo','bán ma túy','vũ khí trái phép','giấy tờ giả','hack tài khoản'],
            'ADULT'=>['khiêu dâm','dịch vụ người lớn','sex tour'],
        ];
        $review=[
            'SCAM'=>['việc nhẹ lương cao','thu nhập không giới hạn','nhận tiền ngay','chuyển khoản trước','nộp tiền trước','đặt cọc'],
            'HARASSMENT'=>['đồ ngu','cút đi','địt','chửi'],
            'SPAM'=>['http://','https://','telegram','zalo','whatsapp','liên hệ ngay'],
        ];
        foreach($critical as $code=>$terms){ foreach($terms as $term){ if(mb_stripos($text,$term)!==false){$reasons[]=$code.': '.$term;$score=100;$decision='blocked';break 2;}}}
        if($decision!=='blocked') foreach($review as $code=>$terms){foreach($terms as $term){if(mb_stripos($text,$term)!==false){$reasons[]=$code.': '.$term;$score=max($score,60);$decision='review';break;}}}

        if($actorId>0 && $contentType!=='comment'){
            $q=$this->db->prepare('SELECT COUNT(*) FROM '.($contentType==='social_post'?'social_bai_dang':'tin_tim_viec_nguoi_lao_dong').' WHERE '.($contentType==='social_post'?'loai_tac_gia=? AND tac_gia_id=?':'nguoi_lao_dong_id=?').' AND ngay_tao >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)');
            $q->execute($contentType==='social_post'?[$actorType,$actorId]:[$actorId]);
            if((int)$q->fetchColumn() >= 20){$reasons[]='BURST_POSTING: quá nhiều nội dung trong thời gian ngắn';$score=max($score,85);$decision='review';}
        }
        if($contentId>0 && $contentType==='social_post'){
            $hash=hash('sha256',$text);
            $q=$this->db->prepare('SELECT COUNT(*) FROM social_bai_dang WHERE loai_tac_gia=? AND tac_gia_id=? AND SHA2(LOWER(TRIM(noi_dung)),256)=? AND id<>? AND ngay_tao>=DATE_SUB(NOW(),INTERVAL 24 HOUR)');
            $q->execute([$actorType,$actorId,$hash,$contentId]);
            if((int)$q->fetchColumn()>=2){$reasons[]='DUPLICATE_CONTENT: nội dung lặp lại';$score=max($score,80);$decision='review';}
        }
        return ['decision'=>$decision,'risk_score'=>$score,'reasons'=>$reasons,'version'=>self::VERSION];
    }

    public function log(string $contentType,int $contentId,string $actorType,int $actorId,array $result): void
    {
        $this->db->prepare('INSERT INTO content_moderation_log (content_type,content_id,actor_type,actor_id,engine_version,decision,risk_score,reasons_json) VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$contentType,$contentId,$actorType,$actorId,$result['version'],$result['decision'],$result['risk_score'],json_encode($result['reasons'],JSON_UNESCAPED_UNICODE)]);
    }

    public function abuseEvent(string $contentType,int $contentId,string $actorType,int $actorId,array $result): void
    {
        if((int)$result['risk_score']<60) return;
        $this->db->prepare('INSERT INTO content_abuse_events (content_type,content_id,actor_type,actor_id,risk_score,reasons_json,status) VALUES (?,?,?,?,?,?,"open")')
            ->execute([$contentType,$contentId,$actorType,$actorId,$result['risk_score'],json_encode($result['reasons'],JSON_UNESCAPED_UNICODE)]);
    }
}
