<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class IdentityService {
    public function __construct(private \PDO $db) {}

    public function syncWorker(int $workerId): int {
        $q=$this->db->prepare('SELECT id,ho_ten,email,so_dien_thoai,trang_thai FROM nguoi_lao_dong WHERE id=? LIMIT 1');
        $q->execute([$workerId]); $w=$q->fetch();
        if(!$w) throw new \RuntimeException('Không tìm thấy Người lao động.');
        return $this->sync('worker:'.$workerId,$w['ho_ten'],$w['email']??null,$w['so_dien_thoai']??null,'worker',$workerId,null,null,$w['trang_thai']==='hoat_dong'?'active':'blocked');
    }

    public function syncEmployerAccount(int $accountId,int $supplierId): int {
        $q=$this->db->prepare('SELECT a.id,a.email,a.so_dien_thoai,a.ten_hien_thi,a.trang_thai,n.ten_nha_cung_ung,n.trang_thai AS supplier_status,n.xac_minh FROM tai_khoan_nha_cung_ung a JOIN nha_cung_ung n ON n.id=a.nha_cung_ung_id WHERE a.id=? AND n.id=? LIMIT 1');
        $q->execute([$accountId,$supplierId]); $a=$q->fetch();
        if(!$a) throw new \RuntimeException('Không tìm thấy tài khoản Đơn vị sử dụng lao động.');
        $status=($a['trang_thai']==='hoat_dong' && $a['supplier_status']==='hoat_dong')?'active':(($a['trang_thai']==='khoa'||$a['supplier_status']==='ngung_hoat_dong')?'blocked':'pending');
        return $this->sync('employer:'.$accountId,$a['ten_hien_thi']?:$a['ten_nha_cung_ung'],$a['email'],$a['so_dien_thoai'],'employer',null,$supplierId,$accountId,$status);
    }

    private function sync(string $key,?string $name,?string $email,?string $phone,string $role,?int $workerId,?int $supplierId,?int $accountId,string $roleStatus): int {
        $ownsTransaction = !$this->db->inTransaction();
        if ($ownsTransaction) $this->db->beginTransaction();
        try {
            $q=$this->db->prepare('SELECT id FROM identity_principals WHERE identity_key=? LIMIT 1'); $q->execute([$key]); $identityId=(int)$q->fetchColumn();
            $onboarding=$roleStatus==='blocked'?'can_xu_ly':($roleStatus==='active'?'dang_onboarding':'moi');
            if($identityId<=0){
                $q=$this->db->prepare('INSERT INTO identity_principals(identity_key,display_name,email,phone,trang_thai,onboarding_status) VALUES(?,?,?,?,?,?)');
                $q->execute([$key,$name,$email?:null,$phone?:null,$roleStatus==='active'?'hoat_dong':($roleStatus==='blocked'?'khoa':'cho_xac_minh'),$onboarding]);
                $identityId=(int)$this->db->lastInsertId();
                $this->event($identityId,$role,'identity.created','completed');
            } else {
                $this->db->prepare('UPDATE identity_principals SET display_name=?,email=?,phone=?,trang_thai=?,onboarding_status=? WHERE id=?')
                    ->execute([$name,$email?:null,$phone?:null,$roleStatus==='active'?'hoat_dong':($roleStatus==='blocked'?'khoa':'cho_xac_minh'),$onboarding,$identityId]);
            }
            $q=$this->db->prepare('SELECT id FROM identity_role_memberships WHERE identity_id=? AND role_code=? AND ((role_code="worker" AND worker_id=?) OR (role_code="employer" AND supplier_account_id=?)) LIMIT 1');
            $q->execute([$identityId,$role,$workerId,$accountId]); $membershipId=(int)$q->fetchColumn();
            if($membershipId<=0){
                $q=$this->db->prepare('INSERT INTO identity_role_memberships(identity_id,role_code,worker_id,supplier_id,supplier_account_id,role_status,onboarding_status) VALUES(?,?,?,?,?,?,?)');
                $q->execute([$identityId,$role,$workerId,$supplierId,$accountId,$roleStatus,$onboarding]);
                $this->event($identityId,$role,'role.attached','completed');
            } else {
                $this->db->prepare('UPDATE identity_role_memberships SET role_status=?,onboarding_status=? WHERE id=?')->execute([$roleStatus,$onboarding,$membershipId]);
            }
            if ($ownsTransaction) $this->db->commit(); return $identityId;
        } catch(\Throwable $e) {
            if ($ownsTransaction && $this->db->inTransaction()) $this->db->rollBack(); throw $e;
        }
    }

    private function event(int $identityId,string $role,string $code,string $status): void {
        $q=$this->db->prepare('INSERT INTO identity_onboarding_events(identity_id,role_code,event_code,event_status) VALUES(?,?,?,?)');
        $q->execute([$identityId,$role,$code,$status]);
    }

    public function currentWorker(int $workerId): array {
        $identityId=$this->syncWorker($workerId);
        return $this->current($identityId);
    }

    public function currentEmployer(int $accountId,int $supplierId): array {
        $identityId=$this->syncEmployerAccount($accountId,$supplierId);
        return $this->current($identityId);
    }

    public function current(int $identityId): array {
        $q=$this->db->prepare('SELECT id,identity_key,display_name,email,phone,trang_thai,onboarding_status,ngay_tao,ngay_cap_nhat FROM identity_principals WHERE id=? LIMIT 1');
        $q->execute([$identityId]); $identity=$q->fetch();
        if(!$identity) throw new \RuntimeException('Identity không tồn tại.');
        $q=$this->db->prepare('SELECT role_code,worker_id,supplier_id,supplier_account_id,role_status,onboarding_status FROM identity_role_memberships WHERE identity_id=? ORDER BY id ASC');
        $q->execute([$identityId]); $identity['roles']=$q->fetchAll()?:[];
        return $identity;
    }
}
