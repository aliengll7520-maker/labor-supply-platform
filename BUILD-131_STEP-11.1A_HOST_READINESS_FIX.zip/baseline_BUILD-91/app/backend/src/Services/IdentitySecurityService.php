<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class IdentitySecurityService {
    public function __construct(private \PDO $db, private int $resetTtlMinutes=30, private int $maxRequests=5, private bool $exposeToken=false) {}

    public function requestPasswordReset(string $role,string $identifier): array {
        $role=trim($role); $identifier=trim($identifier);
        if(!in_array($role,['worker','employer'],true) || $identifier==='') throw new \RuntimeException('Thông tin khôi phục tài khoản không hợp lệ.');
        if(!$this->allowResetRequest($identifier,$role)) throw new \RuntimeException('Yêu cầu khôi phục quá thường xuyên. Vui lòng thử lại sau.');
        $target=$this->findAccount($role,$identifier);
        // Deliberately return a generic response for unknown accounts to reduce account enumeration.
        if(!$target) return ['status'=>'accepted','delivery'=>'pending'];
        $token=bin2hex(random_bytes(32));
        $hash=hash('sha256',$token); $expires=date('Y-m-d H:i:s',time()+$this->resetTtlMinutes*60);
        $this->db->prepare('UPDATE identity_password_resets SET status="cancelled" WHERE identity_id=? AND role_code=? AND status="pending"')->execute([$target['identity_id'],$role]);
        $this->db->prepare('INSERT INTO identity_password_resets(identity_id,role_code,account_id,token_hash,status,expires_at,request_ip) VALUES(?,?,?,?,"pending",?,?)')->execute([$target['identity_id'],$role,$target['account_id'],$hash,$expires,$this->clientIp()]);
        $this->event((int)$target['identity_id'],$role,'password_reset.requested','pending',['ip'=>$this->clientIp(),'identifier'=>$identifier]);
        $out=['status'=>'accepted','delivery'=>'pending','expires_at'=>$expires];
        if($this->exposeToken) $out['test_token']=$token;
        return $out;
    }

    public function confirmPasswordReset(string $role,string $token,string $newPassword): array {
        if(!in_array($role,['worker','employer'],true) || trim($token)==='' || strlen($newPassword)<8) throw new \RuntimeException('Yêu cầu khôi phục không hợp lệ.');
        $q=$this->db->prepare('SELECT * FROM identity_password_resets WHERE role_code=? AND token_hash=? AND status="pending" ORDER BY id DESC LIMIT 1');
        $q->execute([$role,hash('sha256',trim($token))]); $row=$q->fetch();
        if(!$row) throw new \RuntimeException('Liên kết khôi phục không hợp lệ.');
        if(strtotime((string)$row['expires_at'])<time()){ $this->db->prepare('UPDATE identity_password_resets SET status="expired" WHERE id=?')->execute([$row['id']]); throw new \RuntimeException('Liên kết khôi phục đã hết hạn.'); }
        $hash=password_hash($newPassword,PASSWORD_DEFAULT);
        $this->db->beginTransaction();
        try {
            if($role==='worker') $this->db->prepare('UPDATE tai_khoan_nguoi_lao_dong SET mat_khau_hash=?,trang_thai="hoat_dong" WHERE id=?')->execute([$hash,$row['account_id']]);
            else $this->db->prepare('UPDATE tai_khoan_nha_cung_ung SET mat_khau_hash=? WHERE id=?')->execute([$hash,$row['account_id']]);
            $this->db->prepare('UPDATE identity_password_resets SET status="used",used_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$row['id']]);
            $this->event((int)$row['identity_id'],$role,'password_reset.completed','completed',['ip'=>$this->clientIp()]);
            $this->db->commit();
        } catch(\Throwable $e) { if($this->db->inTransaction()) $this->db->rollBack(); throw $e; }
        return ['status'=>'completed'];
    }

    public function securityStatus(int $identityId): array {
        $q=$this->db->prepare('SELECT event_code,event_status,metadata_json,ngay_tao FROM identity_security_events WHERE identity_id=? ORDER BY id DESC LIMIT 50');
        $q->execute([$identityId]); return $q->fetchAll()?:[];
    }

    private function findAccount(string $role,string $identifier): ?array {
        if($role==='worker') {
            $q=$this->db->prepare('SELECT n.id AS identity_source_id,a.id AS account_id,ip.id AS identity_id FROM nguoi_lao_dong n JOIN tai_khoan_nguoi_lao_dong a ON a.nguoi_lao_dong_id=n.id LEFT JOIN identity_principals ip ON ip.identity_key=CONCAT("worker:",n.id) WHERE n.so_dien_thoai=? OR n.email=? LIMIT 1');
        } else {
            $q=$this->db->prepare('SELECT n.id AS identity_source_id,a.id AS account_id,ip.id AS identity_id FROM nha_cung_ung n JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id LEFT JOIN identity_principals ip ON ip.identity_key=CONCAT("employer:",a.id) WHERE a.so_dien_thoai=? OR a.email=? OR a.ten_dang_nhap=? LIMIT 1');
        }
        $role==='worker'?$q->execute([$identifier,$identifier]):$q->execute([$identifier,$identifier,$identifier]);
        $r=$q->fetch(); return $r?:null;
    }
    private function allowResetRequest(string $identifier,string $role): bool {
        $q=$this->db->prepare('SELECT COUNT(*) FROM identity_security_events WHERE event_code="password_reset.requested" AND role_code=? AND metadata_json LIKE ? AND ngay_tao >= DATE_SUB(NOW(),INTERVAL 15 MINUTE)');
        $q->execute([$role,'%"identifier_hash":"'.hash('sha256',strtolower($identifier)).'"%']); return (int)$q->fetchColumn() < $this->maxRequests;
    }
    private function event(int $identityId,string $role,string $code,string $status,array $meta=[]): void {
        $meta['identifier_hash']=$meta['identifier_hash']??'';
        $q=$this->db->prepare('INSERT INTO identity_security_events(identity_id,role_code,event_code,event_status,metadata_json) VALUES(?,?,?,?,?)');
        $meta['identifier_hash']=$meta['identifier_hash']?:hash('sha256',(string)($meta['identifier']??'')); unset($meta['identifier']);
        $q->execute([$identityId,$role,$code,$status,json_encode($meta,JSON_UNESCAPED_UNICODE)]);
    }
    private function clientIp(): string { return substr((string)($_SERVER['REMOTE_ADDR']??''),0,64); }
}
