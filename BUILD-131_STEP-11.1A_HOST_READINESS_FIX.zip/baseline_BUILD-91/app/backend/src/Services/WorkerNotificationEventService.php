<?php
declare(strict_types=1);
namespace LaborPlatform\Services;
use LaborPlatform\Queue\QueueService;
final class WorkerNotificationEventService {
 public function __construct(private NotificationService $notify,private QueueService $queue){}
 public function applicationStatusChanged(int $workerId,int $applicationId,string $status,string $message,?string $code=null,?int $workProfileId=null):void{
  $titles=['da_xem'=>'Hồ sơ đã được Nhà cung ứng tiếp nhận','da_lien_he'=>'Nhà cung ứng đã liên hệ','khong_lien_he_duoc'=>'Chưa liên hệ được với bạn','khong_phu_hop'=>'Kết quả hồ sơ','da_huy'=>'Hồ sơ đã được hủy'];
  $title=$titles[$status]??'Hồ sơ đăng ký được cập nhật';
  $this->notify->worker($workerId,$title,$message,'cap_nhat_trang_thai',$applicationId);
  $this->enqueuePush($workerId,$title,$message,['type' => 'application','target' => 'ApplicationDetail','application_id'=>$applicationId,'status'=>$status,'ma_ho_so'=>$code],'application:'.$applicationId.':'.$status);
 }
 public function jobPublished(int $workerId,int $jobId,string $title):void{
  $message="Tin tuyển dụng mới: {$title}"; $this->notify->worker($workerId,'Tin tuyển dụng mới',$message,'he_thong',null);
  $this->enqueuePush($workerId,'Tin tuyển dụng mới',$message,['type' => 'job','target' => 'JobDetail','job_id'=>$jobId],'job-published:'.$jobId.':'.$workerId);
 }
 private function enqueuePush(int $workerId,string $title,string $body,array $data,string $dedupeKey):void{ $this->queue->enqueue('notifications','worker.push',['worker_id' => $workerId,'title' => $title,'body' => $body,'data' => $data,'delivery_key' => $dedupeKey],200,$dedupeKey,5); }
}
