<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

final class ApplicationStatusWorkflowService
{
    public function __construct(
        private \PDO $db,
        private WorkerNotificationEventService $events
    ) {
    }

    /**
     * Canonical application workflow for the free job-connection product.
     * No employment, attendance, interview or work-profile states are valid.
     */
    public function allowedNext(string $current): array
    {
        return match ($current) {
            'da_mo_so' => ['da_xem', 'da_huy'],
            'da_xem' => ['da_lien_he', 'khong_lien_he_duoc', 'da_huy'],
            'da_lien_he' => [],
            'khong_lien_he_duoc' => ['da_lien_he', 'da_huy'],
            'da_huy' => [],
            default => [],
        };
    }

    public function assertTransition(string $current, string $next): void
    {
        if (!in_array($next, $this->allowedNext($current), true)) {
            throw new \RuntimeException('Chuyển trạng thái Đăng ký hồ sơ không được phép.');
        }
    }

    /**
     * Existing supplier workflow owns the transition rules.
     * This helper is for future controllers that need a single transactional
     * status transition. Notifications are emitted only after commit.
     */
    public function changeStatus(
        int $applicationId,
        string $nextStatus,
        string $message,
        ?int $actorId = null
    ): void {
        $this->db->beginTransaction();

        try {
            $q = $this->db->prepare(
                'SELECT id, nguoi_lao_dong_id, ma_ho_so, trang_thai
                 FROM dang_ky_ho_so_phong_van
                 WHERE id=?
                 FOR UPDATE'
            );
            $q->execute([$applicationId]);
            $application = $q->fetch();

            if (!$application) {
                throw new \RuntimeException('Không tìm thấy Đăng ký hồ sơ.');
            }

            $oldStatus = (string)$application['trang_thai'];
            if ($oldStatus === $nextStatus) {
                $this->db->commit();
                return;
            }

            $this->assertTransition($oldStatus, $nextStatus);

            $u = $this->db->prepare(
                'UPDATE dang_ky_ho_so_phong_van
                 SET trang_thai=?, ngay_cap_nhat=CURRENT_TIMESTAMP
                 WHERE id=?'
            );
            $u->execute([$nextStatus, $applicationId]);

            $history = $this->db->prepare(
                'INSERT INTO qua_trinh_dang_ky_ho_so_phong_van
                    (dang_ky_ho_so_phong_van_id, nguoi_thuc_hien,
                     nguoi_thuc_hien_id, hanh_dong, ghi_chu)
                 VALUES (?, "he_thong", ?, ?, ?)'
            );
            $history->execute([
                $applicationId,
                $actorId,
                $nextStatus,
                $message,
            ]);

            $this->db->commit();

            $this->events->applicationStatusChanged(
                (int)$application['nguoi_lao_dong_id'],
                $applicationId,
                $nextStatus,
                $message,
                (string)$application['ma_ho_so']
            );
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
    }
}
