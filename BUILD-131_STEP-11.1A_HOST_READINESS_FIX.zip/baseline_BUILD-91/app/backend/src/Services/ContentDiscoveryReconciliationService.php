<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 45 — Content Discovery reconciliation/self-healing.
 *
 * Source tables remain authoritative. This service only detects projection
 * drift and re-queues deterministic discovery refresh events. It never edits
 * business source data and never requires Admin interaction on the happy path.
 */
final class ContentDiscoveryReconciliationService
{
    public const VERSION = '45.0.0';

    public function __construct(
        private \PDO $db,
        private ContentDiscoveryEventService $events,
        private array $config = []
    ) {}

    /** @return array<string,mixed> */
    public function run(): array
    {
        if (!(bool)($this->config['enabled'] ?? true)) {
            return ['status' => 'disabled', 'scanned' => 0, 'requeued' => 0, 'orphaned' => 0, 'failed_requeued' => 0];
        }

        $lockName = (string)($this->config['lock_name'] ?? 'labor_content_discovery_reconcile');
        $lockSeconds = max(1, min(30, (int)($this->config['lock_timeout_seconds'] ?? 5)));
        $lock = $this->db->prepare('SELECT GET_LOCK(?, ?)');
        $lock->execute([$lockName, $lockSeconds]);
        if ((int)$lock->fetchColumn() !== 1) {
            return ['status' => 'busy', 'scanned' => 0, 'requeued' => 0, 'orphaned' => 0, 'failed_requeued' => 0];
        }

        try {
            $limit = max(1, min(5000, (int)($this->config['batch_limit'] ?? 500)));
            $result = [
                'status' => 'ok',
                'scanned' => 0,
                'requeued' => 0,
                'orphaned' => 0,
                'failed_requeued' => 0,
                'missing_registry' => 0,
                'stale_registry' => 0,
                'failed_events' => 0,
            ];

            $q = $this->db->prepare(
                'SELECT j.id, j.ngay_cap_nhat, r.id AS registry_id, r.source_updated_at,
                        r.last_processed_at
                 FROM tin_tuyen_dung j
                 LEFT JOIN content_discovery_registry r
                   ON r.content_type="job" AND r.source_table="tin_tuyen_dung" AND r.source_id=j.id
                 WHERE j.trang_thai="dang_tuyen"
                   AND (r.id IS NULL OR r.source_updated_at IS NULL
                        OR j.ngay_cap_nhat > r.source_updated_at
                        OR r.last_processed_at IS NULL)
                 ORDER BY j.id ASC
                 LIMIT '.$limit
            );
            $q->execute();
            foreach ($q->fetchAll(\PDO::FETCH_ASSOC) as $row) {
                $result['scanned']++;
                $reason = empty($row['registry_id']) ? 'missing_registry' : 'stale_registry';
                $result[$reason]++;
                $this->events->publishJobChanged((int)$row['id'], 'reconcile', [
                    'reason' => 'discovery_reconciliation_'.$reason,
                    'source_version' => self::VERSION,
                ]);
                $result['requeued']++;
            }

            $failed = $this->db->prepare(
                'SELECT e.source_id
                 FROM content_discovery_events e
                 INNER JOIN (
                    SELECT source_id, MAX(id) AS max_id
                    FROM content_discovery_events
                    WHERE content_type="job" AND source_table="tin_tuyen_dung"
                    GROUP BY source_id
                 ) latest ON latest.max_id=e.id
                 INNER JOIN tin_tuyen_dung j ON j.id=e.source_id
                 WHERE e.content_type="job"
                   AND e.source_table="tin_tuyen_dung"
                   AND e.status="failed"
                   AND j.trang_thai="dang_tuyen"
                 ORDER BY e.id ASC
                 LIMIT '.$limit
            );
            $failed->execute();
            foreach ($failed->fetchAll(\PDO::FETCH_ASSOC) as $row) {
                $result['failed_events']++;
                $this->events->publishJobChanged((int)$row['source_id'], 'reconcile_failed', [
                    'reason' => 'discovery_reconciliation_failed_event',
                    'source_version' => self::VERSION,
                ]);
                $result['failed_requeued']++;
            }

            // A registry row can survive after a Job stops being public. Mark it
            // private so public discovery never treats it as live content.
            $orphan = $this->db->prepare(
                'UPDATE content_discovery_registry r
                 LEFT JOIN tin_tuyen_dung j ON j.id=r.source_id
                 SET r.visibility="private",
                     r.source_status=COALESCE(j.trang_thai,"missing"),
                     r.updated_at=CURRENT_TIMESTAMP
                 WHERE r.content_type="job"
                   AND r.source_table="tin_tuyen_dung"
                   AND (j.id IS NULL OR j.trang_thai<>"dang_tuyen")
                   AND r.visibility="public"'
            );
            $orphan->execute();
            $result['orphaned'] = $orphan->rowCount();

            $this->record($result);
            return $result;
        } finally {
            $this->db->prepare('SELECT RELEASE_LOCK(?)')->execute([$lockName]);
        }
    }

    /** @param array<string,mixed> $result */
    private function record(array $result): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO content_discovery_reconciliation_runs
             (version, scanned_count, requeued_count, failed_requeued_count, orphaned_count, result_json, created_at)
             VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP)'
        );
        $stmt->execute([
            self::VERSION,
            (int)$result['scanned'],
            (int)$result['requeued'],
            (int)$result['failed_requeued'],
            (int)$result['orphaned'],
            json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
        ]);
    }
}
