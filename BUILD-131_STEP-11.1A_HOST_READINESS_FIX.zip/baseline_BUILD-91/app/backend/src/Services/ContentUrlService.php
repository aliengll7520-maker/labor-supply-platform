<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 10 — canonical URL projection for public Content Discovery objects. */
final class ContentUrlService
{
    public const VERSION = '10.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function publicJobUrl(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, trang_thai
             FROM tin_tuyen_dung
             WHERE id = :id AND trang_thai = "dang_tuyen"
             LIMIT 1'
        );
        $stmt->execute([':id' => $jobId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        if (!$row) {
            throw new \InvalidArgumentException('Không tìm thấy Tin tuyển dụng công khai.');
        }

        $slug = $this->slug((string)$row['tieu_de']);
        $key = trim((string)$row['ma_tin']);
        if ($key === '') {
            $key = (string)$row['id'];
        }

        $path = '/viec-lam/' . (int)$row['id'] . '-' . ($slug !== '' ? $slug : $key);

        return [
            'version' => self::VERSION,
            'type' => 'canonical_url',
            'content_type' => 'job',
            'content_id' => (int)$row['id'],
            'key' => $key,
            'slug' => $slug !== '' ? $slug : $key,
            'path' => $path,
            'canonical_path' => $path,
            'visibility' => 'public',
            'source_of_truth' => 'tin_tuyen_dung',
            'route' => [
                'prefix' => '/viec-lam/',
                'pattern' => '/viec-lam/{id}-{slug}',
            ],
        ];
    }

    private function slug(string $value): string
    {
        $value = trim(mb_strtolower($value, 'UTF-8'));
        $value = preg_replace('/[^\pL\pN]+/u', '-', $value) ?? '';
        $value = trim($value, '-');
        if (function_exists('iconv')) {
            $value = (string)(iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value);
        }
        $value = preg_replace('/[^a-z0-9-]+/i', '-', $value) ?? '';
        return trim($value, '-');
    }
}
