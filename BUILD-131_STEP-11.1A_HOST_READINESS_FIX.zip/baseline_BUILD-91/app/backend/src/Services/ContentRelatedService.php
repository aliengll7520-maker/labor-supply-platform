<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/** BUILD 07 — deterministic related-content projection for public jobs. */
final class ContentRelatedService
{
    public const VERSION = '07.0.0';

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function relatedJob(int $jobId, array $input = []): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');
        $limit = min(20, max(1, (int)($input['limit'] ?? 10)));

        $base = $this->db->prepare(
            'SELECT id, ma_tin, tieu_de, nganh_nghe, dia_diem, luong_co_ban,
                    tong_thu_nhap_du_kien, so_luong, ngay_dang, ngay_cap_nhat
             FROM tin_tuyen_dung
             WHERE id = :id AND trang_thai = "dang_tuyen"
             LIMIT 1'
        );
        $base->execute([':id' => $jobId]);
        $source = $base->fetch(\PDO::FETCH_ASSOC);
        if (!$source) throw new \InvalidArgumentException('Không tìm thấy Tin tuyển dụng công khai.');

        $sql = 'SELECT id, ma_tin, tieu_de, nganh_nghe, dia_diem, luong_co_ban,
                       tong_thu_nhap_du_kien, so_luong, ngay_dang, ngay_cap_nhat,
                       (CASE WHEN nganh_nghe = :industry THEN 3 ELSE 0 END +
                        CASE WHEN dia_diem = :location THEN 2 ELSE 0 END) AS relevance_score
                FROM tin_tuyen_dung
                WHERE trang_thai = "dang_tuyen"
                  AND id <> :id
                  AND (nganh_nghe = :industry OR dia_diem = :location)
                ORDER BY relevance_score DESC, id DESC
                LIMIT :limit';
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':industry', (string)$source['nganh_nghe'], \PDO::PARAM_STR);
        $stmt->bindValue(':location', (string)$source['dia_diem'], \PDO::PARAM_STR);
        $stmt->bindValue(':id', $jobId, \PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();

        $items = array_map(static function (array $row): array {
            return [
                'id' => (int)$row['id'],
                'key' => (string)$row['ma_tin'],
                'title' => (string)$row['tieu_de'],
                'industry' => (string)$row['nganh_nghe'],
                'location' => (string)$row['dia_diem'],
                'salary' => [
                    'base' => $row['luong_co_ban'] === null ? null : (float)$row['luong_co_ban'],
                    'expected_total' => $row['tong_thu_nhap_du_kien'] === null ? null : (float)$row['tong_thu_nhap_du_kien'],
                ],
                'quantity' => (int)$row['so_luong'],
                'published_at' => $row['ngay_dang'],
                'updated_at' => $row['ngay_cap_nhat'],
                'relevance_score' => (int)$row['relevance_score'],
            ];
        }, $stmt->fetchAll(\PDO::FETCH_ASSOC));

        return [
            'version' => self::VERSION,
            'source' => ['id' => $jobId, 'key' => (string)$source['ma_tin']],
            'strategy' => 'industry_location_overlap',
            'items' => $items,
        ];
    }
}
