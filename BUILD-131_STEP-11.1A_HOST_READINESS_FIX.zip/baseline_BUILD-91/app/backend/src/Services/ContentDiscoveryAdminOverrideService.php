<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

use LaborPlatform\Core\AdminAuth;

final class ContentDiscoveryAdminOverrideService
{
    public const VERSION = '20.0.0';

    public function __construct(private \PDO $db) {}

    public function list(int $jobId): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        AdminAuth::requirePermission('content.discovery.override.view');
        $q=$this->db->prepare('SELECT id, job_id, field_name, override_value, reason, status, created_by, created_at, updated_at FROM content_discovery_admin_overrides WHERE job_id=? ORDER BY id DESC');
        $q->execute([$jobId]);
        return ['version'=>self::VERSION,'job_id'=>$jobId,'overrides'=>$q->fetchAll(\PDO::FETCH_ASSOC)];
    }

    public function set(int $jobId,string $field,string $value,string $reason): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        $field=trim($field); $value=trim($value); $reason=trim($reason);
        $allowed=['title','topic','location','seo_title','seo_description','indexable','canonical_path'];
        if(!in_array($field,$allowed,true)) throw new \InvalidArgumentException('Trường override không được phép.');
        if($value==='') throw new \InvalidArgumentException('Giá trị override không được để trống.');
        if(mb_strlen($value)>4000) throw new \InvalidArgumentException('Giá trị override quá dài.');
        if($reason==='') throw new \InvalidArgumentException('Lý do override là bắt buộc.');
        if(mb_strlen($reason)>1000) throw new \InvalidArgumentException('Lý do override quá dài.');
        $actor=AdminAuth::requirePermission('content.discovery.override.manage');
        $q=$this->db->prepare('INSERT INTO content_discovery_admin_overrides (job_id,field_name,override_value,reason,status,created_by,created_at,updated_at) VALUES (?,?,?,?,"active",?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE override_value=VALUES(override_value),reason=VALUES(reason),status="active",created_by=VALUES(created_by),updated_at=CURRENT_TIMESTAMP');
        $q->execute([$jobId,$field,$value,$reason,$actor]);
        return ['version'=>self::VERSION,'job_id'=>$jobId,'field'=>$field,'status'=>'active','updated_by'=>$actor];
    }

    public function remove(int $jobId,string $field): array
    {
        if ($jobId <= 0) throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        $field=trim($field);
        $actor=AdminAuth::requirePermission('content.discovery.override.manage');
        $q=$this->db->prepare('UPDATE content_discovery_admin_overrides SET status="removed",updated_at=CURRENT_TIMESTAMP WHERE job_id=? AND field_name=?');
        $q->execute([$jobId,$field]);
        return ['version'=>self::VERSION,'job_id'=>$jobId,'field'=>$field,'status'=>'removed','updated_by'=>$actor];
    }
}
