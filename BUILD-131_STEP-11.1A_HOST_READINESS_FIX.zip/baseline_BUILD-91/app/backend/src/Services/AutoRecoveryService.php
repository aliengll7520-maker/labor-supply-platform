<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

use LaborPlatform\Queue\QueueService;

final class AutoRecoveryService
{
    public function __construct(private \PDO $db, private QueueService $queue, private array $config = []) {}

    public function run(?string $queueName = null): array
    {
        if (!(bool)($this->config['enabled'] ?? true)) {
            return ['status'=>'disabled','recovered'=>0,'queues'=>[]];
        }
        $lockName = (string)($this->config['lock_name'] ?? 'labor_queue_auto_recovery');
        $lockSeconds = max(1, min(30, (int)($this->config['lock_timeout_seconds'] ?? 5)));
        $lock = $this->db->prepare('SELECT GET_LOCK(?, ?)');
        $lock->execute([$lockName, $lockSeconds]);
        if ((int)$lock->fetchColumn() !== 1) {
            return ['status'=>'busy','recovered'=>0,'queues'=>[]];
        }
        try {
            $queues = $queueName !== null && trim($queueName) !== ''
                ? [trim($queueName)]
                : (array)($this->config['queues'] ?? ['notifications','moderation','search','feed','media','media_cleanup','audit','matching']);
            $limit = max(1, min(10000, (int)($this->config['max_recover_per_queue'] ?? 1000)));
            $result = [];
            $total = 0;
            foreach ($queues as $name) {
                $name = trim((string)$name);
                if ($name === '') continue;
                $count = $this->queue->recoverStale($name, $limit);
                $result[$name] = $count;
                $total += $count;
            }
            $this->record($total, $result);
            return ['status'=>'ok','recovered'=>$total,'queues'=>$result];
        } finally {
            $this->db->prepare('SELECT RELEASE_LOCK(?)')->execute([$lockName]);
        }
    }

    private function record(int $recovered, array $queues): void
    {
        $stmt = $this->db->prepare('INSERT INTO queue_recovery_runs (recovered_count, queues_json, created_at) VALUES (?,?,CURRENT_TIMESTAMP)');
        $stmt->execute([$recovered, json_encode($queues, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    }
}
