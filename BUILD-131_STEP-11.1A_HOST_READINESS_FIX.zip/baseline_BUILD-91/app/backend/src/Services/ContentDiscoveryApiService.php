<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 17 — Content Discovery Backend/API Architecture.
 *
 * Provides a single read-only contract describing the discovery pipeline and
 * the projection state of one content object. Source tables remain authoritative.
 */
final class ContentDiscoveryApiService
{
    public const VERSION = '17.0.0';
    private const JOB_TYPE = 'job';
    private const JOB_TABLE = 'tin_tuyen_dung';

    /** @var array<string,string> */
    private const PROJECTIONS = [
        'registry' => 'content_discovery_registry',
        'classification' => 'content_discovery_classifications',
        'tags' => 'content_discovery_tags',
        'topic_location' => 'content_discovery_topic_locations',
        'search' => 'content_discovery_search_index',
        'sitemap' => 'content_discovery_sitemaps',
        'structured_data' => 'content_discovery_structured_data',
    ];

    public function __construct(private \PDO $db) {}

    /** @return array<string,mixed> */
    public function capabilities(): array
    {
        return [
            'version' => self::VERSION,
            'contract' => 'content-discovery',
            'source_of_truth' => [
                'table' => self::JOB_TABLE,
                'content_type' => self::JOB_TYPE,
            ],
            'read_only' => true,
            'projections_rebuildable' => true,
            'pipeline' => [
                'discovery',
                'classification',
                'tags',
                'topic_location',
                'search',
                'feed',
                'related',
                'recommendation',
                'public',
                'url',
                'seo',
                'structured_data',
                'sitemap',
                'seo_lifecycle',
                'quality_gate',
            ],
        ];
    }

    /** @return array<string,mixed> */
    public function jobPipeline(int $jobId): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('Tin tuyển dụng không hợp lệ.');
        }

        $source = $this->sourceJob($jobId);
        if (!$source) {
            throw new \RuntimeException('Không tìm thấy Tin tuyển dụng.', 404);
        }

        $registry = $this->registry($jobId);
        $steps = [];
        foreach ($this->pipelineStepMap() as $step => $meta) {
            $steps[$step] = [
                'status' => $this->stepStatus($step, $registry, $source),
                'projection' => $meta['projection'],
                'api' => $meta['api'],
            ];
        }

        return [
            'content' => [
                'type' => self::JOB_TYPE,
                'id' => $jobId,
                'source_key' => (string)$source['ma_tin'],
                'source_status' => (string)$source['trang_thai'],
                'source_updated_at' => $source['ngay_cap_nhat'] ?? null,
            ],
            'contract' => self::VERSION,
            'source_of_truth' => self::JOB_TABLE,
            'pipeline' => $steps,
        ];
    }

    /** @return array<string,mixed>|null */
    private function sourceJob(int $jobId): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT id, ma_tin, trang_thai, ngay_cap_nhat FROM tin_tuyen_dung WHERE id=? LIMIT 1'
        );
        $stmt->execute([$jobId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }

    /** @return array<string,mixed>|null */
    private function registry(int $jobId): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT content_fingerprint, source_updated_at, last_processed_at FROM content_discovery_registry WHERE content_type=? AND source_table=? AND source_id=? LIMIT 1'
        );
        $stmt->execute([self::JOB_TYPE, self::JOB_TABLE, $jobId]);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }

    /** @return array<string,array{projection:string,api:string}> */
    private function pipelineStepMap(): array
    {
        return [
            'discovery' => ['projection' => self::PROJECTIONS['registry'], 'api' => '/api/content-discovery/jobs/{id}'],
            'classification' => ['projection' => self::PROJECTIONS['classification'], 'api' => '/api/content-discovery/jobs/{id}/classification'],
            'tags' => ['projection' => self::PROJECTIONS['tags'], 'api' => '/api/content-discovery/jobs/{id}/tags'],
            'topic_location' => ['projection' => self::PROJECTIONS['topic_location'], 'api' => '/api/content-discovery/jobs/{id}/taxonomy'],
            'search' => ['projection' => self::PROJECTIONS['search'], 'api' => '/api/content-discovery/search'],
            'feed' => ['projection' => null, 'api' => '/api/content-discovery/feed'],
            'related' => ['projection' => null, 'api' => '/api/content-discovery/jobs/{id}/related'],
            'recommendation' => ['projection' => null, 'api' => '/api/content-discovery/jobs/{id}/recommendations'],
            'public' => ['projection' => null, 'api' => '/api/content-discovery/public/jobs/{id}'],
            'url' => ['projection' => null, 'api' => '/api/content-discovery/public/jobs/{id}/url'],
            'seo' => ['projection' => null, 'api' => '/api/content-discovery/public/jobs/{id}/seo'],
            'structured_data' => ['projection' => self::PROJECTIONS['structured_data'], 'api' => '/api/content-discovery/public/jobs/{id}/structured-data'],
            'sitemap' => ['projection' => self::PROJECTIONS['sitemap'], 'api' => '/sitemap/jobs.xml'],
            'seo_lifecycle' => ['projection' => null, 'api' => '/api/content-discovery/jobs/{id}/seo-lifecycle'],
            'quality_gate' => ['projection' => null, 'api' => null],
        ];
    }

    private function stepStatus(string $step, ?array $registry, array $source): string
    {
        if ($step === 'discovery') {
            return $registry ? 'ready' : 'pending';
        }
        if ($step === 'quality_gate') {
            return 'contract_only';
        }
        if (in_array($step, ['feed', 'related', 'recommendation', 'public', 'url', 'seo', 'seo_lifecycle'], true)) {
            return $registry ? 'available' : 'blocked';
        }
        if ($step === 'sitemap' && (string)$source['trang_thai'] !== 'dang_tuyen') {
            return 'excluded';
        }
        if ($step === 'structured_data' && (string)$source['trang_thai'] !== 'dang_tuyen') {
            return 'excluded';
        }
        if (!$registry) {
            return 'blocked';
        }
        return 'projection_managed';
    }
}
