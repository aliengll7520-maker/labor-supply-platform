<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

final class MediaStorageFactory
{
    public static function create(array $config): MediaStorageService
    {
        $driver = strtolower(trim((string)($config['driver'] ?? 'local')));
        $adapter = match ($driver) {
            'local' => new LocalMediaStorage((string)($config['root'] ?? ''),(string)($config['public_base_url'] ?? '')),
            's3', 'object_storage', 's3_compatible' => new S3CompatibleMediaStorage($config),
            default => throw new \InvalidArgumentException('Media storage driver không được hỗ trợ: '.$driver),
        };
        return new MediaStorageService($adapter);
    }
}
