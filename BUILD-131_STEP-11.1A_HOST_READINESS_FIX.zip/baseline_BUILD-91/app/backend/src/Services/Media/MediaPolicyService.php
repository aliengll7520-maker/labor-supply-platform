<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

final class MediaPolicyService {
    public function canUploadMime(string $actorType, string $mime): bool {
        if ($actorType === 'nguoi_lao_dong' && str_starts_with($mime, 'video/')) return false;
        return true;
    }

    public function assertCanUploadMime(string $actorType, string $mime): void {
        if (!$this->canUploadMime($actorType, $mime)) {
            throw new \InvalidArgumentException('Người lao động chỉ được đăng chữ và ảnh trên trang cá nhân; video không Live không được hỗ trợ.');
        }
    }
}
