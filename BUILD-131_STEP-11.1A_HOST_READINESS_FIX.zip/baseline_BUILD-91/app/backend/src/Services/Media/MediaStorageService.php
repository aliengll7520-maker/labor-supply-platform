<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

use LaborPlatform\Contracts\MediaStorageInterface;

final class MediaStorageService {
    public function __construct(private MediaStorageInterface $storage) {}
    public function store(string $sourcePath, string $storageKey, array $metadata=[]): array {
        $stored=$this->storage->putFile($sourcePath,$storageKey);
        return array_merge($stored,[
            'mime_type'=>isset($metadata['mime_type']) ? (string)$metadata['mime_type'] : null,
            'width'=>isset($metadata['width']) ? max(0,(int)$metadata['width']) : null,
            'height'=>isset($metadata['height']) ? max(0,(int)$metadata['height']) : null,
            'duration_seconds'=>isset($metadata['duration_seconds']) ? max(0,(int)$metadata['duration_seconds']) : null,
            'status'=>'stored',
        ]);
    }
    public function exists(string $storageKey): bool { return $this->storage->exists($storageKey); }
    public function delete(string $storageKey): bool { return $this->storage->delete($storageKey); }
    public function path(string $storageKey): string { return $this->storage->absolutePath($storageKey); }
    public function url(string $storageKey): string { return $this->storage->publicUrl($storageKey); }
    public function releasePath(string $path): void { $this->storage->releasePath($path); }
}
