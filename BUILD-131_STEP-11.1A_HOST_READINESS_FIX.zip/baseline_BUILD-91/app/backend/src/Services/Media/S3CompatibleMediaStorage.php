<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

use LaborPlatform\Contracts\MediaStorageInterface;

/**
 * PR-03.6: dependency-free S3-compatible Object Storage adapter.
 * Secrets are read from environment/config; no credentials are persisted in source.
 * Files are materialized to a temporary local path only when image processing needs them.
 */
final class S3CompatibleMediaStorage implements MediaStorageInterface
{
    private string $endpoint;
    private string $bucket;
    private string $region;
    private string $accessKey;
    private string $secretKey;
    private string $prefix;
    private string $publicBaseUrl;
    private bool $pathStyle;
    private int $timeout;

    public function __construct(array $config)
    {
        if (!extension_loaded('curl')) {
            throw new \RuntimeException('PHP cURL extension chưa được bật cho Object Storage.');
        }
        $this->endpoint = rtrim((string)($config['endpoint'] ?? ''), '/');
        $this->bucket = trim((string)($config['bucket'] ?? ''));
        $this->region = trim((string)($config['region'] ?? 'us-east-1')) ?: 'us-east-1';
        $this->accessKey = trim((string)($config['access_key'] ?? ''));
        $this->secretKey = (string)($config['secret_key'] ?? '');
        $this->prefix = trim((string)($config['prefix'] ?? ''), '/');
        $this->publicBaseUrl = rtrim((string)($config['public_base_url'] ?? ''), '/');
        $this->pathStyle = (bool)($config['path_style'] ?? true);
        $this->timeout = max(5, (int)($config['timeout'] ?? 30));

        if ($this->endpoint === '' || !filter_var($this->endpoint, FILTER_VALIDATE_URL)) {
            throw new \InvalidArgumentException('Object Storage endpoint không hợp lệ.');
        }
        if ($this->bucket === '' || !preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{1,62}$/', $this->bucket)) {
            throw new \InvalidArgumentException('Object Storage bucket không hợp lệ.');
        }
        if ($this->accessKey === '' || $this->secretKey === '') {
            throw new \InvalidArgumentException('Object Storage credentials chưa được cấu hình.');
        }
    }

    public function putFile(string $sourcePath, string $storageKey): array
    {
        if (!is_file($sourcePath) || !is_readable($sourcePath)) {
            throw new \RuntimeException('File nguồn Media không tồn tại hoặc không đọc được.');
        }
        $key = $this->normalizeKey($storageKey);
        $size = filesize($sourcePath);
        if ($size === false) throw new \RuntimeException('Không đọc được kích thước Media.');
        $sha = hash_file('sha256', $sourcePath);
        if ($sha === false) throw new \RuntimeException('Không tính được SHA-256 Media nguồn.');
        $this->request('PUT', $key, '', $sourcePath, $sha);
        if ($size === false) throw new \RuntimeException('Không đọc được kích thước Media.');
        return ['storage_key'=>$key,'size_bytes'=>(int)$size,'sha256'=>$sha];
    }

    public function exists(string $storageKey): bool
    {
        try {
            $this->request('HEAD', $this->normalizeKey($storageKey));
            return true;
        } catch (\RuntimeException $e) {
            if ($e->getCode() === 404) return false;
            throw $e;
        }
    }

    public function delete(string $storageKey): bool
    {
        try {
            $this->request('DELETE', $this->normalizeKey($storageKey));
            return true;
        } catch (\RuntimeException $e) {
            if ($e->getCode() === 404) return false;
            throw $e;
        }
    }

    public function absolutePath(string $storageKey): string
    {
        $key = $this->normalizeKey($storageKey);
        $tmp = tempnam(sys_get_temp_dir(), 'labor-object-');
        if ($tmp === false) throw new \RuntimeException('Không tạo được file tạm cho Object Storage.');
        try {
            $body = $this->request('GET', $key);
            if (file_put_contents($tmp, $body) === false) throw new \RuntimeException('Không ghi được Object Storage vào file tạm.');
            return $tmp;
        } catch (\Throwable $e) {
            @unlink($tmp);
            throw $e;
        }
    }

    public function releasePath(string $path): void
    {
        if (str_starts_with($path, rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'labor-object-')) {
            @unlink($path);
        }
    }

    public function publicUrl(string $storageKey): string
    {
        $key = $this->normalizeKey($storageKey);
        if ($this->publicBaseUrl !== '') return $this->publicBaseUrl.'/'.$this->encodeKey($key);
        return '';
    }

    private function request(string $method, string $key, string $body='', ?string $sourcePath=null, ?string $sourceSha256=null): string
    {
        $host = (string)(parse_url($this->endpoint, PHP_URL_HOST) ?: '');
        if ($host === '') throw new \RuntimeException('Object Storage endpoint thiếu host.');
        $scheme = (string)(parse_url($this->endpoint, PHP_URL_SCHEME) ?: 'https');
        $basePath = trim((string)(parse_url($this->endpoint, PHP_URL_PATH) ?: ''), '/');
        $objectPath = ($this->pathStyle ? $this->bucket.'/' : '').$this->encodeKey($key);
        $path = '/'.($basePath !== '' ? $basePath.'/' : '').$objectPath;
        $url = $scheme.'://'.$host.$path;
        $payloadHash = $sourceSha256 ?? hash('sha256', $body);
        $amzDate = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');
        $canonicalHeaders = 'host:'.$host."\n".'x-amz-content-sha256:'.$payloadHash."\n".'x-amz-date:'.$amzDate."\n";
        $signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
        $canonicalRequest = $method."\n".$path."\n\n".$canonicalHeaders."\n".$signedHeaders."\n".$payloadHash;
        $credentialScope = $date.'/'.$this->region.'/s3/aws4_request';
        $stringToSign = "AWS4-HMAC-SHA256\n".$amzDate."\n".$credentialScope."\n".hash('sha256',$canonicalRequest);
        $kDate = hash_hmac('sha256',$date,'AWS4'.$this->secretKey,true);
        $kRegion = hash_hmac('sha256',$this->region,$kDate,true);
        $kService = hash_hmac('sha256','s3',$kRegion,true);
        $kSigning = hash_hmac('sha256','aws4_request',$kService,true);
        $signature = hash_hmac('sha256',$stringToSign,$kSigning);
        $authorization = 'AWS4-HMAC-SHA256 Credential='.$this->accessKey.'/'.$credentialScope.', SignedHeaders='.$signedHeaders.', Signature='.$signature;

        $headers = [
            'Authorization: '.$authorization,
            'Host: '.$host,
            'x-amz-content-sha256: '.$payloadHash,
            'x-amz-date: '.$amzDate,
        ];
        if ($method === 'PUT') $headers[] = 'Content-Type: application/octet-stream';

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => min(10,$this->timeout),
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if ($method === 'PUT') {
            if ($sourcePath !== null) {
                $fh = fopen($sourcePath, 'rb');
                if ($fh === false) { curl_close($ch); throw new \RuntimeException('Không mở được file Media để upload.'); }
                curl_setopt($ch, CURLOPT_UPLOAD, true);
                curl_setopt($ch, CURLOPT_INFILE, $fh);
                curl_setopt($ch, CURLOPT_INFILESIZE, filesize($sourcePath) ?: 0);
            } else {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            }
        }
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (isset($fh) && is_resource($fh)) fclose($fh);
        curl_close($ch);
        if ($response === false) throw new \RuntimeException('Object Storage request thất bại: '.($error ?: 'unknown error'));
        if ($status < 200 || $status >= 300) throw new \RuntimeException('Object Storage trả HTTP '.$status.'.', $status);
        return (string)$response;
    }

    private function normalizeKey(string $key): string
    {
        $key = str_replace('\\','/',$key);
        $key = ltrim($key,'/');
        if ($this->prefix !== '') $key = $this->prefix.'/'.$key;
        if ($key==='' || preg_match('~(^|/)\.\.(\/|$)~',$key) || preg_match('/[\x00-\x1F]/',$key)) {
            throw new \InvalidArgumentException('Media storage key không hợp lệ.');
        }
        return $key;
    }

    private function encodeKey(string $key): string
    {
        return implode('/', array_map(static fn(string $part): string => rawurlencode($part), explode('/', $key)));
    }
}
