<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

final class MediaSecurityService {
    public function __construct(private int $maxImagePixels=25000000, private int $maxFilenameLength=255) {}

    public function validateUpload(string $path, string $clientName, string $detectedMime, int $size): array {
        if (!is_file($path) || !is_readable($path)) throw new \RuntimeException('File Media không tồn tại hoặc không đọc được.');
        if ($size <= 0) throw new \InvalidArgumentException('Kích thước Media không hợp lệ.');
        $name=$this->sanitizeFilename($clientName);
        $allowed=['image/jpeg','image/png','image/webp','video/mp4','video/webm'];
        if (!in_array($detectedMime,$allowed,true)) throw new \InvalidArgumentException('Định dạng Media chưa được hỗ trợ.');
        $this->validateSignature($path,$detectedMime);
        $meta=['safe_name'=>$name,'mime_type'=>$detectedMime];
        if (str_starts_with($detectedMime,'image/')) {
            $dim=@getimagesize($path);
            if (!is_array($dim) || ($dim[0]??0)<1 || ($dim[1]??0)<1) throw new \InvalidArgumentException('Ảnh Media không hợp lệ.');
            $width=(int)$dim[0]; $height=(int)$dim[1];
            if ($width*$height > $this->maxImagePixels) throw new \InvalidArgumentException('Ảnh Media có kích thước điểm ảnh quá lớn.');
            $meta['width']=$width; $meta['height']=$height;
        }
        return $meta;
    }

    private function sanitizeFilename(string $name): string {
        $name=trim(str_replace(["\\","/", "\0"], '', $name));
        $name=preg_replace('/[\x00-\x1F\x7F]+/u','',$name) ?? '';
        $name=preg_replace('/[^\pL\pN._ -]+/u','_',$name) ?? '';
        $name=trim($name,'. ');
        if ($name==='') $name='media';
        return function_exists('mb_substr') ? mb_substr($name,0,$this->maxFilenameLength) : substr($name,0,$this->maxFilenameLength);
    }

    private function validateSignature(string $path,string $mime): void {
        $fh=@fopen($path,'rb'); if (!$fh) throw new \RuntimeException('Không thể đọc chữ ký file Media.');
        $head=(string)fread($fh,64); fclose($fh);
        if ($mime==='image/jpeg' && !str_starts_with($head,"\xFF\xD8\xFF")) throw new \InvalidArgumentException('Chữ ký JPEG không hợp lệ.');
        if ($mime==='image/png' && !str_starts_with($head,"\x89PNG\r\n\x1A\n")) throw new \InvalidArgumentException('Chữ ký PNG không hợp lệ.');
        if ($mime==='image/webp' && !(str_starts_with($head,'RIFF') && substr($head,8,4)==='WEBP')) throw new \InvalidArgumentException('Chữ ký WebP không hợp lệ.');
        if ($mime==='video/webm' && !str_starts_with($head,"\x1A\x45\xDF\xA3")) throw new \InvalidArgumentException('Chữ ký WebM không hợp lệ.');
        if ($mime==='video/mp4' && strpos(substr($head,0,32),'ftyp')===false) throw new \InvalidArgumentException('Chữ ký MP4 không hợp lệ.');
    }
}
