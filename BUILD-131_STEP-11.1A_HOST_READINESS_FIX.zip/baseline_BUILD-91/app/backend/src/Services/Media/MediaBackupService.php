<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

/** BUILD 149 — exports/restores logical Media objects independently of the storage driver. */
final class MediaBackupService
{
    public function __construct(private MediaStorageService $storage) {}

    public function exportDatabase(\PDO $db, string $stageRoot): array
    {
        if (!is_dir($stageRoot) && !mkdir($stageRoot, 0700, true) && !is_dir($stageRoot)) {
            throw new \RuntimeException('Không thể tạo Media backup staging.');
        }
        $objectsDir = rtrim($stageRoot, DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'objects';
        if (!mkdir($objectsDir, 0700, true) && !is_dir($objectsDir)) {
            throw new \RuntimeException('Không thể tạo Media objects staging.');
        }
        $manifest = ['format_version'=>1,'created_at_utc'=>gmdate('c'),'objects'=>[]];
        $assets = $db->query('SELECT id,storage_driver,storage_key,sha256,size_bytes,trang_thai FROM media_asset ORDER BY id ASC')->fetchAll();
        $variants = $db->query('SELECT id,media_asset_id,variant_key,storage_driver,storage_key,sha256,size_bytes,trang_thai FROM media_asset_variant ORDER BY id ASC')->fetchAll();
        foreach ($assets as $row) {
            $this->exportObject($row['storage_key'], $objectsDir, $manifest, [
                'kind'=>'asset','id'=>(int)$row['id'],'storage_driver'=>(string)$row['storage_driver'],
                'sha256'=>$row['sha256'] !== null ? (string)$row['sha256'] : null,
                'size_bytes'=>(int)$row['size_bytes'],'status'=>(string)$row['trang_thai'],
            ]);
        }
        foreach ($variants as $row) {
            $this->exportObject($row['storage_key'], $objectsDir, $manifest, [
                'kind'=>'variant','id'=>(int)$row['id'],'media_asset_id'=>(int)$row['media_asset_id'],
                'variant_key'=>(string)$row['variant_key'],'storage_driver'=>(string)$row['storage_driver'],
                'sha256'=>$row['sha256'] !== null ? (string)$row['sha256'] : null,
                'size_bytes'=>(int)$row['size_bytes'],'status'=>(string)$row['trang_thai'],
            ]);
        }
        $manifest['object_count']=count($manifest['objects']);
        file_put_contents($stageRoot.'/media-manifest.json', json_encode($manifest, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n", LOCK_EX);
        return $manifest;
    }

    private function exportObject(string $storageKey, string $objectsDir, array &$manifest, array $meta): void
    {
        $source = $this->storage->path($storageKey);
        try {
            if (!is_file($source) || !is_readable($source)) throw new \RuntimeException('Media object không đọc được: '.$storageKey);
            $token = hash('sha256', $meta['kind'].'|'.$meta['id'].'|'.$storageKey);
            $relative = 'objects/'.$token.'.bin';
            $target = dirname($objectsDir).DIRECTORY_SEPARATOR.$relative;
            if (!copy($source, $target)) throw new \RuntimeException('Không thể sao chép Media vào backup.');
            $actual = hash_file('sha256', $target);
            if ($actual === false) throw new \RuntimeException('Không thể tính checksum Media backup.');
            $meta['storage_key']=$storageKey;
            $meta['archive_file']=$relative;
            $meta['backup_sha256']=$actual;
            $manifest['objects'][]=$meta;
        } finally {
            $this->storage->releasePath($source);
        }
    }

    /** Validate staged Media fully before any destructive database restore begins. */
    public function preflightRestoreFromStage(string $stageRoot): int
    {
        $manifest = $this->loadAndValidateManifest($stageRoot);
        $count = 0;
        foreach ($manifest['objects'] as $object) {
            $file = $this->validatedStageFile($stageRoot, $object);
            $expected=(string)($object['backup_sha256'] ?? '');
            $actual=hash_file('sha256',$file);
            if ($expected==='' || $actual===false || !hash_equals($expected,$actual)) {
                throw new \RuntimeException('Checksum Media backup không khớp: '.(string)$object['archive_file']);
            }
            $count++;
        }
        return $count;
    }

    /**
     * Activate every Media object into final storage before DB restore, with a rollback journal.
     * The journal is returned to the caller so failed database recovery can restore the previous storage state.
     */
    public function activateFromStage(string $stageRoot, string $rollbackRoot): array
    {
        $manifest=$this->loadAndValidateManifest($stageRoot);
        if (!is_dir($rollbackRoot) && !mkdir($rollbackRoot,0700,true) && !is_dir($rollbackRoot)) {
            throw new \RuntimeException('Không thể tạo Media rollback staging.');
        }
        $journal=[];
        try {
            foreach ($manifest['objects'] as $index=>$object) {
                $file=$this->validatedStageFile($stageRoot,$object);
                $key=(string)$object['storage_key'];
                $snapshotPath=$rollbackRoot.'/'.hash('sha256',$key).'.bin';
                $hadExisting=$this->storage->exists($key);
                if ($hadExisting) {
                    $existing=$this->storage->path($key);
                    try {
                        if (!is_file($existing) || !is_readable($existing) || !copy($existing,$snapshotPath)) {
                            throw new \RuntimeException('Không thể snapshot Media hiện tại trước activation: '.$key);
                        }
                        $snapshotSha=hash_file('sha256',$snapshotPath);
                        if ($snapshotSha===false) throw new \RuntimeException('Không thể kiểm tra snapshot Media: '.$key);
                    } finally { $this->storage->releasePath($existing); }
                } else { $snapshotSha=null; }
                $journal[]=['storage_key'=>$key,'had_existing'=>$hadExisting,'snapshot_path'=>$hadExisting?$snapshotPath:null,'snapshot_sha256'=>$snapshotSha];
                $stored=$this->storage->store($file,$key,['mime_type'=>null]);
                $sourceSha=(string)($object['backup_sha256'] ?? '');
                $storedSha=(string)($stored['sha256'] ?? '');
                if ($sourceSha==='' || $storedSha==='' || !hash_equals($sourceSha,$storedSha)) {
                    throw new \RuntimeException('Checksum Media sau activation không khớp: '.$key);
                }
            }
            return ['manifest'=>$manifest,'journal'=>$journal,'count'=>count($manifest['objects'])];
        } catch (\Throwable $e) {
            $this->rollbackActivation($journal);
            throw $e;
        }
    }

    /** Restore the storage state that existed before activation. */
    public function rollbackActivation(array $journal): void
    {
        $errors=[];
        for ($i=count($journal)-1; $i>=0; $i--) {
            $entry=$journal[$i];
            $key=(string)$entry['storage_key'];
            try { $this->storage->delete($key); } catch (\Throwable $e) { $errors[]='delete '.$key.': '.$e->getMessage(); }
            if (!empty($entry['had_existing']) && !empty($entry['snapshot_path']) && is_file($entry['snapshot_path'])) {
                try {
                    $stored=$this->storage->store((string)$entry['snapshot_path'],$key,['mime_type'=>null]);
                    if (!empty($entry['snapshot_sha256']) && !hash_equals((string)$entry['snapshot_sha256'],(string)($stored['sha256'] ?? ''))) {
                        $errors[]='checksum '.$key;
                    }
                } catch (\Throwable $e) { $errors[]='restore '.$key.': '.$e->getMessage(); }
            }
        }
        if ($errors) { throw new \RuntimeException('Media rollback incomplete: '.implode('; ',$errors)); }
    }

    private function validatedStageFile(string $stageRoot, array $object): string
    {
        $relative=(string)($object['archive_file'] ?? '');
        if (!preg_match('~^objects/[a-f0-9]{64}\.bin$~',$relative)) throw new \RuntimeException('Media backup entry không hợp lệ: '.$relative);
        $file=rtrim($stageRoot,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.$relative;
        if (!is_file($file) || !is_readable($file) || is_link($file)) throw new \RuntimeException('Media backup object không phải regular file: '.$relative);
        return $file;
    }

    private function loadAndValidateManifest(string $stageRoot): array
    {
        $path=rtrim($stageRoot,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'media-manifest.json';
        if (!is_file($path) || !is_readable($path)) throw new \RuntimeException('Thiếu media-manifest.json.');
        $raw=file_get_contents($path);
        if ($raw===false) throw new \RuntimeException('Không đọc được media-manifest.json.');
        $manifest=json_decode($raw,true);
        if (!is_array($manifest) || !isset($manifest['objects']) || !is_array($manifest['objects'])) throw new \RuntimeException('Media manifest không hợp lệ.');
        $seen=[];
        foreach ($manifest['objects'] as $object) {
            if (!is_array($object)) throw new \RuntimeException('Media manifest chứa entry không hợp lệ.');
            $relative=(string)($object['archive_file'] ?? '');
            $key=(string)($object['storage_key'] ?? '');
            if ($relative==='' || $key==='' || !preg_match('~^objects/[a-f0-9]{64}\.bin$~',$relative) || str_starts_with($key,'/') || preg_match('~(^|/)\.\.(\/|$)~',$key)) {
                throw new \RuntimeException('Media backup entry không hợp lệ.');
            }
            if (isset($seen[$relative])) throw new \RuntimeException('Media manifest trùng archive_file: '.$relative);
            $seen[$relative]=true;
        }
        return $manifest;
    }

    /** Final consistency check: restored DB references must match the backup manifest and every referenced object must exist with the expected checksum. */
    public function verifyDatabaseConsistency(\PDO $db, array $manifest): array
    {
        $expectedAssets = 0;
        $expectedVariants = 0;
        foreach ($manifest['objects'] as $object) {
            if (($object['kind'] ?? '') === 'asset') $expectedAssets++;
            elseif (($object['kind'] ?? '') === 'variant') $expectedVariants++;
            else throw new \RuntimeException('Media manifest kind không hợp lệ trong final verification.');
        }

        $assetCount = (int)$db->query('SELECT COUNT(*) FROM media_asset')->fetchColumn();
        $variantCount = (int)$db->query('SELECT COUNT(*) FROM media_asset_variant')->fetchColumn();
        if ($assetCount !== $expectedAssets || $variantCount !== $expectedVariants) {
            throw new \RuntimeException(sprintf(
                'Media DB count không khớp manifest: asset %d/%d, variant %d/%d.',
                $assetCount, $expectedAssets, $variantCount, $expectedVariants
            ));
        }

        $assetStmt = $db->prepare('SELECT storage_key, sha256, size_bytes FROM media_asset WHERE id = :id LIMIT 1');
        $variantStmt = $db->prepare('SELECT storage_key, sha256, size_bytes FROM media_asset_variant WHERE id = :id LIMIT 1');
        $verified = 0;
        foreach ($manifest['objects'] as $object) {
            $kind = (string)$object['kind'];
            $id = (int)$object['id'];
            $stmt = $kind === 'asset' ? $assetStmt : $variantStmt;
            $stmt->execute([':id'=>$id]);
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            if (!$row) throw new \RuntimeException("Media DB record thiếu: {$kind}#{$id}.");

            $key = (string)$object['storage_key'];
            if (!hash_equals($key, (string)$row['storage_key'])) {
                throw new \RuntimeException("Media storage_key không khớp: {$kind}#{$id}.");
            }
            if ((int)$row['size_bytes'] !== (int)$object['size_bytes']) {
                throw new \RuntimeException("Media size_bytes không khớp: {$kind}#{$id}.");
            }
            if (($object['sha256'] ?? null) !== null && (string)$row['sha256'] !== (string)$object['sha256']) {
                throw new \RuntimeException("Media DB sha256 không khớp manifest: {$kind}#{$id}.");
            }

            if (!$this->storage->exists($key)) {
                throw new \RuntimeException("Media object thiếu trong Storage: {$key}.");
            }
            $path = $this->storage->path($key);
            try {
                if (!is_file($path) || !is_readable($path)) throw new \RuntimeException("Media object không đọc được sau restore: {$key}.");
                $actual = hash_file('sha256', $path);
                if ($actual === false || !hash_equals((string)$object['backup_sha256'], $actual)) {
                    throw new \RuntimeException("Media Storage checksum không khớp sau restore: {$key}.");
                }
            } finally {
                $this->storage->releasePath($path);
            }
            $verified++;
        }

        return ['assets'=>$assetCount,'variants'=>$variantCount,'objects_verified'=>$verified];
    }

    /** Kept for compatibility; restoration now uses activateFromStage(). */
    public function restoreFromStage(string $stageRoot): int
    {
        $rollbackRoot=rtrim($stageRoot,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'.rollback';
        $result=$this->activateFromStage($stageRoot,$rollbackRoot);
        return (int)$result['count'];
    }
}
