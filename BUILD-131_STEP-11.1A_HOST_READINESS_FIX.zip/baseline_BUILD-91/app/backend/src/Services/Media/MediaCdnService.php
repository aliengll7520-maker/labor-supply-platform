<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

/**
 * PR-03.7: CDN delivery policy. The CDN is only a delivery layer; it never
 * decides whether an asset is public. Private assets are never converted to
 * public CDN URLs by this service.
 */
final class MediaCdnService
{
    private string $baseUrl;
    private bool $enabled;
    private int $cacheSeconds;

    public function __construct(array $config = [])
    {
        $this->enabled = (bool)($config['enabled'] ?? false);
        $this->baseUrl = rtrim((string)($config['base_url'] ?? ''), '/');
        $this->cacheSeconds = max(0, (int)($config['cache_seconds'] ?? 3600));

        if ($this->enabled && $this->baseUrl === '') {
            throw new \InvalidArgumentException('CDN đã bật nhưng thiếu CDN base URL.');
        }
        if ($this->baseUrl !== '' && !filter_var($this->baseUrl, FILTER_VALIDATE_URL)) {
            throw new \InvalidArgumentException('CDN base URL không hợp lệ.');
        }
    }

    public function isEnabled(): bool
    {
        return $this->enabled;
    }

    public function cacheSeconds(): int
    {
        return $this->cacheSeconds;
    }

    /**
     * Returns a CDN URL only for an explicitly public asset.
     * Private assets must be delivered through a future authenticated/signed
     * delivery flow and are never exposed by this helper.
     */
    public function publicUrl(string $storageKey, bool $publicAccess): string
    {
        if (!$publicAccess) {
            throw new \RuntimeException('Media riêng tư không được cấp URL CDN công khai.', 403);
        }
        $key = $this->normalizeKey($storageKey);
        if (!$this->enabled) return '';
        return $this->baseUrl . '/' . $this->encodeKey($key);
    }

    private function normalizeKey(string $key): string
    {
        $key = str_replace('\\', '/', $key);
        $key = ltrim($key, '/');
        if ($key === '' || preg_match('~(^|/)\.\.(\/|$)~', $key) || preg_match('/[\x00-\x1F]/', $key)) {
            throw new \InvalidArgumentException('Media CDN storage key không hợp lệ.');
        }
        return $key;
    }

    private function encodeKey(string $key): string
    {
        return implode('/', array_map(static fn(string $part): string => rawurlencode($part), explode('/', $key)));
    }
}
