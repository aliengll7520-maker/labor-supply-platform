<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

use LaborPlatform\Queue\QueueService;

final class MediaCleanupService
{
    public function __construct(private QueueService $queue, private array $config = []) {}

    public function enqueueObject(string $storageKey, string $reason = 'stale_variant', ?string $dedupeKey = null): int
    {
        $storageKey = trim($storageKey);
        if ($storageKey === '' || preg_match('~(^|/)\.\.(/|$)~', $storageKey) || preg_match('/[\x00-\x1F]/', $storageKey)) {
            throw new \InvalidArgumentException('Media cleanup storage key không hợp lệ.');
        }
        $reason = trim($reason) !== '' ? trim($reason) : 'cleanup';
        $dedupeKey = $dedupeKey ?: 'media:cleanup:'.hash('sha256', $storageKey.'|'.$reason);
        return $this->queue->enqueue('media_cleanup', 'media.cleanup_object', [
            'storage_key' => $storageKey,
            'reason' => $reason,
        ], 60, $dedupeKey, (int)($this->config['max_attempts'] ?? 8));
    }

    public function enqueueTempSweep(?string $tempDir = null): int
    {
        $tempDir = $tempDir !== null && trim($tempDir) !== '' ? trim($tempDir) : sys_get_temp_dir();
        $dedupe = 'media:cleanup:temp:'.date('Y-m-d-H');
        return $this->queue->enqueue('media_cleanup', 'media.cleanup_temp', [
            'temp_dir' => $tempDir,
            'limit' => (int)($this->config['temp_batch_limit'] ?? 200),
        ], 20, $dedupe, (int)($this->config['max_attempts'] ?? 8));
    }

    public function tempMaxAgeSeconds(): int
    {
        return max(300, min(604800, (int)($this->config['temp_max_age_seconds'] ?? 86400)));
    }

    public function cleanupTempFiles(string $tempDir, int $limit = 200): int
    {
        $tempDir = rtrim($tempDir, DIRECTORY_SEPARATOR);
        if ($tempDir === '' || !is_dir($tempDir) || !is_readable($tempDir)) return 0;
        $limit = max(1, min(1000, $limit));
        $cutoff = time() - $this->tempMaxAgeSeconds();
        $removed = 0;
        foreach (glob($tempDir.DIRECTORY_SEPARATOR.'labor-img-*') ?: [] as $path) {
            if ($removed >= $limit || !is_file($path)) continue;
            $mtime = @filemtime($path);
            if ($mtime === false || $mtime > $cutoff) continue;
            if (@unlink($path)) $removed++;
        }
        return $removed;
    }
}
