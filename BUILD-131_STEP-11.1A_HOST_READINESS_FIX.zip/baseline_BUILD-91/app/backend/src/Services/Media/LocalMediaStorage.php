<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

use LaborPlatform\Contracts\MediaStorageInterface;

final class LocalMediaStorage implements MediaStorageInterface {
    public function __construct(private string $root, private string $publicBaseUrl='') {
        $this->root=rtrim($root,DIRECTORY_SEPARATOR);
        if ($this->root==='') throw new \InvalidArgumentException('Media storage root không được để trống.');
    }
    public function putFile(string $sourcePath, string $storageKey): array {
        if (!is_file($sourcePath) || !is_readable($sourcePath)) throw new \RuntimeException('File nguồn Media không tồn tại hoặc không đọc được.');
        $key=$this->normalizeKey($storageKey); $target=$this->absolutePath($key); $dir=dirname($target);
        if (!is_dir($dir) && !mkdir($dir,0750,true) && !is_dir($dir)) throw new \RuntimeException('Không thể tạo thư mục Media.');
        if (!copy($sourcePath,$target)) throw new \RuntimeException('Không thể lưu Media.');
        $size=filesize($target); $sha=hash_file('sha256',$target);
        if ($size===false || $sha===false) throw new \RuntimeException('Không thể đọc metadata Media sau khi lưu.');
        return ['storage_key'=>$key,'size_bytes'=>(int)$size,'sha256'=>$sha];
    }
    public function exists(string $storageKey): bool { return is_file($this->absolutePath($storageKey)); }
    public function delete(string $storageKey): bool { $path=$this->absolutePath($storageKey); return !is_file($path) || unlink($path); }
    public function absolutePath(string $storageKey): string { return $this->root.DIRECTORY_SEPARATOR.$this->normalizeKey($storageKey); }
    public function publicUrl(string $storageKey): string { $key=$this->normalizeKey($storageKey); return $this->publicBaseUrl!=='' ? rtrim($this->publicBaseUrl,'/').'/'.str_replace('\\','/',$key) : $key; }
    public function releasePath(string $path): void {}
    private function normalizeKey(string $key): string {
        $key=str_replace('\\','/',$key); $key=ltrim($key,'/');
        if ($key==='' || preg_match('~(^|/)\.\.(/|$)~',$key) || preg_match('/[\x00-\x1F]/',$key)) throw new \InvalidArgumentException('Media storage key không hợp lệ.');
        return $key;
    }
}
