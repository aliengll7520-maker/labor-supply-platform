<?php
declare(strict_types=1);
namespace LaborPlatform\Services\Media;

final class ImageProcessingService
{
    public function __construct(private MediaStorageService $storage, private array $config = []) {}

    public function process(string $sourcePath, string $baseKey): array
    {
        if (!extension_loaded('gd')) {
            throw new \RuntimeException('PHP GD extension chưa được bật cho xử lý ảnh.');
        }
        $info = @getimagesize($sourcePath);
        if (!is_array($info)) throw new \RuntimeException('Không đọc được thông tin ảnh.');
        $mime = (string)($info['mime'] ?? '');
        $width = (int)($info[0] ?? 0);
        $height = (int)($info[1] ?? 0);
        if ($width < 1 || $height < 1) throw new \RuntimeException('Kích thước ảnh không hợp lệ.');
        $maxPixels = max(1000000, (int)($this->config['max_pixels'] ?? 25000000));
        if ($width * $height > $maxPixels) throw new \RuntimeException('Ảnh có số điểm ảnh vượt quá giới hạn xử lý.');

        $source = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($sourcePath),
            'image/png' => @imagecreatefrompng($sourcePath),
            'image/webp' => @imagecreatefromwebp($sourcePath),
            default => false,
        };
        if ($source === false) throw new \RuntimeException('Không thể giải mã ảnh.');

        $variants = [];
        $createdStorageKeys = [];
        // Each processing attempt gets its own immutable generation so a failed
        // retry can never overwrite or delete variants currently in use.
        $generation = gmdate('YmdHis') . '-' . bin2hex(random_bytes(8));
        $baseStem = preg_replace('/\.[^.]+$/', '', $baseKey);
        try {
            foreach ([
                'web' => [(int)($this->config['web_max_width'] ?? 2000), 82],
                'thumb' => [(int)($this->config['thumb_max_width'] ?? 400), 78],
                // Profile images (worker avatar / employer logo) are deliberately
                // small because they are rendered repeatedly in lists, cards and
                // job-detail screens. The variant is hard-capped below 50 KiB.
                'profile' => [(int)($this->config['profile_max_width'] ?? 200), 82],
            ] as $name => [$maxWidth, $quality]) {
                $maxWidth = max(64, $maxWidth);
                [$tw, $th] = $name === 'profile'
                    ? $this->fitBox($width, $height, $maxWidth, (int)($this->config['profile_max_height'] ?? 200))
                    : $this->fit($width, $height, $maxWidth);
                $canvas = imagecreatetruecolor($tw, $th);
                imagealphablending($canvas, false);
                imagesavealpha($canvas, true);
                $transparent = imagecolorallocatealpha($canvas, 255, 255, 255, 127);
                imagefilledrectangle($canvas, 0, 0, $tw, $th, $transparent);
                imagecopyresampled($canvas, $source, 0, 0, 0, 0, $tw, $th, $width, $height);

                $tmp = tempnam(sys_get_temp_dir(), 'labor-img-');
                if ($tmp === false) throw new \RuntimeException('Không tạo được file tạm xử lý ảnh.');
                $target = $tmp.'.webp';
                @unlink($tmp);
                $maxBytes = $name === 'profile'
                    ? max(10240, (int)($this->config['profile_max_bytes'] ?? 51200))
                    : 0;
                if ($name === 'profile') {
                    $encoded = $this->encodeProfile($canvas, $target, $tw, $th, $quality, $maxBytes);
                    imagedestroy($canvas);
                    if (!$encoded) {
                        @unlink($target);
                        throw new \RuntimeException('Không thể tạo Profile WebP dưới giới hạn dung lượng.');
                    }
                } else {
                    if (!imagewebp($canvas, $target, $quality)) {
                        @unlink($target);
                        imagedestroy($canvas);
                        throw new \RuntimeException('Không thể tạo WebP variant.');
                    }
                    imagedestroy($canvas);
                }

                $key = $baseStem.'/variants/'.$generation.'/'.$name.'.webp';
                try {
                    $stored = $this->storage->store($target, $key, ['mime_type'=>'image/webp','width'=>$tw,'height'=>$th]);
                } finally {
                    @unlink($target);
                }
                $createdStorageKeys[] = $stored['storage_key'];
                $variants[] = [
                    'variant_key'=>$name,
                    'storage_key'=>$stored['storage_key'],
                    'mime_type'=>'image/webp',
                    'size_bytes'=>$stored['size_bytes'],
                    'sha256'=>$stored['sha256'],
                    'width'=>$tw,
                    'height'=>$th,
                ];
            }
        } catch (\Throwable $e) {
            foreach ($createdStorageKeys as $createdKey) {
                try { $this->storage->delete((string)$createdKey); } catch (\Throwable) {}
            }
            throw $e;
        } finally {
            imagedestroy($source);
        }
        return $variants;
    }

    /**
     * Encode a profile image with a hard byte ceiling.
     * Quality is reduced first; if the image is still too large, the dimensions
     * are reduced and encoded again. This guarantees the public profile variant
     * stays lightweight even when a user uploads a very detailed camera image.
     */
    private function encodeProfile($source, string $target, int $width, int $height, int $quality, int $maxBytes): bool
    {
        $q = min(90, max(30, $quality));
        $w = $width;
        $h = $height;
        for ($round = 0; $round < 8; $round++) {
            if ($round > 0) {
                $scale = 0.85;
                $w = max(64, (int)floor($w * $scale));
                $h = max(64, (int)floor($h * $scale));
            }
            $canvas = ($w === $width && $h === $height)
                ? $source
                : $this->resizeCanvas($source, $width, $height, $w, $h);
            if (!imagewebp($canvas, $target, $q)) {
                if ($canvas !== $source) imagedestroy($canvas);
                return false;
            }
            if ($canvas !== $source) imagedestroy($canvas);
            clearstatcache(true, $target);
            if (is_file($target) && (int)filesize($target) <= $maxBytes) return true;
            @unlink($target);
            $q = max(30, $q - 8);
        }
        return false;
    }

    private function resizeCanvas($source, int $sw, int $sh, int $tw, int $th)
    {
        $canvas = imagecreatetruecolor($tw, $th);
        imagealphablending($canvas, false);
        imagesavealpha($canvas, true);
        $transparent = imagecolorallocatealpha($canvas, 255, 255, 255, 127);
        imagefilledrectangle($canvas, 0, 0, $tw, $th, $transparent);
        imagecopyresampled($canvas, $source, 0, 0, 0, 0, $tw, $th, $sw, $sh);
        return $canvas;
    }

    private function fitBox(int $width, int $height, int $maxWidth, int $maxHeight): array
    {
        $maxWidth = max(1, $maxWidth);
        $maxHeight = max(1, $maxHeight);
        $ratio = min($maxWidth / $width, $maxHeight / $height, 1.0);
        return [max(1, (int)round($width * $ratio)), max(1, (int)round($height * $ratio))];
    }

    private function fit(int $width, int $height, int $maxWidth): array
    {
        if ($width <= $maxWidth) return [$width, $height];
        $ratio = $maxWidth / $width;
        return [$maxWidth, max(1, (int)round($height * $ratio))];
    }
}
