<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class DataProtectionService
{
    public function __construct(private \PDO $db) {}

    public function logAccess(
        string $actorType,
        ?int $actorId,
        string $dataCode,
        string $action,
        ?string $objectType,
        ?int $objectId,
        string $result,
        ?string $reason = null
    ): void {
        $stmt=$this->db->prepare(
            'INSERT INTO nhat_ky_truy_cap_du_lieu
             (actor_type,actor_id,ma_du_lieu,hanh_dong,doi_tuong,doi_tuong_id,ket_qua,ly_do,ip,user_agent)
             VALUES (?,?,?,?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            $actorType,$actorId,$dataCode,$action,$objectType,$objectId,$result,
            $reason,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''),0,255)
        ]);
    }

    public function dataMap(): array
    {
        $q=$this->db->query(
            'SELECT ma_du_lieu,ten_du_lieu,muc_do,muc_dich,chu_the_du_lieu,thoi_han_luu_tru,cach_xu_ly_khi_het_han,trang_thai,phien_ban
             FROM danh_muc_du_lieu_bao_mat ORDER BY id ASC'
        );
        return $q->fetchAll();
    }

    public function accessMatrix(): array
    {
        $q=$this->db->query(
            'SELECT ma_du_lieu,vai_tro,hanh_dong,pham_vi,cho_phep,ly_do,phien_ban
             FROM quyen_truy_cap_du_lieu ORDER BY ma_du_lieu,vai_tro,hanh_dong'
        );
        return $q->fetchAll();
    }

    public static function redact(mixed $value): mixed
    {
        if(!is_array($value)) return $value;
        $sensitive=['password','mat_khau','token','access_token','refresh_token','csrf','so_dien_thoai','phone','email','cccd','cmnd','tai_khoan_ngan_hang','so_tai_khoan'];
        $out=[];
        foreach($value as $key=>$item){
            $normalized=strtolower((string)$key);
            if(in_array($normalized,$sensitive,true)){
                $out[$key]='[REDACTED]';
            } elseif(is_array($item)) {
                $out[$key]=self::redact($item);
            } else {
                $out[$key]=$item;
            }
        }
        return $out;
    }
}
