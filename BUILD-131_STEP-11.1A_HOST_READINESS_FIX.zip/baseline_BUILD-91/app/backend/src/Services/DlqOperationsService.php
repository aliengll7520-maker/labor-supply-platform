<?php
declare(strict_types=1);

namespace Labor\Backend\Services;

use PDO;
use RuntimeException;

final class DlqOperationsService
{
    public function __construct(private PDO $pdo) {}

    public function list(int $limit = 100): array
    {
        $limit = max(1, min($limit, 500));
        $stmt = $this->pdo->prepare(
            "SELECT id, queue_job_id, queue_name, job_type, payload_json, attempts, error_message, failed_at
             FROM queue_dead_letters
             ORDER BY failed_at DESC
             LIMIT :limit"
        );
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function retry(int $id, string $actorId): void
    {
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare(
                "SELECT id, queue_job_id, operation_id, dedupe_key, queue_name, job_type, payload_json
                 FROM queue_dead_letters
                 WHERE id = :id
                 FOR UPDATE"
            );
            $stmt->execute([':id' => $id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                throw new RuntimeException('DLQ item not found');
            }

            $insert = $this->pdo->prepare(
                "INSERT INTO queue_jobs
                    (queue_name, job_type, payload_json, status, attempts, max_attempts, dedupe_key, created_at)
                 VALUES
                    (:queue_name, :job_type, :payload_json, 'queued', 0, 3, :dedupe_key, CURRENT_TIMESTAMP)"
            );
            $insert->execute([
                ':queue_name' => $row['queue_name'],
                ':job_type' => $row['job_type'],
                ':payload_json' => $row['payload_json'],
                ':dedupe_key' => $row['dedupe_key'],
            ]);
            $replayJobId = (int) $this->pdo->lastInsertId();

            $delete = $this->pdo->prepare(
                "DELETE FROM queue_dead_letters WHERE id = :id"
            );
            $delete->execute([':id' => $id]);

            $audit = $this->pdo->prepare(
                "INSERT INTO dlq_operation_audit
                    (dead_letter_id, replay_queue_job_id, operation_id, actor_id, action, reason)
                 VALUES
                    (:dead_letter_id, :replay_queue_job_id, :operation_id, :actor_id, 'retry', :reason)"
            );
            $audit->execute([
                ':dead_letter_id' => $id,
                ':replay_queue_job_id' => $replayJobId,
                ':operation_id' => $row['operation_id'],
                ':actor_id' => $actorId,
                ':reason' => 'DLQ item retried',
            ]);

            $this->pdo->commit();
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function resolve(int $id, string $actorId, string $reason): void
    {
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare(
                "UPDATE queue_dead_letters
                 SET error_message = CONCAT('[RESOLVED by ', :actor, '] ', :reason)
                 WHERE id = :id"
            );
            $stmt->execute([
                ':actor' => $actorId,
                ':reason' => $reason,
                ':id' => $id,
            ]);

            $audit = $this->pdo->prepare(
                "INSERT INTO dlq_operation_audit
                    (dead_letter_id, actor_id, action, reason)
                 VALUES
                    (:dead_letter_id, :actor_id, 'resolve', :reason)"
            );
            $audit->execute([
                ':dead_letter_id' => $id,
                ':actor_id' => $actorId,
                ':reason' => $reason,
            ]);

            $this->pdo->commit();
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
}
