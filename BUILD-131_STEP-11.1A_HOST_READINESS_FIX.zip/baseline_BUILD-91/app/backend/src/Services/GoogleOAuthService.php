<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class GoogleOAuthService {
    public function __construct(private array $config) {}

    public function enabled(): bool {
        return trim((string)($this->config['client_id'] ?? '')) !== ''
            && trim((string)($this->config['client_secret'] ?? '')) !== ''
            && trim((string)($this->config['redirect_uri'] ?? '')) !== '';
    }

    public function authorizationUrl(string $state, ?string $redirectUri=null): string {
        $params = [
            'client_id' => $this->config['client_id'],
            'redirect_uri' => $redirectUri ?: $this->config['redirect_uri'],
            'response_type' => 'code',
            'scope' => 'openid email profile',
            'access_type' => 'online',
            'prompt' => 'select_account',
            'state' => $state,
        ];
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }

    public function exchangeCode(string $code, ?string $redirectUri=null): array {
        $body = http_build_query([
            'code' => $code,
            'client_id' => $this->config['client_id'],
            'client_secret' => $this->config['client_secret'],
            'redirect_uri' => $redirectUri ?: $this->config['redirect_uri'],
            'grant_type' => 'authorization_code',
        ], '', '&', PHP_QUERY_RFC3986);
        $token = $this->request('https://oauth2.googleapis.com/token', $body);
        if (empty($token['access_token'])) throw new \RuntimeException('Google không trả về access token.');
        $profile = $this->request('https://openidconnect.googleapis.com/v1/userinfo', null, [
            'Authorization: Bearer ' . $token['access_token'],
        ]);
        if (($profile['sub'] ?? '') === '' || ($profile['email'] ?? '') === '') {
            throw new \RuntimeException('Google không trả về định danh hoặc email hợp lệ.');
        }
        if (isset($profile['email_verified']) && !$profile['email_verified']) {
            throw new \RuntimeException('Email Google chưa được xác minh.');
        }
        return [
            'sub' => (string)$profile['sub'],
            'email' => strtolower(trim((string)$profile['email'])),
            'name' => trim((string)($profile['name'] ?? '')),
            'avatar_url' => trim((string)($profile['picture'] ?? '')),
        ];
    }

    private function request(string $url, ?string $body=null, array $headers=[]): array {
        $method = $body === null ? 'GET' : 'POST';
        $headers[] = 'Accept: application/json';
        if ($body !== null) $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        $context = stream_context_create(['http'=>[
            'method' => $method,
            'header' => implode("\r\n", $headers),
            'content' => $body ?? '',
            'timeout' => 15,
            'ignore_errors' => true,
        ]]);
        $raw = @file_get_contents($url, false, $context);
        if ($raw === false) throw new \RuntimeException('Không thể kết nối Google OAuth.');
        $data = json_decode($raw, true);
        if (!is_array($data)) throw new \RuntimeException('Phản hồi Google OAuth không hợp lệ.');
        if (isset($data['error'])) throw new \RuntimeException('Google OAuth từ chối yêu cầu.');
        return $data;
    }
}
