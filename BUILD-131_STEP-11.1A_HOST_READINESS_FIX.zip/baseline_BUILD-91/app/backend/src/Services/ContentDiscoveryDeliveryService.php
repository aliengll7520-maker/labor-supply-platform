<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

/**
 * BUILD 18 — Website/App Content Delivery contract.
 *
 * Aggregates read-only discovery projections into one delivery envelope for
 * public clients. The source table remains authoritative and every section
 * can be rebuilt independently.
 */
final class ContentDiscoveryDeliveryService
{
    public const VERSION = '18.0.0';

    public function __construct(
        private ContentPublicService $public,
        private ContentUrlService $url,
        private ContentSeoService $seo,
        private ContentStructuredDataService $structuredData,
        private ContentTopicLocationService $taxonomy,
        private ContentTagService $tags,
        private ContentClassificationService $classification,
        private ContentRelatedService $related,
        private ContentRecommendationService $recommendation,
    ) {}

    /** @return array<string,mixed> */
    public function job(int $jobId, array $input = []): array
    {
        if ($jobId <= 0) {
            throw new \InvalidArgumentException('ID Tin tuyển dụng không hợp lệ.');
        }

        $limit = min(20, max(1, (int)($input['limit'] ?? 10)));

        return [
            'version' => self::VERSION,
            'contract' => 'content-delivery',
            'content' => $this->public->publicJob($jobId),
            'canonical' => $this->url->publicJobUrl($jobId),
            'seo' => $this->seo->publicJobSeo($jobId),
            'structured_data' => $this->structuredData->publicJob($jobId),
            'classification' => $this->classification->publicJob($jobId),
            'tags' => $this->tags->publicJob($jobId),
            'taxonomy' => $this->taxonomy->publicJob($jobId),
            'related' => $this->related->relatedJob($jobId, ['limit' => $limit]),
            'recommendations' => $this->recommendation->recommendJob($jobId, ['limit' => $limit]),
            'delivery' => [
                'source_of_truth' => 'tin_tuyen_dung',
                'read_only' => true,
                'client_safe' => true,
                'web' => true,
                'android' => true,
                'ios' => true,
                'cache_key' => 'content:job:' . $jobId,
                'rebuildable' => true,
            ],
        ];
    }
}
