<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class MobileBootstrapService
{
    public function __construct(private array $config = []) {}

    public function versions(): array
    {
        $v = $this->config['versions'] ?? [];
        return [
            'config_version'   => (string)($v['config'] ?? '1'),
            'category_version' => (string)($v['category'] ?? '1'),
            'location_version' => (string)($v['location'] ?? '1'),
            'feature_version'  => (string)($v['feature'] ?? '1'),
        ];
    }

    public function bootstrap(array $session, array $identity): array
    {
        return [
            'server_time' => gmdate('c'),
            'versions' => $this->versions(),
            'session' => [
                'session_id' => (int)$session['id'],
                'role' => (string)$session['role_code'],
                'device_id' => $session['device_id'] !== null ? (string)$session['device_id'] : null,
                'access_expires_at' => $session['access_expires_at'],
                'refresh_expires_at' => $session['refresh_expires_at'],
            ],
            'identity' => $identity,
        ];
    }
}
