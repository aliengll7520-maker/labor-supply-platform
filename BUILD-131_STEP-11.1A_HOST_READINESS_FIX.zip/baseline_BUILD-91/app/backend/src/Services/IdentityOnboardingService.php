<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class IdentityOnboardingService {
    public function __construct(private \PDO $db) {}

    public function refresh(int $identityId): array {
        $q=$this->db->prepare('SELECT id,identity_key,trang_thai,onboarding_status FROM identity_principals WHERE id=? LIMIT 1');
        $q->execute([$identityId]); $identity=$q->fetch();
        if(!$identity) throw new \RuntimeException('Identity không tồn tại.');
        $q=$this->db->prepare('SELECT * FROM identity_role_memberships WHERE identity_id=? ORDER BY id ASC');
        $q->execute([$identityId]); $roles=$q->fetchAll()?:[];
        $results=[];
        foreach($roles as $role){ $results[]=$this->refreshRole($identityId,$role); }
        $status='dang_onboarding';
        foreach($results as $r){ if($r['onboarding_status']==='can_xu_ly'){$status='can_xu_ly';break;} if($r['onboarding_status']==='san_sang')$status='san_sang'; }
        if(!$results && $identity['trang_thai']==='khoa') $status='can_xu_ly';
        $this->db->prepare('UPDATE identity_principals SET onboarding_status=?,ngay_cap_nhat=CURRENT_TIMESTAMP WHERE id=?')->execute([$status,$identityId]);
        return ['identity_id'=>$identityId,'onboarding_status'=>$status,'roles'=>$results];
    }

    public function refreshWorker(int $workerId): array {
        $q=$this->db->prepare('SELECT id FROM identity_principals WHERE identity_key=? LIMIT 1'); $q->execute(['worker:'.$workerId]);
        $id=(int)$q->fetchColumn(); if($id<=0) throw new \RuntimeException('Identity Người lao động chưa được khởi tạo.');
        return $this->refresh($id);
    }

    public function refreshEmployer(int $accountId): array {
        $q=$this->db->prepare('SELECT id FROM identity_principals WHERE identity_key=? LIMIT 1'); $q->execute(['employer:'.$accountId]);
        $id=(int)$q->fetchColumn(); if($id<=0) throw new \RuntimeException('Identity Đơn vị sử dụng lao động chưa được khởi tạo.');
        return $this->refresh($id);
    }

    private function refreshRole(int $identityId,array $role): array {
        $code=(string)$role['role_code']; $status=(string)$role['role_status']; $old=(string)$role['onboarding_status'];
        $steps=[]; $ready=false; $needsAdmin=false;
        if($code==='worker'){
            $steps['account']='completed';
            $q=$this->db->prepare('SELECT n.ho_ten,n.so_dien_thoai,n.trang_thai FROM nguoi_lao_dong n WHERE n.id=? LIMIT 1'); $q->execute([(int)$role['worker_id']]); $w=$q->fetch()?:[];
            $steps['profile']=(!empty($w['ho_ten']) && !empty($w['so_dien_thoai']))?'completed':'pending';
            $steps['phone_verification']=$this->isVerified($identityId,$code,'phone')?'completed':'pending';
            $ready=$status==='active' && $steps['profile']==='completed' && $steps['phone_verification']==='completed' && ($w['trang_thai']??'')==='hoat_dong';
        } elseif($code==='employer'){
            $steps['account']='completed';
            $q=$this->db->prepare('SELECT n.ten_don_vi,n.loai_don_vi,n.nguoi_dai_dien,n.so_dien_thoai,n.email,n.dia_chi,n.google_maps,n.gioi_thieu,n.giay_phep,n.xac_minh,n.trang_thai,a.trang_thai AS account_status FROM nha_cung_ung n JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id WHERE a.id=? LIMIT 1'); $q->execute([(int)$role['supplier_account_id']]); $e=$q->fetch()?:[];
            foreach(['ten_don_vi','loai_don_vi','nguoi_dai_dien','so_dien_thoai','email','dia_chi','google_maps','gioi_thieu','giay_phep'] as $f) $steps['profile_'.$f]=trim((string)($e[$f]??''))!==''?'completed':'pending';
            $profileOk=!in_array('pending',array_values($steps),true);
            $steps['contact_verification']=($this->isVerified($identityId,$code,'phone')||$this->isVerified($identityId,$code,'email'))?'completed':'pending';
            $steps['admin_approval']=($e['xac_minh']??'')==='da_xac_minh' && ($e['trang_thai']??'')==='hoat_dong' && ($e['account_status']??'')==='hoat_dong'?'completed':'pending';
            $needsAdmin=$profileOk && $steps['contact_verification']==='completed' && $steps['admin_approval']==='pending';
            $ready=$status==='active' && $profileOk && $steps['contact_verification']==='completed' && $steps['admin_approval']==='completed';
        } else { $steps['account']='pending'; }
        $new=$ready?'san_sang':($needsAdmin?'can_xu_ly':'dang_onboarding');
        if($status==='blocked') $new='can_xu_ly';
        if($new!==$old) $this->event($identityId,$code,'onboarding.status.'.$new,['previous'=>$old,'steps'=>$steps]);
        $this->db->prepare('UPDATE identity_role_memberships SET onboarding_status=?,ngay_cap_nhat=CURRENT_TIMESTAMP WHERE id=?')->execute([$new,(int)$role['id']]);
        return ['role_code'=>$code,'onboarding_status'=>$new,'steps'=>$steps,'ready'=>$ready,'admin_action_required'=>$needsAdmin];
    }

    private function isVerified(int $identityId,string $role,string $channel): bool {
        $q=$this->db->prepare('SELECT 1 FROM identity_verifications WHERE identity_id=? AND role_code=? AND channel=? AND status="verified" ORDER BY id DESC LIMIT 1');
        $q->execute([$identityId,$role,$channel]); return (bool)$q->fetchColumn();
    }
    private function event(int $identityId,string $role,string $code,array $meta=[]): void {
        $q=$this->db->prepare('INSERT INTO identity_onboarding_events(identity_id,role_code,event_code,event_status,metadata_json) VALUES(?,?,?,"completed",?)');
        $q->execute([$identityId,$role,$code,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    }
}
