<?php
declare(strict_types=1);

namespace Labor\Backend\Services;

use PDO;

final class QueueMetricsService
{
    public function __construct(private PDO $pdo) {}

    public function snapshot(): array
    {
        $sql = <<<SQL
SELECT
    queue_name,
    SUM(status = 'queued') AS queued,
    SUM(status = 'processing') AS processing,
    SUM(status = 'completed') AS completed,
    SUM(status = 'dead') AS dead,
    COALESCE(MAX(TIMESTAMPDIFF(SECOND, created_at, CURRENT_TIMESTAMP) * (status = 'queued')), 0) AS oldest_queued_age_seconds
FROM queue_jobs
GROUP BY queue_name
ORDER BY queue_name
SQL;
        return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function alerts(): array
    {
        $alerts = [];
        foreach ($this->snapshot() as $row) {
            $lag = (int)$row['oldest_queued_age_seconds'];
            $dead = (int)$row['dead'];
            $queued = (int)$row['queued'];

            if ($lag >= 300) {
                $alerts[] = [
                    'severity' => 'critical',
                    'type' => 'queue_lag',
                    'queue' => $row['queue_name'],
                    'value' => $lag,
                    'message' => 'Queue lag is at least 5 minutes',
                ];
            } elseif ($lag >= 30) {
                $alerts[] = [
                    'severity' => 'warning',
                    'type' => 'queue_lag',
                    'queue' => $row['queue_name'],
                    'value' => $lag,
                    'message' => 'Queue lag is at least 30 seconds',
                ];
            }

            if ($dead > 0) {
                $alerts[] = [
                    'severity' => 'critical',
                    'type' => 'dead_letters',
                    'queue' => $row['queue_name'],
                    'value' => $dead,
                    'message' => 'Dead-letter messages exist',
                ];
            }

            if ($queued >= 1000) {
                $alerts[] = [
                    'severity' => 'critical',
                    'type' => 'queue_depth',
                    'queue' => $row['queue_name'],
                    'value' => $queued,
                    'message' => 'Queue depth is at least 1000',
                ];
            }
        }
        return $alerts;
    }
}
