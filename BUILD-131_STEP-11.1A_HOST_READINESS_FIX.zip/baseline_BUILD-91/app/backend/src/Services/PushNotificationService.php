<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

use Labor\Backend\Services\FcmDeliveryMetricsService;

final class PushNotificationService
{
    private ?FcmDeliveryMetricsService $deliveryMetrics = null;

    public function setDeliveryMetrics(FcmDeliveryMetricsService $metrics): void
    {
        $this->deliveryMetrics = $metrics;
    }

    public function __construct(
        private \PDO $db,
        private array $config = [],
        FcmDeliveryMetricsService $deliveryMetrics
    ) {
        $this->deliveryMetrics = $deliveryMetrics;
    }

    public function registerWorkerToken(int $workerId,string $token,string $platform): void
    {
        if($workerId<=0) throw new \InvalidArgumentException('Người lao động không hợp lệ.');
        $token=trim($token); if($token===''||mb_strlen($token)>4096) throw new \InvalidArgumentException('Push token không hợp lệ.');
        if(!in_array($platform,['android','ios','web'],true)) throw new \InvalidArgumentException('Nền tảng không hợp lệ.');
        $q=$this->db->prepare('INSERT INTO nguoi_lao_dong_push_token (nguoi_lao_dong_id,push_token,nen_tang,trang_thai) VALUES (?,?,?,"hoat_dong") ON DUPLICATE KEY UPDATE nen_tang=VALUES(nen_tang),trang_thai="hoat_dong",ngay_cap_nhat=CURRENT_TIMESTAMP');
        $q->execute([$workerId,$token,$platform]);
    }

    public function sendToWorker(int $workerId,string $title,string $body,array $data=[]): array
    {
        $q=$this->db->prepare('SELECT id,push_token FROM nguoi_lao_dong_push_token WHERE nguoi_lao_dong_id=? AND trang_thai="hoat_dong"');
        $q->execute([$workerId]); $rows=$q->fetchAll(); if(!$rows) return [];
        $sent=0; $errors=[];
        foreach($rows as $row){
            $result=$this->sendFcm((string)$row['push_token'],$title,$body,$data);
            if($result['ok']) $sent++; else { $errors[]=$result['error']; if(($result['invalid']??false)) $this->disableToken((int)$row['id']); }
        }
        return ['sent'=>$sent,'errors'=>$errors,'provider'=>'fcm'];
    }

    private function sendFcm(string $token,string $title,string $body,array $data): array
    {
        $project=(string)($this->config['project_id']??''); $client=(string)($this->config['client_email']??''); $key=(string)($this->config['private_key']??'');
        if($project===''||$client===''||$key==='') return ['ok'=>false,'error'=>'FCM chưa được cấu hình.'];
        $access=$this->accessToken($client,$key); if($access==='') return ['ok'=>false,'error'=>'Không lấy được FCM access token.'];
        $payload=['message'=>['token'=>$token,'notification'=>['title'=>$title,'body'=>$body],'data'=>array_map('strval',$data)]];
        $ch=curl_init('https://fcm.googleapis.com/v1/projects/'.rawurlencode($project).'/messages:send');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $access,
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        
        $deliveryKey = (string)($data['delivery_key'] ?? $data['deliveryKey'] ?? hash('sha256', $token . '|' . $title . '|' . json_encode($data)));
        if ($this->deliveryMetrics) {
            $this->deliveryMetrics->record($deliveryKey, 'sent_to_fcm', null, null, null, $fcmLatencyMs);
        }

$fcmStarted = microtime(true);
$response=curl_exec($ch);
$fcmLatencyMs = (int)round((microtime(true) - $fcmStarted) * 1000);

        /* HTTP_FCM_STATUS_CLASSIFICATION */
        if ($this->deliveryMetrics && $response !== false) {
            $httpStatus = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $decodedResponse = json_decode((string)$response, true);
            $fcmStatus = (string)($decodedResponse['error']['status'] ?? '');
            $fcmMessage = (string)($decodedResponse['error']['message'] ?? '');

            if ($httpStatus >= 200 && $httpStatus < 300) {
                $this->deliveryMetrics->record($deliveryKey, 'accepted', null, null, null, $fcmLatencyMs);
            } elseif ($fcmStatus === 'UNREGISTERED') {
                $this->deliveryMetrics->record(
                    $deliveryKey,
                    'invalid_token',
                    null,
                    $fcmStatus,
                    $fcmMessage !== '' ? $fcmMessage : 'FCM token is no longer registered',
                    $fcmLatencyMs
                );
            } else {
                // HTTP 400/404 are not automatically token failures; malformed
                // payloads and other provider errors must remain retry/alertable.
                $this->deliveryMetrics->record(
                    $deliveryKey,
                    'failed',
                    null,
                    $fcmStatus !== '' ? $fcmStatus : (string)$httpStatus,
                    $fcmMessage !== '' ? $fcmMessage : 'FCM HTTP request failed',
                    $fcmLatencyMs
                );
            }
        }


        if ($this->deliveryMetrics) {
            if ($response === false) {
                $this->deliveryMetrics->record(
                    $deliveryKey,
                    'failed',
                    null,
                    'curl_error',
                    curl_error($ch),
                    $fcmLatencyMs
                );
            }
        }
 $error=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if($response===false||$error!=='') return ['ok'=>false,'error'=>$error?:'FCM request failed.'];
        if($code>=200&&$code<300) return ['ok'=>true];
        $decoded=json_decode($response,true); $status=(string)($decoded['error']['status']??''); $message=(string)($decoded['error']['message']??'FCM request failed.');
        return ['ok'=>false,'error'=>$message,'invalid'=>$status==='UNREGISTERED'];
    }

    private function accessToken(string $client,string $privateKey): string
    {
        $cacheKey='labor:fcm:oauth:'.sha1($client);
        if(function_exists('apcu_fetch')){
            $cached=apcu_fetch($cacheKey,$hit);
            if($hit && is_string($cached) && $cached!=='') return $cached;
        }
        $now=time(); $header=$this->b64(['alg'=>'RS256','typ'=>'JWT']); $claim=$this->b64(['iss'=>$client,'scope'=>'https://www.googleapis.com/auth/firebase.messaging','aud'=>'https://oauth2.googleapis.com/token','iat'=>$now,'exp'=>$now+3600]);
        $unsigned=$header.'.'.$claim; $signature=''; if(!openssl_sign($unsigned,$signature,$privateKey,OPENSSL_ALGO_SHA256)) return '';
        $assertion=$unsigned.'.'.$this->b64($signature); $ch=curl_init('https://oauth2.googleapis.com/token');
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query(['grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer','assertion'=>$assertion]),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>10,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
        $response=curl_exec($ch); curl_close($ch); $decoded=json_decode((string)$response,true); $token=(string)($decoded['access_token']??'');
        if($token!=='' && function_exists('apcu_store')) apcu_store($cacheKey,$token,3300);
        return $token;
    }
    private function b64($value): string { $raw=is_string($value)?$value:json_encode($value,JSON_UNESCAPED_SLASHES); return rtrim(strtr(base64_encode((string)$raw),'+/','-_'),'='); }
    private function disableToken(int $id): void { $q=$this->db->prepare('UPDATE nguoi_lao_dong_push_token SET trang_thai="vo_hieu" WHERE id=?'); $q->execute([$id]); }
}
