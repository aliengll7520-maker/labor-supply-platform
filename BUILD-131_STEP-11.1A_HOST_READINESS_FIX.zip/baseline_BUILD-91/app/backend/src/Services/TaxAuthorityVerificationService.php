<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class TaxAuthorityVerificationService {
    public function __construct(private array $config = []) {}

    public function verify(string $taxCode): array {
        $taxCode = $this->normalize($taxCode);
        if (!preg_match('/^\d{10}(?:\d{3})?$/', $taxCode)) {
            return ['ok'=>false,'status'=>'invalid_format','tax_code'=>$taxCode,'message'=>'Mã số thuế phải gồm 10 hoặc 13 chữ số.'];
        }

        if (!(bool)($this->config['enabled'] ?? false)) {
            return ['ok'=>false,'status'=>'provider_not_configured','tax_code'=>$taxCode,'message'=>'Chưa cấu hình dịch vụ xác thực Mã số thuế.'];
        }
        $endpoint=trim((string)($this->config['endpoint'] ?? ''));
        if ($endpoint==='') {
            return ['ok'=>false,'status'=>'provider_not_configured','tax_code'=>$taxCode,'message'=>'Chưa cấu hình endpoint xác thực Mã số thuế.'];
        }

        $payload=['tax_code'=>$taxCode,'ma_so_thue'=>$taxCode];
        $headers=['Content-Type: application/json','Accept: application/json'];
        $token=trim((string)($this->config['token'] ?? ''));
        if ($token!=='') $headers[]='Authorization: Bearer '.$token;
        $timeout=max(2,(int)($this->config['timeout_seconds'] ?? 8));

        $ch=curl_init($endpoint);
        if ($ch===false) return ['ok'=>false,'status'=>'transport_error','tax_code'=>$taxCode,'message'=>'Không khởi tạo được kết nối xác thực Mã số thuế.'];
        curl_setopt_array($ch,[
            CURLOPT_POST=>true,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CONNECTTIMEOUT=>$timeout,
            CURLOPT_TIMEOUT=>$timeout,
            CURLOPT_HTTPHEADER=>$headers,
            CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
        ]);
        $body=curl_exec($ch); $errno=curl_errno($ch); $error=curl_error($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if ($errno!==0 || !is_string($body) || $http<200 || $http>=300) {
            return ['ok'=>false,'status'=>'provider_unavailable','tax_code'=>$taxCode,'message'=>'Không thể xác thực Mã số thuế lúc này.','http_status'=>$http];
        }
        $responseHash=hash('sha256',$body);
        $data=json_decode($body,true);
        if (!is_array($data)) return ['ok'=>false,'status'=>'provider_invalid_response','tax_code'=>$taxCode,'message'=>'Dịch vụ xác thực trả về dữ liệu không hợp lệ.','response_hash'=>$responseHash];

        $providerRequestId=trim((string)($data['request_id'] ?? $data['requestId'] ?? $data['transaction_id'] ?? $data['trace_id'] ?? ''));
        $evidence=['verified_at'=>gmdate('Y-m-d H:i:s'),'provider_request_id'=>$providerRequestId,'response_hash'=>$responseHash,'source'=>'tax_authority_adapter'];
        $found=(bool)($data['found'] ?? $data['exists'] ?? $data['valid'] ?? false);
        $rawStatus=strtolower(trim((string)($data['status'] ?? $data['tax_status'] ?? $data['trang_thai'] ?? '')));
        $active=in_array($rawStatus,['active','operating','hoat_dong','dang_hoat_dong','đang hoạt động'],true);
        $normalizedStatus=$active?'active':($rawStatus!==''?$rawStatus:($found?'unknown':'not_found'));
        $name=trim((string)($data['name'] ?? $data['taxpayer_name'] ?? $data['ten_nguoi_nop_thue'] ?? ''));
        if (!$found) return ['ok'=>false,'status'=>'not_found','tax_code'=>$taxCode,'message'=>'Mã số thuế không tồn tại hoặc không được cơ quan xác thực xác nhận.','provider_status'=>$normalizedStatus,'verification_evidence'=>$evidence];
        if (!$active) return ['ok'=>false,'status'=>'not_active','tax_code'=>$taxCode,'message'=>'Mã số thuế không ở trạng thái đang hoạt động.','provider_status'=>$normalizedStatus,'name'=>$name,'verification_evidence'=>$evidence];
        return ['ok'=>true,'status'=>'active','tax_code'=>$taxCode,'provider_status'=>'active','name'=>$name,'message'=>'Mã số thuế hợp lệ và đang hoạt động.','verification_evidence'=>$evidence];
    }

    public function normalize(string $value): string { return preg_replace('/\D+/', '', trim($value)) ?? ''; }
}
