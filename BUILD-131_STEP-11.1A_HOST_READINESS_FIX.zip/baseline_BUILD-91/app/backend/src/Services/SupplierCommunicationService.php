<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

use LaborPlatform\Queue\QueueService;

final class SupplierCommunicationService
{
    public function __construct(private \PDO $db, private ?QueueService $queue = null) {}

    /** BUILD 109: create the communication record and enqueue delivery. */
    public function sendInitialSms(int $registrationId): array
    {
        $r = $this->loadRegistration($registrationId);
        $message = $this->buildInitialSms($r);

        $existing = $this->db->prepare('SELECT * FROM lien_he_tu_dong_nguoi_lao_dong WHERE dang_ky_ho_so_phong_van_id=? AND kenh="sms" AND loai="tin_nhan_dau_tien" ORDER BY id DESC LIMIT 1');
        $existing->execute([$registrationId]);
        if ($old = $existing->fetch()) return $old;

        if (!$this->queue) {
            throw new \RuntimeException('Queue thông báo chưa được khởi tạo.');
        }

        $i = $this->db->prepare('INSERT INTO lien_he_tu_dong_nguoi_lao_dong (dang_ky_ho_so_phong_van_id,nha_cung_ung_id,kenh,loai,so_dien_thoai_dich,noi_dung,trang_thai,ma_nha_cung_cap) VALUES (?,? ,"sms","tin_nhan_dau_tien",?,?,"cho_gui",NULL)');
        $i->execute([$registrationId, $r['nha_cung_ung_id'], $r['so_dien_thoai'], $message]);
        $id = (int)$this->db->lastInsertId();

        try {
            $this->queue->enqueue(
                'notifications',
                'supplier.sms_initial',
                ['communication_id' => $id, 'registration_id' => $registrationId],
                180,
                'supplier-sms-initial:'.$registrationId,
                5
            );
        } catch (\Throwable $e) {
            $this->db->prepare('UPDATE lien_he_tu_dong_nguoi_lao_dong SET trang_thai="cho_nha_cung_cap" WHERE id=?')->execute([$id]);
            throw $e;
        }

        $q = $this->db->prepare('SELECT * FROM lien_he_tu_dong_nguoi_lao_dong WHERE id=?');
        $q->execute([$id]);
        return $q->fetch() ?: [];
    }

    /** BUILD 109 worker handler: deliver an already-created SMS record. */
    public function deliverInitialSms(int $communicationId): array
    {
        $q = $this->db->prepare('SELECT c.*,h.id AS registration_id,h.so_dien_thoai,h.nha_cung_ung_id FROM lien_he_tu_dong_nguoi_lao_dong c JOIN dang_ky_ho_so_phong_van h ON h.id=c.dang_ky_ho_so_phong_van_id WHERE c.id=? AND c.kenh="sms" AND c.loai="tin_nhan_dau_tien" LIMIT 1');
        $q->execute([$communicationId]);
        $c = $q->fetch();
        if (!$c) return ['status'=>'missing'];
        if (in_array((string)$c['trang_thai'], ['da_gui','da_phan_hoi'], true)) return ['status'=>(string)$c['trang_thai']];

        $provider = getenv('LABOR_SMS_PROVIDER') ?: 'queue';
        if ($provider === 'queue') {
            $this->db->prepare('UPDATE lien_he_tu_dong_nguoi_lao_dong SET trang_thai="cho_nha_cung_cap" WHERE id=?')->execute([$communicationId]);
            throw new \RuntimeException('SMS provider chưa được cấu hình.');
        }

        $endpoint = getenv('LABOR_SMS_ENDPOINT') ?: '';
        $token = getenv('LABOR_SMS_TOKEN') ?: '';
        if ($endpoint === '' || !function_exists('curl_init')) throw new \RuntimeException('SMS provider chưa được cấu hình.');

        $payload = json_encode([
            'to' => $c['so_dien_thoai_dich'],
            'message' => $c['noi_dung'],
            'sender' => getenv('LABOR_SMS_SENDER') ?: 'LABOR',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $headers = array_filter(['Content-Type: application/json', $token !== '' ? 'Authorization: Bearer '.$token : null]);
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$payload,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>15]);
        $body = curl_exec($ch);
        $http = (int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($body === false || $error !== '') throw new \RuntimeException($error ?: 'Không gửi được SMS.');
        if ($http < 200 || $http >= 300) throw new \RuntimeException('SMS provider trả về HTTP '.$http.'.');

        $this->db->prepare('UPDATE lien_he_tu_dong_nguoi_lao_dong SET trang_thai="da_gui",ma_nha_cung_cap=? WHERE id=?')->execute([mb_substr((string)$body,0,1000),$communicationId]);
        return ['status'=>'da_gui','http_status'=>$http];
    }

    private function loadRegistration(int $registrationId): array
    {
        $q=$this->db->prepare('SELECT h.id,h.ma_ho_so,h.ho_ten,h.so_dien_thoai,h.nha_cung_ung_id,t.tieu_de,t.ma_tin,n.ten_nha_cung_ung,n.sms_mau_tin_dau_tien FROM dang_ky_ho_so_phong_van h JOIN tin_tuyen_dung t ON t.id=h.tin_tuyen_dung_id JOIN nha_cung_ung n ON n.id=h.nha_cung_ung_id WHERE h.id=? LIMIT 1');
        $q->execute([$registrationId]);
        $r=$q->fetch();
        if(!$r) throw new \RuntimeException('Không tìm thấy hồ sơ để gửi SMS.');
        return $r;
    }

    private function buildInitialSms(array $r): string
    {
        $message=trim((string)($r['sms_mau_tin_dau_tien']??''));
        if($message==='') $message='Xin chao [TEN_NGUOI_LAO_DONG]. Ho so [MA_HO_SO] cua ban da duoc [TEN_NHA_CUNG_UNG] tiep nhan cho vi tri [TEN_TIN]. Vui long phan hoi tin nhan nay neu ban van quan tam de chung toi lien he.';
        return strtr($message,[
            '[TEN_NGUOI_LAO_DONG]'=>$r['ho_ten'],
            '[MA_HO_SO]'=>$r['ma_ho_so'],
            '[TEN_NHA_CUNG_UNG]'=>$r['ten_nha_cung_ung'],
            '[TEN_TIN]'=>$r['tieu_de'],
            '[MA_TIN]'=>$r['ma_tin']
        ]);
    }

    public function markSmsReply(string $phone,string $reply,string $providerMessageId=''): array
    {
        $q=$this->db->prepare('SELECT id,dang_ky_ho_so_phong_van_id FROM lien_he_tu_dong_nguoi_lao_dong WHERE kenh="sms" AND loai="tin_nhan_dau_tien" AND so_dien_thoai_dich=? ORDER BY id DESC LIMIT 1');
        $q->execute([$phone]);
        $row=$q->fetch();
        if(!$row) throw new \RuntimeException('Không tìm thấy SMS đang chờ phản hồi.');
        $this->db->prepare('UPDATE lien_he_tu_dong_nguoi_lao_dong SET trang_thai="da_phan_hoi",phan_hoi_noi_dung=?,phan_hoi_at=NOW(),ma_nha_cung_cap=COALESCE(NULLIF(? ,""),ma_nha_cung_cap) WHERE id=?')->execute([$reply,$providerMessageId,$row['id']]);
        $this->db->prepare('UPDATE dang_ky_ho_so_phong_van SET nguoi_lao_dong_da_phan_hoi=1,nguoi_lao_dong_phan_hoi_at=NOW(),nguoi_lao_dong_xac_nhan=1,ngay_cap_nhat=NOW() WHERE id=?')->execute([$row['dang_ky_ho_so_phong_van_id']]);
        return ['registration_id'=>(int)$row['dang_ky_ho_so_phong_van_id'],'trang_thai'=>'da_phan_hoi'];
    }

    public function requestMaskedCall(int $registrationId,int $supplierId): array
    {
        $q=$this->db->prepare('SELECT id,nguoi_lao_dong_id,nha_cung_ung_id,nguoi_lao_dong_da_phan_hoi FROM dang_ky_ho_so_phong_van WHERE id=? AND nha_cung_ung_id=? LIMIT 1');
        $q->execute([$registrationId,$supplierId]);
        $r=$q->fetch();
        if(!$r) throw new \RuntimeException('Không tìm thấy hồ sơ liên hệ.');
        if((int)$r['nguoi_lao_dong_da_phan_hoi']!==1) throw new \RuntimeException('Người lao động chưa phản hồi SMS đầu tiên. Chưa được phép gọi trực tiếp.');
        $i=$this->db->prepare('INSERT INTO phien_goi_trung_gian (dang_ky_ho_so_phong_van_id,nha_cung_ung_id,nguoi_lao_dong_id,trang_thai) VALUES (?,?,?,"tao_moi")');
        $i->execute([$registrationId,$supplierId,$r['nguoi_lao_dong_id']]);
        $id=(int)$this->db->lastInsertId();
        return ['phien_goi_id'=>$id,'trang_thai'=>'tao_moi','thong_bao'=>'Yêu cầu gọi trung gian đã được tạo. Cần cấu hình nhà cung cấp thoại masked-call để thực hiện cuộc gọi thật.'];
    }
}
