<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

use LaborPlatform\Queue\QueueService;

final class JobMatchingService
{
    public function __construct(private \PDO $db, private QueueService $queue) {}

    public function enqueueForWorkerPost(int $postId): void
    {
        if($postId<=0) return;
        $this->queue->enqueue('matching','matching.worker_post',['post_id'=>$postId],100,'matching-worker-post:'.$postId);
    }

    public function enqueueForJob(int $jobId): void
    {
        if($jobId<=0) return;
        $this->queue->enqueue('matching','matching.job',['job_id'=>$jobId],100,'matching-job:'.$jobId);
    }

    public function matchWorkerPost(int $postId,int $limit=100): int
    {
        $q=$this->db->prepare('SELECT * FROM tin_tim_viec_nguoi_lao_dong WHERE id=? AND trang_thai="dang_hien" LIMIT 1');
        $q->execute([$postId]); $post=$q->fetch(); if(!$post) return 0;
        $terms=$this->terms(implode(' ',array_filter([$post['tieu_de'],$post['vi_tri_mong_muon'],$post['ky_nang'],$post['kinh_nghiem'],$post['dia_diem_mong_muon'],$post['hinh_thuc_lam_viec'],$post['ca_lam_mong_muon']])));
        if(!$terms) return 0;

        $where=['j.trang_thai="dang_tuyen"','(j.ngay_het_han IS NULL OR j.ngay_het_han>NOW())'];
        $params=[];
        $parts=[];
        foreach(array_slice($terms,0,8) as $term){
            $parts[]='(j.tieu_de LIKE ? OR j.nganh_nghe LIKE ? OR j.dia_diem LIKE ? OR j.dieu_kien_tuyen_dung LIKE ? OR j.mo_ta_cong_viec LIKE ?)';
            for($i=0;$i<5;$i++) $params[]='%'.$term.'%';
        }
        if($parts) $where[]='('.implode(' OR ',$parts).')';
        $sql='SELECT j.id,j.nha_cung_ung_id,j.tieu_de,j.nganh_nghe,j.dia_diem,j.dieu_kien_tuyen_dung,j.mo_ta_cong_viec FROM tin_tuyen_dung j WHERE '.implode(' AND ',$where).' ORDER BY j.ngay_cap_nhat DESC,j.id DESC LIMIT '.max(1,min(300,$limit));
        $s=$this->db->prepare($sql);$s->execute($params);$jobs=$s->fetchAll();$count=0;
        foreach($jobs as $job){
            $score=$this->score($terms,$this->terms(implode(' ',array_filter([$job['tieu_de'],$job['nganh_nghe'],$job['dia_diem'],$job['dieu_kien_tuyen_dung'],$job['mo_ta_cong_viec']]))));
            if($score<15) continue;
            $reasons=$this->reasons($post,$job,$score);
            $this->upsert((int)$postId,(int)$job['id'],(int)$job['nha_cung_ung_id'],$score,$reasons);
            $count++;
        }
        return $count;
    }

    public function matchJob(int $jobId,int $limit=100): int
    {
        $q=$this->db->prepare('SELECT * FROM tin_tuyen_dung WHERE id=? AND trang_thai="dang_tuyen" LIMIT 1');
        $q->execute([$jobId]);$job=$q->fetch();if(!$job)return 0;
        $terms=$this->terms(implode(' ',array_filter([$job['tieu_de'],$job['nganh_nghe'],$job['dia_diem'],$job['dieu_kien_tuyen_dung'],$job['mo_ta_cong_viec']])));
        if(!$terms)return 0;
        $where=['p.trang_thai="dang_hien"'];$params=[];$parts=[];
        foreach(array_slice($terms,0,8) as $term){
            $parts[]='(p.tieu_de LIKE ? OR p.vi_tri_mong_muon LIKE ? OR p.ky_nang LIKE ? OR p.kinh_nghiem LIKE ? OR p.dia_diem_mong_muon LIKE ?)';
            for($i=0;$i<5;$i++)$params[]='%'.$term.'%';
        }
        $where[]='('.implode(' OR ',$parts).')';
        $sql='SELECT p.id,p.nguoi_lao_dong_id,p.tieu_de,p.vi_tri_mong_muon,p.ky_nang,p.kinh_nghiem,p.dia_diem_mong_muon FROM tin_tim_viec_nguoi_lao_dong p WHERE '.implode(' AND ',$where).' ORDER BY p.ngay_cap_nhat DESC,p.id DESC LIMIT '.max(1,min(300,$limit));
        $s=$this->db->prepare($sql);$s->execute($params);$posts=$s->fetchAll();$count=0;
        foreach($posts as $post){
            $score=$this->score($terms,$this->terms(implode(' ',array_filter([$post['tieu_de'],$post['vi_tri_mong_muon'],$post['ky_nang'],$post['kinh_nghiem'],$post['dia_diem_mong_muon']]))));
            if($score<15)continue;
            $this->upsert((int)$post['id'],(int)$jobId,(int)$job['nha_cung_ung_id'],$score,$this->reasons($post,$job,$score));
            $count++;
        }
        return $count;
    }

    public function workerMatches(int $workerId,int $limit=30): array
    {
        $limit=max(1,min(100,$limit));
        $q=$this->db->prepare('SELECT m.job_id,m.score,m.reasons,j.tieu_de,j.nganh_nghe,j.dia_diem,j.ngay_het_han FROM job_match_suggestions m JOIN tin_tuyen_dung j ON j.id=m.job_id WHERE m.worker_id=? AND m.status="suggested" AND j.trang_thai="dang_tuyen" ORDER BY m.score DESC,m.updated_at DESC LIMIT '.$limit);
        $q->execute([$workerId]);
        $rows=$q->fetchAll();
        foreach($rows as &$row){
            if(is_string($row['reasons']??null)){
                $decoded=json_decode($row['reasons'],true);
                $row['reasons']=is_array($decoded)?$decoded:[];
            }
        }
        return $rows;
    }

    private function upsert(int $postId,int $jobId,int $supplierId,int $score,array $reasons): void
    {
        $worker=$this->db->prepare('SELECT nguoi_lao_dong_id FROM tin_tim_viec_nguoi_lao_dong WHERE id=?');$worker->execute([$postId]);$workerId=(int)$worker->fetchColumn();
        if($workerId<=0)return;
        $q=$this->db->prepare('INSERT INTO job_match_suggestions (worker_id,worker_post_id,job_id,supplier_id,score,reasons,status,created_at,updated_at) VALUES (?,?,?,?,?,?,"suggested",CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE score=VALUES(score),reasons=VALUES(reasons),supplier_id=VALUES(supplier_id),status=IF(status="dismissed","dismissed","suggested"),updated_at=CURRENT_TIMESTAMP');
        $q->execute([$workerId,$postId,$jobId,$supplierId,$score,json_encode($reasons,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    }

    private function terms(string $text): array
    {
        $text=mb_strtolower($text,'UTF-8');
        $text=preg_replace('/[^\p{L}\p{N}]+/u',' ',$text)??'';
        $stop=['và','cho','cần','tại','có','làm','việc','người','lao','động','the','a','an'];
        $out=[];foreach(preg_split('/\s+/u',trim($text)) as $t){if(mb_strlen($t,'UTF-8')<3||in_array($t,$stop,true))continue;$out[$t]=true;}
        return array_keys($out);
    }

    private function score(array $a,array $b): int
    {
        if(!$a||!$b)return 0;$set=array_fill_keys($b,true);$hits=0;foreach($a as $t)if(isset($set[$t]))$hits++;
        return (int)min(100,round(($hits/max(count($a),1))*100));
    }

    private function reasons(array $a,array $b,int $score): array
    {
        $reasons=[];
        if($score>=50)$reasons[]='Nhiều từ khóa nghề nghiệp/kỹ năng phù hợp';
        if(!empty($a['dia_diem_mong_muon'])&&!empty($b['dia_diem'])&&mb_stripos((string)$b['dia_diem'],(string)$a['dia_diem_mong_muon'])!==false)$reasons[]='Khu vực phù hợp';
        if(!$reasons)$reasons[]='Có từ khóa tương đồng';
        return $reasons;
    }
}
