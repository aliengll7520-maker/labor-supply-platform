<?php
declare(strict_types=1);

namespace Labor\Backend\Services;

use PDO;
use RuntimeException;

/**
 * Records server-side FCM delivery lifecycle telemetry.
 *
 * States:
 * queued -> sent_to_fcm -> accepted | failed | invalid_token
 *
 * "delivered_to_device" is only recorded when a trusted downstream signal
 * exists; an FCM HTTP 200/accepted response alone is never treated as
 * device delivery.
 */
final class FcmDeliveryMetricsService
{
    public function __construct(private PDO $pdo) {}

    public function record(
        string $deliveryKey,
        string $status,
        ?string $messageId = null,
        ?string $errorCode = null,
        ?string $errorMessage = null,
        ?int $latencyMs = null
    ): void {
        $allowed = [
            'queued', 'sent_to_fcm', 'accepted', 'failed',
            'invalid_token', 'delivery_unknown', 'delivered_to_device'
        ];

        if (!in_array($status, $allowed, true)) {
            throw new RuntimeException('Invalid FCM delivery status');
        }

        $sql = <<<SQL
INSERT INTO fcm_delivery_metrics
    (delivery_key, status, message_id, error_code, error_message, latency_ms, occurred_at)
VALUES
    (:delivery_key, :status, :message_id, :error_code, :error_message, :latency_ms, CURRENT_TIMESTAMP)
ON DUPLICATE KEY UPDATE
    status = VALUES(status),
    message_id = COALESCE(VALUES(message_id), message_id),
    error_code = VALUES(error_code),
    error_message = VALUES(error_message),
    latency_ms = COALESCE(VALUES(latency_ms), latency_ms),
    occurred_at = CURRENT_TIMESTAMP
SQL;

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':delivery_key' => $deliveryKey,
            ':status' => $status,
            ':message_id' => $messageId,
            ':error_code' => $errorCode,
            ':error_message' => $errorMessage,
            ':latency_ms' => $latencyMs !== null ? max(0, $latencyMs) : null,
        ]);
    }

    public function summary(int $minutes = 15): array
    {
        $minutes = max(1, min($minutes, 1440));
        $stmt = $this->pdo->prepare(
            "SELECT status, COUNT(*) AS total
             FROM fcm_delivery_metrics
             WHERE occurred_at >= (CURRENT_TIMESTAMP - INTERVAL :minutes MINUTE)
             GROUP BY status"
        );
        $stmt->bindValue(':minutes', $minutes, PDO::PARAM_INT);
        $stmt->execute();

        $out = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $out[$row['status']] = (int)$row['total'];
        }
        return $out;
    }
}
