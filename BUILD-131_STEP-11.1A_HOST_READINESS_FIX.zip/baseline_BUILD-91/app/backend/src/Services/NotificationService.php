<?php
declare(strict_types=1);

namespace LaborPlatform\Services;

final class NotificationService {
    private const TYPES = [
        'ho_so_moi',
        'cap_nhat_trang_thai',
        'diem_minh_bach',
        'phan_anh',
        'he_thong',
        'nhac_viec',
        'social_like',
        'social_comment',
        'social_share',
        'social_follow',
        'social_message',
    ];

    public function __construct(private \PDO $db) {}

    public function worker(
        int $workerId,
        string $title,
        string $content,
        string $type,
        ?int $applicationRegistrationId = null
    ): void {
        $this->insert(
            'nguoi_lao_dong',
            $workerId,
            $title,
            $content,
            $type,
            $applicationRegistrationId
        );
    }

    public function supplier(
        int $supplierId,
        string $title,
        string $content,
        string $type,
        ?int $applicationRegistrationId = null
    ): void {
        $this->insert(
            'nha_cung_ung',
            $supplierId,
            $title,
            $content,
            $type,
            $applicationRegistrationId
        );
    }

    /**
     * Ghi thông báo bằng chính PDO connection hiện tại.
     * Không tự mở/commit/rollback transaction; caller chịu trách nhiệm
     * để thông báo có thể rollback cùng nghiệp vụ chính.
     */
    private function insert(
        string $recipientType,
        int $recipientId,
        string $title,
        string $content,
        string $type,
        ?int $applicationRegistrationId
    ): void {
        if (!in_array($recipientType, ['nha_cung_ung', 'nguoi_lao_dong'], true)) {
            throw new \InvalidArgumentException('Đối tượng nhận thông báo không hợp lệ.');
        }

        if ($recipientId <= 0) {
            throw new \InvalidArgumentException('ID người nhận thông báo không hợp lệ.');
        }

        if ($applicationRegistrationId !== null && $applicationRegistrationId <= 0) {
            throw new \InvalidArgumentException('ID Đăng ký hồ sơ không hợp lệ.');
        }

        $title = trim($title);
        $content = trim($content);

        if ($title === '' || mb_strlen($title) > 255) {
            throw new \InvalidArgumentException('Tiêu đề thông báo không hợp lệ.');
        }

        if ($content === '') {
            throw new \InvalidArgumentException('Nội dung thông báo không được để trống.');
        }

        if (!in_array($type, self::TYPES, true)) {
            throw new \InvalidArgumentException('Loại thông báo không hợp lệ.');
        }

        $stmt = $this->db->prepare(
            'INSERT INTO thong_bao
            (
                ma_thong_bao,
                doi_tuong,
                doi_tuong_id,
                dang_ky_ho_so_phong_van_id,
                tieu_de,
                noi_dung,
                loai
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)'
        );

        $stmt->execute([
            $this->makeNotificationId(),
            $recipientType,
            $recipientId,
            $applicationRegistrationId,
            $title,
            $content,
            $type
        ]);
    }

    private function makeNotificationId(): string {
        return 'TB' . date('YmdHis') . bin2hex(random_bytes(3));
    }
}
