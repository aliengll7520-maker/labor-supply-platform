<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

final class PhoneMaskService
{
    public static function mask(?string $phone): ?string
    {
        $phone=trim((string)$phone);
        if($phone==='') return null;
        $digits=preg_replace('/\D+/','',$phone) ?? '';
        if(strlen($digits)<=7) return str_repeat('*',strlen($digits));
        return substr($digits,0,3).'***'.substr($digits,-4);
    }
}
