<?php
declare(strict_types=1);
namespace LaborPlatform\Services;

use LaborPlatform\Core\Response;

final class ContentSafetyService
{
    public const VERSION = '1.0.0';

    /**
     * User-generated public text must not contain external links or full phone numbers.
     * System-generated internal links are outside this validator because they never pass
     * through user-authored text fields.
     */
    public static function assertSafe(string $text, string $field='nội dung'): void
    {
        $text=trim($text);
        if($text==='') return;
        if(self::containsExternalLink($text)) {
            Response::error("$field không được chứa liên kết bên ngoài App Website. Vui lòng xóa liên kết và thử lại.",422);
        }
        if(self::containsPhoneNumber($text)) {
            Response::error("$field không được chứa số điện thoại đầy đủ hoặc biến thể dùng để né cơ chế bảo vệ.",422);
        }
    }

    public static function containsExternalLink(string $text): bool
    {
        $t=function_exists('mb_strtolower') ? mb_strtolower($text) : strtolower($text);
        // Protocols, www, common domains and shortened links.
        if(preg_match('~(?:https?|ftp)\s*:\s*//|www\s*\.\s*[a-z0-9-]+\s*\.[a-z]{2,}|\b[a-z0-9-]+(?:\s*\.\s*[a-z0-9-]+)+\s*\.[a-z]{2,}\b~iu',$t)) return true;
        if(preg_match('~\b(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|cutt\.ly|is\.gd|s\.id|rebrand\.ly|shorturl\.at)\b~iu',$t)) return true;
        // Obfuscated common URL spelling: example dot com / example [dot] com.
        if(preg_match('~\b[a-z0-9-]{2,}\s*(?:\.|\[?\s*dot\s*\]?|\s+dot\s+)\s*(?:com|net|org|vn|info|biz|io|co|me|tv|xyz|site|online|shop)\b~iu',$t)) return true;
        return false;
    }

    public static function containsPhoneNumber(string $text): bool
    {
        // Vietnamese/local phone forms: 0xxxxxxxxx or +84xxxxxxxxx, including common separators.
        $normalized=preg_replace('/[\s().-]+/u','',$text) ?? $text;
        if(preg_match('/(?<!\d)(?:\+?84|0)(?:\d{9,10})(?!\d)/u',$normalized)) return true;
        // Separated digits: 091 234 5678 / 091-234-5678 / 091.234.5678
        if(preg_match('/(?<!\d)(?:0\d{2}|\+84\d{2})(?:[\s().-]?\d{3}){2,3}(?!\d)/u',$text)) return true;
        // Word-obfuscation for Vietnamese digits in obvious phone sequences.
        $map=['không'=>'0','một'=>'1','mốt'=>'1','hai'=>'2','ba'=>'3','bốn'=>'4','tư'=>'4','năm'=>'5','lăm'=>'5','sáu'=>'6','bảy'=>'7','tám'=>'8','chín'=>'9'];
        $words=preg_split('/\s+/u',function_exists('mb_strtolower') ? mb_strtolower($text) : strtolower($text)) ?: [];
        $digits='';
        foreach($words as $w){
            $w=preg_replace('/[^\p{L}]/u','',$w) ?? '';
            if(isset($map[$w])) $digits.=$map[$w]; else { if(strlen($digits)>=9) break; $digits=''; }
        }
        return preg_match('/^(?:0\d{9}|84\d{9,10})$/',$digits)===1;
    }
}
