<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class WorkerAuth {
    public static function workerId(\PDO $db, bool $required=true): int {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (!preg_match('/^Bearer\s+(.+)$/i', $header, $m)) {
            if ($required) Response::error('Chưa đăng nhập.',401);
            return 0;
        }
        $hash = hash('sha256', trim($m[1]));
        $q=$db->prepare('SELECT nguoi_lao_dong_id FROM nguoi_lao_dong_access_token WHERE token_hash=? AND trang_thai="hoat_dong" AND het_han_at>NOW() LIMIT 1');
        $q->execute([$hash]);
        $id=(int)$q->fetchColumn();
        if($id>0){
            $db->prepare('UPDATE nguoi_lao_dong_access_token SET lan_su_dung_cuoi=NOW() WHERE token_hash=?')->execute([$hash]);
            return $id;
        }
        $mobile=MobileAuth::resolve($db,false);
        if($mobile && $mobile['role_code']==='worker') return (int)$mobile['worker_id'];
        if($required) Response::error('Phiên đăng nhập không hợp lệ hoặc đã hết hạn.',401);
        return 0;
    }
}
