<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class Database {
    private static ?\PDO $pdo = null;

    public static function connection(array $config): \PDO {
        if (self::$pdo instanceof \PDO) return self::$pdo;

        $host=(string)($config['host']??'127.0.0.1');
        $port=(string)($config['port']??'3306');
        $name=(string)($config['name']??'labor_supply_platform');
        $user=(string)($config['user']??'');
        $pass=(string)($config['pass']??'');
        $charset=(string)($config['charset']??'utf8mb4');

        if($user==='') throw new \RuntimeException('Thiếu DB_USER.');
        $dsn="mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
        self::$pdo=new \PDO($dsn,$user,$pass,[
            \PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES=>false,
        ]);
        return self::$pdo;
    }
}
