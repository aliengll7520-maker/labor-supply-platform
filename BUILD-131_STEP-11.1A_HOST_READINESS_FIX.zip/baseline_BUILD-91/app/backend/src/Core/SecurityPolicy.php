<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class SecurityPolicy {
    public static function applyHeaders(): void {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
        header('Cross-Origin-Opener-Policy: same-origin');
        header('Cross-Origin-Resource-Policy: same-origin');
        if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }
    }

    public static function validateRequestEnvelope(int $maxJsonBytes=2097152): void {
        $method = Request::method();
        if (!in_array($method, ['POST','PUT','PATCH'], true)) return;
        $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
        if (str_contains($contentType, 'multipart/form-data')) return;
        $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($length > $maxJsonBytes) Response::error('Payload quá lớn.', 413);
        if ($length > 0 && !str_contains($contentType, 'application/json') && !str_contains($contentType, 'application/x-www-form-urlencoded')) {
            Response::error('Content-Type không được hỗ trợ.', 415);
        }
    }
}
