<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class ModuleRegistry {
    /** @var array<string,array<string,mixed>> */
    private array $modules = [];

    public function register(string $key, string $name, string $version, string $status='active'): void {
        $this->modules[$key] = [
            'key'=>$key,
            'name'=>$name,
            'version'=>$version,
            'status'=>$status,
        ];
    }

    /** @return array<int,array<string,mixed>> */
    public function all(): array { return array_values($this->modules); }
}
