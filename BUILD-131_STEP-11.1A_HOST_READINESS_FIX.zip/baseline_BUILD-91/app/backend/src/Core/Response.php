<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class Response {
    public static function ok(mixed $data=null, string $message='OK', int $status=200): never {
        self::send(['success'=>true,'message'=>$message,'data'=>$data], $status);
    }
    public static function error(string $message, int $status=400): never {
        self::send(['success'=>false,'message'=>$message,'data'=>null], $status);
    }
    public static function replay(int $status, string $json): never {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Idempotency-Replayed: true');
        echo $json;
        exit;
    }

    private static function send(array $payload, int $status): never {
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if ($json === false) $json = json_encode(['success'=>false,'message'=>'Response encoding error.','data'=>null]);
        $idempotency = RequestContext::idempotency();
        if ($idempotency instanceof ApiIdempotency) {
            $idempotency->finish($status, $json);
        }
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo $json;
        exit;
    }
}
