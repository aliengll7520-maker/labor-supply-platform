<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class Pagination {
    public static function limit(int $default=50, int $max=100): int {
        $value = (int)($_GET['limit'] ?? $default);
        return min(max($value, 1), $max);
    }
    public static function offset(): int {
        return max((int)($_GET['offset'] ?? 0), 0);
    }
}
