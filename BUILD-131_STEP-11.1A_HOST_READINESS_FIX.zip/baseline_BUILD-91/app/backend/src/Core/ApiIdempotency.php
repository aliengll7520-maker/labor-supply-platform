<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

/**
 * BUILD-95: API Idempotency layer.
 *
 * The key is scoped by actor identity + method + path. A request fingerprint
 * prevents accidental reuse of the same key for a different operation.
 * Successful/non-5xx responses are cached for safe replay; 5xx responses
 * release the key so the client can retry the operation.
 */
final class ApiIdempotency {
    private ?array $active = null;
    private int $ttlSeconds = 86400;

    public function __construct(private \PDO $db) {}

    public function begin(): void {
        if (!in_array(Request::method(), ['POST','PUT','PATCH','DELETE'], true)) return;

        $key = IdempotencyKey::value();
        if ($key === null) return; // Backward-compatible rollout: key is supported, not yet globally mandatory.

        $actor = RequestContext::actorKey();
        $scope = hash('sha256', $actor.'|'.Request::method().'|'.Request::path());
        $fingerprint = hash('sha256', Request::method().'|'.Request::path().'|'.Request::rawBody());

        $now = date('Y-m-d H:i:s');
        $expires = date('Y-m-d H:i:s', time()+$this->ttlSeconds);

        // First attempt: create the operation reservation.
        try {
            $q=$this->db->prepare(
                'INSERT INTO api_idempotency_keys
                 (scope_hash,idempotency_key,request_fingerprint,status,expires_at,created_at,updated_at)
                 VALUES (?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)'
            );
            $q->execute([$scope,$key,$fingerprint,'processing',$expires]);
            $this->active=['scope_hash'=>$scope,'idempotency_key'=>$key,'request_fingerprint'=>$fingerprint];
            return;
        } catch (\PDOException $e) {
            // Duplicate key is expected for a retry/race; other DB errors must surface.
            if ((string)$e->getCode() !== '23000') throw $e;
        }

        $q=$this->db->prepare(
            'SELECT request_fingerprint,status,response_status,response_body,expires_at
             FROM api_idempotency_keys
             WHERE scope_hash=? AND idempotency_key=?
             LIMIT 1'
        );
        $q->execute([$scope,$key]);
        $row=$q->fetch(\PDO::FETCH_ASSOC);

        if (!$row) {
            throw new \RuntimeException('Không thể xác định Idempotency operation.');
        }

        if (strtotime((string)$row['expires_at']) !== false && strtotime((string)$row['expires_at']) <= time()) {
            $d=$this->db->prepare(
                'DELETE FROM api_idempotency_keys WHERE scope_hash=? AND idempotency_key=?'
            );
            $d->execute([$scope,$key]);
            $q=$this->db->prepare(
                'INSERT INTO api_idempotency_keys
                 (scope_hash,idempotency_key,request_fingerprint,status,expires_at,created_at,updated_at)
                 VALUES (?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)'
            );
            $q->execute([$scope,$key,$fingerprint,'processing',$expires]);
            $this->active=['scope_hash'=>$scope,'idempotency_key'=>$key,'request_fingerprint'=>$fingerprint];
            return;
        }

        if (!hash_equals((string)$row['request_fingerprint'],$fingerprint)) {
            Response::error('Idempotency-Key đã được sử dụng cho một yêu cầu khác.',409);
        }

        if ((string)$row['status']==='completed') {
            Response::replay(
                (int)$row['response_status'],
                (string)$row['response_body']
            );
        }

        header('Retry-After: 2');
        Response::error('Yêu cầu với Idempotency-Key này đang được xử lý.',409);
    }

    public function finish(int $status, string $responseBody): void {
        if ($this->active === null) return;

        if ($status >= 500) {
            $q=$this->db->prepare(
                'DELETE FROM api_idempotency_keys
                 WHERE scope_hash=? AND idempotency_key=? AND status="processing"'
            );
            $q->execute([$this->active['scope_hash'],$this->active['idempotency_key']]);
            $this->active=null;
            return;
        }

        $q=$this->db->prepare(
            'UPDATE api_idempotency_keys
             SET status="completed",response_status=?,response_body=?,updated_at=CURRENT_TIMESTAMP
             WHERE scope_hash=? AND idempotency_key=? AND request_fingerprint=? AND status="processing"'
        );
        $q->execute([
            $status,
            $responseBody,
            $this->active['scope_hash'],
            $this->active['idempotency_key'],
            $this->active['request_fingerprint']
        ]);
        $this->active=null;
    }

    public function operationId(): ?string {
        if ($this->active === null) return null;
        return 'api:'.$this->active['scope_hash'].':'.$this->active['idempotency_key'];
    }
}
