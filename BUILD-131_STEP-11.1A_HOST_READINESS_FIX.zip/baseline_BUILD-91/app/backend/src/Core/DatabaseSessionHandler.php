<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class DatabaseSessionHandler implements \SessionHandlerInterface {
    private ?\PDO $db = null;
    private string $table;
    private ?string $lockName = null;
    private int $lockTimeout;

    public function __construct(\PDO $db, string $table = 'labor_php_sessions', int $lockTimeout = 5) {
        $this->db = $db;
        $this->table = preg_match('/^[A-Za-z0-9_]+$/', $table) ? $table : 'labor_php_sessions';
        $this->lockTimeout = max(1, min(30, $lockTimeout));
    }

    public function open(string $path, string $name): bool { return true; }
    public function close(): bool {
        if ($this->lockName !== null && $this->db instanceof \PDO) {
            try { $this->db->query("SELECT RELEASE_LOCK(".$this->db->quote($this->lockName).")"); } catch (\Throwable $e) {}
        }
        $this->lockName = null;
        return true;
    }
    public function read(string $id): string|false {
        if (!$this->db instanceof \PDO) return false;
        $this->lockName = 'labor_session_'.hash('sha256', $id);
        $stmt=$this->db->prepare('SELECT GET_LOCK(?, ?)');
        $stmt->execute([$this->lockName,$this->lockTimeout]);
        if ((int)$stmt->fetchColumn() !== 1) return false;
        $q=$this->db->prepare("SELECT session_data FROM {$this->table} WHERE session_id=? AND last_activity >= ? LIMIT 1");
        $q->execute([$id,time()-86400]);
        $data=$q->fetchColumn();
        return $data===false ? '' : (string)$data;
    }
    public function write(string $id, string $data): bool {
        if (!$this->db instanceof \PDO) return false;
        $q=$this->db->prepare("INSERT INTO {$this->table} (session_id,last_activity,session_data) VALUES (?,?,?) ON DUPLICATE KEY UPDATE last_activity=VALUES(last_activity), session_data=VALUES(session_data)");
        return $q->execute([$id,time(),$data]);
    }
    public function destroy(string $id): bool {
        if (!$this->db instanceof \PDO) return false;
        $q=$this->db->prepare("DELETE FROM {$this->table} WHERE session_id=?");
        return $q->execute([$id]);
    }
    public function gc(int $max_lifetime): int|false {
        if (!$this->db instanceof \PDO) return false;
        $cutoff=time()-max(60,$max_lifetime);
        $q=$this->db->prepare("DELETE FROM {$this->table} WHERE last_activity < ?");
        $q->execute([$cutoff]);
        return $q->rowCount();
    }
}
