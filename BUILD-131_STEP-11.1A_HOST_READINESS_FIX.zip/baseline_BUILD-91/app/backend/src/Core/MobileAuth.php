<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class MobileAuth {
    public const ACCESS_TTL_SECONDS = 900;       // 15 minutes
    public const REFRESH_TTL_SECONDS = 2592000;  // 30 days

    public static function resolve(\PDO $db, bool $required=true): ?array {
        $header=(string)($_SERVER['HTTP_AUTHORIZATION']??'');
        if(!preg_match('/^Bearer\s+(.+)$/i',$header,$m)){
            if($required) Response::error('Chưa đăng nhập.',401);
            return null;
        }
        $hash=hash('sha256',trim($m[1]));
        $q=$db->prepare('SELECT s.*,i.trang_thai AS identity_status,r.role_status FROM mobile_auth_sessions s JOIN identity_principals i ON i.id=s.identity_id JOIN identity_role_memberships r ON r.identity_id=s.identity_id AND r.role_code=s.role_code AND ((s.role_code="worker" AND r.worker_id=s.worker_id) OR (s.role_code="employer" AND r.supplier_account_id=s.supplier_account_id)) WHERE s.access_token_hash=? AND s.revoked_at IS NULL AND s.access_expires_at>NOW() LIMIT 1');
        $q->execute([$hash]); $row=$q->fetch();
        if(!$row){ if($required) Response::error('Phiên Mobile không hợp lệ hoặc đã hết hạn.',401); return null; }
        if($row['identity_status']!=='hoat_dong'||$row['role_status']!=='active') Response::error('Tài khoản không còn được phép truy cập.',403);
        $db->prepare('UPDATE mobile_auth_sessions SET last_used_at=NOW() WHERE id=?')->execute([(int)$row['id']]);
        return $row;
    }

    public static function issue(\PDO $db,int $identityId,string $role,?int $workerId,?int $supplierId,?int $accountId,?string $deviceId=null): array {
        $access=bin2hex(random_bytes(32)); $refresh=bin2hex(random_bytes(48)); $family=bin2hex(random_bytes(32));
        $now=time();
        $q=$db->prepare('INSERT INTO mobile_auth_sessions(identity_id,role_code,worker_id,supplier_id,supplier_account_id,device_id,access_token_hash,refresh_token_hash,token_family,access_expires_at,refresh_expires_at,last_used_at) VALUES(?,?,?,?,?,?,?,?,?,FROM_UNIXTIME(?),FROM_UNIXTIME(?),NOW())');
        $q->execute([$identityId,$role,$workerId,$supplierId,$accountId,$deviceId,hash('sha256',$access),hash('sha256',$refresh),$family,$now+self::ACCESS_TTL_SECONDS,$now+self::REFRESH_TTL_SECONDS]);
        return ['access_token'=>$access,'refresh_token'=>$refresh,'token_type'=>'Bearer','expires_in'=>self::ACCESS_TTL_SECONDS,'refresh_expires_in'=>self::REFRESH_TTL_SECONDS,'session_id'=>(int)$db->lastInsertId()];
    }

    public static function refresh(\PDO $db,string $refreshToken): array {
        $hash=hash('sha256',trim($refreshToken));
        $db->beginTransaction();
        try{
            $q=$db->prepare('SELECT s.*,i.trang_thai AS identity_status,r.role_status FROM mobile_auth_sessions s JOIN identity_principals i ON i.id=s.identity_id JOIN identity_role_memberships r ON r.identity_id=s.identity_id AND r.role_code=s.role_code AND ((s.role_code="worker" AND r.worker_id=s.worker_id) OR (s.role_code="employer" AND r.supplier_account_id=s.supplier_account_id)) WHERE s.refresh_token_hash=? AND s.revoked_at IS NULL AND s.refresh_expires_at>NOW() FOR UPDATE');
            $q->execute([$hash]); $row=$q->fetch();
            if(!$row){
                $h=$db->prepare('SELECT * FROM mobile_auth_refresh_history WHERE token_hash=? LIMIT 1 FOR UPDATE');
                $h->execute([$hash]);
                $history=$h->fetch();
                if($history){
                    $db->prepare('UPDATE mobile_auth_refresh_history SET reuse_detected_at=NOW() WHERE id=? AND reuse_detected_at IS NULL')
                       ->execute([(int)$history['id']]);
                    $db->prepare('UPDATE mobile_auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE token_family=? AND revoked_at IS NULL')
                       ->execute([(string)$history['token_family']]);
                    throw new \RuntimeException('REFRESH_REUSE_DETECTED');
                }
                throw new \RuntimeException('REFRESH_INVALID');
            }
            if($row['identity_status']!=='hoat_dong'||$row['role_status']!=='active') throw new \RuntimeException('ACCOUNT_BLOCKED');
            $access=bin2hex(random_bytes(32)); $newRefresh=bin2hex(random_bytes(48));
            $now=time();
            $u=$db->prepare('UPDATE mobile_auth_sessions SET access_token_hash=?,refresh_token_hash=?,access_expires_at=FROM_UNIXTIME(?),refresh_expires_at=FROM_UNIXTIME(?),last_used_at=NOW() WHERE id=? AND refresh_token_hash=? AND revoked_at IS NULL');
            $u->execute([hash('sha256',$access),hash('sha256',$newRefresh),$now+self::ACCESS_TTL_SECONDS,$now+self::REFRESH_TTL_SECONDS,(int)$row['id'],$hash]);
            if($u->rowCount()!==1) throw new \RuntimeException('REFRESH_RACE');
            $h=$db->prepare('INSERT INTO mobile_auth_refresh_history(session_id,identity_id,token_family,token_hash,replaced_by_hash,used_at) VALUES(?,?,?,?,?,NOW())');
            $h->execute([(int)$row['id'],(int)$row['identity_id'],(string)$row['token_family'],$hash,hash('sha256',$newRefresh)]);
            $db->commit();
            return ['access_token'=>$access,'refresh_token'=>$newRefresh,'token_type'=>'Bearer','expires_in'=>self::ACCESS_TTL_SECONDS,'refresh_expires_in'=>self::REFRESH_TTL_SECONDS,'session_id'=>(int)$row['id'],'role'=>$row['role_code']];
        }catch(\Throwable $e){ if($db->inTransaction())$db->rollBack(); throw $e; }
    }

    public static function revokeCurrent(\PDO $db, array $session): void { $db->prepare('UPDATE mobile_auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE id=? AND revoked_at IS NULL')->execute([(int)$session['id']]); }
    public static function revokeSession(\PDO $db,array $current,int $targetId): void {
        $q=$db->prepare('UPDATE mobile_auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE id=? AND identity_id=? AND revoked_at IS NULL');
        $q->execute([$targetId,(int)$current['identity_id']]);
        if($q->rowCount()===0) Response::error('Không tìm thấy phiên thiết bị.',404);
    }
    public static function revokeAll(\PDO $db,array $current): void { $db->prepare('UPDATE mobile_auth_sessions SET revoked_at=NOW(),updated_at=NOW() WHERE identity_id=? AND revoked_at IS NULL')->execute([(int)$current['identity_id']]); }
}
