<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class Auth {
 private static ?\PDO $db=null;
 public static function start(array $config): void {
  if(session_status()!==PHP_SESSION_ACTIVE){
   session_name($config['session_name']);
   $secure=!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS'])!=='off';
   ini_set('session.use_strict_mode','1');
   if(self::$db instanceof \PDO){
    $sessionHandler = new DatabaseSessionHandler(self::$db);
    session_set_save_handler($sessionHandler, true);
   }
   session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Strict','cookie_secure'=>$secure]);
  }
  self::enforceSessionLifetime();
 }
 public static function enforceSessionLifetime(): void {
  $now=time();
  $last=(int)($_SESSION['_labor_last_activity']??0);
  $started=(int)($_SESSION['_labor_session_started']??0);
  if($last>0 && ($now-$last)>28800){ self::expireSession(); Response::error('Phiên đăng nhập đã hết hạn do không hoạt động.',401); }
  if($started>0 && ($now-$started)>86400){ self::expireSession(); Response::error('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.',401); }
  if($started<=0) $_SESSION['_labor_session_started']=$now;
  $_SESSION['_labor_last_activity']=$now;
 }
 private static function expireSession(): void { $_SESSION=[]; if(session_status()===PHP_SESSION_ACTIVE) session_destroy(); }
 public static function bindDatabase(\PDO $db): void {self::$db=$db;}
 public static function login(int $accountId,int $supplierId,bool $active=true): void {session_regenerate_id(true);$_SESSION['_labor_session_started']=time();$_SESSION['_labor_last_activity']=time();$_SESSION['supplier_account_id']=$accountId;$_SESSION['supplier_id']=$supplierId;$_SESSION['supplier_access_active']=$active;$_SESSION['supplier_role']='nhan_vien';$_SESSION['supplier_live_access']=false;}
 public static function logout(): void {$_SESSION=[];if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),' ',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);}session_destroy();}
 public static function supplierId(bool $requireActive=true): int {
  $mobile=null;
  $hasBearer=preg_match('/^Bearer\s+(.+)$/i',(string)($_SERVER['HTTP_AUTHORIZATION']??''))===1;
  if($hasBearer && self::$db instanceof \PDO) $mobile=MobileAuth::resolve(self::$db,false);
  $id=$mobile && $mobile['role_code']==='employer' ? (int)$mobile['supplier_id'] : (int)($_SESSION['supplier_id']??0);
  if($id<=0) Response::error('Chưa đăng nhập.',401);
  if($mobile){
   if($requireActive && ($mobile['identity_status']!=='hoat_dong'||$mobile['role_status']!=='active')) Response::error('Tài khoản không còn được phép truy cập.',403);
   return $id;
  }
  if($requireActive && !($_SESSION['supplier_access_active']??false)) Response::error('Tài khoản chưa được xác minh và kích hoạt.',403);
  if($requireActive && self::$db instanceof \PDO){
   $q=self::$db->prepare('SELECT n.trang_thai AS supplier_status,a.trang_thai AS account_status FROM nha_cung_ung n LEFT JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id AND a.id=? WHERE n.id=? LIMIT 1');
   $q->execute([(int)($_SESSION['supplier_account_id']??0),$id]);
   $row=$q->fetch();
   if(!$row || $row['supplier_status']!=='hoat_dong' || $row['account_status']!=='hoat_dong'){
    $_SESSION['supplier_access_active']=false;
    Response::error('Tài khoản Nhà cung ứng đang bị khóa hoặc tạm dừng vận hành.',403);
   }
  }
  return $id;
 }
 public static function accountId(): int {
  if(self::$db instanceof \PDO && preg_match('/^Bearer\s+(.+)$/i',(string)($_SERVER['HTTP_AUTHORIZATION']??''))===1){$m=MobileAuth::resolve(self::$db,false); if($m&&$m['role_code']==='employer') return (int)$m['supplier_account_id'];}
  return (int)($_SESSION['supplier_account_id']??0);
 }
 public static function role(): string {
  if(self::$db instanceof \PDO && preg_match('/^Bearer\s+(.+)$/i',(string)($_SERVER['HTTP_AUTHORIZATION']??''))===1){$m=MobileAuth::resolve(self::$db,false); if($m&&$m['role_code']==='employer'){ $q=self::$db->prepare('SELECT vai_tro FROM tai_khoan_nha_cung_ung WHERE id=? LIMIT 1'); $q->execute([(int)$m['supplier_account_id']]); return (string)($q->fetchColumn()?:'nhan_vien'); }}
  $r=(string)($_SESSION['supplier_role']??''); return $r!==''?$r:'nhan_vien';
 }
 public static function canManageAccounts(): bool{return in_array(self::role(),['chu_so_huu','quan_ly'],true);}
 public static function canLive(): bool {
  $accountId=self::accountId(); $supplierId=(int)($_SESSION['supplier_id']??0);
  if($supplierId<=0 && self::$db instanceof \PDO){$m=MobileAuth::resolve(self::$db,false); if($m&&$m['role_code']==='employer') $supplierId=(int)$m['supplier_id'];}
  if($accountId<=0 || $supplierId<=0 || !(self::$db instanceof \PDO)) return false;
  $q=self::$db->prepare('SELECT n.trang_thai AS supplier_status,a.trang_thai AS account_status,a.co_quyen_live FROM nha_cung_ung n JOIN tai_khoan_nha_cung_ung a ON a.nha_cung_ung_id=n.id WHERE n.id=? AND a.id=? LIMIT 1');
  $q->execute([$supplierId,$accountId]); $row=$q->fetch();
  if(!$row || $row['supplier_status']!=='hoat_dong' || $row['account_status']!=='hoat_dong' || !(bool)$row['co_quyen_live']) {
   $_SESSION['supplier_live_access']=false; return false;
  }
  $_SESSION['supplier_live_access']=true; return true;
 }
 public static function setAccountContext(string $role,bool $live): void {$_SESSION['supplier_role']=$role;$_SESSION['supplier_live_access']=$live;}
}
