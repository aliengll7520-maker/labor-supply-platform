<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class Request {
    private static ?string $rawBody = null;
    public static function method(): string { return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'); }
    public static function path(): string {
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        return is_string($uri) && $uri !== '' ? $uri : '/';
    }
    public static function rawBody(): string {
        if (self::$rawBody !== null) return self::$rawBody;
        $raw = file_get_contents('php://input');
        self::$rawBody = $raw === false ? '' : $raw;
        return self::$rawBody;
    }

    public static function body(): array {
        $raw = self::rawBody();
        if (trim($raw) === '') return [];
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
    public static function input(string $key, mixed $default=null): mixed {
        $body = self::body();
        return array_key_exists($key, $body) ? $body[$key] : $default;
    }
}
