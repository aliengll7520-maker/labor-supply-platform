<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class AdminAuth {
    private static ?\PDO $db=null;
    private const ROLE_ALIASES = [
        'quan_tri' => 'super_admin',
        'quan_ly' => 'operations_admin',
    ];

    private const PERMISSIONS = [
        'super_admin' => ['*'],
        'operations_admin' => [
            'dashboard.view','suppliers.view','suppliers.manage','jobs.view','jobs.manage',
            'unions.view','system.view','security.view','operations.view','content.discovery.override.view','content.discovery.override.manage','social.reports.view','social.moderate','trust.reviews.view','trust.reviews.manage',
        ],
        'support_admin' => ['dashboard.view','users.view','suppliers.view','notifications.view','operations.view','system.view','social.reports.view'],
        'moderator' => ['dashboard.view','jobs.view','jobs.manage','content.discovery.override.view','content.discovery.override.manage','operations.view','system.view','social.reports.view','social.moderate'],
    ];

    public static function bindDatabase(\PDO $db): void { self::$db=$db; }

    public static function login(int $accountId,string $role): void {
        if (!isset(self::PERMISSIONS[$role]) && !isset(self::ROLE_ALIASES[$role])) Response::error('Vai trò Quản trị không hợp lệ.',403);
        session_regenerate_id(true);
        $_SESSION['_labor_session_started']=time();
        $_SESSION['_labor_last_activity']=time();
        $_SESSION['admin_account_id']=$accountId;
        $_SESSION['admin_role']=$role;
        self::rotateCsrfToken();
    }
    public static function logout(): void {
        unset($_SESSION['admin_account_id'],$_SESSION['admin_role'],$_SESSION['_labor_csrf']);
    }
    public static function accountId(): int {
        $id=(int)($_SESSION['admin_account_id']??0);
        if($id<=0) Response::error('Quản trị viên chưa đăng nhập.',401);
        if(self::$db instanceof \PDO){
            $q=self::$db->prepare('SELECT trang_thai FROM tai_khoan_quan_tri WHERE id=? LIMIT 1');
            $q->execute([$id]);
            $status=$q->fetchColumn();
            if($status!=='hoat_dong'){ self::logout(); Response::error('Tài khoản Quản trị đã bị khóa hoặc ngừng hoạt động.',403); }
        }
        return $id;
    }
    public static function role(): string {
        self::accountId();
        $role=(string)($_SESSION['admin_role']??'');
        return self::ROLE_ALIASES[$role] ?? $role;
    }
    public static function requireManager(): int {
        return self::requirePermission('dashboard.view');
    }
    public static function requirePermission(string $permission): int {
        $id=self::accountId();
        $role=self::role();
        $permissions=self::PERMISSIONS[$role]??[];
        if(!in_array('*',$permissions,true) && !in_array($permission,$permissions,true))
            Response::error('Tài khoản Quản trị không có quyền thực hiện thao tác này.',403);
        return $id;
    }
    public static function permissions(): array {
        $role=self::role();
        return self::PERMISSIONS[$role]??[];
    }
    public static function csrfToken(): string {
        self::accountId();
        if(empty($_SESSION['_labor_csrf'])) self::rotateCsrfToken();
        return (string)$_SESSION['_labor_csrf'];
    }
    public static function rotateCsrfToken(): string {
        $_SESSION['_labor_csrf']=bin2hex(random_bytes(32));
        return $_SESSION['_labor_csrf'];
    }
    public static function requireCsrf(): void {
        self::accountId();
        $expected=(string)($_SESSION['_labor_csrf']??'');
        $provided=(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'');
        if($expected==='' || $provided==='' || !hash_equals($expected,$provided))
            Response::error('CSRF token không hợp lệ hoặc đã hết hạn.',419);
    }
}
