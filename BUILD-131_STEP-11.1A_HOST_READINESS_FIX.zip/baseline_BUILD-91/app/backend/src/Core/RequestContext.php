<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class RequestContext {
    private static ?string $requestId = null;
    private static ?\PDO $db = null;
    private static ?ApiIdempotency $idempotency = null;

    public static function start(): string {
        if (self::$requestId !== null) return self::$requestId;
        $incoming = trim((string)($_SERVER['HTTP_X_REQUEST_ID'] ?? ''));
        self::$requestId = preg_match('/^[A-Za-z0-9._:-]{8,80}$/', $incoming)
            ? $incoming
            : bin2hex(random_bytes(16));
        header('X-Request-ID: '.self::$requestId);
        return self::$requestId;
    }

    public static function bindDatabase(\PDO $db): void {
        self::$db = $db;
        self::$idempotency = new ApiIdempotency($db);
    }

    public static function idempotency(): ?ApiIdempotency {
        return self::$idempotency;
    }

    public static function id(): string {
        return self::$requestId ?? self::start();
    }

    public static function clientIp(): string {
        // Do not trust X-Forwarded-For until the deployment explicitly configures trusted proxies.
        return (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    }

    public static function actorKey(): string {
        $auth = trim((string)($_SERVER['HTTP_AUTHORIZATION'] ?? ''));
        if ($auth !== '' && preg_match('/^Bearer\s+(.+)$/i', $auth, $m)) {
            $tokenHash = hash('sha256', trim($m[1]));
            if (self::$db instanceof \PDO) {
                $q = self::$db->prepare('SELECT nguoi_lao_dong_id FROM nguoi_lao_dong_access_token WHERE token_hash=? AND trang_thai="hoat_dong" AND het_han_at>NOW() LIMIT 1');
                $q->execute([$tokenHash]);
                $workerId = (int)$q->fetchColumn();
                if ($workerId > 0) return 'nguoi_lao_dong:'.$workerId;
            }
            return 'bearer:'.$tokenHash;
        }
        $accountId=(int)($_SESSION['supplier_account_id']??0);
        $supplierId=(int)($_SESSION['supplier_id']??0);
        if ($accountId>0 && $supplierId>0) return 'nha_cung_ung:'.$supplierId.':tai_khoan:'.$accountId;
        $session = session_id();
        return $session !== '' ? 'session:'.hash('sha256', $session) : 'ip:'.self::clientIp();
    }
}
