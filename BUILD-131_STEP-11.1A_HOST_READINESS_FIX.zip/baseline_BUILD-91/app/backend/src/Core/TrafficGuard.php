<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class TrafficGuard {
    public function __construct(private array $config = []) {}

    public function apply(): void {
        RequestContext::start();

        $maxBytes = (int)($this->config['max_body_bytes'] ?? 1048576);
        if (str_starts_with(Request::path(), '/api/media/upload')) {
            $maxBytes = (int)($this->config['media_upload_max_body_bytes'] ?? ($maxBytes));
        }
        $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength > $maxBytes) {
            header('Retry-After: 1');
            Response::error('Yêu cầu quá lớn.', 413);
        }

        $timeout = max(1, (int)($this->config['request_timeout_seconds'] ?? 15));
        if (function_exists('set_time_limit')) @set_time_limit($timeout);

        if (in_array(Request::method(), ['POST','PUT','PATCH','DELETE'], true)) {
            IdempotencyKey::value();
        }

        if ($this->isRateLimited()) {
            $retry = max(1, (int)($this->config['retry_after_seconds'] ?? 2));
            header('Retry-After: '.$retry);
            Response::error('Hệ thống đang nhận quá nhiều yêu cầu. Vui lòng thử lại sau.', 429);
        }

        // Reserve the idempotency operation only after rate-limit admission.
        // A rejected 429 must never become the cached result of a client operation.
        if (in_array(Request::method(), ['POST','PUT','PATCH','DELETE'], true)) {
            $idempotency = RequestContext::idempotency();
            if ($idempotency instanceof ApiIdempotency) {
                $idempotency->begin();
            }
        }

        $this->applyCachePolicy();
    }

    private function isRateLimited(): bool {
        $method = Request::method();
        $path = Request::path();
        $rules = $this->config['rate_limits'] ?? [];
        $rule = $this->ruleFor($path, $method, $rules);
        if (!$rule || ($rule['enabled'] ?? true) === false) return false;

        $limit = max(1, (int)($rule['limit'] ?? 60));
        $window = max(1, (int)($rule['window_seconds'] ?? 60));
        $keyMode = (string)($rule['key'] ?? 'ip');
        $identity = $keyMode === 'actor' ? RequestContext::actorKey() : 'ip:'.RequestContext::clientIp();
        $key = 'labor:rate:'.hash('sha256', $method.'|'.$path.'|'.$identity.'|'.$window);

        $count = $this->incrementCounter($key, $window);
        header('X-RateLimit-Limit: '.$limit);
        header('X-RateLimit-Remaining: '.max(0, $limit - $count));
        return $count > $limit;
    }

    private function ruleFor(string $path, string $method, array $rules): ?array {
        $matches = [];
        foreach ($rules as $rule) {
            $ruleMethod = strtoupper((string)($rule['method'] ?? '*'));
            if ($ruleMethod !== '*' && $ruleMethod !== $method) continue;
            $exact = (string)($rule['path'] ?? '');
            $prefix = (string)($rule['path_prefix'] ?? '');
            $suffix = (string)($rule['path_suffix'] ?? '');
            if ($exact !== '' && $exact !== $path) continue;
            if ($exact === '' && $prefix !== '' && !str_starts_with($path, $prefix)) continue;
            if ($exact === '' && $prefix === '' && $suffix === '') continue;
            if ($suffix !== '' && !str_ends_with($path, $suffix)) continue;
            $specificity = $exact !== '' ? 100000 + strlen($exact) : strlen($prefix) + strlen($suffix) * 10;
            $matches[] = [$specificity, $rule];
        }
        if (!$matches) return null;
        usort($matches, static fn($a,$b) => $b[0] <=> $a[0]);
        return $matches[0][1];
    }

    private function incrementCounter(string $key, int $window): int {
        if (function_exists('apcu_inc')) {
            $created = false;
            $value = apcu_fetch($key, $created);
            if (!$created) {
                apcu_add($key, 1, $window + 5);
                return 1;
            }
            return (int)apcu_inc($key, 1);
        }

        // Local development fallback only. Production should use shared APCu/Redis at the edge.
        $file = sys_get_temp_dir().'/labor-rate-'.substr(hash('sha256', $key), 0, 24).'.json';
        $fp = @fopen($file, 'c+');
        if (!$fp) return 0;
        flock($fp, LOCK_EX);
        $raw = stream_get_contents($fp);
        $state = json_decode($raw ?: '', true);
        $now = time();
        if (!is_array($state) || (int)($state['expires'] ?? 0) <= $now) {
            $state = ['count'=>0,'expires'=>$now+$window];
        }
        $state['count']++;
        ftruncate($fp, 0); rewind($fp); fwrite($fp, json_encode($state)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
        return (int)$state['count'];
    }

    private function applyCachePolicy(): void {
        if (Request::method() !== 'GET') return;
        $path = Request::path();
        $publicPrefixes = ['/api/jobs/public', '/api/worker/job-seeking-posts/public'];
        foreach ($publicPrefixes as $prefix) {
            if (str_starts_with($path, $prefix)) {
                header('Cache-Control: public, max-age=10, stale-while-revalidate=30');
                header('Vary: Accept-Encoding');
                return;
            }
        }
    }
}
