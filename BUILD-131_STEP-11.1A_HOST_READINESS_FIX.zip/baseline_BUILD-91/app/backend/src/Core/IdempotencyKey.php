<?php
declare(strict_types=1);
namespace LaborPlatform\Core;

final class IdempotencyKey {
    public static function value(): ?string {
        $key = trim((string)($_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? ''));
        if ($key === '') return null;
        if (!preg_match('/^[A-Za-z0-9._:-]{8,128}$/', $key)) Response::error('Idempotency-Key không hợp lệ.', 400);
        return $key;
    }
}
