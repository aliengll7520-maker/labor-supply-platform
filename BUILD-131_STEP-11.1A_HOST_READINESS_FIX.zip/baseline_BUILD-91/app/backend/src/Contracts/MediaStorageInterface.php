<?php
declare(strict_types=1);
namespace LaborPlatform\Contracts;

interface MediaStorageInterface {
    public function putFile(string $sourcePath, string $storageKey): array;
    public function exists(string $storageKey): bool;
    public function delete(string $storageKey): bool;
    public function absolutePath(string $storageKey): string;
    public function publicUrl(string $storageKey): string;
    public function releasePath(string $path): void;
}
