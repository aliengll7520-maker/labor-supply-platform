/* BUILD 45 — Content Discovery reconciliation/self-healing run log. */
CREATE TABLE IF NOT EXISTS content_discovery_reconciliation_runs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version VARCHAR(20) NOT NULL,
    scanned_count INT UNSIGNED NOT NULL DEFAULT 0,
    requeued_count INT UNSIGNED NOT NULL DEFAULT 0,
    failed_requeued_count INT UNSIGNED NOT NULL DEFAULT 0,
    orphaned_count INT UNSIGNED NOT NULL DEFAULT 0,
    result_json LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_cdr_reconcile_created (created_at),
    KEY idx_cdr_reconcile_counts (requeued_count, failed_requeued_count, orphaned_count)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
