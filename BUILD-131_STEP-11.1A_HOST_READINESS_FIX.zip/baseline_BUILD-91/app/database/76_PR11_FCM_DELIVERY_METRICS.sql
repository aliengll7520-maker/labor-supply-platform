CREATE TABLE IF NOT EXISTS fcm_delivery_metrics (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    delivery_key VARCHAR(191) NOT NULL,
    status VARCHAR(32) NOT NULL,
    message_id VARCHAR(191) NULL,
    error_code VARCHAR(128) NULL,
    error_message TEXT NULL,
    occurred_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_fcm_delivery_key (delivery_key),
    KEY idx_fcm_delivery_status_time (status, occurred_at),
    KEY idx_fcm_delivery_time (occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
