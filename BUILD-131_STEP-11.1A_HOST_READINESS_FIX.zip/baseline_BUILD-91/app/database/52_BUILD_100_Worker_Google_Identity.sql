-- BUILD 100 - Worker identity: phone + Google
-- No platform fee. This table stores only the external identity needed for login/linking.
ALTER TABLE nguoi_lao_dong
    MODIFY COLUMN so_dien_thoai VARCHAR(20) NULL,
    ADD COLUMN email VARCHAR(320) NULL AFTER so_dien_thoai;

CREATE UNIQUE INDEX uq_nguoi_lao_dong_email ON nguoi_lao_dong (email);

CREATE TABLE nguoi_lao_dong_dang_nhap_lien_ket (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    nha_cung_cap VARCHAR(30) NOT NULL,
    provider_subject VARCHAR(255) NOT NULL,
    provider_email VARCHAR(320) NULL,
    ngay_lien_ket TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_su_dung_cuoi DATETIME NULL,
    trang_thai ENUM('hoat_dong','vo_hieu') NOT NULL DEFAULT 'hoat_dong',
    UNIQUE KEY uq_worker_provider_subject (nha_cung_cap, provider_subject),
    UNIQUE KEY uq_worker_provider_email (nha_cung_cap, provider_email),
    INDEX idx_worker_identity (nguoi_lao_dong_id, trang_thai),
    FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);

CREATE TABLE nguoi_lao_dong_lien_ket_audit (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    hanh_dong VARCHAR(50) NOT NULL,
    nha_cung_cap VARCHAR(30) NOT NULL,
    thoi_gian DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);
