/*
==========================================================
02_NhaCungUng.sql
QUẢN LÝ NHÀ CUNG ỨNG
Labor Supply Platform
Version: 3.0
==========================================================

NGUYÊN TẮC:

Nhà cung ứng là nguồn cung việc làm của nền tảng.

Nhà cung ứng phải:

- Có hồ sơ quản lý.
- Có thông tin liên hệ.
- Được xác minh.
- Có trạng thái hoạt động.
- Có lịch sử tuyển dụng.
- Có dữ liệu Đăng ký hồ sơ phỏng vấn với Người lao động.
- Có điểm minh bạch.

ĐẶC BIỆT:

Số điện thoại Nhà cung ứng KHÔNG phải dữ liệu công khai.

Số điện thoại được lưu trong hệ thống để:

1. Quản trị kiểm soát.
2. Nhà cung ứng sử dụng để liên hệ.
3. Chỉ cấp quyền xem cho Người lao động
   sau khi Đăng ký hồ sơ phỏng vấn được tạo và xác nhận.

KHÔNG hiển thị trực tiếp số điện thoại trong
tin tuyển dụng công khai.

==========================================================
*/

CREATE TABLE nha_cung_ung (

    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    ma_nha_cung_ung VARCHAR(30) UNIQUE NOT NULL,

    ten_nha_cung_ung VARCHAR(255) NOT NULL,

    nguoi_dai_dien VARCHAR(255) NOT NULL,

    so_dien_thoai VARCHAR(20) NOT NULL,

    so_dien_thoai_da_xac_minh TINYINT(1) NOT NULL DEFAULT 0,

    email VARCHAR(255) DEFAULT NULL,

    dia_chi TEXT DEFAULT NULL,

    google_maps TEXT DEFAULT NULL,

    logo VARCHAR(255) DEFAULT NULL,

    gioi_thieu TEXT DEFAULT NULL,

    giay_phep VARCHAR(255) DEFAULT NULL,

    xac_minh ENUM(
        'chua_xac_minh',
        'dang_xac_minh',
        'da_xac_minh',
        'can_xac_minh_lai'
    ) NOT NULL DEFAULT 'chua_xac_minh',

    ngay_xac_minh DATETIME NULL,

    diem_minh_bach DECIMAL(5,2) NOT NULL DEFAULT 100.00,

    tong_tin_tuyen_dung INT UNSIGNED NOT NULL DEFAULT 0,

    tong_dang_ky_ho_so_phong_van INT UNSIGNED NOT NULL DEFAULT 0,

    tong_lien_he INT UNSIGNED NOT NULL DEFAULT 0,

    tong_hen INT UNSIGNED NOT NULL DEFAULT 0,

    tong_nhan_viec INT UNSIGNED NOT NULL DEFAULT 0,

    tong_khong_phu_hop INT UNSIGNED NOT NULL DEFAULT 0,

    tong_huy INT UNSIGNED NOT NULL DEFAULT 0,

    tong_phan_anh INT UNSIGNED NOT NULL DEFAULT 0,

    ti_le_phan_hoi DECIMAL(5,2) NOT NULL DEFAULT 0,

    ti_le_nhan_viec DECIMAL(5,2) NOT NULL DEFAULT 0,

    thoi_gian_phan_hoi_trung_binh INT UNSIGNED NOT NULL DEFAULT 0,

    trang_thai ENUM(
        'cho_duyet',
        'hoat_dong',
        'tam_khoa',
        'ngung_hoat_dong'
    ) NOT NULL DEFAULT 'cho_duyet',

    ghi_chu_quan_tri TEXT NULL,

    ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_trang_thai (
        trang_thai
    ),

    INDEX idx_xac_minh (
        xac_minh
    ),

    INDEX idx_diem_minh_bach (
        diem_minh_bach
    ),

    INDEX idx_so_dien_thoai (
        so_dien_thoai
    ),

    INDEX idx_so_dien_thoai_xac_minh (
        so_dien_thoai_da_xac_minh
    )

);
