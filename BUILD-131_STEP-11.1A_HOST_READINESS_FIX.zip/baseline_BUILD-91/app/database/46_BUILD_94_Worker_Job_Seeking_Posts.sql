/* BUILD 94 - Tin tìm việc của Người lao động */
CREATE TABLE IF NOT EXISTS tin_tim_viec_nguoi_lao_dong (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
 tieu_de VARCHAR(255) NOT NULL COMMENT 'Công việc mong muốn',
 dia_diem_mong_muon VARCHAR(255) NOT NULL,
 thu_nhap_mong_muon VARCHAR(120) NULL,
 ky_nang TEXT NULL,
 kinh_nghiem TEXT NULL,
 gioi_thieu TEXT NULL,
 thoi_gian_co_the_di_lam VARCHAR(255) NULL,
 trang_thai ENUM('cho_duyet','dang_hien','can_chinh_sua','da_an','da_dong') NOT NULL DEFAULT 'cho_duyet',
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_worker_post_status (nguoi_lao_dong_id,trang_thai,ngay_tao),
 INDEX idx_worker_post_public (trang_thai,ngay_tao),
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ket_noi_nha_tuyen_dung_nguoi_lao_dong (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 tin_tim_viec_id BIGINT UNSIGNED NOT NULL,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
 nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
 trang_thai ENUM('cho_nguoi_lao_dong_xac_nhan','da_chap_nhan','tu_choi','da_huy') NOT NULL DEFAULT 'cho_nguoi_lao_dong_xac_nhan',
 ghi_chu VARCHAR(1000) NULL,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_worker_post_employer (tin_tim_viec_id,nha_cung_ung_id),
 INDEX idx_worker_connection (nguoi_lao_dong_id,trang_thai,ngay_tao),
 INDEX idx_employer_connection (nha_cung_ung_id,trang_thai,ngay_tao),
 FOREIGN KEY (tin_tim_viec_id) REFERENCES tin_tim_viec_nguoi_lao_dong(id) ON DELETE CASCADE,
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE,
 FOREIGN KEY (nha_cung_ung_id) REFERENCES nha_cung_ung(id) ON DELETE CASCADE
);
