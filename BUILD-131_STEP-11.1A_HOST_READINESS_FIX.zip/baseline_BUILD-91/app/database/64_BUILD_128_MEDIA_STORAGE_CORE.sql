/* BUILD 128 - Media Storage Core. No upload endpoint is enabled yet. */
CREATE TABLE IF NOT EXISTS media_asset (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 owner_type ENUM('nguoi_lao_dong','nha_cung_ung','system') NOT NULL,
 owner_id BIGINT UNSIGNED NULL,
 storage_driver VARCHAR(50) NOT NULL DEFAULT 'local',
 storage_key VARCHAR(1000) NOT NULL,
 original_name VARCHAR(255) NULL,
 mime_type VARCHAR(100) NULL,
 size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
 sha256 CHAR(64) NULL,
 width INT UNSIGNED NULL,
 height INT UNSIGNED NULL,
 duration_seconds INT UNSIGNED NULL,
 trang_thai ENUM('pending','stored','processing','ready','failed','deleted') NOT NULL DEFAULT 'pending',
 public_access TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_media_asset_storage_key(storage_driver,storage_key),
 INDEX idx_media_asset_owner(owner_type,owner_id,created_at),
 INDEX idx_media_asset_status(trang_thai,created_at),
 INDEX idx_media_asset_sha256(sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_storage_driver','media','Bộ lưu trữ Media hiện tại','local','string','BUILD 128 chỉ xây Storage Core; Object Storage sẽ được nối qua adapter ở bước tiếp theo.'),
('media_storage_public_base_url','media','URL gốc Media công khai','','string','Để trống khi chưa cấu hình CDN hoặc public media URL.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
