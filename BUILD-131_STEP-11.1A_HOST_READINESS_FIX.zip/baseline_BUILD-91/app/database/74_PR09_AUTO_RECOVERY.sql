-- PR-09 Auto Recovery
-- Records recovery agent runs; does not alter historical migrations.
CREATE TABLE IF NOT EXISTS queue_recovery_runs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    recovered_count INT UNSIGNED NOT NULL DEFAULT 0,
    queues_json JSON NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_queue_recovery_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
