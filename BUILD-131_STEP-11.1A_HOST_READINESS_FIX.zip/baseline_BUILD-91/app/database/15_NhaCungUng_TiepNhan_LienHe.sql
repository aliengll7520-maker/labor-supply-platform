/*
==========================================================
15_NhaCungUng_TiepNhan_LienHe.sql
BƯỚC 05 - TIẾP NHẬN + LIÊN HỆ
==========================================================

Mục tiêu:
- Tách rõ "tiếp nhận" khỏi việc liên hệ thực tế.
- Mỗi lần liên hệ được lưu thành một bản ghi riêng.
- Quá trình Đăng ký hồ sơ phỏng vấn vẫn là timeline tổng.
- Không sửa/xóa lịch sử liên hệ; chỉ bổ sung bản ghi mới.

Tiếp nhận:
da_mo_so -> da_xem

Liên hệ thành công:
da_xem -> da_lien_he

Liên hệ không thành công:
da_xem -> khong_lien_he_duoc

==========================================================
*/

CREATE TABLE lien_he_dang_ky_ho_so_phong_van (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL,
    nguoi_thuc_hien ENUM('nha_cung_ung','quan_tri') NOT NULL DEFAULT 'nha_cung_ung',
    nguoi_thuc_hien_id BIGINT UNSIGNED NOT NULL,

    phuong_thuc ENUM(
        'dien_thoai',
        'zalo',
        'sms',
        'truc_tiep',
        'khac'
    ) NOT NULL DEFAULT 'dien_thoai',

    chieu_lien_he ENUM('goi_di','nhan_cuoc_goi','gap_truc_tiep','tin_nhan') NOT NULL DEFAULT 'goi_di',

    ket_qua ENUM(
        'da_lien_he',
        'khong_lien_he_duoc',
        'hen_goi_lai',
        'tu_choi',
        'khac'
    ) NOT NULL,

    thoi_gian DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ghi_chu TEXT NULL,

    INDEX idx_ho_so (dang_ky_ho_so_phong_van_id),
    INDEX idx_thoi_gian (thoi_gian),
    INDEX idx_ket_qua (ket_qua)
);

/*
==========================================================
BƯỚC 05 - KHÓA QUY TẮC
==========================================================

1. Hồ sơ mới ở da_mo_so chỉ được chuyển sang da_xem
   bằng endpoint TIẾP NHẬN.
2. Endpoint đổi trạng thái thông thường không được dùng
   để bỏ qua bước tiếp nhận.
3. Mỗi lần liên hệ được lưu riêng trong
   lien_he_dang_ky_ho_so_phong_van.
4. Kết quả liên hệ thành công -> da_lien_he.
5. Không liên hệ được -> khong_lien_he_duoc.
6. Hẹn gọi lại/từ chối/khác được lưu lịch sử; Nhà cung ứng
   tiếp tục xử lý theo nghiệp vụ sau đó.
7. Không xóa lịch sử liên hệ.
==========================================================
*/
