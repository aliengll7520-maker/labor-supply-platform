/* BUILD 109 - Notification & Communication Automation */
CREATE TABLE IF NOT EXISTS notification_delivery_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    channel ENUM('push','sms','email') NOT NULL,
    recipient_type VARCHAR(40) NOT NULL,
    recipient_id BIGINT UNSIGNED NULL,
    reference_type VARCHAR(80) NULL,
    reference_id BIGINT UNSIGNED NULL,
    queue_job_id BIGINT UNSIGNED NULL,
    status ENUM('queued','sent','failed') NOT NULL DEFAULT 'queued',
    provider VARCHAR(80) NULL,
    provider_message_id VARCHAR(255) NULL,
    error_message VARCHAR(1000) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_delivery_channel_status (channel,status),
    INDEX idx_delivery_recipient (recipient_type,recipient_id),
    INDEX idx_delivery_reference (reference_type,reference_id),
    INDEX idx_delivery_queue_job (queue_job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
