/* BUILD 142 - PR-03.8 Media Cleanup Queue. */
INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_cleanup_max_attempts','media','Số lần retry tối đa cho cleanup Media','8','integer','BUILD 142: cleanup object lỗi sẽ đi qua Queue và retry/backoff.'),
('media_cleanup_temp_max_age_seconds','media','Tuổi tối thiểu file tạm trước khi tự dọn','86400','integer','BUILD 142: chỉ dọn file labor-img-* cũ hơn 24 giờ.'),
('media_cleanup_temp_batch_limit','media','Số file tạm tối đa mỗi lần dọn','200','integer','BUILD 142: giới hạn tác động mỗi lượt cleanup.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
