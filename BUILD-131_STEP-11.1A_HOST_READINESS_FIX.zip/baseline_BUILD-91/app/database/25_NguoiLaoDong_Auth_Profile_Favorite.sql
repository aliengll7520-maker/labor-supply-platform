CREATE TABLE tai_khoan_nguoi_lao_dong (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL UNIQUE,
 mat_khau_hash VARCHAR(255) NOT NULL,
 trang_thai ENUM('hoat_dong','khoa') NOT NULL DEFAULT 'hoat_dong',
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);

CREATE TABLE nguoi_lao_dong_access_token (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 het_han_at DATETIME NOT NULL,
 lan_su_dung_cuoi DATETIME NULL,
 trang_thai ENUM('hoat_dong','vo_hieu') NOT NULL DEFAULT 'hoat_dong',
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_worker_token (nguoi_lao_dong_id, trang_thai),
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);

CREATE TABLE ho_so_nghe_nghiep_nguoi_lao_dong (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL UNIQUE,
 ngay_sinh DATE NULL, gioi_tinh VARCHAR(30) NULL,
 province VARCHAR(120) NULL, district VARCHAR(120) NULL,
 occupation VARCHAR(255) NULL, skills TEXT NULL, experience TEXT NULL,
 education VARCHAR(255) NULL, avatar_url VARCHAR(500) NULL, bio TEXT NULL,
 desired_position VARCHAR(255) NULL, desired_location VARCHAR(255) NULL,
 desired_salary VARCHAR(120) NULL,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);

CREATE TABLE nguoi_lao_dong_tin_yeu_thich (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
 job_id BIGINT UNSIGNED NOT NULL,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_worker_job_favorite (nguoi_lao_dong_id, job_id),
 INDEX idx_worker_favorite (nguoi_lao_dong_id, ngay_tao),
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);
