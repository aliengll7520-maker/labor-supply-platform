-- BUILD 111: Operations Center + Monitoring
CREATE TABLE IF NOT EXISTS operations_health_snapshots (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  status ENUM('healthy','warning','critical','unknown') NOT NULL DEFAULT 'unknown',
  summary_json JSON NOT NULL,
  details_json JSON NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ops_snapshot_created(created_at),
  INDEX idx_ops_snapshot_status(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS operations_alerts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fingerprint CHAR(64) NOT NULL,
  severity ENUM('info','warning','critical') NOT NULL,
  source VARCHAR(60) NOT NULL,
  code VARCHAR(100) NOT NULL,
  message VARCHAR(500) NOT NULL,
  details_json JSON NULL,
  status ENUM('open','resolved') NOT NULL DEFAULT 'open',
  first_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME NULL,
  UNIQUE KEY uq_ops_alert_open (fingerprint,status),
  INDEX idx_ops_alert_status(status,severity,last_seen_at),
  INDEX idx_ops_alert_source(source,code,last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
