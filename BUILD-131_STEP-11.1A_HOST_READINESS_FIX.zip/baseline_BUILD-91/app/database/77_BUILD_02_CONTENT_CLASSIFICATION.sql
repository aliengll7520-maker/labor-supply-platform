/*
 * BUILD 02 — CONTENT CLASSIFICATION
 * Labor Supply Platform
 *
 * Adds a deterministic classification projection for Tin tuyển dụng.
 * tin_tuyen_dung remains the authoritative source.
 */

CREATE TABLE IF NOT EXISTS content_discovery_classifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    source_key VARCHAR(120) NULL,
    classification_json LONGTEXT NOT NULL,
    classification_fingerprint CHAR(64) NOT NULL,
    source_updated_at DATETIME NULL,
    classified_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdc_source (content_type, source_table, source_id),
    KEY idx_cdc_fingerprint (classification_fingerprint),
    KEY idx_cdc_classified_at (classified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
