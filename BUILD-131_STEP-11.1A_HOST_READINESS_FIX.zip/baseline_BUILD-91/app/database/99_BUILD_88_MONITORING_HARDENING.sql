/*
BUILD-88 — MONITORING / OPERATIONS HARDENING
Step 7.

Adds FCM provider request latency telemetry without changing delivery semantics.
The column is nullable for historical rows.
*/
ALTER TABLE fcm_delivery_metrics
    ADD COLUMN latency_ms INT UNSIGNED NULL AFTER error_message,
    ADD INDEX idx_fcm_delivery_latency_time (latency_ms, occurred_at);
