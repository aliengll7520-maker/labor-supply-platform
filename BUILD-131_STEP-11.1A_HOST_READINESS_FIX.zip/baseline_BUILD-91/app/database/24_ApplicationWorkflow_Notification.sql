/*
==========================================================
24_ApplicationWorkflow_Notification.sql
Build 14 — notification event integration support
==========================================================

No new table is required in this migration.
This file documents the required indexes/constraints that
the workflow service expects to exist.

Verify these indexes in the current schema before E2E:

- interview_registrations.nguoi_lao_dong_id
- interview_registrations.trang_thai
- interview_registration_timeline.interview_registration_id
- interview_registration_timeline.thoi_gian
*/
