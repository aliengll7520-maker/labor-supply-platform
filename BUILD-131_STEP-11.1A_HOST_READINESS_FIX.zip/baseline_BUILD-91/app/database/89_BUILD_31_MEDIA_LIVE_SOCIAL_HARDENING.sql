/* BUILD 31 — MEDIA / LIVE / SOCIAL HARDENING
   - Social post images are explicitly capped at six at the application boundary.
   - Live chat is ephemeral: no chat content is retained after a Live room ends.
   - Live video remains transport-only; this migration does not add recording storage.
   - Existing media image processing variants remain authoritative for optimized delivery.
*/
INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('social_post_max_images','social','Số ảnh tối đa trong một bài đăng','6','integer','BUILD 31: hard limit at backend boundary.'),
('live_chat_retention_after_end_seconds','live','Thời gian giữ chat sau khi Live kết thúc','0','integer','BUILD 31: chat Live là dữ liệu tạm thời, xóa ngay sau khi kết thúc.'),
('live_recording_enabled','live','Lưu bản ghi video Live','false','boolean','BUILD 31: không ghi/lưu Replay; transport chỉ phục vụ phiên Live đang hoạt động.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
