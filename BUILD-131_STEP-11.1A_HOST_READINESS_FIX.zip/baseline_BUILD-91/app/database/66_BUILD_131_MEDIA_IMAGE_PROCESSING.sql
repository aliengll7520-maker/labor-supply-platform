/* BUILD 131 - PR-03.4 Image Processing & Thumbnail. */
CREATE TABLE IF NOT EXISTS media_asset_variant (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 media_asset_id BIGINT UNSIGNED NOT NULL,
 variant_key VARCHAR(50) NOT NULL,
 storage_driver VARCHAR(50) NOT NULL DEFAULT 'local',
 storage_key VARCHAR(1000) NOT NULL,
 mime_type VARCHAR(100) NOT NULL,
 size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
 sha256 CHAR(64) NULL,
 width INT UNSIGNED NULL,
 height INT UNSIGNED NULL,
 trang_thai ENUM('processing','ready','failed','deleted') NOT NULL DEFAULT 'processing',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_media_asset_variant(media_asset_id,variant_key),
 UNIQUE KEY uq_media_variant_storage(storage_driver,storage_key),
 INDEX idx_media_variant_status(trang_thai,created_at),
 CONSTRAINT fk_media_asset_variant_asset FOREIGN KEY (media_asset_id) REFERENCES media_asset(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_image_web_max_width','media','Chiều rộng tối đa ảnh Web','2000','integer','BUILD 131: tạo WebP tối ưu từ ảnh gốc.'),
('media_image_thumb_max_width','media','Chiều rộng tối đa thumbnail','400','integer','BUILD 131: tạo thumbnail WebP.'),
('media_image_max_pixels','media','Số điểm ảnh tối đa khi xử lý','25000000','integer','BUILD 131: giới hạn chống ảnh giải mã quá lớn.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
