/* BUILD 04 — TOPIC / LOCATION PROJECTION */
CREATE TABLE IF NOT EXISTS content_discovery_topic_locations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    source_key VARCHAR(120) NULL,
    taxonomy_json LONGTEXT NOT NULL,
    taxonomy_fingerprint CHAR(64) NOT NULL,
    source_updated_at DATETIME NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdtl_source (content_type, source_table, source_id),
    KEY idx_cdtl_fingerprint (taxonomy_fingerprint),
    KEY idx_cdtl_generated_at (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
