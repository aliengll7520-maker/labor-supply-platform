-- BUILD-29 POST-APPLICATION CLEANUP
-- New product boundary: App Website ends its recruitment workflow at application + contact.
-- This migration removes post-employment/interview-management data.

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS hop_thu_gop_y;
DROP TABLE IF EXISTS danh_gia_tin_tuyen_dung;
DROP TABLE IF EXISTS cham_cong_nguoi_lao_dong;
DROP TABLE IF EXISTS ky_cong_nguoi_lao_dong;
DROP TABLE IF EXISTS lich_hen;
DROP TABLE IF EXISTS lich_su_ho_so_lam_viec;
DROP TABLE IF EXISTS ho_so_lam_viec;
SET FOREIGN_KEY_CHECKS=1;

-- Remove legacy post-employment columns from application records when present.
SET @sql = (SELECT IF(COUNT(*)>0,'ALTER TABLE dang_ky_ho_so_phong_van DROP COLUMN ngay_bat_dau','SELECT 1') FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='dang_ky_ho_so_phong_van' AND column_name='ngay_bat_dau');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(COUNT(*)>0,'ALTER TABLE dang_ky_ho_so_phong_van DROP COLUMN ngay_nghi_viec','SELECT 1') FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='dang_ky_ho_so_phong_van' AND column_name='ngay_nghi_viec');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Remove obsolete post-employment reputation counters.
SET @sql = (SELECT IF(COUNT(*)>0,'ALTER TABLE nha_cung_ung DROP COLUMN tong_hen','SELECT 1') FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='nha_cung_ung' AND column_name='tong_hen');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)>0,'ALTER TABLE nha_cung_ung DROP COLUMN tong_nhan_viec','SELECT 1') FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='nha_cung_ung' AND column_name='tong_nhan_viec');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)>0,'ALTER TABLE nha_cung_ung DROP COLUMN ti_le_nhan_viec','SELECT 1') FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='nha_cung_ung' AND column_name='ti_le_nhan_viec');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql = (SELECT IF(COUNT(*)>0,'ALTER TABLE nha_cung_ung DROP COLUMN tong_phan_anh','SELECT 1') FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='nha_cung_ung' AND column_name='tong_phan_anh');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

DELETE FROM quan_tri_quyen WHERE quyen IN ('feedback.view','reviews.view');
