/*
==========================================================
18_NhaCungUng_QuanLy_HoSoLamViec.sql
BƯỚC 08 - QUẢN LÝ HỒ SƠ LÀM VIỆC
==========================================================

- Hồ sơ làm việc là hồ sơ vận hành dài hạn sau khi nhận việc.
- Mỗi lần thay đổi trạng thái / thông tin quản lý được ghi vào lịch sử.
- Không xóa lịch sử.
- Chi tiết Hồ sơ làm việc cho phép Nhà cung ứng xem toàn bộ vòng đời.
==========================================================
*/
CREATE TABLE IF NOT EXISTS lich_su_ho_so_lam_viec (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ho_so_lam_viec_id BIGINT UNSIGNED NOT NULL,
    nguoi_thuc_hien ENUM('nha_cung_ung','quan_tri') NOT NULL DEFAULT 'nha_cung_ung',
    nguoi_thuc_hien_id BIGINT UNSIGNED NOT NULL,
    hanh_dong VARCHAR(80) NOT NULL,
    trang_thai_cu VARCHAR(40) NULL,
    trang_thai_moi VARCHAR(40) NULL,
    ngay_bat_dau DATE NULL,
    ngay_nghi_viec DATE NULL,
    ghi_chu TEXT NULL,
    thoi_gian TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hslv (ho_so_lam_viec_id),
    INDEX idx_time (thoi_gian)
);


-- Append-only policy: application code must INSERT history; UPDATE/DELETE are forbidden
-- at the database role level where the deployment user supports triggers.
