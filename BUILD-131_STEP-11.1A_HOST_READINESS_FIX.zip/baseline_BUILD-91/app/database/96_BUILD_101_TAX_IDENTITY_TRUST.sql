/* BUILD 101 - Tax Identity / Trust Gate
   Mã số thuế là cổng xác thực danh tính doanh nghiệp.
   Chỉ trạng thái được provider xác nhận là active mới tự động kích hoạt tài khoản doanh nghiệp.
*/
ALTER TABLE nha_cung_ung
    ADD COLUMN IF NOT EXISTS tax_status VARCHAR(50) NULL AFTER ma_so_thue,
    ADD COLUMN IF NOT EXISTS tax_verified_at DATETIME NULL AFTER tax_status,
    ADD COLUMN IF NOT EXISTS tax_verification_source VARCHAR(100) NULL AFTER tax_verified_at;

CREATE INDEX idx_nha_cung_ung_tax_status ON nha_cung_ung(tax_status);
CREATE INDEX idx_nha_cung_ung_tax_verified_at ON nha_cung_ung(tax_verified_at);

-- Không tạo UNIQUE trực tiếp trên ma_so_thue để bảo toàn dữ liệu legacy có thể chưa chuẩn hóa.
-- Registration API đã chặn trùng mã số thuế bằng lookup trước khi INSERT.
