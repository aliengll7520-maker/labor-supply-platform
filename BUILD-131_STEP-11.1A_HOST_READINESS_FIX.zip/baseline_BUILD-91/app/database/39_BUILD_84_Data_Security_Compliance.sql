/* BUILD 84 - Data Security & Compliance Foundation
   Luu y: day la lop ky thuat/quan tri du lieu, khong tuyen bo tu dong rang tuan thu phap luat.
*/

CREATE TABLE IF NOT EXISTS danh_muc_du_lieu_bao_mat (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ma_du_lieu VARCHAR(80) UNIQUE NOT NULL,
  ten_du_lieu VARCHAR(255) NOT NULL,
  muc_do ENUM('cong_khai','noi_bo','ca_nhan','nhay_cam') NOT NULL DEFAULT 'ca_nhan',
  muc_dich TEXT NOT NULL,
  chu_the_du_lieu VARCHAR(100) NULL,
  thoi_han_luu_tru VARCHAR(255) NULL,
  cach_xu_ly_khi_het_han TEXT NULL,
  trang_thai ENUM('active','review_required','retired') NOT NULL DEFAULT 'active',
  phien_ban VARCHAR(30) NOT NULL DEFAULT '84.0',
  ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS quyen_truy_cap_du_lieu (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ma_du_lieu VARCHAR(80) NOT NULL,
  vai_tro VARCHAR(50) NOT NULL,
  hanh_dong ENUM('view','create','update','delete','export') NOT NULL,
  pham_vi ENUM('self','related','assigned','platform') NOT NULL DEFAULT 'related',
  cho_phep TINYINT(1) NOT NULL DEFAULT 0,
  ly_do TEXT NULL,
  phien_ban VARCHAR(30) NOT NULL DEFAULT '84.0',
  UNIQUE KEY uq_data_role_action (ma_du_lieu,vai_tro,hanh_dong,pham_vi),
  INDEX idx_data_role (ma_du_lieu,vai_tro)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS nhat_ky_truy_cap_du_lieu (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_type ENUM('worker','supplier','admin','system','anonymous') NOT NULL,
  actor_id BIGINT UNSIGNED NULL,
  ma_du_lieu VARCHAR(80) NOT NULL,
  hanh_dong VARCHAR(30) NOT NULL,
  doi_tuong VARCHAR(100) NULL,
  doi_tuong_id BIGINT UNSIGNED NULL,
  ket_qua ENUM('allowed','denied','masked') NOT NULL,
  ly_do VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_data_access_actor (actor_type,actor_id,created_at),
  INDEX idx_data_access_object (ma_du_lieu,doi_tuong,doi_tuong_id),
  INDEX idx_data_access_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bao_mat_backup_manifest (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  backup_code VARCHAR(80) UNIQUE NOT NULL,
  backup_scope VARCHAR(100) NOT NULL,
  storage_class VARCHAR(100) NOT NULL,
  checksum_sha256 CHAR(64) NULL,
  encrypted TINYINT(1) NOT NULL DEFAULT 1,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  restore_tested TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME NULL,
  notes TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO danh_muc_du_lieu_bao_mat
(ma_du_lieu,ten_du_lieu,muc_do,muc_dich,chu_the_du_lieu,thoi_han_luu_tru,cach_xu_ly_khi_het_han,phien_ban)
VALUES
('worker.identity','Thông tin nhận diện Người lao động','ca_nhan','Tạo tài khoản và xác định hồ sơ','nguoi_lao_dong','Theo chính sách lưu trữ đã phê duyệt','Xóa hoặc ẩn danh theo quy định và mục đích lưu trữ','84.0'),
('worker.phone','Số điện thoại Người lao động','ca_nhan','Đăng nhập và liên hệ tuyển dụng','nguoi_lao_dong','Theo mục đích dịch vụ','Xóa/ẩn danh khi hết mục đích hợp pháp','84.0'),
('supplier.identity','Thông tin Đơn vị sử dụng lao động','ca_nhan','Quản lý tài khoản và tuyển dụng','don_vi_su_dung_lao_dong','Theo chính sách lưu trữ đã phê duyệt','Xóa/ẩn danh theo quy định','84.0'),
('application.profile','Hồ sơ đăng ký phỏng vấn','ca_nhan','Xử lý ứng tuyển và tuyển dụng','nguoi_lao_dong','Theo vòng đời hồ sơ','Xóa/ẩn danh khi hết mục đích','84.0'),
('work.attendance','Hồ sơ làm việc và chấm công','noi_bo','Theo dõi quá trình làm việc và chấm công','hai_ben','Theo chính sách lưu trữ đã phê duyệt','Xóa/ẩn danh khi hết mục đích','119.0'),
('feedback.private','Hòm thư góp ý','ca_nhan','Tiếp nhận và xử lý phản ánh','nguoi_lao_dong','Theo quy trình xử lý góp ý','Ẩn danh/xóa theo chính sách','84.0')
ON DUPLICATE KEY UPDATE ten_du_lieu=VALUES(ten_du_lieu),phien_ban=VALUES(phien_ban),ngay_cap_nhat=CURRENT_TIMESTAMP;

INSERT IGNORE INTO quyen_truy_cap_du_lieu (ma_du_lieu,vai_tro,hanh_dong,pham_vi,cho_phep,ly_do) VALUES
('worker.identity','worker','view','self',1,'Người lao động xem hồ sơ của mình'),
('worker.identity','supplier','view','related',1,'Chỉ khi liên quan hồ sơ tuyển dụng hợp lệ'),
('worker.identity','admin','view','assigned',1,'Theo nhiệm vụ và phân quyền'),
('worker.phone','worker','view','self',1,'Chủ thể dữ liệu'),
('worker.phone','supplier','view','related',1,'Chỉ trong luồng liên hệ hợp lệ; giao diện/API phải che khi không đủ quyền'),
('application.profile','supplier','view','related',1,'Chỉ hồ sơ ứng tuyển vào tin của đơn vị'),
('application.profile','worker','view','self',1,'Chủ thể dữ liệu'),
('application.profile','admin','view','assigned',1,'Theo nhiệm vụ'),
('work.attendance','worker','view','self',1,'Chỉ hồ sơ làm việc của mình'),
('work.attendance','supplier','view','related',1,'Chỉ người lao động thuộc đơn vị'),
('feedback.private','worker','view','self',1,'Người gửi xem góp ý của mình'),
('feedback.private','supplier','view','related',1,'Chỉ góp ý liên quan đơn vị'),
('feedback.private','admin','view','assigned',1,'Xử lý/giám sát theo quyền');
