/* BUILD 98 - Media + Live control plane. No platform fee, wallet or auto collection. */
CREATE TABLE IF NOT EXISTS media_video (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 tac_gia_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 tac_gia_id BIGINT UNSIGNED NOT NULL,
 tieu_de VARCHAR(255) NOT NULL,
 mo_ta TEXT NULL,
 media_url VARCHAR(1000) NOT NULL,
 thumbnail_url VARCHAR(1000) NULL,
 loai_media ENUM('video','short_video') NOT NULL DEFAULT 'video',
 thoi_luong_giay INT UNSIGNED NOT NULL DEFAULT 0,
 luot_xem BIGINT UNSIGNED NOT NULL DEFAULT 0,
 luot_thich BIGINT UNSIGNED NOT NULL DEFAULT 0,
 trang_thai ENUM('cho_duyet','cong_khai','an','tu_choi') NOT NULL DEFAULT 'cho_duyet',
 ngay_tao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_media_status_time(trang_thai,ngay_tao),
 INDEX idx_media_author(tac_gia_type,tac_gia_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS media_chan (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 chan_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 chan_id BIGINT UNSIGNED NOT NULL,
 doi_tuong_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 doi_tuong_id BIGINT UNSIGNED NOT NULL,
 trang_thai ENUM('dang_chan','bo_chan') NOT NULL DEFAULT 'dang_chan',
 ngay_tao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_media_block(chan_type,chan_id,doi_tuong_type,doi_tuong_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS live_chat (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 phong_live_id BIGINT UNSIGNED NOT NULL,
 tac_gia_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 tac_gia_id BIGINT UNSIGNED NOT NULL,
 noi_dung VARCHAR(1000) NOT NULL,
 trang_thai ENUM('cong_khai','an','tu_choi') NOT NULL DEFAULT 'cong_khai',
 ngay_tao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_live_chat_room_time(phong_live_id,id),
 CONSTRAINT fk_live_chat_room FOREIGN KEY(phong_live_id) REFERENCES phong_live_nha_cung_ung(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_video_enabled','media','Video cộng đồng','true','boolean','Video nghề nghiệp và việc làm; kiểm duyệt trước khi công khai.'),
('live_video_enabled','live','Live cộng đồng','true','boolean','Live là chức năng nền tảng, không thu phí sử dụng.'),
('live_stream_transport','live','Lớp truyền video','adapter','string','BUILD 98 quản lý control plane; media transport/RTMP/WebRTC triển khai qua adapter hạ tầng ở bước vận hành.'),
('media_platform_fee','media','Phí nền tảng media','0','integer','Không thu phí đăng/xem video hoặc Live.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
