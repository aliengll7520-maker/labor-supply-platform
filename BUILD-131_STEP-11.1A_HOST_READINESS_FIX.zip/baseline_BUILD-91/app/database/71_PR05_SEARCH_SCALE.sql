/*
 PR-05 — Search Scale
 Search indexes for the public recruitment search path.
 Migration history is immutable; this file is intentionally not tied to a ZIP build number.
*/

ALTER TABLE tin_tuyen_dung
    ADD INDEX idx_job_public_status_date (trang_thai, ngay_dang, id),
    ADD INDEX idx_job_public_status_income (trang_thai, tong_thu_nhap_du_kien, ngay_dang, id),
    ADD FULLTEXT INDEX ft_job_public_search (tieu_de, nganh_nghe, dia_diem);
