/* ==========================================================
10_NhaCungUng_Core.sql
Mở rộng lõi vận hành Nhà cung ứng.
Chạy sau 00..09.
========================================================== */

CREATE TABLE IF NOT EXISTS tai_khoan_nha_cung_ung (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
    ten_dang_nhap VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NULL UNIQUE,
    so_dien_thoai VARCHAR(20) NULL UNIQUE,
    mat_khau_hash VARCHAR(255) NOT NULL,
    trang_thai ENUM('cho_xac_minh','hoat_dong','khoa') NOT NULL DEFAULT 'cho_xac_minh',
    lan_dang_nhap_cuoi DATETIME NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_supplier (nha_cung_ung_id),
    CONSTRAINT fk_tk_ncc FOREIGN KEY (nha_cung_ung_id) REFERENCES nha_cung_ung(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS lich_hen (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL,
    nguoi_tao ENUM('nha_cung_ung','nguoi_lao_dong','quan_tri','he_thong') NOT NULL,
    nguoi_tao_id BIGINT UNSIGNED NULL,
    thoi_gian_hen DATETIME NOT NULL,
    hinh_thuc ENUM('truc_tiep','dien_thoai','video') NOT NULL DEFAULT 'truc_tiep',
    dia_diem TEXT NULL,
    ghi_chu TEXT NULL,
    trang_thai ENUM('cho_xac_nhan','da_dat','da_xac_nhan','da_huy','da_hoan_thanh','vang_mat') NOT NULL DEFAULT 'cho_xac_nhan',
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ho_so (dang_ky_ho_so_phong_van_id),
    INDEX idx_thoi_gian (thoi_gian_hen),
    CONSTRAINT fk_lich_hen_ho_so FOREIGN KEY (dang_ky_ho_so_phong_van_id) REFERENCES dang_ky_ho_so_phong_van(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ho_so_lam_viec (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL,
    nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    tin_tuyen_dung_id BIGINT UNSIGNED NOT NULL,
    ngay_bat_dau DATE NOT NULL,
    ngay_nghi_viec DATE NULL,
    trang_thai ENUM('dang_lam','tam_nghi','da_nghi','da_huy') NOT NULL DEFAULT 'dang_lam',
    ly_do_nghi TEXT NULL,
    ghi_chu TEXT NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_supplier_status (nha_cung_ung_id,trang_thai),
    INDEX idx_worker (nguoi_lao_dong_id),
    INDEX idx_dang_ky_ho_so_phong_van (dang_ky_ho_so_phong_van_id),
    CONSTRAINT fk_hslv_ho_so FOREIGN KEY (dang_ky_ho_so_phong_van_id) REFERENCES dang_ky_ho_so_phong_van(id) ON DELETE RESTRICT,
    CONSTRAINT fk_hslv_ncc FOREIGN KEY (nha_cung_ung_id) REFERENCES nha_cung_ung(id) ON DELETE RESTRICT
);

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta)
VALUES
('ncc_tu_dang_ky','nha_cung_ung','Cho phép Nhà cung ứng tự đăng ký','true','boolean','Nhà cung ứng đăng ký tài khoản mới.'),
('ncc_can_duyet','nha_cung_ung','Nhà cung ứng cần quản trị duyệt','true','boolean','Tài khoản mới ở trạng thái chờ duyệt.'),
('tin_can_duyet','tin_tuyen_dung','Tin mới cần duyệt','true','boolean','Tin mới không tự động công khai.'),
('ncc_cap_nhat_timeline','dang_ky_ho_so_phong_van','Ghi timeline khi Nhà cung ứng thao tác','true','boolean','Mọi thay đổi trạng thái đều ghi lịch sử.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
