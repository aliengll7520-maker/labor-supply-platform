CREATE TABLE IF NOT EXISTS labor_php_sessions (
    session_id VARCHAR(128) NOT NULL,
    last_activity INT UNSIGNED NOT NULL,
    session_data MEDIUMBLOB NOT NULL,
    PRIMARY KEY (session_id),
    KEY idx_labor_php_sessions_activity (last_activity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
