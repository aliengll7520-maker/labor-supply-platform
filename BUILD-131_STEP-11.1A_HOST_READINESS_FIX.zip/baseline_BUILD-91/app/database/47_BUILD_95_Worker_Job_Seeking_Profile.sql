/* BUILD 95 - Hồ sơ Tin tìm việc linh hoạt: mọi trường đều tùy chọn */
ALTER TABLE tin_tim_viec_nguoi_lao_dong
  MODIFY tieu_de VARCHAR(255) NULL COMMENT 'Công việc mong muốn - tùy chọn',
  MODIFY dia_diem_mong_muon VARCHAR(255) NULL COMMENT 'Khu vực mong muốn - tùy chọn',
  ADD COLUMN IF NOT EXISTS vi_tri_mong_muon VARCHAR(255) NULL COMMENT 'Vị trí mong muốn - tùy chọn',
  ADD COLUMN IF NOT EXISTS hinh_thuc_lam_viec VARCHAR(120) NULL COMMENT 'Hình thức làm việc - tùy chọn',
  ADD COLUMN IF NOT EXISTS ca_lam_mong_muon VARCHAR(120) NULL COMMENT 'Ca làm mong muốn - tùy chọn',
  ADD COLUMN IF NOT EXISTS chung_chi TEXT NULL COMMENT 'Chứng chỉ/bằng nghề - tùy chọn',
  ADD COLUMN IF NOT EXISTS video_gioi_thieu_url VARCHAR(500) NULL COMMENT 'Video giới thiệu nghề nghiệp - tùy chọn';
