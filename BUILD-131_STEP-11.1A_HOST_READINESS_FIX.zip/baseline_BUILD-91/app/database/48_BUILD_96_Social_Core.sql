/* BUILD 96 - SOCIAL CORE
 * Feed, bài đăng, follow, like, comment, share, report, block.
 * Không có quảng cáo và không có phí.
 */
ALTER TABLE thong_bao MODIFY loai ENUM(
 'ho_so_moi','cap_nhat_trang_thai','diem_minh_bach','phan_anh','he_thong','nhac_viec',
 'social_like','social_comment','social_share','social_follow'
) NOT NULL;

CREATE TABLE IF NOT EXISTS social_bai_dang (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 loai_tac_gia ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 tac_gia_id BIGINT UNSIGNED NOT NULL,
 loai_bai_dang ENUM('cap_nhat','viec_lam','tim_viec','kien_thuc','hoi_dap') NOT NULL DEFAULT 'cap_nhat',
 noi_dung TEXT NOT NULL,
 hashtag VARCHAR(1000) NULL,
 trang_thai ENUM('cho_duyet','cong_khai','an','tu_choi') NOT NULL DEFAULT 'cong_khai',
 ly_do_kiem_duyet VARCHAR(500) NULL,
 luot_thich INT UNSIGNED NOT NULL DEFAULT 0,
 luot_binh_luan INT UNSIGNED NOT NULL DEFAULT 0,
 luot_chia_se INT UNSIGNED NOT NULL DEFAULT 0,
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_social_feed_status_time(trang_thai,ngay_tao),
 INDEX idx_social_author(loai_tac_gia,tac_gia_id),
 INDEX idx_social_type(loai_bai_dang,trang_thai,ngay_tao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_theo_doi (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_theo_doi_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 nguoi_theo_doi_id BIGINT UNSIGNED NOT NULL,
 doi_tuong_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 doi_tuong_id BIGINT UNSIGNED NOT NULL,
 trang_thai ENUM('dang_theo_doi','da_bo_theo_doi') NOT NULL DEFAULT 'dang_theo_doi',
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_social_follow(nguoi_theo_doi_type,nguoi_theo_doi_id,doi_tuong_type,doi_tuong_id),
 INDEX idx_social_follow_target(doi_tuong_type,doi_tuong_id,trang_thai),
 INDEX idx_social_follow_actor(nguoi_theo_doi_type,nguoi_theo_doi_id,trang_thai)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_thich (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 bai_dang_id BIGINT UNSIGNED NOT NULL,
 tac_gia_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 tac_gia_id BIGINT UNSIGNED NOT NULL,
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_social_like(bai_dang_id,tac_gia_type,tac_gia_id),
 INDEX idx_social_like_post(bai_dang_id),
 CONSTRAINT fk_social_like_post FOREIGN KEY(bai_dang_id) REFERENCES social_bai_dang(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_binh_luan (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 bai_dang_id BIGINT UNSIGNED NOT NULL,
 tac_gia_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 tac_gia_id BIGINT UNSIGNED NOT NULL,
 noi_dung VARCHAR(2000) NOT NULL,
 trang_thai ENUM('cong_khai','an','tu_choi') NOT NULL DEFAULT 'cong_khai',
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_social_comment_post(bai_dang_id,trang_thai,ngay_tao),
 CONSTRAINT fk_social_comment_post FOREIGN KEY(bai_dang_id) REFERENCES social_bai_dang(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_chia_se (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 bai_dang_id BIGINT UNSIGNED NOT NULL,
 tac_gia_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 tac_gia_id BIGINT UNSIGNED NOT NULL,
 ghi_chu VARCHAR(500) NULL,
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_social_share_post(bai_dang_id,ngay_tao),
 CONSTRAINT fk_social_share_post FOREIGN KEY(bai_dang_id) REFERENCES social_bai_dang(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_bao_cao (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 bai_dang_id BIGINT UNSIGNED NULL,
 binh_luan_id BIGINT UNSIGNED NULL,
 nguoi_bao_cao_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 nguoi_bao_cao_id BIGINT UNSIGNED NOT NULL,
 ly_do ENUM('spam','lua_dao','noi_dung_khong_phu_hop','quay_roi','thong_tin_sai','khac') NOT NULL,
 mo_ta VARCHAR(1000) NULL,
 trang_thai ENUM('moi','dang_xu_ly','da_xu_ly','tu_choi') NOT NULL DEFAULT 'moi',
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_social_report_status(trang_thai,ngay_tao),
 INDEX idx_social_report_post(bai_dang_id),
 CONSTRAINT fk_social_report_post FOREIGN KEY(bai_dang_id) REFERENCES social_bai_dang(id) ON DELETE CASCADE,
 CONSTRAINT fk_social_report_comment FOREIGN KEY(binh_luan_id) REFERENCES social_binh_luan(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_chan (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_chan_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 nguoi_chan_id BIGINT UNSIGNED NOT NULL,
 doi_tuong_type ENUM('nguoi_lao_dong','nha_cung_ung') NOT NULL,
 doi_tuong_id BIGINT UNSIGNED NOT NULL,
 trang_thai ENUM('dang_chan','da_bo_chan') NOT NULL DEFAULT 'dang_chan',
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_social_block(nguoi_chan_type,nguoi_chan_id,doi_tuong_type,doi_tuong_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('social_core_enabled','social','Social Core','true','boolean','Feed và tương tác xã hội được bật.'),
('social_feed_public','social','Feed công khai','true','boolean','Người dùng có thể xem Feed công khai mà không cần đăng nhập.'),
('social_platform_fee','social','Phí Social Core','0','number','Social Core không thu phí sử dụng.'),
('social_ads_enabled','social','Quảng cáo Social Core','false','boolean','Chưa bật quảng cáo trong BUILD 96.'),
('social_moderation_enabled','social','Kiểm duyệt Social Core','true','boolean','Bài đăng và bình luận có cơ chế báo cáo/kiểm duyệt.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
