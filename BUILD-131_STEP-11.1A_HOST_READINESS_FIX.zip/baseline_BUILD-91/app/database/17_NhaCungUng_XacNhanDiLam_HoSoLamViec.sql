/*
==========================================================
17_NhaCungUng_XacNhanDiLam_HoSoLamViec.sql
BƯỚC 07 - XÁC NHẬN ĐI LÀM
==========================================================

Khóa nghiệp vụ:
1. Chỉ Đăng ký hồ sơ phỏng vấn ở trạng thái da_phong_van
   mới được xác nhận đi làm.
2. Xác nhận đi làm tạo đúng một Hồ sơ làm việc đang hoạt động.
3. Sau khi tạo Hồ sơ làm việc:
      Đăng ký hồ sơ phỏng vấn -> da_nhan_viec
      Hồ sơ làm việc -> dang_lam
4. Không tạo trùng Hồ sơ làm việc đang hoạt động.
5. Hồ sơ làm việc:
      dang_lam -> tam_nghi -> dang_lam
      dang_lam/tam_nghi -> da_nghi
6. Nghỉ việc bắt buộc có ngày nghỉ và lý do.
7. Mọi thay đổi đều ghi Audit; xác nhận đi làm ghi Timeline.
==========================================================
*/
