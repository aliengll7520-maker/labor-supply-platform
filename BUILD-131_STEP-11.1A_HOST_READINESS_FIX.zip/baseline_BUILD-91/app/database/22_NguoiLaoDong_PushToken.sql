/*
==========================================================
22_NguoiLaoDong_PushToken.sql
Push notification device tokens
Labor Supply Platform
==========================================================
*/

CREATE TABLE nguoi_lao_dong_push_token (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    push_token VARCHAR(255) NOT NULL,
    nen_tang ENUM('android','ios','web') NOT NULL,
    trang_thai ENUM('hoat_dong','vo_hieu') NOT NULL DEFAULT 'hoat_dong',
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uq_worker_token (nguoi_lao_dong_id, push_token),
    INDEX idx_worker_status (nguoi_lao_dong_id, trang_thai),
    CONSTRAINT fk_worker_push_token_worker
        FOREIGN KEY (nguoi_lao_dong_id)
        REFERENCES nguoi_lao_dong(id)
        ON DELETE CASCADE
);
