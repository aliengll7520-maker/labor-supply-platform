/* BUILD 93 - Multi-account Employer Workspace + Live access */
ALTER TABLE tai_khoan_nha_cung_ung
  ADD COLUMN IF NOT EXISTS vai_tro VARCHAR(40) NOT NULL DEFAULT 'nhan_vien',
  ADD COLUMN IF NOT EXISTS ten_hien_thi VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS co_quyen_live TINYINT(1) NOT NULL DEFAULT 0;

UPDATE tai_khoan_nha_cung_ung SET vai_tro='chu_so_huu', co_quyen_live=1, ten_hien_thi=COALESCE(ten_hien_thi, ten_dang_nhap) WHERE id IN (SELECT id FROM (SELECT MIN(id) id FROM tai_khoan_nha_cung_ung GROUP BY nha_cung_ung_id) x);

CREATE INDEX idx_tk_ncc_role ON tai_khoan_nha_cung_ung(nha_cung_ung_id,vai_tro,trang_thai);

CREATE TABLE IF NOT EXISTS phong_live_nha_cung_ung (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
 nguoi_tao_tai_khoan_id BIGINT UNSIGNED NOT NULL,
 tieu_de VARCHAR(255) NOT NULL,
 mo_ta TEXT NULL,
 trang_thai ENUM('nhap','da_len_lich','dang_live','da_ket_thuc','da_huy') NOT NULL DEFAULT 'nhap',
 bat_dau_du_kien DATETIME NULL,
 bat_dau_thuc_te DATETIME NULL,
 ket_thuc DATETIME NULL,
 room_key VARCHAR(100) NOT NULL UNIQUE,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_live_supplier_status(nha_cung_ung_id,trang_thai),
 CONSTRAINT fk_live_supplier FOREIGN KEY(nha_cung_ung_id) REFERENCES nha_cung_ung(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS thanh_vien_phong_live (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 phong_live_id BIGINT UNSIGNED NOT NULL,
 tai_khoan_nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
 vai_tro_live ENUM('chu_phong','dong_phong','quan_ly_chat') NOT NULL DEFAULT 'dong_phong',
 trang_thai ENUM('duoc_phep','dang_tham_gia','roi_phong','bi_chan') NOT NULL DEFAULT 'duoc_phep',
 ngay_tham_gia DATETIME NULL,
 ngay_roi DATETIME NULL,
 UNIQUE KEY uq_live_member(phong_live_id,tai_khoan_nha_cung_ung_id),
 CONSTRAINT fk_live_member_room FOREIGN KEY(phong_live_id) REFERENCES phong_live_nha_cung_ung(id) ON DELETE CASCADE,
 CONSTRAINT fk_live_member_account FOREIGN KEY(tai_khoan_nha_cung_ung_id) REFERENCES tai_khoan_nha_cung_ung(id) ON DELETE CASCADE
);

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('ncc_da_tai_khoan','nha_cung_ung','Cho phép nhiều tài khoản cùng một đơn vị','true','boolean','Một đơn vị sử dụng lao động có thể có nhiều tài khoản đăng nhập đồng thời.'),
('ncc_tai_khoan_dong_thoi','nha_cung_ung','Cho phép đăng nhập đồng thời','true','boolean','Mỗi tài khoản có phiên riêng; nhiều tài khoản cùng một đơn vị có thể làm việc đồng thời.'),
('ncc_live_tai_khoan','live','Tài khoản đơn vị được tham gia Live','true','boolean','Cho phép chủ sở hữu cấp quyền Live cho các tài khoản thành viên.'),
('ncc_live_khong_thu_phi','live','Live không thu phí nền tảng','true','boolean','Quyền Live là chức năng nền tảng, không tạo phí sử dụng nền tảng.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
