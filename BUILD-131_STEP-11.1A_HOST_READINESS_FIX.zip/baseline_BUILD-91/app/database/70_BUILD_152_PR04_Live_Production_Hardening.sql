-- BUILD 152 — PR-04 Live Production hardening
-- Adds heartbeat observability without changing the room state machine.
ALTER TABLE phong_live_nha_cung_ung
    ADD COLUMN IF NOT EXISTS live_heartbeat_at DATETIME NULL AFTER ket_thuc;

CREATE INDEX idx_live_heartbeat ON phong_live_nha_cung_ung(trang_thai,live_heartbeat_at);
