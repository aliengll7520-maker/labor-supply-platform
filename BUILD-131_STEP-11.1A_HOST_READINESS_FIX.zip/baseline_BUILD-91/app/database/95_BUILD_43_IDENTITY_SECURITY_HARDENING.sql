/* BUILD 43 - Identity Security / Abuse / Recovery / Hardening */
CREATE TABLE IF NOT EXISTS identity_password_resets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 identity_id BIGINT UNSIGNED NOT NULL,
 role_code ENUM('worker','employer') NOT NULL,
 account_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL,
 status ENUM('pending','used','expired','cancelled') NOT NULL DEFAULT 'pending',
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 request_ip VARCHAR(64) NULL,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_reset_token(token_hash,status), INDEX idx_reset_identity(identity_id,role_code,status),
 CONSTRAINT fk_reset_identity FOREIGN KEY(identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS identity_security_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 identity_id BIGINT UNSIGNED NULL,
 role_code ENUM('worker','employer') NOT NULL,
 event_code VARCHAR(80) NOT NULL,
 event_status ENUM('completed','pending','blocked','failed') NOT NULL DEFAULT 'completed',
 metadata_json JSON NULL,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_security_identity(identity_id,role_code,ngay_tao), INDEX idx_security_event(event_code,ngay_tao)
);
INSERT INTO cau_hinh_he_thong(ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('identity_password_reset_enabled','identity','Khôi phục mật khẩu','true','boolean','Cho phép luồng khôi phục mật khẩu an toàn cho Worker và Employer.'),
('identity_password_reset_ttl_minutes','identity','Thời gian hiệu lực khôi phục mật khẩu','30','integer','Thời gian hiệu lực của token khôi phục.'),
('identity_password_reset_max_requests','identity','Giới hạn yêu cầu khôi phục','5','integer','Số yêu cầu khôi phục tối đa trong cửa sổ 15 phút.'),
('identity_security_expose_reset_token','identity','Chỉ trả token khôi phục ở môi trường kiểm thử','false','boolean','Production không trả token khôi phục trong API.'),
('identity_auto_merge_disabled','identity','Không tự động gộp danh tính','true','boolean','Không gộp tài khoản tự động trong mọi luồng Identity.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
