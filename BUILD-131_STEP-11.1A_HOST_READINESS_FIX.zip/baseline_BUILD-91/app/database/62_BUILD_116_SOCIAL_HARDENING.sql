/* BUILD 116 - SOCIAL HARDENING & PERFORMANCE
 * Cứng hóa Social: index cho cursor/report moderation và không tạo hệ thống tiền.
 */
ALTER TABLE social_binh_luan
  ADD INDEX idx_social_comment_cursor (bai_dang_id,trang_thai,id),
  ADD INDEX idx_social_comment_parent (bai_dang_id,tra_loi_cho_id,id);

ALTER TABLE social_chia_se
  ADD INDEX idx_social_share_actor (tac_gia_type,tac_gia_id,bai_dang_id,id);

ALTER TABLE social_bao_cao
  ADD INDEX idx_social_report_comment_review (binh_luan_id,trang_thai,id);
