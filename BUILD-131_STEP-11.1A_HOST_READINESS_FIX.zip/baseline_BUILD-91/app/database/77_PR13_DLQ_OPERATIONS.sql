CREATE TABLE IF NOT EXISTS dlq_operation_audit (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dead_letter_id BIGINT UNSIGNED NOT NULL,
    actor_id VARCHAR(191) NOT NULL,
    action VARCHAR(32) NOT NULL,
    reason TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_dlq_audit_item (dead_letter_id),
    KEY idx_dlq_audit_actor_time (actor_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
