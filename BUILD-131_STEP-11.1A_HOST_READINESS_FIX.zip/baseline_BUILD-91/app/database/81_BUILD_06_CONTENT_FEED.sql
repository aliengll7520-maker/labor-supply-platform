-- BUILD 06 — Content Discovery Feed
-- Source of truth remains tin_tuyen_dung. This index supports stable cursor feed reads.
ALTER TABLE tin_tuyen_dung
  ADD INDEX idx_ttd_discovery_feed(trang_thai,id);
