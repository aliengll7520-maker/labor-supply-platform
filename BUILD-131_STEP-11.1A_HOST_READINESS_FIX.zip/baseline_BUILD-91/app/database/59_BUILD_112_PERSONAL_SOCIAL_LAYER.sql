/* BUILD 112 - PERSONAL SOCIAL LAYER
 * Kết bạn, Theo dõi, Trang cá nhân, quyền riêng tư, ảnh/chữ, chia sẻ tin tuyển dụng, trao đổi riêng.
 * Chỉ áp dụng cho tài khoản Người lao động ở lớp cá nhân.
 */

ALTER TABLE social_bai_dang
  ADD COLUMN anh_urls TEXT NULL AFTER hashtag,
  ADD COLUMN loai_nguon VARCHAR(40) NULL AFTER loai_bai_dang,
  ADD COLUMN nguon_id BIGINT UNSIGNED NULL AFTER loai_nguon;

CREATE INDEX idx_social_source ON social_bai_dang(loai_nguon,nguon_id);

CREATE TABLE IF NOT EXISTS social_ket_ban (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_gui_id BIGINT UNSIGNED NOT NULL,
 nguoi_nhan_id BIGINT UNSIGNED NOT NULL,
 trang_thai ENUM('cho_chap_nhan','da_chap_nhan','da_tu_choi','da_huy','da_huy_ket_ban') NOT NULL DEFAULT 'cho_chap_nhan',
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_social_ket_ban(nguoi_gui_id,nguoi_nhan_id),
 INDEX idx_social_friend_receiver(trang_thai,nguoi_nhan_id),
 INDEX idx_social_friend_sender(trang_thai,nguoi_gui_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_quyen_rieng_tu (
 nguoi_lao_dong_id BIGINT UNSIGNED PRIMARY KEY,
 hien_ban_be ENUM('cong_khai','ban_be','chi_minh_toi') NOT NULL DEFAULT 'cong_khai',
 hien_bai_viet ENUM('cong_khai','ban_be','chi_minh_toi') NOT NULL DEFAULT 'cong_khai',
 cho_phep_ket_ban ENUM('tat_ca','ban_be_cua_ban_be','khong_ai') NOT NULL DEFAULT 'tat_ca',
 cho_phep_theo_doi ENUM('tat_ca','khong_ai') NOT NULL DEFAULT 'tat_ca',
 cho_phep_trao_doi ENUM('tat_ca','ban_be','khong_ai') NOT NULL DEFAULT 'ban_be',
 ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS social_trao_doi (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_gui_id BIGINT UNSIGNED NOT NULL,
 nguoi_nhan_id BIGINT UNSIGNED NOT NULL,
 noi_dung VARCHAR(2000) NOT NULL,
 trang_thai ENUM('da_gui','da_doc','da_an') NOT NULL DEFAULT 'da_gui',
 ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_social_chat_pair(nguoi_gui_id,nguoi_nhan_id,ngay_tao),
 INDEX idx_social_chat_receiver(nguoi_nhan_id,trang_thai,ngay_tao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
