/*
==========================================================
13_NhaCungUng_HoSo.sql
BƯỚC 02 - HỒ SƠ NHÀ CUNG ỨNG
==========================================================

Không tạo thêm cột vì cấu trúc 02_NhaCungUng.sql đã có đủ
dữ liệu hồ sơ cần thiết. Mức độ hoàn thiện hồ sơ được tính
từ dữ liệu thực tế tại API /supplier/me.

Mục tiêu:
- Quản lý hồ sơ tập trung.
- Tính phần trăm hoàn thiện.
- Liệt kê trường còn thiếu.
- Cho phép Nhà cung ứng tự cập nhật hồ sơ.
- Nếu hồ sơ đã xác minh mà thay đổi thông tin nhận diện/
  pháp lý, chuyển sang can_xac_minh_lai.
- Không cho Nhà cung ứng tự sửa ghi_chu_quan_tri,
  diem_minh_bach hoặc các chỉ số vận hành.
- Số điện thoại là dữ liệu xác minh riêng, không cho sửa
  qua endpoint hồ sơ thông thường.
==========================================================
*/

-- Không có ALTER TABLE bắt buộc.
-- File được giữ làm mốc kiến trúc cho Bước 02.
