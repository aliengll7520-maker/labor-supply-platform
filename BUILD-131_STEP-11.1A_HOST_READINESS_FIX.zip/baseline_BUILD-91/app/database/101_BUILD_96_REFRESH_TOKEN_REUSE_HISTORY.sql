CREATE TABLE IF NOT EXISTS mobile_auth_refresh_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    session_id BIGINT UNSIGNED NOT NULL,
    identity_id BIGINT UNSIGNED NOT NULL,
    token_family CHAR(64) NOT NULL,
    token_hash CHAR(64) NOT NULL,
    replaced_by_hash CHAR(64) NULL,
    used_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reuse_detected_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_refresh_history_token_hash(token_hash),
    KEY idx_refresh_history_family(token_family, reuse_detected_at),
    KEY idx_refresh_history_session(session_id),
    CONSTRAINT fk_refresh_history_session FOREIGN KEY(session_id)
      REFERENCES mobile_auth_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
