/*
==========================================================
23_NguoiLaoDong_ThongBao.sql
In-app notifications for Worker App
==========================================================
*/

CREATE TABLE thong_bao_nguoi_lao_dong (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    loai VARCHAR(50) NOT NULL,
    tieu_de VARCHAR(255) NOT NULL,
    noi_dung TEXT NOT NULL,
    du_lieu_json JSON NULL,
    da_doc TINYINT(1) NOT NULL DEFAULT 0,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_worker_read (nguoi_lao_dong_id, da_doc, ngay_tao),
    CONSTRAINT fk_worker_notification_worker
        FOREIGN KEY (nguoi_lao_dong_id)
        REFERENCES nguoi_lao_dong(id)
        ON DELETE CASCADE
);
