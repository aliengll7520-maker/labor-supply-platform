/* BUILD 76 - Nền tảng mở rộng tương lai
   Mục tiêu: thêm module, danh mục chuẩn, trường hồ sơ và sự kiện mà không phải phá lõi nghiệp vụ. */

CREATE TABLE IF NOT EXISTS he_thong_module (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  module_key VARCHAR(80) NOT NULL UNIQUE,
  module_name VARCHAR(150) NOT NULL,
  version VARCHAR(30) NOT NULL DEFAULT '1.0.0',
  trang_thai ENUM('active','inactive','planned') NOT NULL DEFAULT 'active',
  thu_tu INT NOT NULL DEFAULT 100,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO he_thong_module (module_key,module_name,version,trang_thai,thu_tu) VALUES
('worker','Người lao động','1.0.0','active',10),
('employer','Đơn vị sử dụng lao động','1.0.0','active',20),
('jobs','Tuyển dụng','1.0.0','active',30),
('applications','Hồ sơ ứng tuyển','1.0.0','active',40),
('work_profiles','Hồ sơ làm việc','1.0.0','active',50),
('attendance','Chấm công','1.0.0','active',60),
('reviews','Đánh giá','1.0.0','active',80),
('feedback','Hòm thư góp ý','1.0.0','active',90),
('union_info','Thông tin Công đoàn','1.0.0','active',100),
('notifications','Thông báo','1.0.0','active',110)
ON DUPLICATE KEY UPDATE module_name=VALUES(module_name),version=VALUES(version),trang_thai=VALUES(trang_thai),thu_tu=VALUES(thu_tu);

CREATE TABLE IF NOT EXISTS danh_muc_chuan (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  loai VARCHAR(60) NOT NULL,
  ma VARCHAR(80) NOT NULL,
  ten VARCHAR(180) NOT NULL,
  mo_ta VARCHAR(500) NULL,
  trang_thai ENUM('active','inactive') NOT NULL DEFAULT 'active',
  thu_tu INT NOT NULL DEFAULT 100,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_danh_muc_chuan (loai,ma),
  INDEX idx_danh_muc_loai (loai,trang_thai,thu_tu)
);

INSERT INTO danh_muc_chuan (loai,ma,ten,mo_ta,thu_tu) VALUES
('nganh_nghe','san_xuat','Sản xuất','Nhóm nghề sản xuất và nhà máy',10),
('nganh_nghe','xay_dung','Xây dựng','Nhóm nghề xây dựng',20),
('nganh_nghe','dich_vu','Dịch vụ','Nhóm nghề dịch vụ',30),
('nganh_nghe','kho_van','Kho vận','Nhóm nghề kho vận và logistics',40),
('nganh_nghe','nha_hang','Nhà hàng','Nhóm nghề nhà hàng và ăn uống',50),
('ky_nang','han','Hàn','Kỹ năng hàn',10),
('ky_nang','dien','Điện','Kỹ năng điện',20),
('ky_nang','co_khi','Cơ khí','Kỹ năng cơ khí',30),
('ky_nang','lai_xe','Lái xe','Kỹ năng lái xe',40),
('ky_nang','van_hanh_may','Vận hành máy','Kỹ năng vận hành máy',50)
ON DUPLICATE KEY UPDATE ten=VALUES(ten),mo_ta=VALUES(mo_ta),thu_tu=VALUES(thu_tu);

CREATE TABLE IF NOT EXISTS mo_ta_truong_ho_so (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  doi_tuong ENUM('worker','supplier') NOT NULL,
  field_key VARCHAR(80) NOT NULL,
  field_label VARCHAR(180) NOT NULL,
  field_type VARCHAR(40) NOT NULL DEFAULT 'text',
  required TINYINT(1) NOT NULL DEFAULT 0,
  trang_thai ENUM('active','inactive') NOT NULL DEFAULT 'active',
  thu_tu INT NOT NULL DEFAULT 100,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_profile_field (doi_tuong,field_key),
  INDEX idx_profile_schema (doi_tuong,trang_thai,thu_tu)
);

INSERT INTO mo_ta_truong_ho_so (doi_tuong,field_key,field_label,field_type,required,thu_tu) VALUES
('worker','skills','Kỹ năng','multi_select',0,60),
('worker','experience_years','Số năm kinh nghiệm','number',0,70),
('worker','certificates','Chứng chỉ','multi_text',0,80),
('worker','education_level','Trình độ','select',0,90),
('worker','preferred_industries','Ngành nghề mong muốn','multi_select',0,100),
('worker','shift_availability','Khả năng làm ca','multi_select',0,110),
('worker','preferred_income','Mức thu nhập mong muốn','money_range',0,120),
('worker','preferred_area','Khu vực có thể làm việc','multi_select',0,130),
('supplier','industry','Ngành nghề','select',0,60),
('supplier','workforce_size','Quy mô lao động','number',0,70),
('supplier','benefits','Chính sách phúc lợi','multi_text',0,80),
('supplier','work_conditions','Điều kiện làm việc','multi_text',0,90),
('supplier','common_skills','Kỹ năng thường tuyển','multi_select',0,100)
ON DUPLICATE KEY UPDATE field_label=VALUES(field_label),field_type=VALUES(field_type),required=VALUES(required),thu_tu=VALUES(thu_tu);

CREATE TABLE IF NOT EXISTS su_kien_he_thong (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_key VARCHAR(100) NOT NULL,
  actor_type VARCHAR(40) NOT NULL,
  actor_id BIGINT UNSIGNED NULL,
  entity_type VARCHAR(60) NULL,
  entity_id BIGINT UNSIGNED NULL,
  payload_json JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_event_key (event_key,created_at),
  INDEX idx_event_actor (actor_type,actor_id,created_at),
  INDEX idx_event_entity (entity_type,entity_id,created_at)
);

CREATE TABLE IF NOT EXISTS api_contract_version (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  contract_key VARCHAR(80) NOT NULL UNIQUE,
  version VARCHAR(30) NOT NULL,
  status ENUM('active','deprecated','planned') NOT NULL DEFAULT 'active',
  min_supported_client VARCHAR(30) NULL,
  notes VARCHAR(500) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO api_contract_version (contract_key,version,status,min_supported_client,notes) VALUES
('public_api','v1','active','v1','Giữ tương thích ngược; thêm endpoint không phá endpoint cũ.')
ON DUPLICATE KEY UPDATE version=VALUES(version),status=VALUES(status),min_supported_client=VALUES(min_supported_client),notes=VALUES(notes);
