-- BUILD 101: replace self-service advertising with third-party Ad Network integration.
-- The platform does NOT sell ad inventory directly and does NOT manage advertiser campaigns,
-- orders, budgets or advertiser payments.

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS ad_events;
DROP TABLE IF EXISTS ad_creatives;
DROP TABLE IF EXISTS ad_campaigns;
DROP TABLE IF EXISTS ad_placements;
SET FOREIGN_KEY_CHECKS=1;

DELETE FROM cau_hinh_he_thong WHERE nhom='advertising';

INSERT INTO cau_hinh_he_thong
(ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta)
VALUES
('build_101_ad_network_enabled','ad_network','Tích hợp mạng quảng cáo','false','boolean','Bật tích hợp mạng quảng cáo bên thứ ba khi đã cấu hình nhà cung cấp.'),
('ad_network_provider','ad_network','Nhà cung cấp mạng quảng cáo','','string','Tên/định danh nhà cung cấp quảng cáo bên thứ ba.'),
('ad_network_publisher_id','ad_network','Publisher ID','','string','Mã publisher do mạng quảng cáo cấp; không phải mã chiến dịch nội bộ.'),
('ad_network_script_url','ad_network','Ad Network Script URL','','string','URL script công khai do mạng quảng cáo cung cấp.'),
('ad_network_feed_slot','ad_network','Vị trí Feed','feed','string','Slot quảng cáo do mạng quảng cáo cung cấp.'),
('ad_network_job_detail_slot','ad_network','Vị trí Job Detail','job_detail','string','Slot quảng cáo do mạng quảng cáo cung cấp.'),
('ad_network_video_slot','ad_network','Vị trí Video','video','string','Slot quảng cáo do mạng quảng cáo cung cấp.'),
('ad_network_live_slot','ad_network','Vị trí Live','live','string','Slot quảng cáo do mạng quảng cáo cung cấp.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
