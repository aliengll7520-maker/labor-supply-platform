/* BUILD 102 - Tax verification evidence + lifecycle support
   Lưu bằng chứng tối thiểu để truy vết lần xác thực mà không lưu raw response.
*/
ALTER TABLE nha_cung_ung
    ADD COLUMN IF NOT EXISTS tax_provider_request_id VARCHAR(150) NULL AFTER tax_verification_source,
    ADD COLUMN IF NOT EXISTS tax_response_hash CHAR(64) NULL AFTER tax_provider_request_id;

CREATE INDEX idx_nha_cung_ung_tax_reverify ON nha_cung_ung(tax_status,tax_verified_at);
