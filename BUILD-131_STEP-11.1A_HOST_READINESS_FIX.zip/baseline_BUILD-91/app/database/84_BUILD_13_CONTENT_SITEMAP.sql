/* BUILD 13 — CONTENT SITEMAP PROJECTION */
CREATE TABLE IF NOT EXISTS content_discovery_sitemaps (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sitemap_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    item_count INT UNSIGNED NOT NULL DEFAULT 0,
    sitemap_xml LONGTEXT NOT NULL,
    sitemap_fingerprint CHAR(64) NOT NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdsitemap_type_source (sitemap_type, source_table),
    KEY idx_cdsitemap_fingerprint (sitemap_fingerprint),
    KEY idx_cdsitemap_generated_at (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
