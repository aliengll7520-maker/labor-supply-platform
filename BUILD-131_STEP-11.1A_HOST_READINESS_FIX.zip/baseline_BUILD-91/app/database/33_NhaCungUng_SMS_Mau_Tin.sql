/*
33_NhaCungUng_SMS_Mau_Tin.sql
BUILD 70 - Mẫu SMS đầu tiên theo từng Nhà cung ứng.
*/

ALTER TABLE nha_cung_ung
    ADD COLUMN sms_mau_tin_dau_tien TEXT NULL AFTER gioi_thieu;

UPDATE nha_cung_ung
SET sms_mau_tin_dau_tien =
    'Xin chao [TEN_NGUOI_LAO_DONG]. Ho so [MA_HO_SO] cua ban da duoc [TEN_NHA_CUNG_UNG] tiep nhan cho vi tri [TEN_TIN]. Vui long phan hoi tin nhan nay neu ban van quan tam de chung toi lien he.'
WHERE sms_mau_tin_dau_tien IS NULL OR TRIM(sms_mau_tin_dau_tien)='';
