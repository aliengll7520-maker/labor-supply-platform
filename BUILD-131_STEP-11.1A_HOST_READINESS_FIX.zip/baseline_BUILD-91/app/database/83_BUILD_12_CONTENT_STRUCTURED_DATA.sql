/* BUILD 12 — CONTENT STRUCTURED DATA PROJECTION */
CREATE TABLE IF NOT EXISTS content_discovery_structured_data (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    schema_json LONGTEXT NOT NULL,
    schema_fingerprint CHAR(64) NOT NULL,
    source_updated_at DATETIME NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdstructured_source (content_type, source_table, source_id),
    KEY idx_cdstructured_fingerprint (schema_fingerprint),
    KEY idx_cdstructured_generated_at (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
