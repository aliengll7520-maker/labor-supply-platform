/*
28_NhaCungUng_KyCong_Ca.sql
Period-level hour breakdown.
*/
ALTER TABLE ky_cong_nguoi_lao_dong
    ADD COLUMN tong_gio_ca_ngay DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER tong_gio,
    ADD COLUMN tong_gio_ca_dem DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER tong_gio_ca_ngay,
    ADD COLUMN tong_gio_tang_ca DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER tong_gio_ca_dem;
