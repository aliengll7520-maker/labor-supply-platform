-- BUILD 83: Tự động duyệt Tin tuyển dụng theo mức rủi ro
ALTER TABLE tin_tuyen_dung
  ADD COLUMN moderation_status ENUM('auto_approved','review','blocked','manual_approved','manual_rejected') NOT NULL DEFAULT 'review' AFTER trang_thai,
  ADD COLUMN moderation_risk_score TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER moderation_status,
  ADD COLUMN moderation_version VARCHAR(30) NULL AFTER moderation_risk_score,
  ADD COLUMN moderation_reasons TEXT NULL AFTER moderation_version,
  ADD COLUMN moderation_at DATETIME NULL AFTER moderation_reasons;

CREATE INDEX idx_tin_moderation_status ON tin_tuyen_dung(moderation_status);
CREATE INDEX idx_tin_moderation_risk ON tin_tuyen_dung(moderation_risk_score);

-- Lưu từng lần quét để có thể kiểm tra/audit về sau.
CREATE TABLE IF NOT EXISTS tin_tuyen_dung_moderation_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tin_tuyen_dung_id BIGINT UNSIGNED NOT NULL,
  engine_version VARCHAR(30) NOT NULL,
  ket_qua ENUM('auto_approved','review','blocked') NOT NULL,
  risk_score TINYINT UNSIGNED NOT NULL DEFAULT 0,
  ly_do TEXT NULL,
  du_lieu_quyet_dinh JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mod_log_tin (tin_tuyen_dung_id),
  INDEX idx_mod_log_created (created_at),
  CONSTRAINT fk_mod_log_tin FOREIGN KEY (tin_tuyen_dung_id) REFERENCES tin_tuyen_dung(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS moderation_rules (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  rule_code VARCHAR(50) UNIQUE NOT NULL,
  rule_name VARCHAR(255) NOT NULL,
  severity ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  action ENUM('review','block') NOT NULL DEFAULT 'review',
  pattern TEXT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  version VARCHAR(30) NOT NULL DEFAULT '83.0',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO moderation_rules (rule_code,rule_name,severity,action,pattern,is_active,version) VALUES
('CONTENT_ADULT','Nội dung tình dục/người lớn','critical','block','&lt;adult-content-patterns-managed-by-policy&gt;',1,'83.0'),
('CONTENT_ILLEGAL','Dấu hiệu nội dung tuyển dụng trái pháp luật','critical','block','&lt;illegal-recruitment-patterns-managed-by-policy&gt;',1,'83.0'),
('CONTENT_FEE','Yêu cầu người lao động nộp tiền/đặt cọc','high','review','&lt;deposit-fee-patterns-managed-by-policy&gt;',1,'83.0'),
('CONTENT_DISCRIMINATION','Yêu cầu tuyển dụng có dấu hiệu phân biệt đối xử','medium','review','&lt;discrimination-patterns-managed-by-policy&gt;',1,'83.0'),
('CONTENT_SCAM','Dấu hiệu lừa đảo/spam','high','review','&lt;scam-patterns-managed-by-policy&gt;',1,'83.0')
ON DUPLICATE KEY UPDATE rule_name=VALUES(rule_name),version=VALUES(version);
