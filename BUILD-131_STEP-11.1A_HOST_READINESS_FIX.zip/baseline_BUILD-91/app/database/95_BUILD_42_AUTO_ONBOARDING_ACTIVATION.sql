/* BUILD 42 - Auto Onboarding & Activation
   Automatic role onboarding state machine; Admin remains only an exception/approval gate for employers.
*/
INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('identity_auto_onboarding_v2','identity','Auto Onboarding v2','true','boolean','Tự động tính toán trạng thái onboarding cho Worker và Employer.'),
('identity_worker_auto_activation','identity','Tự động kích hoạt Worker','true','boolean','Worker đủ điều kiện sẽ tự chuyển sang sẵn sàng mà không cần Admin kích hoạt thủ công.'),
('identity_employer_admin_gate','identity','Cổng duyệt Employer','true','boolean','Employer chỉ sẵn sàng sau khi hồ sơ, xác minh liên hệ và phê duyệt vận hành đều đạt.'),
('identity_onboarding_exception_mode','identity','Exception-only Admin','true','boolean','Admin chỉ can thiệp khi onboarding rơi vào ngoại lệ hoặc cần phê duyệt bắt buộc.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
