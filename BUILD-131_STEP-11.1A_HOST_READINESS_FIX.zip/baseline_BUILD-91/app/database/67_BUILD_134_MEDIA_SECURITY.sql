/* BUILD 134 - PR-03.5 Media Security */
INSERT INTO cau_hinh_he_thong (ma_cau_hinh, nhom, ten_cau_hinh, gia_tri, kieu_du_lieu, mo_ta, trang_thai)
VALUES
('media_security_max_pixels','media','Điểm ảnh tối đa khi nhận ảnh','25000000','number','BUILD 134: chặn ảnh có kích thước giải mã quá lớn.','bat'),
('media_security_filename_max','media','Độ dài tên file Media tối đa','255','number','BUILD 134: tên file chỉ là metadata, không được dùng làm storage path.','bat'),
('media_security_signature_check','media','Kiểm tra chữ ký file','true','boolean','BUILD 134: xác minh magic bytes theo MIME thực tế trước khi lưu.','bat'),
('media_security_storage_private','media','Media Storage riêng tư mặc định','true','boolean','BUILD 134: Media upload không được phục vụ trực tiếp từ web root.','bat')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri), mo_ta=VALUES(mo_ta), trang_thai=VALUES(trang_thai);
