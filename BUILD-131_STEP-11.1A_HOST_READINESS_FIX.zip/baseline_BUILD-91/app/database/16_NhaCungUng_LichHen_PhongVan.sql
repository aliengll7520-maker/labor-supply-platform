/*
==========================================================
16_NhaCungUng_LichHen_PhongVan.sql
BƯỚC 06 - LỊCH HẸN / PHỎNG VẤN
==========================================================

Khóa nghiệp vụ:
1. Chỉ tạo lịch sau khi đã liên hệ.
2. Một hồ sơ chỉ có một lịch tương lai đang hiệu lực.
3. Tạo lịch từ da_lien_he -> da_hen.
4. Hoàn thành lịch -> da_phong_van.
5. Lịch đã hủy/hoàn thành/vắng mặt không quay lại trạng thái đang xử lý.
6. Mọi thay đổi lịch được ghi Audit.
7. Lịch hẹn luôn thuộc về Đăng ký hồ sơ phỏng vấn của đúng Nhà cung ứng.
==========================================================
*/
