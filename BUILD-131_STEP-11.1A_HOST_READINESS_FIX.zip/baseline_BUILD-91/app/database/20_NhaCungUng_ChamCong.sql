/*
==========================================================
20_NhaCungUng_ChamCong.sql
BƯỚC 09 - CHẤM CÔNG
==========================================================
*/
CREATE TABLE IF NOT EXISTS cham_cong_nguoi_lao_dong (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ho_so_lam_viec_id BIGINT UNSIGNED NOT NULL,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
    ngay_cong DATE NOT NULL,
    trang_thai ENUM('di_lam','nghi_phep','nghi_khong_phep','vang') NOT NULL,
    so_gio DECIMAL(5,2) NOT NULL DEFAULT 0,
    ghi_chu TEXT NULL,
    nguoi_cap_nhat_id BIGINT UNSIGNED NOT NULL,
    thoi_gian_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_hslv_ngay (ho_so_lam_viec_id,ngay_cong),
    INDEX idx_worker_date (nguoi_lao_dong_id,ngay_cong),
    INDEX idx_supplier_date (nha_cung_ung_id,ngay_cong)
);
