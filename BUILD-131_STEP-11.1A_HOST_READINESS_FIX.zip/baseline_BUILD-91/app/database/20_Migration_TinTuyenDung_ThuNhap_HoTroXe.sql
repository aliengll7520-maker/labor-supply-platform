-- ==========================================================
-- 20_Migration_TinTuyenDung_ThuNhap_HoTroXe.sql
-- LABOR SUPPLY PLATFORM
-- Bổ sung dữ liệu bắt buộc cho Tin tuyển dụng
-- ==========================================================

-- MỤC ĐÍCH:
-- Bổ sung 2 trường:
-- 1. Tổng thu nhập dự kiến
-- 2. Hỗ trợ tiền xe cho Người lao động ở xa
--
-- QUY TẮC:
-- - Tổng thu nhập dự kiến: bắt buộc, một mức tiền cụ thể > 0.
-- - Hỗ trợ tiền xe: bắt buộc, một mức tiền cụ thể >= 0.
-- - 0 = Nhà cung ứng không hỗ trợ tiền xe.
-- - Không sử dụng khoảng giá trị.
-- - Không để NULL.
--
-- LƯU Ý:
-- Migration này dành cho database đã tồn tại từ schema cũ.
-- Schema mới đã được cập nhật tại:
-- database/03_TinTuyenDung.sql
-- ==========================================================
ALTER TABLE tin_tuyen_dung
    ADD COLUMN tong_thu_nhap_du_kien DECIMAL(12,2) NULL
        COMMENT 'Tổng thu nhập dự kiến do Nhà cung ứng bắt buộc khai báo'
        AFTER luong_co_ban,

    ADD COLUMN ho_tro_tien_xe_nguoi_lao_dong_o_xa DECIMAL(12,2) NOT NULL DEFAULT 0
        COMMENT 'Hỗ trợ tiền xe cho Người lao động ở xa; 0 = không hỗ trợ'
        AFTER tong_thu_nhap_du_kien;
-- ==========================================================
-- KIỂM TRA DỮ LIỆU SAU KHI MIGRATION
-- ==========================================================

SELECT
    id,
    ma_tin,
    luong_co_ban,
    tong_thu_nhap_du_kien,
    ho_tro_tien_xe_nguoi_lao_dong_o_xa
FROM tin_tuyen_dung
ORDER BY id DESC;
