-- BUILD-59: FCM registration tokens can exceed legacy Expo token length.
ALTER TABLE nguoi_lao_dong_push_token MODIFY push_token VARCHAR(4096) NOT NULL;
