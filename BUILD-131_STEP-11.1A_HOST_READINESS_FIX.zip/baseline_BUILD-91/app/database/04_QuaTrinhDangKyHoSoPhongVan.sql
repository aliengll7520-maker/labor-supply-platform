/*
==========================================================
04_QuaTrinhDangKyHoSoPhongVan.sql
QUÁ TRÌNH ĐĂNG KÝ HỒ SƠ PHỎNG VẤN
Labor Supply Platform
Version: 3.0
==========================================================

Mục đích:

Lưu toàn bộ LỊCH SỬ của một Đăng ký hồ sơ phỏng vấn.

Không lưu lại hồ sơ Người lao động.
Không lưu lại hồ sơ Nhà cung ứng.
Không lưu lại Tin tuyển dụng.

Thông tin chính nằm ở:

00_DangKyHoSoPhongVan

Bảng 04 chỉ trả lời:

- Hồ sơ được tạo khi nào?
- Ai thực hiện hành động?
- Hành động gì?
- Hành động xảy ra lúc nào?
- Có ghi chú/đối chiếu gì?

==========================================================
*/

CREATE TABLE qua_trinh_dang_ky_ho_so_phong_van (

    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL
        COMMENT 'ID Đăng ký hồ sơ phỏng vấn',

    nguoi_thuc_hien ENUM(
        'quan_tri',
        'nha_cung_ung',
        'nguoi_lao_dong',
        'he_thong'
    ) NOT NULL
        COMMENT 'Chủ thể thực hiện hành động',

    nguoi_thuc_hien_id BIGINT UNSIGNED NULL
        COMMENT 'ID người thực hiện, NULL nếu hệ thống',

    hanh_dong ENUM(
        'tao_dang_ky',
        'mo_so_dien_thoai',
        'da_xem',
        'da_lien_he',
        'khong_lien_he_duoc',
        'da_hen',
        'da_phong_van',
        'da_nhan_viec',
        'khong_phu_hop',
        'da_huy',
        'nguoi_lao_dong_xac_nhan',
        'nha_cung_ung_xac_nhan',
        'phan_anh',
        'dong_ho_so'
    ) NOT NULL
        COMMENT 'Hành động trong Quá trình đăng ký hồ sơ phỏng vấn',

    ghi_chu TEXT NULL
        COMMENT 'Ghi chú của hành động',

    thoi_gian DATETIME NOT NULL
        DEFAULT CURRENT_TIMESTAMP
        COMMENT 'Thời điểm hành động xảy ra',

    INDEX idx_ho_so (
        dang_ky_ho_so_phong_van_id
    ),

    INDEX idx_nguoi_thuc_hien (
        nguoi_thuc_hien,
        nguoi_thuc_hien_id
    ),

    INDEX idx_hanh_dong (
        hanh_dong
    ),

    INDEX idx_thoi_gian (
        thoi_gian
    ),

    INDEX idx_ho_so_thoi_gian (
        dang_ky_ho_so_phong_van_id,
        thoi_gian
    )

);
