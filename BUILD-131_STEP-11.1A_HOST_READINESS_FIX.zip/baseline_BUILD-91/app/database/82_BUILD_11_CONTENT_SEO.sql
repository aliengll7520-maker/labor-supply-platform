/* BUILD 11 — CONTENT SEO PROJECTION */
CREATE TABLE IF NOT EXISTS content_discovery_seo (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    seo_json LONGTEXT NOT NULL,
    seo_fingerprint CHAR(64) NOT NULL,
    source_updated_at DATETIME NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdseo_source (content_type, source_table, source_id),
    KEY idx_cdseo_fingerprint (seo_fingerprint),
    KEY idx_cdseo_generated_at (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
