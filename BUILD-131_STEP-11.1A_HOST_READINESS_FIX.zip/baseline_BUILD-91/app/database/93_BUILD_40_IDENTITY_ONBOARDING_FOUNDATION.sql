/* BUILD 40 - Identity & Onboarding Foundation
   ONE IDENTITY -> MULTIPLE ROLES -> AUTOMATIC ONBOARDING foundation.
   Non-breaking bridge over existing Worker and Employer/Supplier accounts.
*/

CREATE TABLE IF NOT EXISTS identity_principals (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identity_key VARCHAR(120) NOT NULL UNIQUE,
    display_name VARCHAR(255) NULL,
    email VARCHAR(255) NULL,
    phone VARCHAR(30) NULL,
    trang_thai ENUM('hoat_dong','cho_xac_minh','khoa') NOT NULL DEFAULT 'hoat_dong',
    onboarding_status ENUM('moi','dang_onboarding','san_sang','can_xu_ly') NOT NULL DEFAULT 'moi',
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_identity_email(email),
    INDEX idx_identity_phone(phone),
    INDEX idx_identity_onboarding(onboarding_status,trang_thai)
);

CREATE TABLE IF NOT EXISTS identity_role_memberships (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identity_id BIGINT UNSIGNED NOT NULL,
    role_code ENUM('worker','employer') NOT NULL,
    worker_id BIGINT UNSIGNED NULL,
    supplier_id BIGINT UNSIGNED NULL,
    supplier_account_id BIGINT UNSIGNED NULL,
    role_status ENUM('active','pending','blocked') NOT NULL DEFAULT 'active',
    onboarding_status ENUM('moi','dang_onboarding','san_sang','can_xu_ly') NOT NULL DEFAULT 'moi',
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_identity_worker(identity_id,worker_id),
    UNIQUE KEY uq_identity_supplier_account(identity_id,supplier_account_id),
    INDEX idx_identity_role(identity_id,role_code,role_status),
    INDEX idx_worker_identity(worker_id),
    INDEX idx_supplier_identity(supplier_id),
    CONSTRAINT fk_identity_role_identity FOREIGN KEY(identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS identity_links (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identity_id BIGINT UNSIGNED NOT NULL,
    linked_identity_id BIGINT UNSIGNED NOT NULL,
    link_method ENUM('verified_phone','verified_email','verified_provider','admin_verified') NOT NULL,
    trang_thai ENUM('cho_xac_nhan','hoat_dong','vo_hieu') NOT NULL DEFAULT 'cho_xac_nhan',
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_identity_link(identity_id,linked_identity_id,link_method),
    INDEX idx_identity_link(identity_id,trang_thai),
    CONSTRAINT fk_identity_link_source FOREIGN KEY(identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE,
    CONSTRAINT fk_identity_link_target FOREIGN KEY(linked_identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS identity_onboarding_events (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identity_id BIGINT UNSIGNED NOT NULL,
    role_code ENUM('worker','employer') NOT NULL,
    event_code VARCHAR(80) NOT NULL,
    event_status ENUM('completed','pending','failed') NOT NULL DEFAULT 'completed',
    metadata_json JSON NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_identity_onboarding_events(identity_id,role_code,ngay_tao),
    CONSTRAINT fk_identity_onboarding_identity FOREIGN KEY(identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE
);

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('identity_foundation_enabled','identity','Identity Foundation','true','boolean','Bật lớp Identity chung trên nền tài khoản hiện hữu.'),
('identity_auto_onboarding','identity','Tự động khởi tạo onboarding','true','boolean','Tài khoản mới tự tạo trạng thái onboarding mà không cần quản trị viên khởi tạo thủ công.'),
('identity_auto_merge_disabled','identity','Không tự động gộp danh tính','true','boolean','Không tự động gộp hai tài khoản chỉ vì trùng số điện thoại/email; việc liên kết phải qua bước xác minh.'),
('identity_multiple_roles','identity','Một danh tính có nhiều vai trò','true','boolean','Cho phép một Identity sở hữu nhiều role khi được liên kết/xác minh hợp lệ.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
