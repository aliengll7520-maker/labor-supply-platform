/* BUILD 26 - Admin Scope: revoke direct access to worker application/work/attendance data */
DELETE FROM quan_tri_quyen
WHERE quyen IN ('applications.view','work_records.view','attendance.view');
