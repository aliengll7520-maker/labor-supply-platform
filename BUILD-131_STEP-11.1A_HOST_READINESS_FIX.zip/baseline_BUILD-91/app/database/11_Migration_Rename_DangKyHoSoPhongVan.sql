/* ==========================================================
11_Migration_Rename_DangKyHoSoPhongVan.sql
MIGRATION DI SẢN — chỉ dùng khi database cũ còn tên:
ho_so_phong_van / qua_trinh_ket_noi / ho_so_ket_noi_id.
Không chạy file này trên database mới đã dùng bộ 00..10.
========================================================== */

SET @db = DATABASE();

SET @sql = (
 SELECT IF(COUNT(*) > 0,
   'RENAME TABLE ho_so_phong_van TO dang_ky_ho_so_phong_van',
   'SELECT 1')
 FROM information_schema.tables
 WHERE table_schema=@db AND table_name='ho_so_phong_van'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
 SELECT IF(COUNT(*) > 0,
   'RENAME TABLE qua_trinh_ket_noi TO qua_trinh_dang_ky_ho_so_phong_van',
   'SELECT 1')
 FROM information_schema.tables
 WHERE table_schema=@db AND table_name='qua_trinh_ket_noi'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

/* Các đổi tên cột bên dưới chỉ chạy nếu cột cũ còn tồn tại. */
SET @sql = (
 SELECT IF(COUNT(*) > 0,
   'ALTER TABLE qua_trinh_dang_ky_ho_so_phong_van CHANGE COLUMN ho_so_ket_noi_id dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL',
   'SELECT 1')
 FROM information_schema.columns
 WHERE table_schema=@db AND table_name='qua_trinh_dang_ky_ho_so_phong_van' AND column_name='ho_so_ket_noi_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

/* Các bảng tham chiếu khác: đổi tên cột cũ nếu thực sự tồn tại. */
SET @targets='05_DiemMinhBach';

/*
Lưu ý: các schema mới trong 00..10 đã dùng tên chính thức
"Đăng ký hồ sơ phỏng vấn" nên không cần migration này.
*/
