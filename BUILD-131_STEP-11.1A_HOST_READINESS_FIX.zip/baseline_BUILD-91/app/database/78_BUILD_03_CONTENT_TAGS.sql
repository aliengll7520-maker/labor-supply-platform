/*
 * BUILD 03 — CONTENT TAGS / HASHTAGS
 * Labor Supply Platform
 *
 * Generated tags are a deterministic projection of Tin tuyển dụng.
 * tin_tuyen_dung remains the authoritative source.
 */

CREATE TABLE IF NOT EXISTS content_discovery_tags (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    source_key VARCHAR(120) NULL,
    tags_json LONGTEXT NOT NULL,
    hashtags_json LONGTEXT NOT NULL,
    tag_fingerprint CHAR(64) NOT NULL,
    source_updated_at DATETIME NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdt_source (content_type, source_table, source_id),
    KEY idx_cdt_fingerprint (tag_fingerprint),
    KEY idx_cdt_generated_at (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
