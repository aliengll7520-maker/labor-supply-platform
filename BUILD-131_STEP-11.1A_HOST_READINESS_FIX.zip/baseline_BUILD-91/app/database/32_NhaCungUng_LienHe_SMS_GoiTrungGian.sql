/*
32_NhaCungUng_LienHe_SMS_GoiTrungGian.sql
BUILD 69 - Liên hệ có kiểm soát.

- Số điện thoại hiển thị được che 3 số ở giữa.
- SMS đầu tiên do hệ thống gửi khi hồ sơ phỏng vấn được tạo.
- Chi phí SMS thuộc Nhà cung ứng.
- Cuộc gọi dùng số trung gian/masked call; không công khai số thật.
*/

ALTER TABLE dang_ky_ho_so_phong_van
    ADD COLUMN nguoi_lao_dong_da_phan_hoi TINYINT(1) NOT NULL DEFAULT 0 AFTER nguoi_lao_dong_xac_nhan,
    ADD COLUMN nguoi_lao_dong_phan_hoi_at DATETIME NULL AFTER nguoi_lao_dong_da_phan_hoi;

CREATE TABLE IF NOT EXISTS lien_he_tu_dong_nguoi_lao_dong (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL,
    nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
    kenh ENUM('sms','cuoc_goi') NOT NULL,
    loai ENUM('tin_nhan_dau_tien','goi_trung_gian') NOT NULL,
    so_dien_thoai_dich VARCHAR(20) NOT NULL,
    noi_dung TEXT NULL,
    trang_thai ENUM('cho_gui','da_gui','da_phan_hoi','that_bai','cho_nha_cung_cap') NOT NULL DEFAULT 'cho_gui',
    ma_nha_cung_cap VARCHAR(120) NULL,
    loi TEXT NULL,
    phan_hoi_noi_dung TEXT NULL,
    phan_hoi_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_auto_contact_registration (dang_ky_ho_so_phong_van_id),
    INDEX idx_auto_contact_supplier (nha_cung_ung_id,created_at),
    CONSTRAINT fk_auto_contact_registration FOREIGN KEY (dang_ky_ho_so_phong_van_id)
        REFERENCES dang_ky_ho_so_phong_van(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS phien_goi_trung_gian (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    dang_ky_ho_so_phong_van_id BIGINT UNSIGNED NOT NULL,
    nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    so_trung_gian VARCHAR(30) NULL,
    trang_thai ENUM('tao_moi','dang_goi','ket_thuc','that_bai') NOT NULL DEFAULT 'tao_moi',
    ma_nha_cung_cap VARCHAR(120) NULL,
    thoi_gian_bat_dau DATETIME NULL,
    thoi_gian_ket_thuc DATETIME NULL,
    thoi_luong_giay INT UNSIGNED NULL,
    loi TEXT NULL,
    phan_hoi_noi_dung TEXT NULL,
    phan_hoi_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_masked_call_registration (dang_ky_ho_so_phong_van_id),
    INDEX idx_masked_call_supplier (nha_cung_ung_id,created_at),
    CONSTRAINT fk_masked_call_registration FOREIGN KEY (dang_ky_ho_so_phong_van_id)
        REFERENCES dang_ky_ho_so_phong_van(id) ON DELETE CASCADE
);

INSERT INTO cau_hinh_he_thong
    (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta,trang_thai)
VALUES
    ('lien_he_sms_tu_dong','lien_he','Tự động gửi SMS đầu tiên','true','boolean','Khi có Đăng ký hồ sơ phỏng vấn mới, hệ thống tạo/gửi SMS đầu tiên tới Người lao động. Chi phí do Nhà cung ứng chịu.','bat'),
    ('lien_he_nguoi_that_sau_phan_hoi','lien_he','Chỉ liên hệ người thật sau phản hồi','true','boolean','Sau SMS đầu tiên, Nhà cung ứng chỉ thực hiện liên hệ người thật khi Người lao động đã phản hồi.','bat'),
    ('lien_he_che_3_so','lien_he','Che 3 số điện thoại','true','boolean','Mọi giao diện và API công khai giữa hai bên đều che 3 số ở giữa.','bat')
ON DUPLICATE KEY UPDATE
    ten_cau_hinh=VALUES(ten_cau_hinh),
    mo_ta=VALUES(mo_ta),
    ngay_cap_nhat=CURRENT_TIMESTAMP;
