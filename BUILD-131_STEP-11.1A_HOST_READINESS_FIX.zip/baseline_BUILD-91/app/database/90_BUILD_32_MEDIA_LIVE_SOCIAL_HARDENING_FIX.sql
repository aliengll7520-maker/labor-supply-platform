-- BUILD 32: đồng bộ cấu hình Media/Social/Live với code.
-- Idempotent: có thể chạy lại.
INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta,trang_thai) VALUES
('social_post_max_images','social','Số ảnh tối đa trong một bài đăng','6','number','BUILD 32: backend đọc trực tiếp cấu hình; giới hạn thực tế tối đa 6.','bat'),
('live_chat_retention_after_end_seconds','live','Thời gian giữ chat sau khi Live kết thúc','0','number','BUILD 32: 0 = xóa ngay khi Live kết thúc; >0 = worker tự dọn theo TTL.','bat'),
('live_recording_enabled','live','Lưu bản ghi video Live','false','boolean','BUILD 32: chính sách sản phẩm không lưu Replay tự động.','bat')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),kieu_du_lieu=VALUES(kieu_du_lieu),mo_ta=VALUES(mo_ta),trang_thai='bat';
