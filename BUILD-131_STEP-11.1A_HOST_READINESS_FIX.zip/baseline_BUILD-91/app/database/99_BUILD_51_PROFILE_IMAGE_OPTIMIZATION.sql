/* BUILD 51 - Profile Image Optimization
 * Worker avatars and employer logos receive a dedicated WebP profile variant.
 * Target: max 200x200 px and <= 50 KiB (51,200 bytes).
 */
INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_image_profile_max_width','media','Chiều rộng tối đa ảnh đại diện/logo','200','integer','BUILD 51: profile WebP tối đa 200x200.'),
('media_image_profile_max_height','media','Chiều cao tối đa ảnh đại diện/logo','200','integer','BUILD 51: profile WebP tối đa 200x200.'),
('media_image_profile_max_bytes','media','Dung lượng tối đa ảnh đại diện/logo','51200','integer','BUILD 51: profile WebP không vượt 50 KiB.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
