-- BUILD-39 — TRUST & REPUTATION CORE
-- Two-way community reputation based only on a valid App Website application connection.
-- No attendance, employment, payroll, work-profile or leave management is used.

CREATE TABLE IF NOT EXISTS trust_reviews (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reviewer_type ENUM('worker','employer') NOT NULL,
  reviewer_id BIGINT UNSIGNED NOT NULL,
  reviewee_type ENUM('worker','employer') NOT NULL,
  reviewee_id BIGINT UNSIGNED NOT NULL,
  context_type ENUM('application') NOT NULL DEFAULT 'application',
  context_id BIGINT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  review_text VARCHAR(1000) NULL,
  status ENUM('cong_khai','an','cho_xu_ly') NOT NULL DEFAULT 'cong_khai',
  moderation_reason VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_trust_review_context (reviewer_type,reviewer_id,reviewee_type,reviewee_id,context_type,context_id),
  INDEX idx_trust_reviewee (reviewee_type,reviewee_id,status),
  INDEX idx_trust_reviewer (reviewer_type,reviewer_id),
  INDEX idx_trust_context (context_type,context_id)
);

CREATE TABLE IF NOT EXISTS trust_review_reports (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  review_id BIGINT UNSIGNED NOT NULL,
  reporter_type ENUM('worker','employer') NOT NULL,
  reporter_id BIGINT UNSIGNED NOT NULL,
  reason VARCHAR(100) NOT NULL,
  description VARCHAR(500) NULL,
  status ENUM('mo','dang_xu_ly','da_xu_ly','tu_choi') NOT NULL DEFAULT 'mo',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_trust_report_review (review_id),
  INDEX idx_trust_report_status (status)
);
