/* BUILD 75 - Đánh giá, Hòm thư góp ý, thông tin Công đoàn */
ALTER TABLE tin_tuyen_dung
  ADD COLUMN diem_danh_gia DECIMAL(3,2) NOT NULL DEFAULT 0,
  ADD COLUMN luot_danh_gia INT UNSIGNED NOT NULL DEFAULT 0;

ALTER TABLE nha_cung_ung
  ADD COLUMN cong_doan_trang_thai ENUM('co','khong','khong_khai_bao') NOT NULL DEFAULT 'khong_khai_bao',
  ADD COLUMN cong_doan_ten VARCHAR(255) NULL,
  ADD COLUMN cong_doan_lien_he VARCHAR(255) NULL;

ALTER TABLE ho_so_nghe_nghiep_nguoi_lao_dong
  ADD COLUMN cong_doan_trang_thai ENUM('co','khong','khong_khai_bao') NOT NULL DEFAULT 'khong_khai_bao',
  ADD COLUMN cong_doan_ten VARCHAR(255) NULL;

CREATE TABLE IF NOT EXISTS danh_gia_tin_tuyen_dung (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tin_tuyen_dung_id BIGINT UNSIGNED NOT NULL,
  ho_so_lam_viec_id BIGINT UNSIGNED NOT NULL,
  nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
  nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
  so_sao TINYINT UNSIGNED NOT NULL,
  nhan_xet VARCHAR(1000) NULL,
  trang_thai ENUM('cong_khai','an','cho_xu_ly') NOT NULL DEFAULT 'cong_khai',
  ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_danh_gia_nguoi_lao_dong_tin (nguoi_lao_dong_id,tin_tuyen_dung_id),
  INDEX idx_danh_gia_tin (tin_tuyen_dung_id),
  INDEX idx_danh_gia_nha_cung_ung (nha_cung_ung_id),
  CONSTRAINT fk_dg_tin FOREIGN KEY (tin_tuyen_dung_id) REFERENCES tin_tuyen_dung(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dg_hslv FOREIGN KEY (ho_so_lam_viec_id) REFERENCES ho_so_lam_viec(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS hop_thu_gop_y (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ma_gop_y VARCHAR(30) NOT NULL UNIQUE,
  nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
  nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
  tin_tuyen_dung_id BIGINT UNSIGNED NULL,
  ho_so_lam_viec_id BIGINT UNSIGNED NULL,
  chu_de ENUM('cong_viec','cham_cong','luong','dieu_kien_lam_viec','tin_tuyen_dung','phu_cap','ung_xu','khac') NOT NULL DEFAULT 'khac',
  noi_dung TEXT NOT NULL,
  trang_thai ENUM('da_gui','da_tiep_nhan','dang_xu_ly','da_phan_hoi','da_dong') NOT NULL DEFAULT 'da_gui',
  phan_hoi_don_vi TEXT NULL,
  phan_hoi_quan_tri TEXT NULL,
  ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ngay_cap_nhat TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_gopy_worker (nguoi_lao_dong_id),
  INDEX idx_gopy_supplier (nha_cung_ung_id),
  INDEX idx_gopy_tin (tin_tuyen_dung_id),
  INDEX idx_gopy_status (trang_thai)
);

CREATE TABLE IF NOT EXISTS gop_y_lich_su (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  gop_y_id BIGINT UNSIGNED NOT NULL,
  nguoi_thao_tac ENUM('nguoi_lao_dong','nha_cung_ung','quan_tri','he_thong') NOT NULL,
  nguoi_thao_tac_id BIGINT UNSIGNED NULL,
  hanh_dong VARCHAR(100) NOT NULL,
  noi_dung TEXT NULL,
  ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_gyls_gopy (gop_y_id)
);
