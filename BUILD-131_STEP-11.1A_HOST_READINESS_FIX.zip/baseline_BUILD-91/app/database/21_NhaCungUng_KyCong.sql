/*
21_NhaCungUng_KyCong.sql
Kỳ công là bản ghi tổng hợp chấm công theo một khoảng thời gian.
Không lưu dữ liệu tiền, thanh toán hoặc đối soát tài chính.
*/
CREATE TABLE IF NOT EXISTS ky_cong_nguoi_lao_dong (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ho_so_lam_viec_id BIGINT UNSIGNED NOT NULL,
    nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
    nha_cung_ung_id BIGINT UNSIGNED NOT NULL,
    tu_ngay DATE NOT NULL,
    den_ngay DATE NOT NULL,
    trang_thai ENUM('mo','da_chot') NOT NULL DEFAULT 'mo',
    tong_ngay_cong DECIMAL(8,2) NOT NULL DEFAULT 0,
    tong_gio DECIMAL(10,2) NOT NULL DEFAULT 0,
    ngay_chot TIMESTAMP NULL,
    nguoi_chot_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_profile_period (ho_so_lam_viec_id,tu_ngay,den_ngay),
    INDEX idx_worker_period (nguoi_lao_dong_id,tu_ngay,den_ngay),
    INDEX idx_supplier_period (nha_cung_ung_id,tu_ngay,den_ngay)
);
