-- BUILD 94: DLQ replay operation identity
ALTER TABLE queue_dead_letters
  ADD COLUMN operation_id VARCHAR(191) NULL AFTER queue_job_id,
  ADD COLUMN dedupe_key VARCHAR(191) NULL AFTER job_type;

ALTER TABLE dlq_operation_audit
  ADD COLUMN replay_queue_job_id BIGINT UNSIGNED NULL AFTER dead_letter_id,
  ADD COLUMN operation_id VARCHAR(191) NULL AFTER replay_queue_job_id;

CREATE INDEX idx_dlq_operation_id ON queue_dead_letters(operation_id);
CREATE INDEX idx_dlq_audit_operation ON dlq_operation_audit(operation_id);
CREATE INDEX idx_dlq_audit_replay_job ON dlq_operation_audit(replay_queue_job_id);
