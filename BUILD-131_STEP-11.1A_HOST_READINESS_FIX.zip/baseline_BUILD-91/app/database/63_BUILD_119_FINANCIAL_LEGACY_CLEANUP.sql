/*
BUILD 119 - FINANCIAL LEGACY CLEANUP

Mục tiêu:
- Xóa các bảng dữ liệu tiền, thanh toán, phiếu thu nhập, đối soát và hoa hồng của mô hình cũ.
- Xóa quyền, module và cấu hình tài chính cũ.
- Giữ lại chấm công/kỳ công ở mức vận hành, không có dữ liệu tiền.
- Thu nhập/lương/hỗ trợ xuất hiện trong Tin tuyển dụng hoặc Tin tìm việc vẫn là nội dung do người dùng tự khai báo; không phải sổ sách tài chính của app/website.
*/

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS thanh_toan_nguoi_lao_dong;
DROP TABLE IF EXISTS xac_nhan_doi_soat;
DROP TABLE IF EXISTS phieu_doi_soat_nguoi_lao_dong;
DROP TABLE IF EXISTS chi_tiet_phieu_thu_nhap;
DROP TABLE IF EXISTS phieu_thu_nhap_nguoi_lao_dong;
DROP TABLE IF EXISTS quy_tac_don_gia_ca;
DROP TABLE IF EXISTS quy_tac_tinh_thu_nhap;
DROP TABLE IF EXISTS doi_soat_nha_cung_ung;
DROP TABLE IF EXISTS ho_tro_quan_tri_vien;
DROP TABLE IF EXISTS vi_nha_cung_ung_giao_dich;
DROP TABLE IF EXISTS vi_nha_cung_ung;
DROP TABLE IF EXISTS doanh_thu_nen_tang;
DROP TABLE IF EXISTS phi_moi_gioi_vao_lam;
DROP TABLE IF EXISTS phi_dich_vu_nguoi_lao_dong;

SET FOREIGN_KEY_CHECKS=1;

SET @db := DATABASE();
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='ho_so_lam_viec' AND column_name='luong_thuc_te'),
  'ALTER TABLE ho_so_lam_viec DROP COLUMN luong_thuc_te',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='lich_su_ho_so_lam_viec' AND column_name='luong_thuc_te'),
  'ALTER TABLE lich_su_ho_so_lam_viec DROP COLUMN luong_thuc_te',
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @sql := IF(EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema=@db AND table_name='ky_cong_nguoi_lao_dong' AND column_name='trang_thai'),
  'ALTER TABLE ky_cong_nguoi_lao_dong MODIFY COLUMN trang_thai ENUM(''mo'',''da_chot'') NOT NULL DEFAULT ''mo''' ,
  'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

DELETE FROM he_thong_module WHERE module_key IN ('finance','reconciliation');
DELETE FROM quan_tri_quyen WHERE vai_tro='finance_admin' OR quyen IN ('finance.view','finance.manage','reconciliation.view');
DELETE FROM danh_muc_du_lieu_bao_mat WHERE ma_du_lieu='finance.reconciliation';
DELETE FROM quyen_truy_cap_du_lieu WHERE ma_du_lieu='finance.reconciliation' OR vai_tro='finance_admin';
DELETE FROM cau_hinh_he_thong WHERE ma_cau_hinh IN ('employer_platform_fee','employer_support_voluntary','employer_support_payment_gateway','employer_reconciliation_view','employer_support_voluntary_enabled','employer_support_payment_gateway_enabled') OR nhom IN ('finance','reconciliation');

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('financial_data_collection','privacy','Thu thập dữ liệu tiền riêng','false','boolean','App và website không thu thập, quản lý hoặc đối soát giao dịch tiền riêng giữa người dùng.'),
('platform_financial_collection','privacy','Quản lý thanh toán người dùng','false','boolean','App và website không là bên nhận, giữ, chuyển hoặc xác nhận thanh toán trong giao dịch riêng của người dùng.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),mo_ta=VALUES(mo_ta),ngay_cap_nhat=CURRENT_TIMESTAMP;
