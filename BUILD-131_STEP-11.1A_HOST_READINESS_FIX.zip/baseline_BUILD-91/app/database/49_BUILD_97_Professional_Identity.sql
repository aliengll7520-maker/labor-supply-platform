/* BUILD 97 - Professional Identity: danh tính nghề nghiệp hai chiều */
CREATE TABLE IF NOT EXISTS ho_so_nghe_nghiep_chung_chi (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
 ten_chung_chi VARCHAR(255) NOT NULL,
 don_vi_cap VARCHAR(255) NULL,
 nam_cap SMALLINT UNSIGNED NULL,
 mo_ta TEXT NULL,
 tep_dinh_kem_url VARCHAR(500) NULL,
 trang_thai ENUM('hien_thi','an') NOT NULL DEFAULT 'hien_thi',
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_worker_cert (nguoi_lao_dong_id),
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ho_so_nghe_nghiep_kinh_nghiem (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nguoi_lao_dong_id BIGINT UNSIGNED NOT NULL,
 ten_cong_viec VARCHAR(255) NOT NULL,
 ten_don_vi VARCHAR(255) NULL,
 tu_thang VARCHAR(20) NULL,
 den_thang VARCHAR(20) NULL,
 mo_ta TEXT NULL,
 trang_thai ENUM('hien_thi','an') NOT NULL DEFAULT 'hien_thi',
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_worker_history (nguoi_lao_dong_id),
 FOREIGN KEY (nguoi_lao_dong_id) REFERENCES nguoi_lao_dong(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ho_so_danh_tinh_nha_su_dung_lao_dong (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nha_cung_ung_id BIGINT UNSIGNED NOT NULL UNIQUE,
 linh_vuc VARCHAR(255) NULL,
 quy_mo VARCHAR(120) NULL,
 website VARCHAR(500) NULL,
 moi_truong_lam_viec TEXT NULL,
 gioi_thieu_tuyen_dung TEXT NULL,
 phuc_loi_tong_quat TEXT NULL,
 video_gioi_thieu_url VARCHAR(500) NULL,
 ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (nha_cung_ung_id) REFERENCES nha_cung_ung(id) ON DELETE CASCADE
);
INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta)
VALUES ('professional_identity_enabled','professional_identity','Danh tính nghề nghiệp hai chiều','true','boolean','Hồ sơ nghề nghiệp cho Người lao động và hồ sơ tuyển dụng chuyên nghiệp cho Đơn vị sử dụng lao động.'),
('professional_profile_required','professional_identity','Bắt buộc hoàn thiện hồ sơ','false','boolean','Không bắt buộc hoàn thiện hồ sơ để sử dụng nền tảng hoặc đăng Tin tìm việc.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
