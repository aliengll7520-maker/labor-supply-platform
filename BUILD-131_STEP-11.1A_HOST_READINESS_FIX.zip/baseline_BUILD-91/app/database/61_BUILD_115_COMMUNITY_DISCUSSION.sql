/* BUILD 115 - CỘNG ĐỒNG & THẢO LUẬN
 * Thảo luận theo luồng: bình luận có thể trả lời một bình luận khác.
 * Không tạo hệ thống tiền hoặc giao dịch.
 */
ALTER TABLE social_binh_luan
  ADD COLUMN tra_loi_cho_id BIGINT UNSIGNED NULL AFTER bai_dang_id,
  ADD INDEX idx_social_comment_thread (bai_dang_id,tra_loi_cho_id,trang_thai,ngay_tao);

ALTER TABLE social_binh_luan
  ADD CONSTRAINT fk_social_comment_parent
  FOREIGN KEY (tra_loi_cho_id) REFERENCES social_binh_luan(id) ON DELETE CASCADE;

ALTER TABLE social_bao_cao
  ADD INDEX idx_social_report_comment_status (binh_luan_id,trang_thai,ngay_tao);
