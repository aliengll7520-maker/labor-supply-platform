-- BUILD 108: Auto Moderation + Anti-Abuse
ALTER TABLE social_bai_dang MODIFY trang_thai ENUM('cho_duyet','cong_khai','an','tu_choi') NOT NULL DEFAULT 'cho_duyet';
ALTER TABLE social_binh_luan MODIFY trang_thai ENUM('cho_duyet','cong_khai','an','tu_choi') NOT NULL DEFAULT 'cho_duyet';

CREATE TABLE IF NOT EXISTS content_moderation_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 content_type VARCHAR(40) NOT NULL,
 content_id BIGINT UNSIGNED NOT NULL,
 actor_type VARCHAR(40) NOT NULL,
 actor_id BIGINT UNSIGNED NOT NULL,
 engine_version VARCHAR(30) NOT NULL,
 decision ENUM('auto_approved','review','blocked') NOT NULL,
 risk_score TINYINT UNSIGNED NOT NULL DEFAULT 0,
 reasons_json JSON NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_cmod_content(content_type,content_id,created_at),
 INDEX idx_cmod_review(decision,created_at),
 INDEX idx_cmod_actor(actor_type,actor_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS content_abuse_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 content_type VARCHAR(40) NOT NULL,
 content_id BIGINT UNSIGNED NOT NULL,
 actor_type VARCHAR(40) NOT NULL,
 actor_id BIGINT UNSIGNED NOT NULL,
 risk_score TINYINT UNSIGNED NOT NULL DEFAULT 0,
 reasons_json JSON NULL,
 status ENUM('open','reviewing','resolved','dismissed') NOT NULL DEFAULT 'open',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 resolved_at DATETIME NULL,
 INDEX idx_abuse_status(status,created_at),
 INDEX idx_abuse_actor(actor_type,actor_id,created_at),
 INDEX idx_abuse_content(content_type,content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('auto_moderation_enabled','moderation','Tự động kiểm duyệt','true','boolean','Tự động kiểm tra nội dung trước khi công khai.'),
('auto_abuse_detection_enabled','moderation','Phát hiện lạm dụng','true','boolean','Phát hiện spam, nội dung lặp và đăng quá nhanh.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
