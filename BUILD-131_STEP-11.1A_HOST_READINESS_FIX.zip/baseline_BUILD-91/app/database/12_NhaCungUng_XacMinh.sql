/* 12_NhaCungUng_XacMinh.sql - Chuẩn hóa tài khoản và xác minh Nhà cung ứng. */
ALTER TABLE nha_cung_ung ADD INDEX idx_trang_thai_xac_minh (trang_thai, xac_minh);
ALTER TABLE tai_khoan_nha_cung_ung ADD INDEX idx_tai_khoan_trang_thai (trang_thai);
