/* BUILD 91 - Employer Portal deep operations.
   Adds read-only/detail APIs at application layer; no platform fees, wallet or auto collection.
   No new monetary collection mechanism is introduced.
*/
INSERT INTO cau_hinh_he_thong
    (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta)
VALUES
('employer_portal_build','employer','Trang quản trị Đơn vị sử dụng lao động','119','string','Quản lý tuyển dụng, ứng viên, người đi làm và thông báo.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
