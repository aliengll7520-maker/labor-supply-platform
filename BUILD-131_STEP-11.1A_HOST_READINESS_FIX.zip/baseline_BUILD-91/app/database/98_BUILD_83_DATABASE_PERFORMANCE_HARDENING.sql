/*
BUILD-83 — DATABASE PERFORMANCE HARDENING
Step 2: Schema / Index / Query / Lock

Only adds composite indexes for confirmed hot query paths.
Source-of-truth tables and business semantics are unchanged.

Targets:
1) Public job discovery: status + updated_at + id ordering.
2) Supplier job expiry sweep: supplier + status + expiry.
3) Worker application list: worker + updated_at + id.
4) Supplier application/dashboard paths: supplier + status + updated_at.
5) Matching suggestion reads: worker/job + status + score + updated_at.
6) Worker job-seeking post matching: status + updated_at + id.
*/

ALTER TABLE tin_tuyen_dung
    ADD INDEX idx_ttd_public_updated (trang_thai, ngay_cap_nhat, id),
    ADD INDEX idx_ttd_supplier_expiry_status (nha_cung_ung_id, trang_thai, ngay_het_han, id);

ALTER TABLE dang_ky_ho_so_phong_van
    ADD INDEX idx_dk_worker_updated (nguoi_lao_dong_id, ngay_cap_nhat, id),
    ADD INDEX idx_dk_supplier_status_updated (nha_cung_ung_id, trang_thai, ngay_cap_nhat, id);

ALTER TABLE job_match_suggestions
    ADD INDEX idx_match_worker_status_score_updated (worker_id, status, score, updated_at, id),
    ADD INDEX idx_match_job_status_score_updated (job_id, status, score, updated_at, id);

ALTER TABLE tin_tim_viec_nguoi_lao_dong
    ADD INDEX idx_worker_post_status_updated (trang_thai, ngay_cap_nhat, id);
