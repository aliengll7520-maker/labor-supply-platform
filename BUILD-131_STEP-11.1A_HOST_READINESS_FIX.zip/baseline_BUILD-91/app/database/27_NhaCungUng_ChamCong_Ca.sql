/*
27_NhaCungUng_ChamCong_Ca.sql
Attendance hour breakdown:
- gio_ca_ngay
- gio_ca_dem
- gio_tang_ca
tong_gio is their sum.
No overtime multiplier is assumed here; pricing policy remains separate.
*/
ALTER TABLE cham_cong_nguoi_lao_dong
    ADD COLUMN gio_ca_ngay DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER so_gio,
    ADD COLUMN gio_ca_dem DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER gio_ca_ngay,
    ADD COLUMN gio_tang_ca DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER gio_ca_dem;
