/*
==========================================================
14_NhaCungUng_TinTuyenDung.sql
BƯỚC 03 - QUẢN LÝ TIN TUYỂN DỤNG
==========================================================

Không thay đổi cấu trúc bảng hiện có.

Khóa nghiệp vụ:
1. Nhà cung ứng tạo tin -> cho_duyet.
2. Nhà cung ứng hoàn thiện nội dung -> gửi duyệt.
3. Quản trị viên là bên duyệt cho phép công khai -> dang_tuyen.
4. Nhà cung ứng được tạm dừng / đăng lại / đóng tin đang vận hành.
5. Hệ thống tự chuyển dang_tuyen -> het_han khi qua ngay_het_han.
6. Tin da_dong hoặc het_han không được chỉnh sửa.
7. Số điện thoại Nhà cung ứng không nằm trong Tin tuyển dụng.
==========================================================
