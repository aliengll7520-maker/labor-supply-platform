-- BUILD 19: Content Discovery source-change events.
-- Events are orchestration metadata only; tin_tuyen_dung remains authoritative.
CREATE TABLE IF NOT EXISTS content_discovery_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_key VARCHAR(191) NOT NULL,
  event_type VARCHAR(80) NOT NULL,
  content_type VARCHAR(50) NOT NULL,
  source_table VARCHAR(120) NOT NULL,
  source_id BIGINT UNSIGNED NOT NULL,
  queue_job_id BIGINT UNSIGNED NULL,
  payload_json JSON NOT NULL,
  status ENUM('queued','processing','processed','failed') NOT NULL DEFAULT 'queued',
  last_error VARCHAR(4000) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_content_discovery_event (event_key),
  INDEX idx_content_discovery_event_source (content_type, source_table, source_id),
  INDEX idx_content_discovery_event_status (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
