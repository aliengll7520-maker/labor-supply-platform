-- BUILD 94: Moderation operation idempotency
-- Adds a stable operation identity for one moderation attempt.
-- Same operation_id must never create a second moderation audit row.

ALTER TABLE tin_tuyen_dung_moderation_log
  ADD COLUMN operation_id VARCHAR(191) NULL AFTER id;

CREATE UNIQUE INDEX uq_mod_log_operation_id
  ON tin_tuyen_dung_moderation_log(operation_id);

-- Existing rows are intentionally left NULL so historical audit records
-- are not retroactively assigned a synthetic operation identity.
