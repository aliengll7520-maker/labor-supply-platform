/* ==========================================================
34_DonViSuDungLaoDong.sql
BUILD 72 - Mở rộng chủ thể tuyển dụng thành Đơn vị sử dụng lao động.
Tương thích ngược: giữ bảng/ID nha_cung_ung để không phá các FK,
API và lịch sử đã xây dựng ở các BUILD trước.
========================================================== */

ALTER TABLE nha_cung_ung
    ADD COLUMN IF NOT EXISTS loai_don_vi ENUM(
        'doanh_nghiep',
        'ho_kinh_doanh',
        'hop_tac_xa',
        'to_chuc',
        'ca_nhan'
    ) NULL AFTER ma_nha_cung_ung,
    ADD COLUMN IF NOT EXISTS ten_don_vi VARCHAR(255) NULL AFTER loai_don_vi,
    ADD COLUMN IF NOT EXISTS ma_so_thue VARCHAR(50) NULL AFTER ten_don_vi;

UPDATE nha_cung_ung
SET ten_don_vi = ten_nha_cung_ung
WHERE (ten_don_vi IS NULL OR ten_don_vi = '')
  AND ten_nha_cung_ung IS NOT NULL;

UPDATE nha_cung_ung
SET loai_don_vi = 'doanh_nghiep'
WHERE loai_don_vi IS NULL OR loai_don_vi = '';

ALTER TABLE nha_cung_ung
    MODIFY COLUMN loai_don_vi ENUM(
        'doanh_nghiep',
        'ho_kinh_doanh',
        'hop_tac_xa',
        'to_chuc',
        'ca_nhan'
    ) NOT NULL DEFAULT 'doanh_nghiep';

CREATE INDEX idx_loai_don_vi ON nha_cung_ung(loai_don_vi);
CREATE INDEX idx_ma_so_thue ON nha_cung_ung(ma_so_thue);

INSERT INTO cau_hinh_he_thong
    (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta)
VALUES
('don_vi_su_dung_lao_dong_mo_rong','don_vi_su_dung_lao_dong','Cho phép nhiều loại đơn vị sử dụng lao động','true','boolean','Nền tảng hỗ trợ doanh nghiệp, hộ kinh doanh, hợp tác xã, tổ chức và cá nhân sử dụng lao động.'),
('don_vi_su_dung_lao_dong_ten_hien_thi','don_vi_su_dung_lao_dong','Tên chủ thể hiển thị','Đơn vị sử dụng lao động','string','Tên hiển thị thống nhất trên giao diện; mã nội bộ nha_cung_ung được giữ để tương thích ngược.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
