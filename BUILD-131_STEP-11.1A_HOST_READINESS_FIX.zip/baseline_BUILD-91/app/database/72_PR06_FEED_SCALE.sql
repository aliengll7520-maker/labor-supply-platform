/* PR-06 - FEED SCALE
 * Feed cursor pagination indexes and actor-interaction lookup indexes.
 * No change to social state model.
 */
ALTER TABLE social_bai_dang
  ADD INDEX idx_social_feed_cursor(trang_thai,id),
  ADD INDEX idx_social_feed_author_cursor(trang_thai,loai_tac_gia,tac_gia_id,id);

ALTER TABLE social_theo_doi
  ADD INDEX idx_social_follow_actor_target(nguoi_theo_doi_type,nguoi_theo_doi_id,doi_tuong_type,doi_tuong_id,trang_thai);

ALTER TABLE social_chan
  ADD INDEX idx_social_block_actor_target(nguoi_chan_type,nguoi_chan_id,doi_tuong_type,doi_tuong_id,trang_thai);
