/* BUILD 114 - HOÀN THIỆN QUAN HỆ CÁ NHÂN VÀ TRAO ĐỔI
 * Mở hộp Trao đổi, trạng thái đã đọc và chỉ mục phục vụ tải lớn.
 */
ALTER TABLE social_trao_doi ADD INDEX idx_social_chat_unread (nguoi_nhan_id,trang_thai,ngay_tao);
