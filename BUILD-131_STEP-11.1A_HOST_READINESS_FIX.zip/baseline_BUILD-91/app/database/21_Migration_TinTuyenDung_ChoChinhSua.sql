-- ============================================================
-- K86 / LABOR PLATFORM
-- Migration 21
-- Tin tuyển dụng: bổ sung trạng thái can_chinh_sua
-- ============================================================

ALTER TABLE tin_tuyen_dung
MODIFY COLUMN trang_thai ENUM(
    'cho_duyet',
    'can_chinh_sua',
    'dang_tuyen',
    'tam_dung',
    'het_han',
    'da_dong'
)
NOT NULL DEFAULT 'cho_duyet'
COMMENT 'Trạng thái Tin tuyển dụng';


-- ============================================================
-- QUY ƯỚC VÒNG DUYỆT
--
-- cho_duyet
--      ↓
-- Admin duyệt
--      ↓
-- dang_tuyen
--
-- cho_duyet
--      ↓
-- Admin yêu cầu chỉnh sửa
--      ↓
-- can_chinh_sua
--      ↓
-- Nhà cung ứng chỉnh sửa
--      ↓
-- cho_duyet
--
-- can_chinh_sua không được hiển thị công khai.
-- ============================================================
