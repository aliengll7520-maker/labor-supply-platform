/* BUILD 92 — Quyền sử dụng bình đẳng cho mọi Đơn vị sử dụng lao động.
   Không phân biệt quy mô hoặc loại hình; không tạo gói cao cấp/giới hạn tính năng theo quy mô. */
INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('employer_equal_access','employer','Quyền sử dụng bình đẳng','true','boolean','Mọi Đơn vị sử dụng lao động dùng cùng bộ chức năng nền tảng trong phạm vi quyền và pháp luật áp dụng.'),
('employer_size_based_restriction','employer','Giới hạn theo quy mô','false','boolean','Không giới hạn chức năng theo quy mô lớn/nhỏ.'),
('employer_type_based_restriction','employer','Giới hạn theo loại hình','false','boolean','Không giới hạn chức năng theo doanh nghiệp, hộ kinh doanh, hợp tác xã, tổ chức hoặc cá nhân.')
ON DUPLICATE KEY UPDATE ten_cau_hinh=VALUES(ten_cau_hinh),gia_tri=VALUES(gia_tri),kieu_du_lieu=VALUES(kieu_du_lieu),mo_ta=VALUES(mo_ta),ngay_cap_nhat=CURRENT_TIMESTAMP;
