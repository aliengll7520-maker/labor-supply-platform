/* BUILD 110 - Application & Matching Automation */
CREATE TABLE IF NOT EXISTS application_automation_log (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_key VARCHAR(191) NOT NULL UNIQUE,
    event_type VARCHAR(80) NOT NULL,
    reference_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_type_reference (event_type,reference_id),
    INDEX idx_created_at (created_at)
);

CREATE TABLE IF NOT EXISTS job_match_suggestions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    worker_id BIGINT UNSIGNED NOT NULL,
    worker_post_id BIGINT UNSIGNED NOT NULL,
    job_id BIGINT UNSIGNED NOT NULL,
    supplier_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
    score TINYINT UNSIGNED NOT NULL DEFAULT 0,
    reasons JSON NULL,
    status ENUM('suggested','dismissed','viewed','applied') NOT NULL DEFAULT 'suggested',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_worker_post_job (worker_post_id,job_id),
    INDEX idx_worker_score (worker_id,status,score),
    INDEX idx_job_score (job_id,status,score),
    INDEX idx_updated (updated_at)
);
