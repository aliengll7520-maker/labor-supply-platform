-- BUILD 107: Queue + Worker System
-- Database-backed queue for asynchronous post-processing, retries and dead letters.
CREATE TABLE IF NOT EXISTS queue_jobs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  queue_name VARCHAR(80) NOT NULL,
  job_type VARCHAR(120) NOT NULL,
  payload_json JSON NOT NULL,
  priority SMALLINT UNSIGNED NOT NULL DEFAULT 100,
  status ENUM('queued','processing','completed','dead') NOT NULL DEFAULT 'queued',
  attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  max_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 5,
  available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reserved_at DATETIME NULL,
  lease_until DATETIME NULL,
  completed_at DATETIME NULL,
  dedupe_key VARCHAR(191) NULL,
  last_error VARCHAR(4000) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_queue_ready (queue_name,status,available_at,priority,id),
  INDEX idx_queue_lease (status,lease_until),
  INDEX idx_queue_completed (status,completed_at),
  UNIQUE KEY uq_queue_dedupe (queue_name,dedupe_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS queue_dead_letters (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  queue_job_id BIGINT UNSIGNED NOT NULL,
  queue_name VARCHAR(80) NOT NULL,
  job_type VARCHAR(120) NOT NULL,
  payload_json JSON NOT NULL,
  attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  error_message VARCHAR(4000) NULL,
  failed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dead_queue (queue_name,failed_at),
  INDEX idx_dead_job_type (job_type,failed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
