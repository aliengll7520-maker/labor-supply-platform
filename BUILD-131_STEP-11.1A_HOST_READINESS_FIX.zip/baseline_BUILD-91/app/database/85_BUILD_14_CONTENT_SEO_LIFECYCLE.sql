/* BUILD 14 — CONTENT SEO LIFECYCLE PROJECTION */
CREATE TABLE IF NOT EXISTS content_discovery_seo_lifecycle (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_id BIGINT UNSIGNED NOT NULL,
    content_type VARCHAR(60) NOT NULL,
    seo_state VARCHAR(40) NOT NULL,
    indexable TINYINT(1) NOT NULL DEFAULT 0,
    canonical_required TINYINT(1) NOT NULL DEFAULT 0,
    structured_data_allowed TINYINT(1) NOT NULL DEFAULT 0,
    sitemap_allowed TINYINT(1) NOT NULL DEFAULT 0,
    source_status VARCHAR(60) NOT NULL,
    fingerprint CHAR(64) NOT NULL,
    updated_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdseo_content (content_id, content_type),
    KEY idx_cdseo_state (seo_state),
    KEY idx_cdseo_fingerprint (fingerprint)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
