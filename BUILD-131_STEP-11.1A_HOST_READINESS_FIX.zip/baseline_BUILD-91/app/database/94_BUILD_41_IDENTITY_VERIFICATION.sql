/* BUILD 41 - Identity Verification & Auto Account Flow
   Non-breaking verification layer.
*/

CREATE TABLE IF NOT EXISTS identity_verifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identity_id BIGINT UNSIGNED NOT NULL,
    role_code ENUM('worker','employer') NOT NULL,
    channel ENUM('phone','email','provider') NOT NULL,
    destination VARCHAR(255) NOT NULL,
    challenge_hash CHAR(64) NULL,
    provider VARCHAR(80) NULL,
    status ENUM('pending','verified','expired','cancelled','failed') NOT NULL DEFAULT 'pending',
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    max_attempts INT UNSIGNED NOT NULL DEFAULT 5,
    expires_at DATETIME NULL,
    verified_at DATETIME NULL,
    metadata_json JSON NULL,
    ngay_tao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_identity_verification(identity_id,role_code,channel,status),
    INDEX idx_identity_verification_expiry(status,expires_at),
    CONSTRAINT fk_identity_verification_identity FOREIGN KEY(identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE
);

INSERT INTO cau_hinh_he_thong (ma_cau_hinh,nhom,ten_cau_hinh,gia_tri,kieu_du_lieu,mo_ta) VALUES
('identity_verification_enabled','identity','Identity Verification','true','boolean','Bật lớp xác minh danh tính cho Worker và Employer.'),
('identity_worker_phone_required_for_sensitive_actions','identity','Xác minh điện thoại Người lao động trước thao tác nhạy cảm','true','boolean','Tài khoản Worker vẫn đăng ký nhanh nhưng phải xác minh điện thoại trước các thao tác nhạy cảm.'),
('identity_verification_challenge_ttl_minutes','identity','Thời gian hiệu lực mã xác minh','10','integer','Số phút hiệu lực của challenge xác minh.'),
('identity_verification_max_attempts','identity','Số lần nhập mã tối đa','5','integer','Số lần nhập mã xác minh tối đa cho mỗi challenge.'),
('identity_verification_auto_merge_disabled','identity','Không tự động gộp sau xác minh','true','boolean','Xác minh không tự động gộp hai tài khoản độc lập.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ngay_cap_nhat=CURRENT_TIMESTAMP;
