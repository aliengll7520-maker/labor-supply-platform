/*
 * BUILD 17 — CONTENT DISCOVERY BACKEND/API ARCHITECTURE
 *
 * No new source-of-truth table is introduced.
 * Existing discovery projections remain rebuildable from tin_tuyen_dung.
 */

CREATE TABLE IF NOT EXISTS content_discovery_api_contracts (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    contract_key VARCHAR(120) NOT NULL,
    contract_version VARCHAR(40) NOT NULL,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    read_only TINYINT(1) NOT NULL DEFAULT 1,
    rebuildable TINYINT(1) NOT NULL DEFAULT 1,
    definition_json LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdac_contract (contract_key, contract_version),
    KEY idx_cdac_content_source (content_type, source_table)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO content_discovery_api_contracts
(contract_key, contract_version, content_type, source_table, read_only, rebuildable, definition_json)
VALUES
(
    'content-discovery',
    '17.0.0',
    'job',
    'tin_tuyen_dung',
    1,
    1,
    '{"source_of_truth":"tin_tuyen_dung","mode":"read_only","projection_policy":"rebuildable","pipeline":"discovery>classification>tags>topic_location>search>feed>related>recommendation>public>url>seo>structured_data>sitemap>seo_lifecycle>quality_gate"}'
)
ON DUPLICATE KEY UPDATE
    definition_json=VALUES(definition_json),
    updated_at=CURRENT_TIMESTAMP;
