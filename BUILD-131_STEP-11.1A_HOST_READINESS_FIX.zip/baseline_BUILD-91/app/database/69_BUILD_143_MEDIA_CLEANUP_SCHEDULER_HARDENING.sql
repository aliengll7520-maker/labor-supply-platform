/* BUILD 143 - PR-03.8 Media Cleanup Scheduler Hardening.
   The cleanup worker dispatches one bounded temp sweep per clock hour.
   Queue dedupe key remains hour-scoped so repeated worker cycles are safe. */
