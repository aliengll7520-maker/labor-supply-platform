/* PR-07 — Notification Scale
   Queue-backed delivery, idempotent push delivery, notification read indexes.
   Does not rename or alter historical migrations.
*/

ALTER TABLE notification_delivery_log
    ADD COLUMN delivery_key VARCHAR(191) NULL AFTER queue_job_id,
    ADD COLUMN delivery_claimed_at TIMESTAMP NULL AFTER delivery_key,
    MODIFY COLUMN status ENUM('queued','processing','sent','failed') NOT NULL DEFAULT 'queued',
    ADD UNIQUE KEY uq_notification_delivery_key (delivery_key),
    ADD INDEX idx_delivery_status_created (status, created_at);

CREATE INDEX idx_thong_bao_recipient_read_id
    ON thong_bao (doi_tuong, doi_tuong_id, da_doc, id);

CREATE INDEX idx_thong_bao_recipient_created
    ON thong_bao (doi_tuong, doi_tuong_id, ngay_tao, id);
