/* BUILD 149 - Media policy + video pipeline consolidation.
   New video writes use media_asset. media_video is legacy/read-only compatibility storage.
   Personal worker profiles cannot publish non-Live video. */
ALTER TABLE media_asset
  ADD COLUMN video_tieu_de VARCHAR(255) NULL AFTER original_name,
  ADD COLUMN video_mo_ta TEXT NULL AFTER video_tieu_de,
  ADD COLUMN video_thumbnail_storage_key VARCHAR(1000) NULL AFTER video_mo_ta,
  ADD COLUMN video_trang_thai ENUM('khong_ap_dung','cho_duyet','cong_khai','an','tu_choi') NOT NULL DEFAULT 'khong_ap_dung' AFTER public_access,
  ADD COLUMN video_luot_xem BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER video_trang_thai,
  ADD COLUMN video_luot_thich BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER video_luot_xem,
  ADD COLUMN video_cong_khai_at DATETIME NULL AFTER video_luot_thich,
  ADD INDEX idx_media_video_public(video_trang_thai,public_access,created_at);

INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_video_pipeline','media','Kiến trúc video','media_asset','string','BUILD 149: video mới dùng media_asset; media_video là legacy chỉ đọc, không nhận ghi mới.'),
('worker_profile_video_enabled','media','Video không Live trên trang cá nhân Người lao động','false','boolean','BUILD 149: Người lao động chỉ đăng chữ và ảnh; Live là luồng riêng của Đơn vị sử dụng lao động.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
