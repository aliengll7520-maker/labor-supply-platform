/* BUILD 46 — Exception Center & Observability. */
CREATE TABLE IF NOT EXISTS operations_exception_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fingerprint CHAR(64) NOT NULL,
  severity ENUM('info','warning','critical') NOT NULL,
  source VARCHAR(80) NOT NULL,
  code VARCHAR(120) NOT NULL,
  message VARCHAR(500) NOT NULL,
  details_json JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ops_exception_created(created_at),
  INDEX idx_ops_exception_source(source,code,created_at),
  INDEX idx_ops_exception_fingerprint(fingerprint,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
