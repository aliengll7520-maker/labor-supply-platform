-- BUILD-59: Content Discovery FULLTEXT + cache support and FCM-ready push schema.
ALTER TABLE tin_tuyen_dung
    ADD FULLTEXT INDEX ft_job_public_search_v2 (tieu_de, nganh_nghe, dia_diem, mo_ta_cong_viec, dieu_kien_tuyen_dung),
    ADD INDEX idx_job_public_location_status (dia_diem, trang_thai, ngay_cap_nhat, id);
