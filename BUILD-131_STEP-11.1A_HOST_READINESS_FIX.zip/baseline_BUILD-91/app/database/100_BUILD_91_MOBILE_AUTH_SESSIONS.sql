/* BUILD-91 — Mobile Identity / Token Session Core
   Non-breaking bridge: existing Worker access tokens and Supplier web sessions remain valid.
*/
CREATE TABLE IF NOT EXISTS mobile_auth_sessions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identity_id BIGINT UNSIGNED NOT NULL,
    role_code ENUM('worker','employer') NOT NULL,
    worker_id BIGINT UNSIGNED NULL,
    supplier_id BIGINT UNSIGNED NULL,
    supplier_account_id BIGINT UNSIGNED NULL,
    device_id VARCHAR(128) NULL,
    access_token_hash CHAR(64) NOT NULL,
    refresh_token_hash CHAR(64) NOT NULL,
    token_family CHAR(64) NOT NULL,
    access_expires_at DATETIME NOT NULL,
    refresh_expires_at DATETIME NOT NULL,
    last_used_at DATETIME NULL,
    revoked_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_mobile_access_token_hash(access_token_hash),
    UNIQUE KEY uq_mobile_refresh_token_hash(refresh_token_hash),
    KEY idx_mobile_identity_active(identity_id, revoked_at, refresh_expires_at),
    KEY idx_mobile_role_worker(role_code, worker_id, revoked_at),
    KEY idx_mobile_role_supplier(role_code, supplier_id, supplier_account_id, revoked_at),
    CONSTRAINT fk_mobile_auth_identity FOREIGN KEY(identity_id) REFERENCES identity_principals(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
