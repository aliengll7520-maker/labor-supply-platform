/* BUILD 129 - PR-03.3 Media Upload Pipeline. */
-- No new table: upload persists metadata in media_asset from BUILD 128.
-- This migration records the upload pipeline configuration only.
INSERT INTO he_thong_cau_hinh (ma,nhom,mo_ta,gia_tri,kieu,ghi_chu) VALUES
('media_upload_max_bytes','media','Dung lượng tối đa cho một Media upload','10485760','integer','BUILD 129: 10 MiB; image/video processing and CDN are deferred to later PR-03 steps.')
ON DUPLICATE KEY UPDATE gia_tri=VALUES(gia_tri),ghi_chu=VALUES(ghi_chu);
