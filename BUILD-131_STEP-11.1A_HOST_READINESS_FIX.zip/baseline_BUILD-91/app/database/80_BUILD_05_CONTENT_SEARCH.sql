-- BUILD 05 — Content Discovery Search foundation
-- Source of truth remains tin_tuyen_dung. This table is reserved for future
-- materialized search indexing and does not replace the business table.
CREATE TABLE IF NOT EXISTS content_discovery_search_index (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    content_type VARCHAR(40) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    source_key VARCHAR(120) NOT NULL,
    searchable_text LONGTEXT NOT NULL,
    source_updated_at DATETIME NULL,
    indexed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_cds_search_source (content_type, source_table, source_id),
    KEY idx_cds_search_key (source_key),
    KEY idx_cds_search_updated (source_updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
