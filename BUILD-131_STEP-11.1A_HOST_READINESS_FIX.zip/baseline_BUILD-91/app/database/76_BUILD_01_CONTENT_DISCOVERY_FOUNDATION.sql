/*
 * BUILD 01 — CONTENT DISCOVERY FOUNDATION
 * Labor Supply Platform
 *
 * Purpose:
 * Establish the first neutral registry for content discovered from existing
 * platform sources. This migration does NOT replace tin_tuyen_dung and does
 * NOT introduce taxonomy/search/feed behavior yet.
 */

CREATE TABLE IF NOT EXISTS content_discovery_registry (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    content_type VARCHAR(60) NOT NULL,
    source_table VARCHAR(120) NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    source_key VARCHAR(120) NULL,
    title VARCHAR(255) NULL,
    visibility ENUM('public','private','restricted') NOT NULL DEFAULT 'private',
    source_status VARCHAR(60) NOT NULL DEFAULT 'unknown',
    location_text TEXT NULL,
    payload_json LONGTEXT NULL,
    content_fingerprint CHAR(64) NOT NULL,
    discovered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    source_updated_at DATETIME NULL,
    last_processed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cdr_source (content_type, source_table, source_id),
    KEY idx_cdr_fingerprint (content_fingerprint),
    KEY idx_cdr_type_status (content_type, source_status),
    KEY idx_cdr_visibility (visibility),
    KEY idx_cdr_source_updated (source_updated_at),
    KEY idx_cdr_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
