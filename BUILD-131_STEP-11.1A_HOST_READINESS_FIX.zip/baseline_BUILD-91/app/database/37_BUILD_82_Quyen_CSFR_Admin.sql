/* BUILD 82 - Quyền Quản trị + CSRF + mở rộng vai trò */
ALTER TABLE tai_khoan_quan_tri
  MODIFY COLUMN vai_tro VARCHAR(50) NOT NULL DEFAULT 'quan_tri';

CREATE TABLE IF NOT EXISTS quan_tri_quyen (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  vai_tro VARCHAR(50) NOT NULL,
  quyen VARCHAR(100) NOT NULL,
  ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_quyen_vai_tro (vai_tro,quyen)
);

INSERT IGNORE INTO quan_tri_quyen (vai_tro,quyen) VALUES
('super_admin','*'),
('operations_admin','dashboard.view'),('operations_admin','suppliers.view'),('operations_admin','suppliers.manage'),('operations_admin','jobs.view'),('operations_admin','jobs.manage'),('operations_admin','feedback.view'),('operations_admin','reviews.view'),('operations_admin','unions.view'),('operations_admin','system.view'),('operations_admin','security.view'),
('support_admin','dashboard.view'),('support_admin','users.view'),('support_admin','suppliers.view'),('support_admin','feedback.view'),('support_admin','notifications.view'),('support_admin','system.view'),
('moderator','dashboard.view'),('moderator','jobs.view'),('moderator','jobs.manage'),('moderator','reviews.view'),('moderator','feedback.view'),('moderator','system.view');

CREATE TABLE IF NOT EXISTS bao_mat_su_kien (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_account_id BIGINT UNSIGNED NULL,
  hanh_dong VARCHAR(100) NOT NULL,
  duong_dan VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  ngay_tao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_bmsk_admin (admin_account_id),
  INDEX idx_bmsk_time (ngay_tao)
);
