<?php
declare(strict_types=1);

$root=__DIR__;
$files=[
 'backend/src/Services/ContentDiscoveryControlService.php',
 'backend/src/Controllers/ContentDiscoveryControlController.php',
 'BUILD_22_CONTENT_DISCOVERY_CONTROL_CENTER.md',
];
foreach($files as $f){ if(!is_file($root.'/'.$f)) throw new RuntimeException('Missing: '.$f); }
$service=file_get_contents($root.'/backend/src/Services/ContentDiscoveryControlService.php');
$controller=file_get_contents($root.'/backend/src/Controllers/ContentDiscoveryControlController.php');
$index=file_get_contents($root.'/backend/public/index.php');
foreach(['22.0.0','system.view','rebuildActive','content_discovery_events','tin_tuyen_dung'] as $needle){ if(strpos($service,$needle)===false) throw new RuntimeException('Service contract missing: '.$needle); }
foreach(['/api/admin/content-discovery/control','/api/admin/content-discovery/control/rebuild','contentDiscoveryControl'] as $needle){ if(strpos($index,$needle)===false) throw new RuntimeException('Route contract missing: '.$needle); }
if(strpos($controller,'rebuildActive')===false) throw new RuntimeException('Controller contract missing.');
echo "BUILD-22 contract PASS\n";
