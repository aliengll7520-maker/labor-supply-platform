# BUILD-113 — Operation Coordinator Integration Test Matrix

T01: create operation -> CREATED.
T02: start operation -> RUNNING.
T03: 5xx result -> WAIT_RETRY before scheduler handoff.
T04: network error -> WAIT_NETWORK.
T05: 401 -> AUTHENTICATION_RECOVERY.
T06: released retry checks lifecycle is still active.
T07: cancelled operation rejects released retry.
T08: successful retry -> SUCCESS.
T09: terminal retry result -> TERMINAL.
T10: stale lifecycle version is rejected.
T11: late result cannot resurrect CANCELLED.
T12: operationId remains unchanged end-to-end.
T13: mutation Idempotency-Key remains unchanged end-to-end.
T14: coordinator never sends HTTP.
T15: coordinator never refreshes tokens.
T16: coordinator never calculates retry timing.
T17: coordinator delegates execution to BUILD-109 only.
T18: failed retry returns normalized result to recovery handling.

T19: Android consumeResult receives the original ApiRequest explicitly; no placeholder request provider remains.
T20: Android OperationCoordinator references only lifecycle CANCELLED state for cancellation; RecoveryLoopState has no invented CANCELLED value.
