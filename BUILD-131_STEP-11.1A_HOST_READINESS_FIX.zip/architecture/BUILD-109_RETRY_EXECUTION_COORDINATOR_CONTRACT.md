# BUILD-109 — Retry Execution Coordinator Contract

Baseline: BUILD-108.

## Responsibility

Retry Execution Coordinator executes retry intents produced by Recovery Orchestrator.

It does NOT:
- calculate backoff;
- calculate jitter;
- create a second retry scheduler;
- manipulate tokens;
- classify HTTP errors;
- recursively invoke recovery.

BUILD-100 remains the only owner of retry timing/backoff/jitter.

## Execution flow

Recovery Orchestrator
-> Retry Intent
-> BUILD-100 Scheduler
-> Retry Execution Coordinator
-> API Client
-> normalized result
-> Recovery Orchestrator

## Admission rules

A retry is admitted only when:
- the intent is retryable;
- attempt count is below the configured maximum;
- the session is still eligible for an authenticated request;
- the operation is not cancelled;
- the network is available when the scheduler releases WAIT_NETWORK.

## Idempotency

Mutation operations retain the exact original Idempotency-Key.
Retry Execution Coordinator never generates a replacement key.

## Authentication

Retry Execution Coordinator does not refresh tokens.
If authentication is required, Session Manager owns refresh.
A stale/unauthorized session causes the retry to be rejected rather than recursively refreshing.

## Network

The coordinator does not retry immediately after a network error.
BUILD-100 decides when the retry becomes executable.

## Attempt accounting

Each execution consumes exactly one attempt.
The coordinator never resets attempt count after an error.

## Terminal conditions

Reject execution when:
- max attempts reached;
- operation cancelled;
- session signed out/revoked;
- retry intent is stale;
- request is no longer eligible.

No retry loop is created inside this component.
