# BUILD-99 — Mobile Sync State Machine

Baseline: BUILD-98_CORRECTED_FINAL

## States

PENDING
RUNNING
WAIT_NETWORK
WAIT_RETRY
SUCCESS
FAILED
CANCELLED

## Valid transitions

PENDING -> RUNNING
PENDING -> CANCELLED
RUNNING -> SUCCESS
RUNNING -> WAIT_NETWORK
RUNNING -> WAIT_RETRY
RUNNING -> FAILED
RUNNING -> CANCELLED
WAIT_NETWORK -> PENDING
WAIT_RETRY -> PENDING
WAIT_RETRY -> FAILED
FAILED -> PENDING (manual/explicit retry only)
FAILED -> CANCELLED
CANCELLED -> terminal
SUCCESS -> terminal

No implicit transitions from SUCCESS/CANCELLED back to RUNNING.

## Lease / crash recovery

RUNNING carries a lease deadline (`lease_until`).
If the process is killed or the OS suspends the app and the lease expires:
RUNNING -> PENDING.

A stale RUNNING job must never remain permanently stuck.

## Retry

- attempt_count increments only when an actual network/API attempt starts.
- retryable errors use exponential backoff + jitter.
- recommended base sequence: 2s, 5s, 15s, 30s, 60s, capped.
- 429 uses server Retry-After when present.
- 401 coordinates with single-flight token refresh; original request is retried once.
- Refresh-token invalid/revoked is terminal for the authenticated session and must not loop.
- Non-retryable 4xx becomes FAILED without blind retry.

## Mutation rule

POST/PUT/PATCH/DELETE jobs retain the same Idempotency-Key for every retry of the same logical operation.

A retry must never generate a new key.

## Priority

P0 > P1 > P2.
P1/P2 cannot block first usable UI.
Only one active attempt is allowed for a coalesced GET domain/operation.

## Cancellation

Cancellation is explicit. A cancelled job is terminal and is not automatically retried.

## Offline

Network unavailable:
- move RUNNING -> WAIT_NETWORK;
- do not consume retry attempts while there is no network;
- resume WAIT_NETWORK -> PENDING when connectivity is restored;
- do not invalidate the auth session because of network failure.
