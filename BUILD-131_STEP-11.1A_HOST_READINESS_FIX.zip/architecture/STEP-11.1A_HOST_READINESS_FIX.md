# STEP 11.1A — Host Readiness Fix

Baseline:
`BUILD-130_STEP-10.9_FINAL_AUDIT_LOCK_FIXED.zip`

## Findings fixed

### Android
- Corrected the malformed `WEBSITE_URL` BuildConfig string so the Gradle DSL is syntactically valid.
- Corrected the `BuildConfig` package import in `MainActivity`.
- Added explicit placeholder handling so a missing deployment URL shows a configuration message instead of attempting to load an invalid URL.
- Wired the existing `AndroidFloatingSurfaceHost` into the existing `AndroidAppShell` surface callback.
- Added a minimal presentation-only native surface with a close action that emits the existing Website callback.
- Added cleanup of the floating host before App Shell shutdown.

### iOS
- Replaced the placeholder root-only AppDelegate wiring with the existing `IOSAppShell` composition point.
- Wired the existing `IOSFloatingSurfaceHost` into the existing surface callback.
- Added a minimal presentation-only native surface with a close action that emits the existing Website callback.
- Changed Website URL configuration from fatal error to a safe configuration state.
- Corrected the iOS request-id label interpolation used by the minimal runtime surface.
- Kept the official Xcode project, bundle identifier, signing, and approved Website URL external to this scaffold.

## Architecture boundary

No new Website content, business logic, social state, database, or API was introduced.
The native surface is presentation-only.

## Runtime qualification

This fix is statically audited. It does **not** claim physical Android/iOS device or simulator execution. Android/iOS runtime execution still requires the official Website URL and deployment-specific project configuration.

Status: HOST READINESS STATIC FIX — READY FOR REVIEW
