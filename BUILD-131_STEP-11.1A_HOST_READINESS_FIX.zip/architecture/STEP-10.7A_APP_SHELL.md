# STEP 10.7A — Native Web-in-App App Shell

Baseline:
`BUILD-130_STEP-10.6_INTEGRATION_TEST_FIXED.zip`

## Added

Android:
`mobile/android/AppShell.kt`

iOS:
`mobile/ios/AppShell.swift`

## Behavior

Both shells:
1. Accept the Website URL from the host caller.
2. Create the platform WebView.
3. Load the supplied Website URL.
4. Attach the already-approved 10.3 Bridge Listener.
5. Expose the WebView to the existing Native integration layer.
6. On stop, detach the Bridge Listener, stop loading, clear the WebView navigation delegate where applicable, remove the WebView from its host, and destroy/release the WebView.

## Deliberate non-assumptions

No production/development URL is hard-coded.
No package identifier or bundle identifier is invented.
No new backend API is created.
No local database or App-owned Content/Social state is created.
No Website Content or Business Logic is duplicated.
No Floating Surface implementation is changed.

## Runtime boundary

This creates the missing App Shell/WebView source primitives, but the ZIP
still does not contain complete Android Gradle or iOS Xcode project metadata.
A host application must supply the platform project entry point and the
approved Website URL.

Status: IMPLEMENTED — READY FOR REVIEW
