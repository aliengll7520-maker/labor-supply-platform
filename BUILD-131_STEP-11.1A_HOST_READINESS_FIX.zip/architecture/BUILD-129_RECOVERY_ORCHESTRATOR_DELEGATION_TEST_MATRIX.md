# BUILD-129 — Recovery Orchestrator Delegation Test Matrix

T01: CLOSED delegates as terminal/no-recovery.
T02: CONTINUE_RECOVERY delegates to Recovery Orchestrator.
T03: Boundary never performs recovery work.
T04: Boundary never retries.
T05: Boundary never schedules retry.
T06: Boundary never calculates retry timing.
T07: Boundary never executes retry.
T08: Boundary never mutates lifecycle state.
T09: Boundary never rolls back committed state.
T10: operationId is preserved.
T11: eventId is preserved.
T12: attempt is preserved.
T13: Closure decision is preserved.
T14: Confirmation metadata is preserved.
T15: Boundary performs no HTTP.
T16: No Token/credential/Idempotency-Key/HTTP secret enters boundary.
T17: Recovery Orchestrator remains recovery owner.
T18: No BUILD-129 database migration.
