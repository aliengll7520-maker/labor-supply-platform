# BUILD-105 — Concurrency / Race Test Matrix

T01: One request receives 401 -> exactly one refresh -> one retry.
T02: Ten concurrent requests receive 401 -> one refresh -> all await same result.
T03: Refresh succeeds -> all eligible original requests retry once.
T04: Refresh returns invalid -> session becomes SIGNED_OUT; no request retries.
T05: Refresh returns reuse-detected -> session becomes SIGNED_OUT; no request retries.
T06: Second 401 after successful refresh -> terminal UNAUTHORIZED; no second refresh.
T07: Logout during refresh -> generation changes; late refresh result is rejected.
T08: Network failure during refresh -> no logout; scheduler may recover.
T09: Mutation 401 -> refresh -> retry with identical Idempotency-Key.
T10: Mutation timeout -> scheduler retry with identical Idempotency-Key.
T11: GET retry -> no Idempotency-Key is created.
T12: No duplicate retry scheduler is started by API Client.
