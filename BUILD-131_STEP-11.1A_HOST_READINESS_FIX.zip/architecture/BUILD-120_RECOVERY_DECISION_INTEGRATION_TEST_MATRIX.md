# BUILD-120 — Recovery Decision Integration Test Matrix

T01: RETRY_ELIGIBLE routes to BUILD-100 timing delegation.
T02: TERMINAL routes to terminal path.
T03: ESCALATE routes to escalation path.
T04: RETRY_ELIGIBLE does not execute retry.
T05: RETRY_ELIGIBLE does not schedule retry.
T06: BUILD-100 remains retry timing owner.
T07: BUILD-109 remains retry execution owner.
T08: Terminal routing does not mutate lifecycle inside this boundary.
T09: Escalation routing performs no HTTP.
T10: Operation identity is preserved.
T11: No Token/credential/Idempotency-Key/HTTP secret enters routing.
T12: No BUILD-120 database migration.
