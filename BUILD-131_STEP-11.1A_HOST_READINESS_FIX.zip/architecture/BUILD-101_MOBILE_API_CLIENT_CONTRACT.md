# BUILD-101 — Mobile API Client Contract

Baseline: BUILD-100

## Responsibility

API Client is the single application-facing HTTP boundary.

UI/features MUST NOT implement their own:
- token attachment
- refresh locking
- retry loops
- Request-ID generation
- Idempotency-Key generation for mutations
- HTTP error parsing

## Request pipeline

Screen/Repository
-> API Client
-> Request Builder
-> Auth Header
-> Request-ID
-> Idempotency-Key (mutation)
-> HTTP Transport
-> Response Normalizer

## Request-ID

Every HTTP request gets a unique X-Request-ID.
A retry is a new HTTP attempt but remains traceable to the same logical operation/job.

## Access Token

- Access token is read from Secure Storage.
- Refresh token is never exposed to UI/repositories.
- Tokens are never written to ordinary cache payloads or logs.

## 401 / Single-flight Refresh

For an authenticated request:
1. Send with current access token.
2. On 401, enter the single-flight refresh coordinator.
3. Exactly one refresh operation runs.
4. Other failed requests wait for the same refresh result.
5. On success, update Secure Storage and retry each original request once.
6. If refresh is invalid/revoked/reuse-detected, clear authenticated state and require login.
7. A second 401 after the one allowed retry is terminal for that request.

Never recursively call the normal request pipeline for refresh itself.

## Mutation Idempotency

POST/PUT/PATCH/DELETE create an Idempotency-Key once for the logical operation.
All retries of that operation reuse the same key.
GET requests do not require an Idempotency-Key.

## Timeout / Network

Timeouts and network errors are normalized to NETWORK_ERROR or TIMEOUT.
The API Client does not create an infinite retry loop.
Retryable work is handed to the BUILD-100 Retry Scheduler.

## HTTP normalization

2xx -> success
400/422 -> VALIDATION_ERROR when validation payload is present
401 -> UNAUTHORIZED
403 -> FORBIDDEN
404 -> NOT_FOUND
409 -> CONFLICT
429 -> RATE_LIMITED + Retry-After metadata
5xx -> SERVER_ERROR
timeout -> TIMEOUT
transport failure -> NETWORK_ERROR

Unknown response -> UNKNOWN_ERROR

## Response contract

Normalized result:
- success: boolean
- status: integer|null
- data: object|array|null
- error_code: normalized enum|null
- message: safe user-facing message|null
- request_id: string|null
- retry_after_ms: integer|null
- raw_backend_code: string|null (never expose to UI directly)

## Security

- Never log Authorization header.
- Never log access/refresh token values.
- Never log full Idempotency-Key if it is treated as sensitive by the client policy.
- Do not store server response secrets in ordinary cache.

## Relationship with existing builds

BUILD-95: server idempotency.
BUILD-96: refresh-token reuse protection.
BUILD-97: bootstrap.
BUILD-98: local cache/sync.
BUILD-99: sync state machine.
BUILD-100: network/retry scheduler.
BUILD-101: one client boundary joining them.
