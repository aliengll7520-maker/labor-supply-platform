# BUILD-98 — Mobile Local Cache + Sync Schema

Baseline: BUILD-97

## 1. Cache domains

- bootstrap_meta: server_time + config/category/location/feature versions.
- config: low-change platform configuration.
- categories: job/category reference data.
- locations: province/district/ward reference data.
- feature_flags: feature availability.
- jobs: short-lived dynamic job feed cache.
- matching: short-lived matching cache.
- notifications: short-lived notification cache.
- identity: non-secret identity/profile snapshot.

## 2. Persistent cache record

Each cache domain has:
- cache_key
- version
- payload
- fetched_at
- expires_at
- last_sync_at
- stale_after

Rules:
- UI may render stale-but-known data when offline.
- Security/session tokens are NOT stored here.
- Access/refresh tokens remain in Secure Storage.

## 3. Sync job model

States:
pending -> running -> success
pending -> running -> failed -> pending
pending -> running -> cancelled

Fields:
- id
- domain
- operation
- priority (P0/P1/P2)
- state
- attempt_count
- max_attempts
- next_retry_at
- last_error_code
- last_error_at
- idempotency_key (mutation only)
- created_at
- updated_at

Rules:
- One active sync job per (domain, operation) unless explicitly coalesced.
- GET sync may retry with exponential backoff + jitter.
- Mutations MUST reuse the same idempotency_key on retry.
- Retry is never a tight loop.
- P0 runs before P1; P1 before P2.
- P2 never blocks App startup.

## 4. Retry policy

Recommended base delays:
2s, 5s, 15s, 30s, 60s, then capped backoff.

Apply random jitter to avoid synchronized retries.

Network-unavailable errors:
- keep job pending;
- do not invalidate the session;
- resume after network recovery.

HTTP 401:
- first coordinate with single-flight token refresh;
- retry the original request once with the new access token;
- only force login when refresh is actually invalid/revoked.

HTTP 429:
- respect Retry-After;
- do not hammer the API.

HTTP 5xx/timeouts:
- backoff + jitter.

## 5. Version sync

GET /api/mobile/bootstrap supplies:
- config_version
- category_version
- location_version
- feature_version

The client syncs only domains whose local version differs.

## 6. Conflict and coalescing

- Latest successful version wins for reference/config domains.
- Older responses must not overwrite a newer local version.
- Duplicate pending jobs for the same GET domain are coalesced.
- Mutation jobs are never silently coalesced unless their idempotency contract explicitly allows it.

## 7. Startup guarantee

The startup path is:
Secure Session -> Local Cache -> Render UI -> Bootstrap -> Background Sync.

No P1/P2 sync is allowed to block first usable UI.
