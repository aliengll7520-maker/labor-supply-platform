# STEP 10.3 — Native WebView Listener

Baseline:
`BUILD-130_STEP-10.2_WEB_BRIDGE.zip`

## Implemented

The existing Android and iOS HostIntegration files now contain the minimal
WebView listener needed to receive the Website's `window.postMessage`
transport.

### Android
`AndroidWebViewBridgeListener`
- attaches to an existing `android.webkit.WebView`
- installs a narrow JavaScript forwarding hook for `window.message`
- receives the JSON envelope through a WebView JavaScript interface
- validates protocol version, requestId, event and surfaceId
- forwards only a validated `BridgeRequest` to the caller

### iOS
`IOSWebViewBridgeListener`
- attaches to an existing `WKWebView`
- installs a narrow JavaScript forwarding hook for `window.message`
- receives the message through `WKUserContentController`
- validates protocol version, requestId, event and surfaceId
- forwards only a validated `BridgeRequest` to the caller

## Explicit boundaries

This step does not:
- create a new App screen/UI
- create Floating Surface
- execute business logic
- create local database/state
- call a new backend API
- implement callback
- change Website code
- implement memory cleanup

The listener is transport/protocol handling only. The existing WebView/App
Shell owns lifecycle; the next step decides what to do with a validated
request.

Status: IMPLEMENTED — READY FOR REVIEW
