# BUILD-110 — Retry/Recovery Integration Test Matrix

T01: Recovery Orchestrator produces one RetryIntent for a retryable 5xx.
T02: BUILD-100 release reaches RetryExecutionCoordinator exactly once.
T03: One released intent produces exactly one API Client execution.
T04: Failed retry returns normalized result to Recovery Orchestrator.
T05: Failed retry does not recursively execute another retry.
T06: Attempt count increases monotonically.
T07: Attempt count is not reset after a failed execution.
T08: Mutation keeps the exact original Idempotency-Key.
T09: GET remains without Idempotency-Key.
T10: Signed-out authenticated request is rejected.
T11: 401 remains delegated to Session Manager.
T12: 429/5xx/timeout/network timing remains delegated to BUILD-100.
T13: Duplicate operation identity is rejected while already in flight.
T14: No token value is passed through RetryIntent.
T15: No second retry scheduler is created.
