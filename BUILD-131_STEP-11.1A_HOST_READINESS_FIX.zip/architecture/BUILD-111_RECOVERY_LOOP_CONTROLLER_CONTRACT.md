# BUILD-111 — Recovery Loop Controller Contract

Baseline: BUILD-110 Final.

## Purpose

Close the recovery loop after a retry execution returns a normalized result.

## Ownership

- API Client: HTTP execution and normalization.
- Recovery Loop Controller: closes one logical operation state transition.
- Recovery Orchestrator: decides the next recovery category.
- BUILD-100: owns retry timing/backoff/jitter.
- BUILD-109: executes one released retry intent.
- Session Manager: owns authentication state and refresh.

## State machine

OPEN
-> SUCCESS
-> TERMINAL
-> AUTHENTICATION_RECOVERY
-> WAIT_RETRY
-> WAIT_NETWORK

Terminal states cannot transition back to retry.

SUCCESS closes the logical operation.

SIGNED_OUT closes authenticated recovery without scheduling another retry.

## Loop prevention

For one logical operation:
- each execution result is consumed exactly once;
- attempt count is monotonic;
- the controller never calls itself recursively;
- the controller never directly calls the API Client;
- the controller never schedules retry timing;
- a second 401 after authentication recovery is terminal.

## Idempotency

Mutation Idempotency-Key is immutable for the lifetime of the logical operation.
GET does not acquire a key.

## Concurrency

Only one transition may be committed for an operation version.
Stale results are rejected.

## Result handling

SUCCESS -> close.
401 -> Session Manager path.
429/5xx/timeout/network -> Recovery Orchestrator/BUILD-100 path.
Terminal 4xx -> close terminal.
Signed-out session -> close without retry.

No token values are carried in controller state.


## Audit clarification

The concurrency rule is:
"Only one transition may be committed for an operation version."

This means a given operation version can produce at most one committed state transition.
The implementation enforces this with the operation version map and stale-version rejection.
