# BUILD-92 — Mobile Bootstrap Resilience Layer (MBRL) — Architecture Lock

Status: ARCHITECTURE LOCKED / CODE NOT IMPLEMENTED

Baseline:
- BUILD-91 — Mobile Identity / Token Session

Purpose:
Define the Mobile Bootstrap Resilience Layer so unstable 4G/Wi-Fi and large simultaneous app starts
do not create request storms, refresh-token storms, crashes, or unnecessary Backend load.

## 1. Bootstrap State Machine

APP_START
 -> SPLASH
 -> NETWORK_GUARD
 -> SECURE_SESSION_CHECK
 -> TOKEN_CHECK
    -> VALID -> LOCAL_SNAPSHOT -> OPEN_APP
    -> EXPIRED -> REFRESH_LOCK -> TOKEN_CHECK
    -> INVALID -> LOGIN
 -> P0 -> P1 -> P2(background)

## 2. Request Budget

P0: <= 2 synchronous requests
P1: <= 3 synchronous requests
P2: background only
P2 must never block opening the app.

## 3. Network / Failure Policy

Timeout:
- P0 target: ~5 seconds
- P1 target: ~5–8 seconds
- P2 must not block UI

Retry:
- Maximum 2 retries per bootstrap request.
- Retryable: network failure, timeout, 5xx, 429.
- Non-retryable: 400, 403, and 401 after refresh fails.
- 429 must respect Retry-After.
- Retry uses exponential backoff + jitter.

## 4. Circuit Breaker

Circuit breakers are per service/API group, not global.

Initial test parameters:
- 5 consecutive failures -> OPEN
- ~30 second cooldown
- HALF-OPEN -> one probe request
- Success -> CLOSED
- Failure -> OPEN again

Identity/Refresh must not be blocked merely because Discovery/Feed is unhealthy.

## 5. Request Deduplication

One in-flight logical request per key:
method + endpoint + logical parameters.

Repeated lifecycle calls must share the in-flight result rather than create duplicate requests.

## 6. Offline / Network Recovery

Network failure does not mean session invalidation.

OFFLINE:
- use Local Snapshot where available;
- do not issue useless background retries;
- show user-friendly Offline state;
- allow explicit retry.

When connectivity returns:
- do not create a request burst;
- refresh using randomized delay/jitter;
- respect Request Budget.

## 7. Identity Integration

401 handling:
- acquire Refresh Lock;
- refresh only once concurrently;
- retry original request at most once;
- if retry remains 401, mark session expired and route to Login.

Refresh Token rotation remains governed by BUILD-91 backend transaction/locking.

Network timeout/5xx must NOT clear tokens or log the user out.

## 8. Items intentionally deferred to later API Contract work

These are findings already identified and must not be forgotten:
- Mobile Auth-specific rate limits, especially refresh/session/device aware limits.
- Full Idempotency Store.
- Standard Mobile Error Contract.
- API version metadata correction.

They are not MBRL architecture defects and belong to the API Contract / Rate Limit stage.

## 9. Implementation Boundary

This BUILD-92 package locks architecture only.

No Android/iOS Native code is introduced because BUILD-91 contains no Native Mobile codebase/baseline.
Implementation must begin only after the Mobile project/framework/baseline is established.

## 10. Acceptance Criteria for later implementation

The implementation is not considered complete until:
- code is implemented against the approved Mobile baseline;
- static/code audit passes;
- fault tests cover offline, timeout, 401, 429, 5xx, lifecycle restart;
- refresh storm is prevented;
- network recovery does not create a request burst;
- runtime tests pass.

