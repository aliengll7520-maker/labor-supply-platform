-- BUILD-99 — Mobile-local sync_jobs extension.
-- Not a backend/cPanel migration.

ALTER TABLE sync_jobs ADD COLUMN lease_until INTEGER NULL;
ALTER TABLE sync_jobs ADD COLUMN last_http_status INTEGER NULL;
ALTER TABLE sync_jobs ADD COLUMN cancel_reason TEXT NULL;

CREATE INDEX IF NOT EXISTS idx_sync_lease
ON sync_jobs(state, lease_until);

-- Valid state values are enforced by the Mobile repository/state machine:
-- pending, running, wait_network, wait_retry, success, failed, cancelled.
