# BUILD-114 — Operation Event & Transition Audit Contract

Baseline: BUILD-113 Final.

## Purpose

Provide a deterministic, non-invasive audit trail for operation lifecycle transitions.

## Event identity

Every committed transition produces one immutable event:
- eventId: unique event identity;
- operationId: immutable logical operation identity;
- fromState;
- toState;
- versionBefore;
- versionAfter;
- attempt;
- reason;
- category;
- timestamp.

## Categories

SUCCESS
RETRY
NETWORK
AUTHENTICATION
TERMINAL
CANCELLED
LIFECYCLE

## Rules

1. An event is created only after a transition is successfully committed.
2. A rejected stale/duplicate transition creates no committed event.
3. One operation version may commit at most one event.
4. eventId is never reused for another transition.
5. operationId never changes.
6. Mutation Idempotency-Key is not stored in audit events.
7. Token, refresh token and credentials are never stored.
8. Event payload contains no HTTP body or secret headers.
9. Audit recorder never sends HTTP.
10. Audit recorder never schedules retry.
11. Audit recorder never changes lifecycle state.
12. Audit persistence is abstract; BUILD-114 adds no database migration.
13. Event ordering is determined by operation version; timestamp is informational.
14. Duplicate event submission is idempotent by eventId.
