# BUILD-112 — Operation Lifecycle Contract

Baseline: BUILD-111 Final.

## Purpose

Own the lifecycle of one logical operation without taking ownership from:
- BUILD-100 timing;
- BUILD-109 execution;
- BUILD-111 recovery transition;
- Session Manager authentication;
- API Client HTTP.

## States

CREATED
RUNNING
WAIT_RETRY
WAIT_NETWORK
AUTHENTICATION_RECOVERY
SUCCESS
TERMINAL
CANCELLED

Only active states may transition to another active/waiting state.
SUCCESS, TERMINAL and CANCELLED are closed states.

## Cancellation

Cancellation is terminal for the logical operation.
A cancelled operation:
- cannot schedule a retry;
- cannot execute a released retry;
- cannot commit a stale result;
- cannot be resurrected by a late network response.

## Operation identity

Every operation has:
- immutable operationId;
- monotonically increasing version;
- attempt count;
- immutable Idempotency-Key for mutations.

OperationId and Idempotency-Key are never regenerated during recovery.

## Concurrency

Only the current version may commit.
A later version supersedes an older result.
Duplicate cancellation is idempotent.

## Ownership

Lifecycle Controller owns lifecycle state only.
It does not:
- send HTTP;
- refresh tokens;
- calculate retry delay;
- execute retries;
- create another scheduler.

## Terminal safety

SUCCESS/TERMINAL/CANCELLED cannot transition back to RUNNING or retry states.
