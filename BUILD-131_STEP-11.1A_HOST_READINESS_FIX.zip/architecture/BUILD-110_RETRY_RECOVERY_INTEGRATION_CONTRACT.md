# BUILD-110 — Retry Execution ↔ Recovery Orchestrator Integration Contract

Baseline: BUILD-109 Final.

## Ownership

- Recovery Orchestrator decides whether recovery is required and creates a retry intent.
- BUILD-100 Scheduler decides when the retry intent is released.
- BUILD-109 RetryExecutionCoordinator admits and executes one released retry intent.
- API Client performs the HTTP request.
- Session Manager owns authentication state and refresh.

## Integration flow

API Client normalized result
-> Recovery Orchestrator
-> Retry Intent
-> BUILD-100 Scheduler
-> BUILD-109 RetryExecutionCoordinator
-> API Client
-> normalized result

## Hard rules

1. A released retry intent produces at most one API Client execution.
2. RetryExecutionCoordinator never schedules another retry.
3. RecoveryOrchestrator never directly executes HTTP.
4. Attempt count is monotonic and is not reset after failure.
5. Mutation Idempotency-Key is copied unchanged through the integration.
6. GET never receives an Idempotency-Key from this integration layer.
7. 401 recovery remains owned by Session Manager.
8. 429/5xx/timeout/network timing remains owned by BUILD-100.
9. Signed-out authenticated requests are rejected.
10. A failed retry returns its normalized result to Recovery Orchestrator; it does not recursively retry.
11. Operation identity is preserved for in-flight deduplication.
12. No token values cross the integration boundary.
