# BUILD-126 — Lifecycle Transition Decision → Lifecycle Controller Delegation

Baseline: BUILD-125 Final.

## Purpose
Create an explicit delegation boundary from BUILD-125 lifecycle transition decisions to the existing Lifecycle Controller, without executing or mutating lifecycle state inside BUILD-126.

## Ownership
- BUILD-125: produces lifecycle transition decision.
- BUILD-126: delegates the decision only.
- Lifecycle Controller: single owner of actual lifecycle transition execution.
- BUILD-100: retry timing.
- BUILD-109: retry execution.

## Rules
1. BUILD-126 accepts a lifecycle transition decision.
2. BUILD-126 delegates ownership to the Lifecycle Controller.
3. BUILD-126 never executes a lifecycle transition.
4. BUILD-126 never mutates lifecycle state.
5. BUILD-126 never rolls back a committed lifecycle transition.
6. BUILD-126 never retries or schedules retry.
7. BUILD-126 never calculates retry timing.
8. BUILD-126 never executes retry.
9. operationId, eventId and attempt are preserved unchanged.
10. Transition decision and outcome metadata are preserved unchanged.
11. No HTTP is performed.
12. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
13. No BUILD-126 database migration.
