# BUILD-120 — Recovery Decision Integration Contract

Baseline: BUILD-119 Final.

## Purpose
Integrate persistence-failure recovery decisions into the operation flow without creating a new retry scheduler or retry executor.

## Ownership
- BUILD-119 boundary: classifies persistence failure and creates decision.
- BUILD-120 integration: routes the decision.
- BUILD-100: owns retry timing/scheduling.
- BUILD-109: owns retry execution.
- Operation Coordinator: owns orchestration.
- Lifecycle Controller: owns lifecycle state.

## Routing
RETRY_ELIGIBLE -> DELEGATE_TO_RETRY_TIMING
TERMINAL -> TERMINAL_PATH
ESCALATE -> ESCALATION_PATH

## Rules
1. BUILD-120 routes decisions only.
2. RETRY_ELIGIBLE never starts a retry itself.
3. No retry scheduler is introduced.
4. No retry executor is introduced.
5. Retry timing remains BUILD-100.
6. Retry execution remains BUILD-109.
7. TERMINAL routing does not mutate lifecycle state inside this boundary.
8. ESCALATE routing does not perform HTTP or external notification.
9. A committed lifecycle transition is never rolled back.
10. No Token, credential, Idempotency-Key, HTTP body or secret header enters routing.
11. No database migration is introduced by BUILD-120.
