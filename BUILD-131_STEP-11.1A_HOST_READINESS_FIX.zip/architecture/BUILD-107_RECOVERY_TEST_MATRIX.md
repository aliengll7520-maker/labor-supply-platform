# BUILD-107 — Recovery Orchestrator Test Matrix

T01: 2xx -> SUCCESS; no retry.
T02: 401 -> Session Manager recovery; no direct token manipulation.
T03: 401 after one recovery retry -> terminal UNAUTHORIZED.
T04: 429 with Retry-After -> BUILD-100 receives delay metadata.
T05: 429 without Retry-After -> BUILD-100 policy decides backoff.
T06: 500 -> BUILD-100; no immediate loop.
T07: timeout -> BUILD-100.
T08: network error -> WAIT_NETWORK.
T09: 403 -> terminal; no blind retry.
T10: validation error -> terminal; no blind retry.
T11: mutation recovery -> same Idempotency-Key.
T12: GET recovery -> no generated Idempotency-Key.
T13: offline before retry -> WAIT_NETWORK, zero network attempts while offline.
T14: concurrent 401s -> one Session refresh, not multiple Recovery loops.
T15: Session becomes SIGNED_OUT -> no retry scheduled.
T16: Recovery Orchestrator never recursively invokes itself.
T17: Retry Scheduler remains the only owner of backoff/jitter.
