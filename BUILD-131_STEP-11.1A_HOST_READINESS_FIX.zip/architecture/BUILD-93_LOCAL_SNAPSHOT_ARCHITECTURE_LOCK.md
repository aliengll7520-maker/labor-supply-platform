# BUILD-93 — Local Snapshot / Offline First — Architecture Lock

Status: ARCHITECTURE LOCKED / CODE NOT IMPLEMENTED

Baseline:
- BUILD-92 — MBRL Architecture Lock
- BUILD-91 — Mobile Identity / Token Session

Purpose:
Define the Mobile Local Snapshot / Offline First architecture so the App can open safely
with weak/no network, avoid unnecessary Backend requests, prevent cache stampede, and
never expose stale identity data across accounts.

## 1. Storage Boundaries

A. Secure Storage
- Access Token
- Refresh Token
- Session credentials

B. Local Snapshot
- Platform modules
- Dictionaries/configuration
- Profile schema
- Region/config metadata when contract supports it

C. Short-lived Operational Cache
- Discovery feed
- Search results
- Recent jobs
- Profile summary
- Notification summary/unread count

D. Server Authoritative / Not a normal snapshot
- Credentials
- CCCD/identity-sensitive data
- Tax information
- Financial/salary-sensitive data
- Full authoritative application/interview state
- Other sensitive data unless a later security review explicitly permits it

The Local Snapshot is never the source of truth for authoritative business state.

## 2. Identity Isolation

All user-scoped local data must be identity/session scoped.

Never use a global key for user data such as:
- global:profile
- global:jobs
- global:notifications

On logout/account switch:
- revoke session as defined by BUILD-91;
- clear sensitive credentials;
- clear identity-scoped user cache;
- keep only public/global configuration where safe.

A new account must never inherit the previous account's user-scoped snapshot.

## 3. Snapshot Metadata

Each snapshot resource should carry:
- identity_scope where applicable
- resource_type
- resource_key
- schema_version
- data_version
- generated/updated timestamp
- expires_at where TTL is applicable

## 4. Synchronization Strategy

Configuration/Dictionary:
- version-based synchronization;
- conditional request / ETag or equivalent when supported;
- full snapshot is acceptable when the resource is small;
- do not introduce Delta Sync unless scale/data size later proves it necessary.

Discovery/Search:
- short-lived cache;
- pagination/cursor;
- controlled refresh;
- never download an entire feed for offline use.

Profile summary:
- TTL + version/updated_at where available;
- refresh when stale;
- Server remains authoritative.

Notification:
- server authoritative;
- local unread/summary cache only;
- FCM is a signal to refresh, not the authoritative notification database.

## 5. Offline Behavior

When offline:
- open the App using the last known good local snapshot where available;
- do not repeatedly call the Backend;
- clearly indicate that some displayed data may be stale;
- actions requiring server confirmation must not pretend to have succeeded.

Network recovery:
- pass through BUILD-92 MBRL;
- use jitter/backoff;
- perform version checks;
- refresh only stale resources;
- never create a recovery request burst.

## 6. Cache Stampede Protection

If a snapshot becomes stale:
- one logical refresh request per resource;
- other concurrent consumers share the in-flight result;
- use BUILD-92 request deduplication;
- use jitter for background refresh;
- keep the previous snapshot available until the new one is valid.

## 7. Atomic Snapshot Update

Never replace the active snapshot with partially downloaded data.

Required sequence:
download -> validate -> build new snapshot -> atomic replace.

If download/validation fails:
- retain the last known good snapshot;
- do not delete the old snapshot.

## 8. Invalidation Matrix

Access-token refresh:
- keep local snapshot unless resource is stale.

Logout:
- clear identity-scoped sensitive/user cache.

Account switch:
- clear old identity scope before activating the new identity scope.

Account blocked/revoked:
- clear sensitive/user snapshot and stop authoritative actions.

Network loss:
- use eligible local snapshot.

Network recovery:
- version-check and refresh only stale resources.

OS process kill:
- local snapshot may remain;
- on next start perform Secure Session Check + Snapshot Check;
- OS kill is not equivalent to logout.

## 9. Compatibility

Snapshot data must distinguish:
- schema_version
- data_version

If schema is incompatible:
- migrate if a supported migration exists;
- otherwise rebuild/download a compatible snapshot.

## 10. Last Known Good Rule

The App must always prefer:
"last known good snapshot"
over:
"empty/corrupted/partially updated snapshot".

## 11. Deferred Items

These remain outside BUILD-93 and are carried to later API Contract work:
- Mobile Error Contract
- Mobile Auth-specific rate limits
- Refresh/session/device-aware rate limits
- Full Idempotency Store
- API version metadata contract

Native local database technology is intentionally not selected because the Native Mobile codebase/framework baseline has not yet been established.

## 12. Implementation Boundary

BUILD-93 is an architecture lock only.
No Android/iOS Native implementation is introduced.
No Backend code is changed.

Implementation can begin only after the Native Mobile baseline/framework is established.

## 13. Acceptance Criteria for Later Implementation

Implementation is not complete until:
- storage boundaries are enforced;
- identity isolation is tested;
- offline start works;
- network recovery does not create request storms;
- cache stampede protection works;
- atomic snapshot replacement works;
- corrupted/new snapshot failure retains the last known good snapshot;
- logout/account-switch isolation passes;
- schema/data version compatibility passes;
- runtime fault tests pass.
