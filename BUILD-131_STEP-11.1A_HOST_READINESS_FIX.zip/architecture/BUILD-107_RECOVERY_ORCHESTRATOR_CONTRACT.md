# BUILD-107 — Recovery Orchestrator Contract

Baseline: BUILD-106 Corrected.

## Responsibility boundaries

Recovery Orchestrator is the single decision layer for normalized recoverable failures.

- API Client: builds/sends HTTP and normalizes response.
- Session Manager: owns authentication state and refresh.
- Recovery Orchestrator: classifies the normalized result and chooses the next owner.
- BUILD-100 Retry Scheduler: owns retry timing, backoff, jitter, WAIT_NETWORK and WAIT_RETRY.

No component may create a second retry engine.

## Decision table

SUCCESS (2xx)
-> complete operation.

UNAUTHORIZED (401)
-> Session Manager authentication recovery.
-> original request may be retried exactly once.
-> second 401 is terminal.

RATE_LIMITED (429)
-> honor Retry-After when present.
-> hand retry timing to BUILD-100.
-> no immediate busy retry.

SERVER_ERROR (5xx)
-> hand retryable work to BUILD-100.

TIMEOUT
-> hand retryable work to BUILD-100.

NETWORK_ERROR
-> WAIT_NETWORK / BUILD-100.

FORBIDDEN / VALIDATION_ERROR / NOT_FOUND / CONFLICT
-> terminal for automatic retry unless an explicit feature policy says otherwise.

## Idempotency

For mutation operations:
- one logical operation owns one Idempotency-Key;
- Recovery Orchestrator never generates a replacement key;
- BUILD-100 retries preserve the same key.

GET requests do not acquire an Idempotency-Key merely because recovery is scheduled.

## Authentication boundary

Recovery Orchestrator never directly manipulates access/refresh tokens.
It asks Session Manager to recover authentication.

If Session Manager reaches SIGNED_OUT:
- no retry is scheduled for the authenticated request;
- UI may navigate to login through the normal session observer.

## Retry handoff

Recovery Orchestrator submits a retry intent containing:
- original request;
- logical operation identifier;
- current attempt count;
- priority;
- idempotency key if mutation;
- normalized error;
- Retry-After metadata if present.

It does not calculate exponential backoff or jitter. BUILD-100 does that.

## Offline

When Network Monitor reports offline:
- no retry attempt is made;
- operation enters WAIT_NETWORK through BUILD-100;
- recovery resumes only after network recovery/debounce.

## Loop prevention

A recovery action must have a bounded transition:
REQUEST -> RESPONSE -> RECOVERY DECISION -> OWNER.

The Recovery Orchestrator MUST NOT call itself recursively.

## Security

- no token values;
- no Authorization headers;
- no secrets in retry payload;
- logs use request/operation identifiers only.
