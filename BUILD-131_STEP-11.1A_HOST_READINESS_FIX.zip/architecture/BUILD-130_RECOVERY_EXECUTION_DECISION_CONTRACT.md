# BUILD-130 — Recovery Orchestrator Delegation → Recovery Execution Decision

Baseline: BUILD-129 Final.

## Purpose
Translate a Recovery Orchestrator delegation into an explicit recovery execution decision without performing recovery work.

## Decisions
CLOSED -> NO_ACTION
CONTINUE_RECOVERY -> EXECUTE_RECOVERY

## Ownership
- BUILD-129: delegates the recovery closure decision.
- BUILD-130: produces recovery execution decision only.
- Recovery Orchestrator: single owner of actual recovery execution.
- BUILD-100: retry timing.
- BUILD-109: retry execution.
- Lifecycle Controller: lifecycle transition execution.

## Rules
1. BUILD-130 never performs recovery work.
2. BUILD-130 never executes retry.
3. BUILD-130 never schedules retry.
4. BUILD-130 never calculates retry timing.
5. BUILD-130 never mutates lifecycle state.
6. BUILD-130 never rolls back committed state.
7. CLOSED produces NO_ACTION only.
8. CONTINUE_RECOVERY produces EXECUTE_RECOVERY only; it does not execute recovery inside BUILD-130.
9. operationId, eventId and attempt are preserved unchanged.
10. Delegation metadata is preserved unchanged.
11. No HTTP is performed.
12. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
13. No BUILD-130 database migration.
