# BUILD-116 — Event Idempotency Test Matrix

T01: First eventId submission is STORED.
T02: Same eventId + identical payload returns DUPLICATE_IDEMPOTENT.
T03: Same eventId + different payload returns CONFLICT.
T04: Conflict never overwrites the original event.
T05: Concurrent same-eventId submissions store exactly one event.
T06: Different eventIds are independently accepted.
T07: operationId remains unchanged.
T08: versionBefore/versionAfter remain unchanged.
T09: Category remains unchanged.
T10: No Token/credential is accepted into audit payload.
T11: No Idempotency-Key is accepted into audit payload.
T12: Deduplication layer does not mutate lifecycle.
T13: Deduplication layer does not send HTTP.
T14: Deduplication layer does not schedule retry.
T15: No BUILD-116 database migration.
