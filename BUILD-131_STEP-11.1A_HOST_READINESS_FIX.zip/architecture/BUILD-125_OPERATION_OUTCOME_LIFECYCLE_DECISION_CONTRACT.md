# BUILD-125 — Operation Outcome → Lifecycle Transition Decision Contract

Baseline: BUILD-124 Final.

## Purpose
Translate an immutable OperationOutcome into a lifecycle transition decision without mutating lifecycle state.

## Ownership
- BUILD-124: produces OperationOutcome.
- BUILD-125: produces lifecycle transition decision only.
- Lifecycle Controller: single owner of lifecycle transition execution.
- BUILD-100: retry timing.
- BUILD-109: retry execution.

## Decisions
SUCCESS -> COMPLETE
FAILED -> RECOVERY_REQUIRED
ABORTED -> ABORTED

## Rules
1. BUILD-125 never executes a lifecycle transition.
2. BUILD-125 never mutates lifecycle state.
3. BUILD-125 never rolls back a committed lifecycle transition.
4. BUILD-125 never retries.
5. BUILD-125 never schedules retry.
6. BUILD-125 never calculates retry timing.
7. BUILD-125 never executes retry.
8. operationId, eventId and attempt are preserved unchanged.
9. Outcome metadata is preserved unchanged.
10. No HTTP is performed.
11. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
12. Lifecycle Controller remains the single transition executor.
13. No BUILD-125 database migration.
