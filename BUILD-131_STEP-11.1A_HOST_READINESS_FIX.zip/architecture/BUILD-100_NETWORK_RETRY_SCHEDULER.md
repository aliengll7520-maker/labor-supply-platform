# BUILD-100 — Mobile Network Monitor + Retry Scheduler

Baseline: BUILD-99

## Network Monitor

Single app-level source of truth:
ONLINE -> OFFLINE -> ONLINE

Rules:
- API calls do not independently own global network state.
- OFFLINE pauses retryable work and moves active network jobs to WAIT_NETWORK.
- Network failure does not invalidate authentication.
- ONLINE recovery is debounced and jittered before scheduler wake-up.

## Retry Scheduler

A single scheduler selects jobs where:
- state = pending
- next_retry_at is null or <= now
- network is ONLINE

Ordering:
1. priority ASC (P0 before P1 before P2)
2. next_retry_at ASC
3. created_at ASC

Concurrency:
- one active attempt per coalesced GET domain/operation.
- scheduler must not create duplicate attempts for the same logical job.

## Retry Policy

Network/timeout/408/5xx:
- WAIT_RETRY
- exponential backoff + jitter
- recommended base: 2s, 5s, 15s, 30s, 60s, capped.

429:
- WAIT_RETRY
- honor Retry-After when supplied
- never retry faster than the server-directed delay.

Offline:
- WAIT_NETWORK
- attempt_count is NOT incremented while no network exists.

401:
- coordinate through one single-flight refresh.
- retry the original request once after successful refresh.
- if refresh is invalid/revoked, terminate the authenticated session and require login.

Other 4xx:
- FAILED without blind retry.

## Mutation Safety

For POST/PUT/PATCH/DELETE:
- Idempotency-Key is generated once when the logical job is created.
- Every retry of that same job uses the exact same key.
- A new key means a new logical operation.

## Recovery

When ONLINE returns:
- wait for debounce window;
- apply per-device jitter;
- wake scheduler;
- process P0 then P1 then P2;
- P1/P2 never block first usable UI.

## Scheduler Safety

- No tight retry loops.
- No retry while OFFLINE.
- No duplicate scheduler instances.
- Scheduler state survives app restarts through the local sync_jobs store.
