# BUILD-115 — Audit Integration Test Matrix

T01: CREATED -> RUNNING committed transition emits one audit event.
T02: RUNNING -> WAIT_RETRY emits RETRY event.
T03: RUNNING -> WAIT_NETWORK emits NETWORK event.
T04: RUNNING -> AUTHENTICATION_RECOVERY emits AUTHENTICATION event.
T05: RUNNING -> SUCCESS emits SUCCESS event.
T06: RUNNING -> TERMINAL emits TERMINAL event.
T07: Any active state -> CANCELLED emits CANCELLED event.
T08: Rejected/stale transition emits no event.
T09: Event ID is unique per committed transition.
T10: operationId is preserved.
T11: versionBefore/versionAfter match the committed transition.
T12: attempt and reason are preserved.
T13: Audit sink failure does not roll back lifecycle state.
T14: Audit integration does not send HTTP.
T15: Audit integration does not schedule retries.
T16: Audit integration does not execute retries.
T17: Audit integration does not mutate lifecycle.
T18: No Token/credential/Idempotency-Key/HTTP secret enters event.
T19: No BUILD-115 database migration.
