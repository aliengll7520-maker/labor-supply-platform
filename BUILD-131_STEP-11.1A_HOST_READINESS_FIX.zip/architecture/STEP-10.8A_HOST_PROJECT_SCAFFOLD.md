# STEP 10.8A — Host Project Scaffold

Baseline:
`BUILD-130_STEP-10.8_RUNTIME_VERIFICATION.zip`

## Added

Android host scaffold:
`host/android/`

iOS host scaffold:
`host/ios/`

## Purpose

Supply the missing project-level entry/configuration primitives identified by
10.8 so the existing App Shell, WebView, Bridge Listener, Floating Host, and
Callback chain can be hosted by a real application project.

## Deliberate configuration boundaries

The Website URL is a deployment configuration value and is intentionally not
invented.

The package/application/bundle identifiers in the scaffold are technical
placeholder values and must be replaced by the official project identifiers
before release.

## No architecture changes

Existing Bridge, Content, Floating Surface, Callback, Session, and Business
Logic are not duplicated or redesigned.

## Runtime status

This scaffold removes the specific "missing host project metadata" blocker at
the source/project-structure level. Actual build and device/emulator execution
still requires the official project identifiers, approved Website URL, and
platform SDK/toolchain.

Status: IMPLEMENTED — READY FOR REVIEW
