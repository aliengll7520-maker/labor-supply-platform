# BUILD-115 — Audit Integration Contract

Baseline: BUILD-114 Final.

## Purpose

Connect committed lifecycle transitions to the BUILD-114 Operation Event Audit layer.

## Ownership

- Operation Coordinator: coordinates operation flow.
- Operation Lifecycle Controller: commits lifecycle transitions.
- Operation Event Audit: creates audit events after committed transitions.
- Event Sink: persists/delivers audit events.
- Recovery Loop: recovery decisions.
- BUILD-100: retry timing.
- BUILD-109: retry execution.
- API Client: HTTP.
- Session Manager: authentication.

## Rules

1. Audit recording occurs only after a lifecycle transition is committed.
2. Rejected/stale transitions create no audit event.
3. Audit failure must not roll back an already committed lifecycle transition.
4. Event ID is unique per committed transition.
5. operationId is immutable.
6. versionBefore and versionAfter exactly describe the committed transition.
7. attempt and reason are copied from the committed operation context.
8. No Token, credential, Idempotency-Key, HTTP body, or secret header enters the audit event.
9. Audit integration never sends HTTP directly.
10. Audit integration never schedules or executes retries.
11. Audit integration never changes lifecycle state.
12. Event sink failure is observable but does not mutate operation state.
13. No BUILD-115 database migration.
