# STEP 10.4A — Native Floating Hosts

Baseline:
`BUILD-130_STEP-10.3_NATIVE_WEBVIEW_LISTENER.zip`

## Added

### Android
`mobile/android/FloatingSurfaceHost.kt`

A minimal presentation host that overlays a supplied View on the existing
Activity content root. It owns only the transient presentation container.

### iOS
`mobile/ios/FloatingSurfaceHost.swift`

A minimal presentation host that presents a supplied UIViewController over
the existing host UIViewController.

## Boundaries

These hosts do not:
- create a new content source;
- create a business layer;
- create a social state;
- create a database;
- call an API;
- implement sharing/comment/like/rating;
- implement callback;
- implement final memory cleanup;
- replace the WebView/App Shell.

The caller supplies the existing Native host and the surface content.

## Important

This step establishes the missing Native Floating Host primitives only.
The actual Floating Surface content and lifecycle integration remain the
next controlled sub-step.

Status: IMPLEMENTED — READY FOR REVIEW
