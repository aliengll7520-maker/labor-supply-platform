-- BUILD-100 — Mobile-local schema documentation.
-- No backend/cPanel migration.

-- Existing BUILD-99 sync_jobs fields used:
-- state, priority, attempt_count, max_attempts, next_retry_at,
-- last_error_code, last_error_at, idempotency_key, lease_until.

-- Optional scheduler coordination record:
CREATE TABLE IF NOT EXISTS scheduler_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    network_state TEXT NOT NULL DEFAULT 'offline',
    next_wake_at INTEGER NULL,
    last_online_at INTEGER NULL,
    last_run_at INTEGER NULL,
    updated_at INTEGER NOT NULL
);

-- State values:
-- network_state: online | offline | unknown
