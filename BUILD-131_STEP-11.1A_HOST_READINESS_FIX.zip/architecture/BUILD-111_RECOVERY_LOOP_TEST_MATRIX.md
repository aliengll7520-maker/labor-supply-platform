# BUILD-111 — Recovery Loop Test Matrix

T01: SUCCESS closes operation.
T02: terminal 4xx closes operation.
T03: 401 routes to authentication recovery.
T04: second 401 after recovery closes terminal.
T05: 429 routes to BUILD-100 without local backoff.
T06: 5xx routes to BUILD-100.
T07: timeout routes to BUILD-100.
T08: network error routes to WAIT_NETWORK.
T09: signed-out authenticated operation closes without retry.
T10: attempt count is monotonic.
T11: stale result/version is rejected.
T12: duplicate result cannot commit a second transition.
T13: mutation Idempotency-Key remains unchanged.
T14: GET remains without Idempotency-Key.
T15: controller never calls API Client directly.
T16: controller never recursively invokes itself.
T17: one logical operation has one committed transition at a time.

T18: Audit confirms one committed transition per operation version using version matching and stale-result rejection.
