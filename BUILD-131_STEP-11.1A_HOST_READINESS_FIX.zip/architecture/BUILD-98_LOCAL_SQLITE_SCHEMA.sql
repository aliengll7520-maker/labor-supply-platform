-- BUILD-98 — illustrative local SQLite schema for Android/iPhone.
-- This is a Mobile-local schema, not a Backend migration.

CREATE TABLE cache_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cache_key TEXT NOT NULL UNIQUE,
    domain TEXT NOT NULL,
    version TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    fetched_at INTEGER NOT NULL,
    expires_at INTEGER NULL,
    stale_after INTEGER NULL,
    last_sync_at INTEGER NULL,
    updated_at INTEGER NOT NULL
);

CREATE INDEX idx_cache_domain ON cache_records(domain);

CREATE TABLE sync_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT NOT NULL,
    operation TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 2,
    state TEXT NOT NULL DEFAULT 'pending',
    attempt_count INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 6,
    next_retry_at INTEGER NULL,
    last_error_code TEXT NULL,
    last_error_at INTEGER NULL,
    idempotency_key TEXT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    UNIQUE(domain, operation)
);

CREATE INDEX idx_sync_ready
ON sync_jobs(state, priority, next_retry_at);

CREATE INDEX idx_sync_idempotency
ON sync_jobs(idempotency_key);
