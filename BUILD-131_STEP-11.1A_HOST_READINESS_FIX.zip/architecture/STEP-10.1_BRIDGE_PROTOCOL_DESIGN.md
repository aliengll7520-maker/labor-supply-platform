# STEP 10.1 — Bridge Protocol Design
## Unified Content Interaction / Floating Surface Architecture

Status: REVISED DESIGN — READY FOR REVIEW

### 1. Architectural Principle

The Website and Native App are two presentation surfaces over the same
Website/Platform source of truth.

- Website Surface: direct browser experience.
- Native App Shell: native presentation shell that exposes Platform content
  and interaction UI.
- Shared Content Core: owns content/resources.
- Platform / Social Core: owns interaction rules and Unified Social State.
- Bidirectional Bridge: communication contract between Web and Native
  surfaces; it does not own business state.

The Native App does not become an independent content/business platform.

### 2. Unified Interaction Model

Any content resource that exposes social interaction may use the same
interaction model, including recruitment jobs from Suppliers or Enterprises
and other supported content.

Canonical interaction context:
- `resourceType`
- `resourceId`
- `action`
- `context` (optional/minimal)

Examples of actions include:
- `like`
- `favorite`/`save` where already defined by the platform
- `comment`
- `share`
- `rating` where supported

The protocol does not redefine the business semantics of these actions.
Existing Platform/Social Core remains authoritative.

### 3. Web → Native Trigger

Event:
`platform.surface.open`

Required envelope:
- `protocolVersion`
- `requestId`
- `event`
- `surfaceId`
- `payload`

For an interaction-driven Floating Surface, `payload` contains only the
minimal context needed to identify the current resource and requested
interaction, for example:
- `resourceType`
- `resourceId`
- `action`
- optional minimal `context`

`requestId` remains unchanged through the complete lifecycle.

### 4. Native → Web Callback

Event:
`platform.surface.callback`

Required envelope:
- `protocolVersion`
- `requestId`
- `event`
- `surfaceId`
- `status`
- `result` (optional/minimal)

The callback allows the originating surface to update presentation state.
Business truth remains in the Platform/Social Core.

### 5. Status

Reserved surface lifecycle statuses:
- `OPENED`
- `CLOSED`
- `CANCELLED`
- `FAILED`

A surface status is not itself a business/social state.

### 6. Bidirectional Flow

For a Native App interaction requiring a Floating Surface:

App Shell / Native UI
→ Bridge Trigger
→ Native Floating Surface
→ existing Session/Cache as applicable
→ User interaction / close
→ Memory Cleanup
→ Bridge Callback
→ App UI state update

Where Website-side execution is required, the Platform/Social Core remains
the source of truth and the Website surface updates from the authoritative
result.

### 7. Website Direct Access

When the user accesses the Website directly, the same interaction concepts
are rendered by the Website Surface without requiring the Native App.

Example:
Website Surface → Interaction → Platform/Social Core → Unified Social State.

The existence of the Native App must not create a second social system.

### 8. Ownership

- Website/Platform: content, business rules, social rules, authoritative
  interaction state and database.
- Website Surface: browser presentation.
- Native App Shell: native presentation.
- Bridge: bidirectional transport/connection contract.
- Floating Surface: transient native presentation.
- Session/Cache: reuse existing approved infrastructure.

### 9. Explicit Non-Goals

This protocol does not:
- create a second Social Core;
- create App-owned social state;
- create a feature database;
- create a new business API;
- duplicate Content Core;
- define a new Like/Comment/Share business implementation;
- implement Android/iOS UI;
- implement Website trigger code;
- implement callback code.

### 10. Acceptance Criteria

10.1-A Website and Native App are treated as two surfaces over one Platform.
10.1-B Interaction context is resource/action based, not Job-only.
10.1-C Supplier and Enterprise jobs can use the same interaction contract.
10.1-D Bridge is bidirectional.
10.1-E Unified Social State belongs to Platform/Social Core, not Bridge.
10.1-F Existing Session/Cache are reused where applicable.
10.1-G No second social/database/state system is introduced.
10.1-H No Web/Android/iOS implementation is included in this protocol step.
