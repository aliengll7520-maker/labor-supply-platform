# BUILD-118 — Persistence Adapter Integration Contract

Baseline: BUILD-117 Final.

## Purpose
Connect committed lifecycle audit events to the BUILD-117 persistence boundary while preserving ownership and failure isolation.

## Rules
1. A lifecycle transition must be committed before persistence is attempted.
2. Audit event creation remains owned by OperationEventAudit.
3. Deduplication remains owned by OperationEventDeduplicator.
4. Persistence is delegated only through OperationEventPersistenceAdapter.
5. STORED means the event was persisted.
6. IDEMPOTENT means the event already exists with identical payload.
7. CONFLICT means the eventId exists with different payload; existing data is never overwritten.
8. Persistence failure never rolls back an already committed lifecycle transition.
9. operationId, eventId, versions, category, attempt and reason are preserved.
10. No Token, credential, Idempotency-Key, HTTP body or secret header enters persistence.
11. Integration sends no HTTP.
12. Integration schedules/executes no retry.
13. Integration changes no lifecycle state.
14. BUILD-118 introduces no database migration.
