# BUILD-122 — Coordinator → Retry Timing Delegation Boundary

Baseline: BUILD-121 Final.

## Purpose
Create the explicit delegation boundary from the Operation Coordinator to the existing BUILD-100 retry timing owner.

## Ownership
- BUILD-121: coordinator recovery delegation.
- BUILD-122: delegation boundary only.
- BUILD-100: single owner of retry timing/scheduling.
- BUILD-109: single owner of retry execution.

## Rules
1. BUILD-122 accepts a RETRY_ELIGIBLE recovery route only.
2. BUILD-122 delegates timing decisions to BUILD-100.
3. BUILD-122 does not calculate retry timing.
4. BUILD-122 does not schedule retry.
5. BUILD-122 does not execute retry.
6. BUILD-122 does not call HTTP.
7. BUILD-122 does not mutate lifecycle state.
8. operationId, eventId, attempt and recovery context are preserved unchanged.
9. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
10. BUILD-109 remains the single owner of retry execution.
11. No BUILD-122 database migration.
