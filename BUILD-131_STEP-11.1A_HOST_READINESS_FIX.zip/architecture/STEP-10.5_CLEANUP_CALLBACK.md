# STEP 10.5 — Memory Cleanup + Callback

Baseline:
`BUILD-130_STEP-10.4B_CONTENT_CONTRACT.zip`

## Implemented lifecycle

Native Floating Surface close now follows:

1. Remove/dismiss the transient surface.
2. Release the Native surface reference.
3. Emit `platform.surface.callback` back into the Website WebView.
4. Website receives the callback and updates the existing Share UI state.

## Callback envelope

- `protocolVersion`
- `requestId`
- `event = platform.surface.callback`
- `surfaceId`
- `status`
- optional `result`

Supported lifecycle statuses:
- `CLOSED`
- `CANCELLED`
- `FAILED`

## Website

The existing `api.js` now exposes `bridgeSubscribe(callback)` for the Website
surface to receive approved callback messages.

The existing `ShareMenu` subscribes and updates its local presentation message
for matching `share-*` request IDs.

## Native

Android and iOS Floating Hosts:
- remove/dismiss the surface;
- clear the retained surface reference;
- only then emit the callback.

The WebView remains the existing content/session surface. No Native business
state or local database is introduced.

## Explicit non-goals

- No new backend API.
- No database.
- No duplicated content.
- No App-owned social state.
- No new utility file.
- No new Business Logic.
- No change to Website content source.

Status: IMPLEMENTED — READY FOR REVIEW
