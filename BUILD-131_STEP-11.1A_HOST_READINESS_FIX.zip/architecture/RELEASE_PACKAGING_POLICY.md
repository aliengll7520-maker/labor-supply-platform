# Labor Platform — Release Packaging Policy

1. BUILD ZIP
   - Complete development snapshot.
   - Used for audit, rollback and continued development.
   - Not a migration command.

2. RELEASE ZIP
   - One complete production source tree (the production application files required by the release).
   - Never contains BUILD ZIPs.
   - Never requires stacking multiple BUILD ZIPs.

3. Database migrations
   - Managed separately from source release packaging.
   - Existing legacy migration filenames are preserved.
   - New migration identifiers must be allocated by the migration registry/process, not derived from BUILD numbers.
   - A BUILD that changes no backend database schema creates no backend migration.

4. Mobile-local SQL
   - Mobile SQLite schema files belong under architecture/mobile documentation.
   - They are never executed against the cPanel backend database.

5. cPanel deployment
   - Deploy one RELEASE ZIP.
   - Apply only the database migrations explicitly listed for that release.
   - Do not run the entire historical database directory again.
