# BUILD-116 — Audit Event Idempotency & Deduplication Contract

Baseline: BUILD-115 Final.

## Purpose

Prevent duplicate audit events while preserving immutable event identity and payload integrity.

## Rules

1. eventId is the idempotency key for an audit event.
2. First submission of an eventId stores the event.
3. Re-submission of the same eventId with identical payload is idempotent success.
4. Re-submission of the same eventId with different payload is a conflict.
5. A conflict never overwrites the original event.
6. Concurrent submissions of the same eventId result in one stored event.
7. Deduplication is performed before persistence.
8. The deduplication layer does not change lifecycle state.
9. It does not send HTTP, schedule retries, or execute retries.
10. operationId, versionBefore, versionAfter and category remain immutable.
11. No Token, credential, Idempotency-Key, HTTP body or secret header is stored.
12. BUILD-116 adds no database migration.
