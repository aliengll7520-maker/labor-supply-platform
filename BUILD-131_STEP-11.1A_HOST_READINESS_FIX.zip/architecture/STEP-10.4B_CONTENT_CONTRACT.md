# STEP 10.4B — Floating Surface Content Contract

Baseline:
`BUILD-130_STEP-10.4A_FLOATING_HOSTS.zip`

## Implemented contract boundary

The Native Floating Host now accepts the validated `BridgeRequest` together
with caller-supplied presentation content.

The host uses only:
- `surfaceId` to verify that a surface has been identified;
- the supplied View / UIViewController as presentation content.

The host does NOT extract or duplicate Website content and does NOT own
business or social state.

## Content rule

The Website remains the content source and Platform remains the source of
truth.

The Bridge request carries minimal context:

- `protocolVersion`
- `requestId`
- `event`
- `surfaceId`
- `payload.resourceType`
- `payload.resourceId`
- `payload.action`
- `payload.context`

No recruitment/job content is copied into Native by this step.

## Implemented source delta

Android:
`AndroidFloatingSurfaceHost.open(request: BridgeRequest, contentView: View)`

iOS:
`IOSFloatingSurfaceHost.open(request: BridgeRequest, surfaceViewController: UIViewController)`

Both methods only validate the surface identifier and delegate to the
existing presentation host.

## Explicit non-goals

- No new UI/business implementation.
- No duplicated Website content.
- No database.
- No App-owned social state.
- No new API.
- No callback.
- No final memory-cleanup lifecycle.
- No content fetching.

Status: IMPLEMENTED — READY FOR REVIEW
