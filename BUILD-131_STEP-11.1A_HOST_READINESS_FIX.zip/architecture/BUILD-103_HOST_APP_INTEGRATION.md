# BUILD-103 — Host App Integration Contract

Baseline: BUILD-102.

## Scope

Connect BUILD-102 API Client to a future Android/iOS host application without inventing a native project structure that does not exist in the baseline.

## Android

Host provides:
- HTTP transport implementation.
- Android protected token store.
- single-flight refresh coordinator.
- network monitor adapter.
- retry scheduler adapter.

`AndroidApiEnvironment` is the composition root for the API Client.

## iOS

Host provides:
- HTTP transport implementation.
- Keychain-backed token store.
- single-flight refresh coordinator.
- network monitor adapter.
- retry scheduler adapter.

`IOSApiEnvironment` is the composition root for the API Client.

## Security

- Access/refresh tokens stay in protected storage.
- Tokens never enter SQLite/local cache payloads.
- Authorization headers never go to logs.
- Refresh is never initiated recursively through the ordinary API Client request path.

## Retry ownership

BUILD-100 owns retry timing/state.
BUILD-102 owns request construction and response normalization.
BUILD-103 only provides the adapter boundary between them.

The API Client must not create a second independent retry engine.

## Connectivity

One host-level Network Monitor feeds the scheduler.
Offline does not invalidate authentication.
Network recovery wakes the scheduler after debounce/jitter.

## Mutation

The logical operation owns one Idempotency-Key.
Host adapters must preserve that key when handing a mutation back to BUILD-100.

## Lifecycle

A future native host may start/stop:
- Network Monitor
- Retry Scheduler
- Cache/Sync worker

without changing the API Client contract.

## No backend change

BUILD-103 adds no backend database migration and no cPanel deployment requirement.
