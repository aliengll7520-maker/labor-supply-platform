# BUILD-121 — Recovery Decision → Operation Coordinator Integration

Baseline: BUILD-120 Final.

## Purpose
Connect BUILD-120 recovery routing to the Operation Coordinator without transferring ownership of retry timing, retry execution, lifecycle state, HTTP, or escalation transport.

## Ownership
- BUILD-119: failure classification and recovery decision.
- BUILD-120: decision-to-route mapping.
- BUILD-121: coordinator-level delegation only.
- BUILD-100: retry timing/scheduling.
- BUILD-109: retry execution.
- Operation Lifecycle Controller: lifecycle state.
- API Client: HTTP.
- Escalation boundary: external escalation delivery.

## Rules
1. Operation Coordinator receives a recovery decision and delegates it to the correct owner.
2. RETRY_ELIGIBLE delegates to BUILD-100 timing.
3. TERMINAL delegates to the terminal lifecycle path; BUILD-121 does not mutate lifecycle directly.
4. ESCALATE delegates to the escalation boundary; BUILD-121 does not perform HTTP or notification.
5. BUILD-121 never schedules a retry.
6. BUILD-121 never executes a retry.
7. BUILD-121 never changes lifecycle state directly.
8. operationId and eventId are preserved unchanged.
9. No Token, credential, Idempotency-Key, HTTP body or secret header enters coordinator routing.
10. Existing committed lifecycle state is never rolled back.
11. No BUILD-121 database migration.
