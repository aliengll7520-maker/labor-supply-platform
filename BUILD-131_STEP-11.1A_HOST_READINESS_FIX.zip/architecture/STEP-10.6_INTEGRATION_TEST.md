# STEP 10.6 — Integration Test / Static Contract Audit

Baseline: `BUILD-130_STEP-10.5_CLEANUP_CALLBACK.zip`

Audit-only step. No application source, API, database, UI, or business logic
is changed.

Verified loop:
Website interaction → `platform.surface.open` → Android/iOS WebView listener
→ validated BridgeRequest → Floating Host → cleanup/dismiss
→ `platform.surface.callback` → Website `bridgeSubscribe`
→ matching Share UI state update.

The audit verifies protocol continuity, request correlation, resource/action/
context continuity, listener validation, Floating Host availability, cleanup
before callback, callback continuity, Website consumption, and source scope.

Runtime limitation: this audit does not execute the Android/iOS application on
a physical device or emulator because the baseline does not contain a complete
buildable App Shell/WebView project.

Limitation: this is a static integration audit. Runtime Android/iOS device or
emulator execution requires a buildable App Shell/WebView project, which is
not represented as a complete build project in this baseline.

Status: STATIC INTEGRATION AUDIT — READY FOR REVIEW
