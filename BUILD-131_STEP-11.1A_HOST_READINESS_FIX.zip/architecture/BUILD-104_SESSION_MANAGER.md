# BUILD-104 — Authentication Session Manager

Baseline: BUILD-103.

## Single owner

SessionManager is the single owner of Mobile authentication state.

UI, repositories and feature modules:
- observe state;
- request authenticated operations;
- do not independently decide logout.

## States

SIGNED_OUT
RESTORING
AUTHENTICATED
REFRESHING
EXPIRED
REVOKED

## Core transitions

SIGNED_OUT -> RESTORING
RESTORING -> AUTHENTICATED
RESTORING -> SIGNED_OUT
AUTHENTICATED -> REFRESHING
REFRESHING -> AUTHENTICATED
REFRESHING -> REVOKED
REFRESHING -> EXPIRED
EXPIRED -> SIGNED_OUT
REVOKED -> SIGNED_OUT

## Refresh rules

- One refresh operation may be active at a time.
- Concurrent callers must await/coalesce the same refresh operation at the host integration layer.
- Successful refresh updates only Secure Storage.
- Network failure does not log the user out.
- Invalid/revoked/reuse-detected refresh terminates the authenticated session.
- The normal API request pipeline must not recursively invoke refresh.

## Logout

Logout:
- clears Secure Storage;
- stops further refresh;
- transitions to SIGNED_OUT;
- does not allow a late refresh result to restore AUTHENTICATED.

## Startup

App start:
RESTORING -> inspect protected session -> AUTHENTICATED or SIGNED_OUT.

The Session Manager does not read tokens from SQLite/local cache.

## Lifecycle

When app is backgrounded, session state remains owned by SessionManager.
When foregrounded, the host may request a session validation/refresh through the same manager.

## Security

Access/refresh tokens never enter:
- SQLite cache;
- logs;
- UI state;
- analytics payloads.

## Build relationships

BUILD-96: refresh-token security.
BUILD-101/102: API Client.
BUILD-103: host integration.
BUILD-104: authentication session state owner.
