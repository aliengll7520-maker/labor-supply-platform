# BUILD-109 — Retry Execution Test Matrix

T01: Valid retry intent executes exactly one API Client request.
T02: Attempt count increments exactly once.
T03: Max-attempt intent is rejected without HTTP execution.
T04: Cancelled operation is rejected without HTTP execution.
T05: Signed-out authenticated session is rejected without HTTP execution.
T06: WAIT_NETWORK intent executes only after Scheduler release.
T07: Coordinator never calculates backoff/jitter.
T08: Coordinator never creates a second retry scheduler.
T09: Mutation preserves the original Idempotency-Key.
T10: GET does not acquire a new Idempotency-Key.
T11: Coordinator never directly refreshes tokens.
T12: Stale retry intent is rejected.
T13: Retry execution returns normalized API result to Recovery Orchestrator.
T14: A failed retry does not recursively execute another retry.
T15: Concurrent execution of the same intent is deduplicated.

T16: Static audit confirms RetryExecutionCoordinator has no token read/write calls.
T17: Static audit confirms execute() has no self-call and performs one client.execute call per admitted invocation.

T18: Self-recursion audit distinguishes `client.execute(...)` from a direct `RetryExecutionCoordinator.execute(...)` self-call.
