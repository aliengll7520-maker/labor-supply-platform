# BUILD-117 — Event Persistence Adapter Test Matrix

T01: First event is STORED.
T02: Same eventId + same payload is IDEMPOTENT.
T03: Same eventId + different payload is CONFLICT.
T04: Conflict never overwrites existing event.
T05: Concurrent same-eventId writes store one event.
T06: Different eventIds are independent.
T07: operationId is preserved.
T08: versionBefore/versionAfter are preserved.
T09: Category, attempt and reason are preserved.
T10: No Token/credential/Idempotency-Key/HTTP secret is persisted.
T11: Persistence does not mutate lifecycle.
T12: Persistence does not send HTTP.
T13: Persistence does not schedule/execute retry.
T14: Adapter has no database-specific dependency in its contract.
T15: No BUILD-117 database migration.
