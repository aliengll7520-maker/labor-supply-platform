# BUILD-112 — Operation Lifecycle Test Matrix

T01: New operation starts CREATED.
T02: Start moves CREATED -> RUNNING exactly once.
T03: RUNNING can enter WAIT_RETRY.
T04: RUNNING can enter WAIT_NETWORK.
T05: RUNNING can enter AUTHENTICATION_RECOVERY.
T06: SUCCESS is terminal.
T07: TERMINAL is terminal.
T08: CANCELLED is terminal.
T09: Cancelled operation cannot be retried.
T10: Cancelled operation cannot execute a released retry.
T11: Late network result cannot resurrect CANCELLED.
T12: OperationId remains immutable.
T13: Mutation Idempotency-Key remains immutable.
T14: Version is monotonic.
T15: Stale version cannot commit.
T16: Duplicate cancellation is idempotent.
T17: Lifecycle Controller never sends HTTP.
T18: Lifecycle Controller never refreshes tokens.
T19: Lifecycle Controller never calculates retry timing.
T20: Closed operation cannot transition back to RUNNING.
