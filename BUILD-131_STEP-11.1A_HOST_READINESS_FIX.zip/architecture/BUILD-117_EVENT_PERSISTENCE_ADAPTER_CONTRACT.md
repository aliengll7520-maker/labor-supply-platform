# BUILD-117 — Event Persistence Adapter Contract

Baseline: BUILD-116 Final.

## Purpose
Define a persistence boundary for audit events without coupling audit logic to a database, HTTP, retry, or lifecycle implementation.

## Ownership
- OperationEventAudit: creates validated audit events.
- OperationEventDeduplicator: prevents duplicate/conflicting event identity.
- OperationEventPersistenceAdapter: persists already-deduplicated events.
- Storage implementation: owns physical persistence.
- Lifecycle/Coordinator/Recovery/Retry/API layers remain independent.

## Rules
1. Persistence accepts only a complete OperationAuditEvent.
2. eventId is the unique persistence identity.
3. First eventId stores the event.
4. Same eventId + identical payload is idempotent success.
5. Same eventId + different payload is conflict; existing data is never overwritten.
6. Persistence must be atomic for one event.
7. Concurrent writes of the same eventId result in one stored event.
8. Persistence does not mutate lifecycle state.
9. Persistence does not send HTTP.
10. Persistence does not schedule or execute retries.
11. No Token, credential, Idempotency-Key, HTTP body, or secret header is persisted.
12. Adapter is storage-technology agnostic.
13. BUILD-117 introduces no database migration.
