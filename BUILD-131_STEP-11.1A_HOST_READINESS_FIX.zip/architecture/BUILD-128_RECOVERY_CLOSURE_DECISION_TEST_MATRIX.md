# BUILD-128 — Recovery Closure Decision Test Matrix

T01: CONFIRMED maps to CLOSED.
T02: ALREADY_APPLIED maps to CLOSED.
T03: RECOVERY_SIGNAL maps to CONTINUE_RECOVERY.
T04: CONFIRMED does not mutate state.
T05: ALREADY_APPLIED does not re-execute transition.
T06: RECOVERY_SIGNAL does not choose retry.
T07: Boundary never performs recovery work.
T08: Boundary never retries.
T09: Boundary never schedules retry.
T10: Boundary never calculates retry timing.
T11: Boundary never executes retry.
T12: Boundary never mutates lifecycle.
T13: Boundary never rolls back committed state.
T14: operationId is preserved.
T15: eventId is preserved.
T16: attempt is preserved.
T17: Confirmation metadata is preserved.
T18: Boundary performs no HTTP.
T19: No Token/credential/Idempotency-Key/HTTP secret enters boundary.
T20: No BUILD-128 database migration.
