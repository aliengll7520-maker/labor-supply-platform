# BUILD-128 — Operation State Confirmation → Recovery Closure Decision

Baseline: BUILD-127 Final.

## Purpose
Translate an operation state confirmation into a recovery closure decision without mutating lifecycle state or performing recovery work.

## Decisions
CONFIRMED -> CLOSED
ALREADY_APPLIED -> CLOSED
RECOVERY_SIGNAL -> CONTINUE_RECOVERY

## Ownership
- BUILD-127: produces OperationStateConfirmation.
- BUILD-128: produces recovery closure decision only.
- Recovery orchestrator/owner: executes subsequent recovery work.
- Lifecycle Controller: lifecycle transition execution.
- BUILD-100: retry timing.
- BUILD-109: retry execution.

## Rules
1. BUILD-128 never closes or mutates lifecycle state directly.
2. BUILD-128 never performs recovery work.
3. BUILD-128 never retries.
4. BUILD-128 never schedules retry.
5. BUILD-128 never calculates retry timing.
6. BUILD-128 never executes retry.
7. BUILD-128 never rolls back committed state.
8. RECOVERY_SIGNAL only produces CONTINUE_RECOVERY; it does not choose a retry.
9. CONFIRMED and ALREADY_APPLIED produce CLOSED decisions only; they do not mutate state.
10. operationId, eventId and attempt are preserved unchanged.
11. Confirmation metadata is preserved unchanged.
12. No HTTP is performed.
13. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
14. No BUILD-128 database migration.
