# BUILD-105 — Session ↔ API Client Integration Contract

Baseline: BUILD-104.

## Ownership

SessionManager is the single owner of authentication state.
API Client is the single HTTP request boundary.
RefreshCoordinator is the single-flight refresh mechanism.
Retry Scheduler owns retry timing.

No layer may duplicate another layer's responsibility.

## Authenticated request

API Client obtains the current access token from SessionManager/SecureTokenStore boundary and sends the request.

## 401 flow

1. API Client sends request with current access token.
2. Backend returns 401.
3. API Client asks SessionManager for coordinated refresh.
4. Exactly one refresh operation may run.
5. Concurrent 401 requests await the same refresh result.
6. On refresh success, the original request is retried exactly once.
7. Mutation retries retain the original Idempotency-Key.
8. If refresh is invalid/revoked/reuse-detected, SessionManager transitions to terminal auth state and SIGNED_OUT.
9. A second 401 after the one retry is terminal for that request.

## Logout race

If logout occurs while refresh is running:
- session generation/version is advanced;
- refresh completion must compare its captured generation;
- a stale refresh result MUST NOT restore AUTHENTICATED;
- tokens remain cleared.

## Refresh network failure

A network/timeout failure during refresh:
- does not logout the user;
- does not invalidate tokens merely because connectivity failed;
- is handed to BUILD-100 retry/recovery policy where appropriate.

## Retry separation

API Client:
- builds/sends request;
- normalizes response;
- performs one coordinated auth recovery.

BUILD-100:
- schedules retryable network/server work;
- manages WAIT_NETWORK/WAIT_RETRY;
- owns backoff/jitter.

API Client must not start a second retry engine.

## Session generation

Every authenticated session has a monotonically increasing session generation.
Login/restore creates a current generation.
Logout/revocation increments it.
A refresh result is accepted only if its generation still matches the current generation.

## Security

- No token values in logs.
- No token values in cache.
- Refresh token never exposed to UI.
- No recursive refresh through the ordinary API request path.
