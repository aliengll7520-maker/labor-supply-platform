# BUILD-101 — Normalized Error Model

NETWORK_ERROR: DNS/socket/connectivity failure; scheduler may retry.
TIMEOUT: transport deadline exceeded; scheduler may retry.
UNAUTHORIZED: access token rejected; coordinate refresh once.
FORBIDDEN: authenticated but not allowed; no blind retry.
NOT_FOUND: resource absent; no blind retry.
VALIDATION_ERROR: request data invalid; fix input, no blind retry.
CONFLICT: business/resource conflict; no blind retry unless operation policy says otherwise.
RATE_LIMITED: respect Retry-After; scheduler waits.
SERVER_ERROR: retry according to scheduler policy.
UNKNOWN_ERROR: safe fallback; no uncontrolled retry.

Authentication terminal:
- REFRESH_INVALID
- REFRESH_REVOKED
- REFRESH_REUSE_DETECTED

These terminate the authenticated session and require login.
