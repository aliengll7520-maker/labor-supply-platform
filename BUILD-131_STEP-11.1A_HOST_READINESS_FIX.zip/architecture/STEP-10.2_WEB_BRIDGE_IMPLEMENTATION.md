# STEP 10.2 — Web-side Bridge Integration

Baseline:
`BUILD-130_STEP-10.1_BRIDGE_PROTOCOL_REVISED.zip`

## Implemented delta

1. Extended the existing `frontend/website/src/api.js` module with the
   Web-side Bridge transport function `bridgePostMessage(...)`.
2. Updated the existing `components/Share/ShareMenu.jsx` trigger for
   "Chia sẻ bằng điện thoại" to emit the approved
   `platform.surface.open` message before attempting the browser-native
   share fallback.

## Message envelope

- `protocolVersion`
- `requestId`
- `event`
- `surfaceId`
- `payload.resourceType`
- `payload.resourceId`
- `payload.action`
- `payload.context`

## Ownership

This step does not create a new Content/Social system. The Website remains
the source of truth. Native only receives the interaction context.

## Browser compatibility

If the Web-side bridge cannot be emitted, the existing browser
`navigator.share` behavior remains the fallback.

## Not implemented in 10.2

- Android/iOS WebView listener
- Native Floating Surface
- Native callback listener
- Database changes
- New backend API
- New local App state
- New utility file
- Business logic changes

Status: IMPLEMENTED — READY FOR REVIEW
