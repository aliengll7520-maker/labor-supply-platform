# STEP 10.8B — Host Integration Wiring

Baseline:
`BUILD-130_STEP-10.8A_HOST_PROJECT_SCAFFOLD.zip`

## Purpose

Confirm the new Host Project Scaffold has an explicit composition point for
the already-approved App Shell and existing integration boundary.

## Scope

- Android `MainActivity` keeps ownership of `AndroidAppShell`.
- Android exposes the existing request/surface callbacks without implementing
  new Bridge or Floating Surface logic.
- iOS `AppDelegate` exposes the official composition point for injecting the
  existing `IOSAppShell` and integration boundary.

## Explicit boundaries

No Bridge Protocol change.
No Web Bridge change.
No Native Listener change.
No Floating Host change.
No Content duplication.
No Business Logic.
No local database.
No new API.
No new utility file.

## Runtime status

This step validates host-level wiring points statically. It does not claim
device/emulator runtime execution.

Status: IMPLEMENTED — READY FOR REVIEW
