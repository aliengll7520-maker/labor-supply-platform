# BUILD-129 — Recovery Closure Decision → Recovery Orchestrator Delegation

Baseline: BUILD-128 Final.

## Purpose
Create an explicit delegation boundary from BUILD-128 recovery closure decisions to the Recovery Orchestrator, without executing recovery work inside BUILD-129.

## Ownership
- BUILD-128: produces CLOSED or CONTINUE_RECOVERY.
- BUILD-129: delegates the decision only.
- Recovery Orchestrator: single owner of subsequent recovery handling.
- BUILD-100: retry timing.
- BUILD-109: retry execution.
- Lifecycle Controller: lifecycle transition execution.

## Rules
1. CLOSED is delegated as a terminal/no-recovery decision.
2. CONTINUE_RECOVERY is delegated to the Recovery Orchestrator.
3. BUILD-129 never performs recovery work.
4. BUILD-129 never retries.
5. BUILD-129 never schedules retry.
6. BUILD-129 never calculates retry timing.
7. BUILD-129 never executes retry.
8. BUILD-129 never mutates lifecycle state.
9. BUILD-129 never rolls back committed state.
10. operationId, eventId and attempt are preserved unchanged.
11. Closure decision and confirmation metadata are preserved unchanged.
12. No HTTP is performed.
13. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
14. No BUILD-129 database migration.

## Provenance Clarification
The baseline may contain an inherited file named `65_BUILD_129_MEDIA_UPLOAD_PIPELINE.sql`.
This file is a pre-existing baseline artifact inherited unchanged from the previous baseline.
BUILD-129 does not create, modify, or add any database migration.
Therefore the presence of that inherited file is not a BUILD-129 database change.
