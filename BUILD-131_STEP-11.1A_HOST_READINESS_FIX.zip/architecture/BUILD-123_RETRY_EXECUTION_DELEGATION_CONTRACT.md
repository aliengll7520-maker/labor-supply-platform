# BUILD-123 — Retry Timing → Retry Execution Delegation Contract

Baseline: BUILD-122 Final.

## Purpose
Create an explicit boundary that transfers an already-approved retry timing result to the existing BUILD-109 retry execution owner.

## Ownership
- BUILD-100: single owner of retry timing/scheduling.
- BUILD-123: execution-context delegation only.
- BUILD-109: single owner of retry execution.

## Rules
1. BUILD-123 accepts only a timing-approved retry execution context.
2. BUILD-123 does not calculate retry timing.
3. BUILD-123 does not schedule retry.
4. BUILD-123 does not execute retry.
5. BUILD-123 delegates execution ownership to BUILD-109.
6. operationId, eventId, attempt and recovery context are preserved unchanged.
7. Timing metadata is preserved unchanged.
8. No HTTP is performed by this boundary.
9. No lifecycle state is mutated by this boundary.
10. No Token, credential, Idempotency-Key, HTTP body or secret header enters the boundary.
11. BUILD-109 remains the single owner of retry execution.
12. No BUILD-123 database migration.
