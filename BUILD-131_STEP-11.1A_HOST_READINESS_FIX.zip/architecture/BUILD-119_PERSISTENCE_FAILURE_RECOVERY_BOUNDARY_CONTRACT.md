# BUILD-119 — Persistence Failure / Recovery Boundary Contract

Baseline: BUILD-118 Final.

## Purpose
Classify persistence failures and produce a recovery decision without introducing a new retry scheduler or retry executor.

## Ownership
- Persistence Adapter: reports persistence result/failure.
- Failure Classifier: classifies the failure.
- Recovery Decision Boundary: maps classification to a decision.
- BUILD-100: retry timing/scheduling.
- BUILD-109: retry execution.
- Operation Coordinator: orchestration.
- Lifecycle Controller: lifecycle state.

## Failure classes
TRANSIENT
PERMANENT
UNKNOWN

## Decisions
RETRY_ELIGIBLE
TERMINAL
ESCALATE

## Rules
1. A persistence failure never rolls back an already committed lifecycle transition.
2. Classification does not perform retry.
3. Recovery decision does not schedule retry.
4. Recovery decision does not execute retry.
5. RETRY_ELIGIBLE is a decision only; timing remains BUILD-100.
6. Retry execution remains BUILD-109.
7. PERMANENT maps to TERMINAL.
8. UNKNOWN maps to ESCALATE unless explicitly classified by policy.
9. No Token, credential, Idempotency-Key, HTTP body or secret header enters classification.
10. No HTTP is performed by the boundary.
11. No lifecycle state is mutated by the boundary.
12. BUILD-119 introduces no database migration.
