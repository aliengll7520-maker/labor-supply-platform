# BUILD-113 — Operation Coordinator Integration Contract

Baseline: BUILD-112 Final.

## Purpose

Integrate operation lifecycle with the existing recovery loop without taking ownership from existing components.

## Ownership

- Operation Coordinator: coordinates lifecycle and recovery handoffs for one operation.
- Operation Lifecycle Controller: owns lifecycle state transitions.
- Recovery Loop Controller: consumes normalized results and closes recovery-loop transitions.
- Recovery Orchestrator: classifies recovery.
- BUILD-100: owns retry timing/backoff/jitter.
- BUILD-109: executes one released retry.
- API Client: owns HTTP.
- Session Manager: owns authentication.

## Hard rules

1. One immutable operationId is carried through the complete flow.
2. Lifecycle state is updated before a retry/network/auth handoff is exposed.
3. Cancellation is checked before executing a released retry.
4. A closed operation cannot be resurrected by a late result.
5. Stale lifecycle versions are rejected.
6. Mutation Idempotency-Key remains unchanged.
7. Coordinator never sends HTTP.
8. Coordinator never refreshes tokens.
9. Coordinator never calculates retry timing.
10. Coordinator never executes retry itself; it delegates to BUILD-109.
11. A retry failure returns to the recovery path through normalized result handling.
12. SUCCESS, TERMINAL and CANCELLED end the logical operation.


## Host request boundary

The original ApiRequest is supplied explicitly to `consumeResult`.
The coordinator does not invent, cache, or retrieve an HTTP request from hidden state.
